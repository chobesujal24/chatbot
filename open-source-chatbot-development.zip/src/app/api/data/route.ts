import { db } from "@/db";
import {
  agents,
  conversations,
  memories,
  messageFeedback,
  messages,
  promptTemplates,
  sharedLinks,
  tasks,
} from "@/db/schema";
import { asc, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, route } from "@/lib/http";
import { seedAgents } from "@/lib/workspace";
import { toAgent, toMemory, toSummary, toTask, toTemplate, toMessage } from "@/lib/data";

export const dynamic = "force-dynamic";

/** GDPR-style full export of everything the workspace owns. */
export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "export", limit: 10, windowMs: 60_000 },
  });
  const [convs, allMessages, ags, mems, tks, tmpls] = await Promise.all([
    db.select().from(conversations).where(eq(conversations.workspaceId, ws)),
    db.select().from(messages).where(eq(messages.workspaceId, ws)).orderBy(asc(messages.createdAt)),
    db.select().from(agents).where(eq(agents.workspaceId, ws)),
    db.select().from(memories).where(eq(memories.workspaceId, ws)),
    db.select().from(tasks).where(eq(tasks.workspaceId, ws)),
    db.select().from(promptTemplates).where(eq(promptTemplates.workspaceId, ws)),
  ]);
  return NextResponse.json(
    {
      exportedAt: new Date().toISOString(),
      conversations: convs.map(toSummary),
      messages: allMessages.map(toMessage),
      agents: ags.map(toAgent),
      memories: mems.map(toMemory),
      tasks: tks.map(toTask),
      templates: tmpls.map(toTemplate),
    },
    { headers: noStore },
  );
});

/** Irreversibly removes all workspace data, then restores the default agents. */
export const DELETE = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "purge", limit: 3, windowMs: 60_000 },
  });
  const convIds = (
    await db
      .select({ id: conversations.id })
      .from(conversations)
      .where(eq(conversations.workspaceId, ws))
  ).map((r) => r.id);

  await db.delete(messageFeedback).where(eq(messageFeedback.workspaceId, ws));
  await db.delete(messages).where(eq(messages.workspaceId, ws));
  await db.delete(sharedLinks).where(eq(sharedLinks.workspaceId, ws));
  if (convIds.length > 0) {
    await db.delete(conversations).where(inArray(conversations.id, convIds));
  }
  await db.delete(tasks).where(eq(tasks.workspaceId, ws));
  await db.delete(memories).where(eq(memories.workspaceId, ws));
  await db.delete(promptTemplates).where(eq(promptTemplates.workspaceId, ws));
  await db.delete(agents).where(eq(agents.workspaceId, ws));
  await seedAgents(ws);
  return NextResponse.json({ ok: true });
});
