import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { credentialSecret, listCredentials } from "@/lib/credentials";
import { findProvider } from "@/lib/providers";
import { credentialTestSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

/** Verifies a stored credential by making the cheapest possible authenticated call. */
export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "credential-test", limit: 30, windowMs: 60_000 },
  });
  const { provider } = await parseBody(request, credentialTestSchema);
  const preset = findProvider(provider);
  if (!preset) {
    return NextResponse.json(
      { error: { code: "unknown_provider", message: `Unknown provider "${provider}".` } },
      { status: 400 },
    );
  }

  const stored = await credentialSecret(ws, provider);
  const secret = stored?.secret ?? "";
  const baseURL = stored?.baseURL || preset.baseURL;
  if (!secret && preset.requiresKey) {
    return NextResponse.json({
      ok: false,
      provider,
      message: "No API key stored for this provider yet.",
    });
  }

  const started = Date.now();
  try {
    if (preset.kind === "openai" || preset.kind === "openai-compatible") {
      const url = `${baseURL.replace(/\/$/, "")}${preset.modelsPath ?? "/models"}`;
      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${secret || "not-required"}`,
          "User-Agent": "Nova/1.0",
        },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message:
            res.status === 401 || res.status === 403
              ? "The API key was rejected."
              : `Provider returned HTTP ${res.status}.`,
        });
      }
      const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
      const count = payload?.data?.length ?? 0;
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: `Connected. ${count ? `${count} models available.` : "Endpoint reachable."}`,
      });
    }

    if (preset.kind === "anthropic") {
      const res = await fetch(`${baseURL.replace(/\/$/, "")}/models`, {
        headers: { "x-api-key": secret, "anthropic-version": "2023-06-01" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message: res.status === 401 ? "The API key was rejected." : `HTTP ${res.status}.`,
        });
      }
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: "Connected. Anthropic API is reachable.",
      });
    }

    if (preset.kind === "google") {
      const url = `${baseURL.replace(/\/$/, "")}/models?key=${encodeURIComponent(secret)}`;
      const res = await fetch(url, {
        headers: { "User-Agent": "Nova/1.0" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message: res.status === 400 || res.status === 403 ? "The API key was rejected." : `HTTP ${res.status}.`,
        });
      }
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: "Connected. Gemini API is reachable.",
      });
    }

    // Search / reader providers: a minimal authenticated search verifies the key.
    const url =
      preset.id === "brave"
        ? `${baseURL.replace(/\/$/, "")}/web/search?q=nova&count=1`
        : preset.id === "serpapi"
          ? `${baseURL.replace(/\/$/, "")}/search.json?q=nova&api_key=${encodeURIComponent(secret)}`
          : preset.id === "jina-search"
            ? `${baseURL.replace(/\/$/, "")}/nova`
            : preset.id === "you"
              ? `${baseURL.replace(/\/$/, "")}/search`
              : `${baseURL.replace(/\/$/, "")}/search`;

    const res = await fetch(url, {
      method: preset.id === "tavily" || preset.id === "firecrawl" || preset.id === "exa" || preset.id === "serper" || preset.id === "you" ? "POST" : "GET",
      headers: {
        Authorization: `Bearer ${secret}`,
        "x-api-key": secret,
        "X-Subscription-Token": secret,
        Accept: "application/json",
        "Content-Type": "application/json",
        "User-Agent": "Nova/1.0",
        ...(preset.id === "tavily" || preset.id === "firecrawl" || preset.id === "exa" || preset.id === "serper" || preset.id === "you"
          ? { body: JSON.stringify({ query: "nova", max_results: 1, limit: 1, numResults: 1, num: 1 }) }
          : {}),
      },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) {
      return NextResponse.json({
        ok: false,
        provider,
        status: res.status,
        message:
          res.status === 401 || res.status === 403 || res.status === 402
            ? "The API key was rejected or has no credit."
            : `Provider returned HTTP ${res.status}.`,
      });
    }
    return NextResponse.json({
      ok: true,
      provider,
      latencyMs: Date.now() - started,
      message: "Connected. The provider accepted the key.",
    });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      provider,
      message: error instanceof Error ? error.message : "Connection failed.",
    });
  }
});

/** Lists the model ids a provider exposes, using the stored key. */
export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const url = new URL(request.url);
  const provider = url.searchParams.get("provider") ?? "";
  const preset = findProvider(provider);
  if (!preset) {
    return NextResponse.json({ error: { code: "unknown_provider", message: "Unknown provider." } }, { status: 400 });
  }
  const stored = await credentialSecret(ws, provider);
  const secret = stored?.secret ?? "";
  const baseURL = stored?.baseURL || preset.baseURL;
  if (!baseURL) {
    return NextResponse.json({ models: preset.models, source: "preset" });
  }
  try {
    const res = await fetch(`${baseURL.replace(/\/$/, "")}${preset.modelsPath ?? "/models"}`, {
      headers: {
        Authorization: `Bearer ${secret || "not-required"}`,
        "User-Agent": "Nova/1.0",
      },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) {
      return NextResponse.json({ models: preset.models, source: "preset" });
    }
    const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
    const models = (payload?.data ?? [])
      .map((m) => m.id)
      .filter((id): id is string => Boolean(id))
      .sort();
    return NextResponse.json({
      models: models.length ? models : preset.models,
      source: models.length ? "provider" : "preset",
    });
  } catch {
    return NextResponse.json({ models: preset.models, source: "preset" });
  }
});

export { listCredentials };
