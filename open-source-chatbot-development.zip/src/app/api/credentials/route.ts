import { db } from "@/db";
import { credentials } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { deleteCredential, listCredentials, saveCredential, summarize } from "@/lib/credentials";
import { credentialInputSchema } from "@/lib/validation";
import { findProvider } from "@/lib/providers";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const rows = await listCredentials(ws);
  const stamps = await db
    .select({ id: credentials.id, updatedAt: credentials.updatedAt })
    .from(credentials)
    .where(eq(credentials.workspaceId, ws));
  const stampMap = new Map(stamps.map((s) => [s.id, s.updatedAt]));
  return NextResponse.json({
    credentials: rows.map((r) => summarize(r, stampMap.get(r.id) ?? new Date())),
  });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "credentials", limit: 40, windowMs: 60_000 },
  });
  const body = await parseBody(request, credentialInputSchema);
  const preset = findProvider(body.provider);
  if (!preset) {
    return NextResponse.json(
      { error: { code: "unknown_provider", message: `Unknown provider "${body.provider}".` } },
      { status: 400 },
    );
  }
  const row = await saveCredential(ws, {
    provider: body.provider,
    kind: body.kind ?? preset.credentialKind,
    label: body.label,
    secret: body.secret,
    baseURL: body.baseURL,
    options: body.options,
    enabled: body.enabled,
    isActive: body.isActive,
  });
  return NextResponse.json({ credential: summarize(row, new Date()) });
});

export const DELETE = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const url = new URL(request.url);
  const id = url.searchParams.get("id");
  if (!id) {
    return NextResponse.json(
      { error: { code: "missing_id", message: "id is required." } },
      { status: 400 },
    );
  }
  const removed = await deleteCredential(ws, id);
  if (!removed) {
    return NextResponse.json(
      { error: { code: "not_found", message: "Credential not found." } },
      { status: 404 },
    );
  }
  return NextResponse.json({ ok: true });
});
