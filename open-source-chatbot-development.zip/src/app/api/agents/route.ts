import { db } from "@/db";
import { agents } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { toAgent } from "@/lib/data";
import { agentSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const rows = await db
    .select()
    .from(agents)
    .where(eq(agents.workspaceId, ws))
    .orderBy(asc(agents.isDefault), asc(agents.name));
  return NextResponse.json({ agents: rows.map(toAgent) });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, agentSchema);
  const [row] = await db
    .insert(agents)
    .values({ ...body, workspaceId: ws, model: body.model?.trim() || null })
    .returning();
  return NextResponse.json({ agent: toAgent(row) });
});
