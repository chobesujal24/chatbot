import { db } from "@/db";
import {
  agents,
  conversations,
  messages,
  skills as skillsTable,
  type ContextMeta,
  type ToolCallRecord,
} from "@/db/schema";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { generateText, isStepCount, streamText, type ModelMessage } from "ai";
import { deriveTitle, offlineReply } from "@/lib/offline";
import { resolveModel } from "@/lib/model";
import { buildTools } from "@/lib/tools";
import { listCredentials } from "@/lib/credentials";
import { getPreferences } from "@/lib/preferences";
import { guard, parseBody, route } from "@/lib/http";
import { ownedConversation } from "@/lib/data";
import { chatSchema } from "@/lib/validation";
import { renderSkillIndex, seedSkills, selectSkills } from "@/lib/skills";
import { loadSkillInstructions, pickAutoLoadSkill } from "@/lib/skills-server";
import { extractCandidates, recall, remember, renderMemoryBlock } from "@/lib/memory";
import {
  buildBreakdown,
  compactionTargets,
  estimateTokens,
  extractiveSummary,
  planHistory,
  renderSummaryBlock,
  resolveContextSettings,
  shouldCompact,
  type ContextBreakdown,
} from "@/lib/context";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

function withAttachments(content: string, files: { name: string; content: string }[]): string {
  if (files.length === 0) return content;
  return (
    content +
    "\n\n" +
    files
      .map((f) => `--- Attached file: ${f.name} ---\n${f.content}\n--- End of ${f.name} ---`)
      .join("\n\n")
  );
}

async function* offlineChunks(text: string) {
  yield JSON.stringify({ type: "start", messageId: "offline" });
  yield JSON.stringify({ type: "text-start", id: "t1" });
  const pieces = text.match(/\S+\s*|\s+/g) ?? [text];
  let buffer = "";
  for (const piece of pieces) {
    buffer += piece;
    if (buffer.length >= 9) {
      yield JSON.stringify({ type: "text-delta", id: "t1", delta: buffer });
      buffer = "";
      await new Promise((resolve) => setTimeout(resolve, 12));
    }
  }
  if (buffer) yield JSON.stringify({ type: "text-delta", id: "t1", delta: buffer });
  yield JSON.stringify({ type: "text-end", id: "t1" });
  yield JSON.stringify({ type: "finish", finishReason: "stop" });
}

const EXTRACTION_PROMPT = `You maintain a long-term memory store. From the user's latest message, extract only durable, reusable facts: preferences, corrections, stable identity or project facts, recurring workflows. Ignore one-off questions and anything already implied.
Return a JSON array (max 3 items) of objects: {"value": string <=300 chars, "type": "preference"|"fact"|"entity"|"procedure"|"event", "importance": number 0-1}. Return [] when nothing is worth storing. Output JSON only.`;

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "chat", limit: 40, windowMs: 60_000 },
  });
  const body = await parseBody(request, chatSchema);
  const settings = body.settings;
  const mode = body.mode;
  const startedAt = Date.now();

  const [credentials, preferences] = await Promise.all([
    listCredentials(ws),
    getPreferences(ws),
  ]);
  const modelCredential =
    credentials.find((c) => c.kind === "model" && c.isActive && c.enabled) ?? null;
  await seedSkills(ws);

  /* ── Agent ─────────────────────────────────────────────────────────────── */
  let agent: typeof agents.$inferSelect | null = null;
  if (body.agentId) {
    const [found] = await db
      .select()
      .from(agents)
      .where(and(eq(agents.id, body.agentId), eq(agents.workspaceId, ws)))
      .limit(1);
    agent = found ?? null;
  }
  if (!agent) {
    const rows = await db.select().from(agents).where(eq(agents.workspaceId, ws)).limit(20);
    agent = rows.find((a) => a.isDefault) ?? rows[0] ?? null;
  }

  const effectiveSystem = agent?.systemPrompt || settings.systemPrompt || "";
  const effectiveModel = agent?.model || settings.model;
  const effectiveTemperature = agent?.temperature ?? settings.temperature;
  const maxSteps = agent?.maxSteps ?? 5;
  const memoryMode = agent?.memoryMode ?? "auto";
  const agentToolNames = agent?.tools ?? [];
  const effectiveTools = Array.from(new Set([...agentToolNames]));

  let conversationId = body.conversationId ?? null;

  /* ── Persist the turn ──────────────────────────────────────────────────── */
  if (mode === "send") {
    const content = body.content!.trim();
    if (conversationId) {
      await ownedConversation(ws, conversationId);
      if (agent) {
        await db
          .update(conversations)
          .set({ agentId: agent.id })
          .where(eq(conversations.id, conversationId));
      }
    } else {
      const [created] = await db
        .insert(conversations)
        .values({
          workspaceId: ws,
          title: deriveTitle(content),
          model: effectiveModel,
          agentId: agent?.id ?? null,
        })
        .returning();
      conversationId = created.id;
    }
    await db.insert(messages).values({
      workspaceId: ws,
      conversationId: conversationId!,
      role: "user",
      content: withAttachments(content, body.attachments),
      attachments: body.attachments.map((a) => ({ name: a.name, size: a.content.length })),
      seq: 0,
    });
  } else {
    await ownedConversation(ws, conversationId!);
    const history = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId!))
      .orderBy(asc(messages.createdAt));
    let toDelete: string[] = [];
    if (mode === "regenerate") {
      const lastUserIndex = history.map((m) => m.role).lastIndexOf("user");
      toDelete = history.slice(lastUserIndex + 1).map((m) => m.id);
    } else {
      const index = history.findIndex((m) => m.id === body.editMessageId);
      if (index < 0 || history[index].role !== "user") {
        return new Response("Message not found", { status: 404 });
      }
      await db.update(messages).set({ content: body.editContent! }).where(eq(messages.id, body.editMessageId!));
      toDelete = history.slice(index + 1).map((m) => m.id);
    }
    if (toDelete.length > 0) await db.delete(messages).where(inArray(messages.id, toDelete));
  }

  const stopSequences = (preferences.stopSequences ?? "")
    .split(",")
    .map((s) => s.replace(/\\n/g, "\n").trim())
    .filter(Boolean)
    .slice(0, 4);

  const cid = conversationId!;
  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, cid))
    .limit(1);

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, cid))
    .orderBy(asc(messages.createdAt))
    .limit(400);
  const lastUserMessage = [...history].reverse().find((m) => m.role === "user");
  const prompt = lastUserMessage?.content ?? "";

  /* ── Context settings, skills, memory ──────────────────────────────────── */
  const contextSettings = resolveContextSettings(
    preferences as unknown as Record<string, unknown>,
    conversation?.context,
  );
  const allSkills = await db.select().from(skillsTable).where(eq(skillsTable.workspaceId, ws));
  const skills = contextSettings.includeSkills ? selectSkills(allSkills, agent?.skills) : [];
  const skillsIndex = renderSkillIndex(skills).replace(
    "Do not load more than two skills per turn.",
    `Do not load more than ${preferences.maxSkillsPerTurn} skill${preferences.maxSkillsPerTurn === 1 ? "" : "s"} per turn.`,
  );

  // Skills need the loader tool; add it implicitly when any skill is offered.
  const toolNames = new Set(effectiveTools);
  if (skills.length > 0) toolNames.add("loadSkill");
  if (memoryMode !== "off") {
    toolNames.add("remember");
    toolNames.add("recall");
  }
  if (memoryMode === "auto") toolNames.add("forgetMemory");

  const memoryEnabled = contextSettings.injectMemories && memoryMode !== "off";
  const recalled = memoryEnabled
    ? await recall(ws, prompt, contextSettings.memoryLimit, {
        minScore: preferences.memoryMinScore,
        halfLifeDays: preferences.memoryHalfLifeDays,
        reinforce: preferences.memoryReinforce,
      })
    : [];
  const memoryBlock = renderMemoryBlock(recalled);

  /* ── History windowing + optional compaction ───────────────────────────── */
  const plan = planHistory(history, contextSettings, conversation?.summarizedCount ?? 0);
  // Progressive disclosure shortcut: attach one clearly-matching skill up front.
  let autoSkillBlock = "";
  const autoSkillName: string[] = [];
  if (preferences.autoLoadSkill && skills.length > 0 && prompt.trim()) {
    const candidate = pickAutoLoadSkill(skills, prompt, preferences.skillMatchThreshold);
    if (candidate) {
      const loaded = await loadSkillInstructions(ws, candidate.name);
      if (loaded) {
        autoSkillBlock = `# Active skill: ${loaded.name}\nFollow these instructions for this turn.\n\n${loaded.instructions.slice(0, 9000)}`;
        autoSkillName.push(loaded.name);
      }
    }
  }

  const systemBase = [effectiveSystem, skillsIndex, memoryBlock, autoSkillBlock].filter(Boolean).join("\n\n");
  const summaryBlock = conversation?.summary
    ? renderSummaryBlock(conversation.summary, conversation.summarizedCount)
    : null;

  let breakdown: ContextBreakdown = buildBreakdown({
    system: systemBase,
    history: plan.included.map((m) => ({ role: m.role, content: m.content })),
    summary: summaryBlock ?? undefined,
    settings: contextSettings,
  });

  let effectiveIncluded = plan.included;
  let summarizedCount = conversation?.summarizedCount ?? 0;
  let compactedThisTurn = false;

  // Compaction serves two purposes: relieve pressure near the window limit, and
  // make sure turns that history-depth trimming would silently drop are folded
  // into the durable summary instead of just disappearing.
  // Batch the fold so a long thread does not trigger a summarisation call on
  // every single turn.
  const mustFoldDropped = plan.dropped.length >= 2;
  if ((mustFoldDropped || shouldCompact(breakdown, contextSettings)) && (mustFoldDropped || effectiveIncluded.length > 6)) {
    const fixed =
      estimateTokens(systemBase) + (summaryBlock ? estimateTokens(summaryBlock) : 0);
    const drop = mustFoldDropped
      ? plan.dropped.length
      : compactionTargets(
          effectiveIncluded.map((m) => ({ content: m.content })),
          contextSettings,
          fixed,
        );
    if (drop > 0) {
      const toFold = (mustFoldDropped ? plan.dropped : effectiveIncluded.slice(0, drop)).slice(-40);
      const combined = [...(conversation?.summary ? [{ role: "system", content: conversation.summary }] : []), ...toFold.map((m) => ({ role: m.role, content: m.content }))];
      let summaryText = extractiveSummary(combined);
      // A connected model produces a far better summary; fall back on any error.
      const resolutionForSummary = await resolveModel(
        { ...settings, model: effectiveModel },
        modelCredential,
      );
      if (!resolutionForSummary.model) {
        // offline: no summariser
      } else {
        try {
          const { text } = await generateText({
            model: resolutionForSummary.model,
            system:
              "Compress the conversation notes below into durable bullet points. Keep every name, number, file path, decision and correction. Drop pleasantries. Max 220 words, bullets only.",
            prompt: combined
              .map((m) => `${m.role}: ${m.content.slice(0, 1500)}`)
              .join("\n")
              .slice(0, 24000),
            maxOutputTokens: 512,
          });
          if (text.trim().length > 40) summaryText = text.trim();
        } catch {
          /* keep the extractive summary */
        }
      }
      if (summaryText) {
        summarizedCount += drop;
        await db
          .update(conversations)
          .set({ summary: summaryText.slice(0, 8000), summarizedCount })
          .where(eq(conversations.id, cid));
        effectiveIncluded = effectiveIncluded.slice(drop);
        breakdown = buildBreakdown({
          system: systemBase,
          history: effectiveIncluded.map((m) => ({ role: m.role, content: m.content })),
          summary: renderSummaryBlock(summaryText, summarizedCount),
          settings: contextSettings,
        });
        compactedThisTurn = true;
      }
    }
  }

  /* ── Model resolution ──────────────────────────────────────────────────── */
  const resolution = await resolveModel(
    { ...settings, model: effectiveModel },
    modelCredential,
  );
  const isOffline = settings.provider === "offline" || resolution.error != null || !resolution.model;
  const modelLabel = isOffline ? "offline-demo" : resolution.label;

  const contextMeta: ContextMeta = {
    injectedMemoryIds: recalled.map((r) => r.id),
    usedSkillNames: autoSkillName,
    historyMessages: effectiveIncluded.length,
    summarizedMessages: summarizedCount,
    estimatedTokens: breakdown.promptTokens,
    compacted: compactedThisTurn,
  };

  const encoder = new TextEncoder();
  let full = "";
  let saved = false;
  let streamError = "";
  let providerError = "";

  const persist = async (
    text: string,
    toolCalls: ToolCallRecord[],
    usage: { inputTokens: number; outputTokens: number; totalTokens: number } | null,
    stopped: boolean,
  ) => {
    if (saved) return;
    saved = true;
    const base = text.trim() || (stopped ? "*Generation stopped.*" : "*No response generated.*");
    const content = stopped && text.trim() ? `${base}\n\n*Generation stopped.*` : base;
    const usedSkills = Array.from(
      new Set(
        toolCalls
          .filter((c) => c.name === "loadSkill" && c.status === "done")
          .map((c) => String((c.input as { name?: string } | null)?.name ?? ""))
          .filter(Boolean),
      ),
    );
    try {
      const [row] = await db.insert(messages).values({
        workspaceId: ws,
        conversationId: cid,
        role: "assistant",
        content,
        model: modelLabel,
        toolCalls: toolCalls.length > 0 ? toolCalls : null,
        usage: usage
          ? { ...usage, durationMs: Date.now() - startedAt }
          : { inputTokens: 0, outputTokens: 0, totalTokens: 0, durationMs: Date.now() - startedAt },
        contextMeta: { ...contextMeta, usedSkillNames: usedSkills },
        seq: history.length + 1,
      }).returning({ id: messages.id });

      await db
        .update(conversations)
        .set({
          updatedAt: new Date(),
          model: modelLabel,
          lastSequence: history.length + 1,
          ...(mode === "edit" && prompt ? { title: deriveTitle(prompt) } : {}),
        })
        .where(eq(conversations.id, cid));

      // Memory write-back: heuristic always, model-assisted when connected.
      if (memoryMode !== "off") {
        const candidates = extractCandidates(prompt);
        if (!isOffline && row) {
          try {
            const { text: extraction } = await generateText({
              model: resolution.model!,
              system: EXTRACTION_PROMPT,
              prompt: `Latest user message:\n"""\n${prompt.slice(0, 4000)}\n"""`,
              maxOutputTokens: 300,
            });
            const json = /\[[\s\S]*\]/.exec(extraction)?.[0];
            if (json) {
              const parsed = JSON.parse(json) as Array<{
                value?: string;
                type?: string;
                importance?: number;
              }>;
              for (const item of parsed.slice(0, 3)) {
                if (!item?.value) continue;
                candidates.push({
                  value: String(item.value).slice(0, 400),
                  type: (["preference", "fact", "entity", "procedure", "event"].includes(String(item.type))
                    ? item.type
                    : "fact") as "fact",
                  importance: typeof item.importance === "number" ? item.importance : 0.6,
                  confidence: 0.7,
                  origin: "extracted",
                });
              }
            }
          } catch {
            /* heuristic candidates are still stored */
          }
        }
        for (const candidate of candidates) {
          await remember(ws, candidate);
        }
      }
    } catch (error) {
      console.error("Failed to persist assistant message", error);
    }
  };

  let stream: ReadableStream<Uint8Array>;

  if (isOffline) {
    const text = resolution.error
      ? `**Model connection failed.** ${resolution.error}\n\nPick a provider in Settings → Providers, or stay in offline demo mode. No request was sent anywhere.`
      : offlineReply(prompt);
    streamError = resolution.error ?? "";
    stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        try {
          for await (const line of offlineChunks(text)) {
            if (line.includes('"text-delta"')) {
              full += (JSON.parse(line) as { delta: string }).delta;
            }
            controller.enqueue(encoder.encode(`${line}\n`));
          }
        } catch {
          /* ignore */
        } finally {
          await persist(full, [], null, false);
          try {
            controller.close();
          } catch {
            /* closed */
          }
        }
      },
      cancel() {
        void persist(full, [], null, true);
      },
    });
  } else {
    const modelMessages: ModelMessage[] = [
      ...(summaryBlock
        ? ([{ role: "system", content: summaryBlock } as ModelMessage])
        : []),
      ...effectiveIncluded
        .filter((m) => m.id !== lastUserMessage?.id)
        .map((m) =>
          m.role === "user"
            ? ({ role: "user", content: m.content } as ModelMessage)
            : ({ role: "assistant", content: m.content } as ModelMessage),
        ),
      ...(lastUserMessage
        ? ([{ role: "user", content: lastUserMessage.content } as ModelMessage])
        : []),
    ];

    const result = streamText({
      model: resolution.model!,
      system: systemBase || undefined,
      messages: modelMessages,
      tools: buildTools(Array.from(toolNames), ws),
      stopWhen: isStepCount(maxSteps),
      temperature: effectiveTemperature,
      topP: preferences.topP,
      presencePenalty: preferences.presencePenalty,
      frequencyPenalty: preferences.frequencyPenalty,
      maxOutputTokens: Math.min(settings.maxTokens, contextSettings.outputBudget),
      maxRetries: preferences.maxRetries,
      ...(stopSequences.length ? { stopWords: stopSequences } : {}),
      abortSignal: request.signal,
      onError: ({ error }) => console.error("streamText error", error),
    });

    const uiStream = result.toUIMessageStream({
      onError: (error) => {
        const raw = error instanceof Error ? error.message : String(error);
        return raw.replace(/\s+/g, " ").slice(0, 300) || "The model request failed.";
      },
    });

    stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const reader = uiStream.getReader();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = value as { type?: string; delta?: string; errorText?: string };
            if (chunk.type === "text-delta" && chunk.delta) full += chunk.delta;
            if (chunk.type === "error" && chunk.errorText) providerError = chunk.errorText;
            controller.enqueue(encoder.encode(`${JSON.stringify(value)}\n`));
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : "The model request failed.";
          streamError = message;
          const note = `\n\n> **Provider error:** ${message}`;
          full += note;
          try {
            controller.enqueue(
              encoder.encode(`${JSON.stringify({ type: "text-delta", id: "err", delta: note })}\n`),
            );
          } catch {
            /* closed */
          }
        } finally {
          let toolCalls: ToolCallRecord[] = [];
          let usage: { inputTokens: number; outputTokens: number; totalTokens: number } | null = null;
          try {
            const [text, steps, totalUsage] = await Promise.all([
              result.text,
              result.steps,
              result.totalUsage,
            ]);
            if (text) full = text;
            toolCalls = steps.flatMap((step) =>
              step.toolCalls.map((call) => {
                const res = step.toolResults.find((r) => r.toolCallId === call.toolCallId);
                const failed = res && "error" in (res as object);
                return {
                  id: call.toolCallId,
                  name: call.toolName,
                  input: call.input,
                  output: res?.output ?? null,
                  status: failed ? ("error" as const) : ("done" as const),
                };
              }),
            );
            usage = {
              inputTokens: totalUsage.inputTokens ?? 0,
              outputTokens: totalUsage.outputTokens ?? 0,
              totalTokens: totalUsage.totalTokens ?? 0,
            };
            // Prefer measured prompt tokens for the meter.
            if ((totalUsage.inputTokens ?? 0) > 0) {
              breakdown = { ...breakdown, promptTokens: totalUsage.inputTokens ?? breakdown.promptTokens };
            }
          } catch (error) {
            console.error("Failed to collect stream result", error);
          }
          if (providerError && !full.trim()) {
            streamError = providerError;
            full = `> **Provider error:** ${providerError}\n\nCheck the model ID, API key and base URL in Settings → Providers.`;
          }
          await persist(full, toolCalls, usage, false);
          try {
            controller.close();
          } catch {
            /* closed */
          }
        }
      },
      cancel() {
        void persist(full, [], null, true);
      },
    });
  }

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
      "x-nova-conversation-id": cid,
      "x-nova-mode": isOffline ? "offline" : "model",
      "x-nova-model": modelLabel,
      "x-nova-agent": agent?.name ?? "",
      "x-nova-skills": String(skills.length),
      "x-nova-memories": String(recalled.length),
      "x-nova-context-tokens": String(breakdown.promptTokens),
      "x-nova-context-ratio": String(breakdown.ratio),
      "x-nova-compacted": compactedThisTurn ? "1" : "0",
      ...(streamError ? { "x-nova-error": encodeURIComponent(streamError) } : {}),
    },
  });
});
