import { db } from "@/db";
import {
  agents,
  conversations,
  memories,
  messageFeedback,
  promptTemplates,
  sharedLinks,
  skills as skillsTable,
  tasks,
} from "@/db/schema";
import { and, desc, eq, gt, isNull, or } from "drizzle-orm";
import { NextResponse } from "next/server";
import { ApiError, guard, noStore, route } from "@/lib/http";
import { bootstrapWorkspace, isAuthorized, passwordRequired } from "@/lib/workspace";
import { toAgent, toMemory, toSummary, toTask, toTemplate } from "@/lib/data";
import { listCredentials, summarize } from "@/lib/credentials";
import { getPreferences, normalizePreferences } from "@/lib/preferences";
import { seedSkills, toSkill } from "@/lib/skills";
import { hasServerKey } from "@/lib/model-server";

export const dynamic = "force-dynamic";

/**
 * Single entry point for the app shell: mints the workspace if needed and
 * returns everything required for a first paint in one round trip.
 */
export const GET = route(async (request) => {
  const rateLimited = await guard(request, {
    public: true,
    rateLimit: { bucket: "bootstrap", limit: 90, windowMs: 60_000 },
  });
  void rateLimited;
  if (!(await isAuthorized())) {
    throw new ApiError(401, "authentication_required", "A passcode is required.");
  }
  const { id, created } = await bootstrapWorkspace();

  const [
    convRows,
    agentRows,
    taskRows,
    memoryRows,
    templateRows,
    feedbackRows,
    credentialRows,
    skillRows,
    preferences,
    shareRows,
  ] = await Promise.all([
    db
      .select()
      .from(conversations)
      .where(eq(conversations.workspaceId, id))
      .orderBy(desc(conversations.pinned), desc(conversations.updatedAt))
      .limit(200),
    db.select().from(agents).where(eq(agents.workspaceId, id)),
    db
      .select()
      .from(tasks)
      .where(eq(tasks.workspaceId, id))
      .orderBy(desc(tasks.createdAt))
      .limit(200),
    db.select().from(memories).where(eq(memories.workspaceId, id)),
    db.select().from(promptTemplates).where(eq(promptTemplates.workspaceId, id)),
    db.select().from(messageFeedback).where(eq(messageFeedback.workspaceId, id)),
    listCredentials(id),
    seedSkills(id).then(() =>
      db.select().from(skillsTable).where(eq(skillsTable.workspaceId, id)),
    ),
    getPreferences(id),
    db
      .select({ id: sharedLinks.id })
      .from(sharedLinks)
      .where(
        and(
          eq(sharedLinks.workspaceId, id),
          or(isNull(sharedLinks.expiresAt), gt(sharedLinks.expiresAt, new Date())),
        ),
      ),
  ]);

  const serverKeys = {
    openai: hasServerKey("openai"),
    anthropic: hasServerKey("anthropic"),
    google: hasServerKey("google"),
  };
  const suggestedProvider = serverKeys.openai
    ? "openai"
    : serverKeys.anthropic
      ? "anthropic"
      : serverKeys.google
        ? "google"
        : "offline";

  return NextResponse.json(
    {
      workspace: { id, created },
      passwordRequired: passwordRequired(),
      serverKeys,
      suggestedProvider,
      preferences: normalizePreferences(preferences),
      credentials: credentialRows.map((c) => summarize(c, new Date())),
      conversations: convRows.map(toSummary),
      agents: agentRows.map(toAgent),
      skills: skillRows.map(toSkill),
      memories: memoryRows.map(toMemory),
      memoryStats: {
        total: memoryRows.length,
        enabled: memoryRows.filter((m) => m.enabled).length,
        recalled: memoryRows.reduce((n, m) => n + m.useCount, 0),
      },
      tasks: taskRows.map(toTask),
      templates: templateRows.map(toTemplate),
      feedback: Object.fromEntries(feedbackRows.map((f) => [f.messageId, f.rating])),
      shareCount: shareRows.length,
    },
    { headers: noStore },
  );
});
