import { db } from "@/db";
import { sharedLinks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { guard, noStore, route } from "@/lib/http";
import { ownedConversation, ownedSharedLink, toSharedLink } from "@/lib/data";
import { getPreferences } from "@/lib/preferences";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const GET = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  const link = await ownedSharedLink(ws, id);
  return NextResponse.json({ link: link ? toSharedLink(link) : null }, { headers: noStore });
});

export const POST = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  const existing = await ownedSharedLink(ws, id);
  if (existing) {
    return NextResponse.json({ link: toSharedLink(existing) });
  }
  const preferences = await getPreferences(ws);
  const token = randomBytes(18).toString("base64url");
  const days = preferences.shareExpiryDays;
  const expiresAt = days > 0 ? new Date(Date.now() + 1000 * 60 * 60 * 24 * days) : null;
  const [row] = await db
    .insert(sharedLinks)
    .values({ workspaceId: ws, conversationId: id, token, expiresAt })
    .returning();
  return NextResponse.json({ link: toSharedLink(row) });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  await db
    .delete(sharedLinks)
    .where(eq(sharedLinks.conversationId, id));
  return NextResponse.json({ ok: true });
});
