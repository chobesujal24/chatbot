import { db } from "@/db";
import { conversations, messages, skills as skillsTable } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, requireUuidParam, route } from "@/lib/http";
import { contextPatchSchema } from "@/lib/validation";
import { ownedConversation, toMessage } from "@/lib/data";
import { getPreferences } from "@/lib/preferences";
import { renderSkillIndex, seedSkills, selectSkills } from "@/lib/skills";
import { recall, renderMemoryBlock } from "@/lib/memory";
import {
  buildBreakdown,
  estimateTokens,
  planHistory,
  renderSummaryBlock,
  resolveContextSettings,
} from "@/lib/context";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

/** Preview the exact prompt composition for the next turn. */
export const GET = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const conversation = await ownedConversation(ws, id);
  const preferences = (await getPreferences(ws)) as unknown as Record<string, unknown>;
  const settings = resolveContextSettings(preferences, conversation.context);

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt))
    .limit(400);
  const lastUser = [...history].reverse().find((m) => m.role === "user");

  await seedSkills(ws);
  const allSkills = await db.select().from(skillsTable).where(eq(skillsTable.workspaceId, ws));
  const skillList = settings.includeSkills ? selectSkills(allSkills, null) : [];
  const memoryItems = settings.injectMemories
    ? await recall(ws, lastUser?.content ?? "", settings.memoryLimit, { minScore: 0.22 })
    : [];

  const plan = planHistory(history, settings, conversation.summarizedCount);
  const breakdown = buildBreakdown({
    system: conversation.agentId
      ? undefined
      : (preferences.systemPrompt as string | undefined),
    skillsIndex: renderSkillIndex(skillList),
    memoryBlock: renderMemoryBlock(memoryItems),
    summary: conversation.summary
      ? renderSummaryBlock(conversation.summary, conversation.summarizedCount)
      : undefined,
    history: plan.included.map((m) => ({ role: m.role, content: m.content })),
    settings,
    measuredPromptTokens: null,
  });

  return NextResponse.json(
    {
      settings,
      breakdown,
      injectedMemories: memoryItems,
      skills: skillList.map((s) => ({ name: s.name, description: s.description, emoji: s.emoji })),
      messageCount: history.length,
      includedCount: plan.included.length,
      droppedCount: history.length - plan.included.length,
      summarizedCount: conversation.summarizedCount,
      hasSummary: Boolean(conversation.summary),
      totalEstimatedTokens: history.reduce((sum, m) => sum + estimateTokens(m.content), 0),
    },
    { headers: noStore },
  );
});

/** Per-conversation overrides of the workspace context defaults. */
export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const conversation = await ownedConversation(ws, id);
  const body = await parseBody(request, contextPatchSchema);
  const merged = { ...(conversation.context ?? {}), ...body };
  const [row] = await db
    .update(conversations)
    .set({ context: merged, updatedAt: new Date() })
    .where(eq(conversations.id, id))
    .returning();
  return NextResponse.json({
    context: row.context,
    settings: resolveContextSettings(
      (await getPreferences(ws)) as unknown as Record<string, unknown>,
      row.context,
    ),
  });
});

/** Reset the conversation to workspace defaults and drop its summary. */
export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  await db
    .update(conversations)
    .set({ context: null, summary: null, summarizedCount: 0 })
    .where(eq(conversations.id, id));
  return NextResponse.json({ ok: true });
});

export { toMessage };
