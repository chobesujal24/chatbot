import { db } from "@/db";
import { messages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { ownedMessage } from "@/lib/data";
import { messagePatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedMessage(ws, id);
  const { content } = await parseBody(request, messagePatchSchema);
  await db.update(messages).set({ content }).where(eq(messages.id, id));
  return NextResponse.json({ ok: true });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedMessage(ws, id);
  await db.delete(messages).where(eq(messages.id, id));
  return NextResponse.json({ ok: true });
});
