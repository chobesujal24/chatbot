import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import {
  clearModelCredential,
  getModelCredential,
  setModelCredential,
} from "@/lib/workspace";
import { credentialSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

/** Only ever reports whether a key exists — the value never leaves the server. */
export const GET = route(async (request) => {
  await guard(request);
  const credential = await getModelCredential();
  return NextResponse.json({
    hasKey: Boolean(credential?.apiKey),
    baseURL: credential?.baseURL ?? "",
  });
});

export const POST = route(async (request) => {
  await guard(request, {
    rateLimit: { bucket: "credential", limit: 20, windowMs: 60_000 },
  });
  const body = await parseBody(request, credentialSchema);
  const existing = await getModelCredential();
  const apiKey = body.apiKey !== undefined ? body.apiKey.trim() : (existing?.apiKey ?? "");
  const baseURL = body.baseURL !== undefined ? body.baseURL.trim() : (existing?.baseURL ?? "");
  await setModelCredential(apiKey, baseURL);
  return NextResponse.json({ ok: true, hasKey: Boolean(apiKey), baseURL });
});

export const DELETE = route(async (request) => {
  await guard(request);
  await clearModelCredential();
  return NextResponse.json({ ok: true });
});
