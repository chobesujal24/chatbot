"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";
import {
  IconCalculator,
  IconCheck,
  IconChevronRight,
  IconClock,
  IconClose,
  IconGlobe,
  IconMemory,
  IconSearch,
  IconTasks,
  IconWrench,
  type IconProps,
} from "./icons";
import { TOOL_META } from "@/lib/tool-meta";
import { cn } from "@/lib/utils";

export interface ToolCallView {
  id: string;
  name: string;
  input: unknown;
  output: unknown;
  status: "running" | "done" | "error";
}

const ICONS: Record<string, React.ComponentType<IconProps>> = {
  calculator: IconCalculator,
  currentTime: IconClock,
  fetchUrl: IconGlobe,
  searchHistory: IconSearch,
  saveMemory: IconMemory,
  recallMemories: IconMemory,
  createTask: IconTasks,
  listTasks: IconTasks,
  completeTask: IconTasks,
};

const labelFor = (name: string) => TOOL_META.find((t) => t.name === name)?.label ?? name;

type Rec = Record<string, unknown>;
const asRec = (v: unknown): Rec => (v && typeof v === "object" ? (v as Rec) : {});

function describe(call: ToolCallView): string {
  const input = asRec(call.input);
  const output = asRec(call.output);
  switch (call.name) {
    case "calculator":
      return output.result !== undefined
        ? `${String(input.expression)} = ${String(output.result)}`
        : String(input.expression ?? "");
    case "currentTime":
      return String(output.formatted ?? "Reading the clock");
    case "fetchUrl":
      return String(input.url ?? "");
    case "searchHistory":
      return `“${String(input.query ?? "")}”${
        Array.isArray(output.results) ? ` · ${output.results.length} found` : ""
      }`;
    case "saveMemory":
      return String(input.key ?? "");
    case "recallMemories":
      return Array.isArray(output.memories) ? `${output.memories.length} memories` : "Reading memory";
    case "createTask":
      return String(input.title ?? "");
    case "listTasks":
      return Array.isArray(output.tasks) ? `${output.tasks.length} tasks` : "Listing tasks";
    case "completeTask":
      return String(output.title ?? input.id ?? "");
    default: {
      const first = Object.values(input)[0];
      return typeof first === "string" ? first : "";
    }
  }
}

function pretty(value: unknown): string {
  if (value === undefined || value === null) return "—";
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

export default function ToolCalls({ calls }: { calls: ToolCallView[] }) {
  const [manual, setManual] = useState<boolean | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  if (calls.length === 0) return null;

  const running = calls.some((c) => c.status === "running");
  const failed = calls.some((c) => c.status === "error");
  const open = manual ?? running;
  const names = Array.from(new Set(calls.map((c) => labelFor(c.name))));
  const summary = running
    ? "Working…"
    : `Used ${calls.length} tool${calls.length === 1 ? "" : "s"} · ${names.slice(0, 3).join(", ")}${
        names.length > 3 ? ` +${names.length - 3}` : ""
      }`;

  return (
    <div className="mb-3">
      <button
        type="button"
        onClick={() => setManual(!open)}
        aria-expanded={open}
        className="group inline-flex max-w-full items-center gap-2 rounded-full border bg-card/70 py-1.5 pl-3 pr-2.5 text-[13px] text-muted-foreground outline-none transition hover:border-foreground/20 hover:text-foreground"
      >
        {running ? (
          <Loader2 size={14} className="shrink-0 animate-spin text-brand" />
        ) : failed ? (
          <IconClose size={14} className="shrink-0 text-destructive" />
        ) : (
          <IconWrench size={14} className="shrink-0" />
        )}
        <span className="truncate">{summary}</span>
        <IconChevronRight
          size={14}
          className={cn("shrink-0 opacity-60 transition-transform", open && "rotate-90")}
        />
      </button>

      {open && (
        <ol className="animate-fade-in relative mt-3 space-y-1 pl-3">
          <span className="absolute bottom-3 left-[21px] top-3 w-px bg-border" aria-hidden />
          {calls.map((call) => {
            const Icon = ICONS[call.name] ?? IconWrench;
            const detail = detailId === call.id;
            return (
              <li key={call.id} className="relative">
                <button
                  type="button"
                  onClick={() => setDetailId(detail ? null : call.id)}
                  className="flex w-full items-center gap-3 rounded-lg py-1.5 pr-2 text-left outline-none transition hover:bg-accent/60"
                >
                  <span
                    className={cn(
                      "relative z-10 flex size-[19px] shrink-0 items-center justify-center rounded-full border bg-background",
                      call.status === "error" && "border-destructive/50 text-destructive",
                    )}
                  >
                    {call.status === "running" ? (
                      <Loader2 size={11} className="animate-spin text-brand" />
                    ) : call.status === "error" ? (
                      <IconClose size={11} />
                    ) : (
                      <IconCheck size={11} className="text-muted-foreground" />
                    )}
                  </span>
                  <Icon size={15} className="shrink-0 text-muted-foreground" />
                  <span className="shrink-0 text-[14px] font-medium">{labelFor(call.name)}</span>
                  <span className="min-w-0 flex-1 truncate text-[13px] text-muted-foreground">
                    {describe(call)}
                  </span>
                  <IconChevronRight
                    size={14}
                    className={cn(
                      "shrink-0 text-muted-foreground/70 transition-transform",
                      detail && "rotate-90",
                    )}
                  />
                </button>
                {detail && (
                  <div className="ml-[31px] mt-1 grid gap-2 pb-2 sm:grid-cols-2">
                    {[
                      { label: "Input", value: call.input },
                      { label: "Output", value: call.output },
                    ].map((block) => (
                      <div key={block.label}>
                        <p className="mb-1 text-[12px] font-medium text-muted-foreground">
                          {block.label}
                        </p>
                        <pre className="scroll-slim max-h-48 overflow-auto whitespace-pre-wrap break-words rounded-lg border bg-muted/50 p-3 font-mono text-[12px] leading-relaxed">
                          {pretty(block.value)}
                        </pre>
                      </div>
                    ))}
                  </div>
                )}
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
