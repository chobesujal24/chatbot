"use client";

import { useState } from "react";
import { LayoutTemplate, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import type { PromptTemplate } from "@/lib/types";

interface TemplatesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  templates: PromptTemplate[];
  onChanged: () => void;
  onInsert: (content: string) => void;
}

export default function TemplatesDialog(props: TemplatesDialogProps) {
  const [name, setName] = useState("");
  const [content, setContent] = useState("");

  const add = async () => {
    if (!name.trim() || !content.trim()) return;
    const res = await fetch("/api/templates", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim(), content: content.trim() }),
    });
    if (!res.ok) {
      toast.error("Could not save template");
      return;
    }
    setName("");
    setContent("");
    props.onChanged();
  };

  const remove = async (id: string) => {
    const res = await fetch(`/api/templates/${id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not delete template");
      return;
    }
    props.onChanged();
  };

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[85vh] sm:max-w-[520px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutTemplate size={16} /> Prompt templates
          </DialogTitle>
          <DialogDescription>
            Reusable prompts. Insert one into the composer with a click.
          </DialogDescription>
        </DialogHeader>
        <div>
          <div className="space-y-2">
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Template name"
              className="text-[14px]"
            />
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Prompt text…"
              rows={3}
              className="resize-y text-[13px]"
            />
            <Button size="sm" onClick={() => void add()} disabled={!name.trim() || !content.trim()}>
              <Plus size={14} /> Save template
            </Button>
          </div>
          <div className="mt-4 space-y-2">
            {props.templates.map((t) => (
              <div
                key={t.id}
                className="group rounded-lg border border-border p-3 transition hover:bg-accent/40"
              >
                <div className="flex items-center gap-2">
                  <p className="min-w-0 flex-1 truncate text-[14px] font-medium">{t.name}</p>
                  <Button
                    size="xs"
                    variant="outline"
                    onClick={() => {
                      props.onInsert(t.content);
                      props.onOpenChange(false);
                    }}
                  >
                    Insert
                  </Button>
                  <button
                    type="button"
                    aria-label="Delete template"
                    onClick={() => void remove(t.id)}
                    className="rounded p-1 text-muted-foreground opacity-0 transition hover:bg-accent hover:text-destructive group-hover:opacity-100"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
                <p className="mt-1 line-clamp-2 whitespace-pre-wrap text-[12px] text-muted-foreground">
                  {t.content}
                </p>
              </div>
            ))}
            {props.templates.length === 0 && (
              <p className="py-6 text-center text-[13px] text-muted-foreground">
                No templates yet.
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
