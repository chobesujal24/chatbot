"use client";

import { useEffect, useState } from "react";
import { ArrowRight, Check, KeyRound, Loader2, Plug, Sparkles, Zap } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "./logo";
import { findProvider, PROVIDERS, type ProviderPreset } from "@/lib/providers";
import { cn } from "@/lib/utils";

type Step = "welcome" | "provider" | "key" | "done";

const STEPS: Step[] = ["welcome", "provider", "key", "done"];

export default function Onboarding({ onFinish }: { onFinish: () => void }) {
  const [step, setStep] = useState<Step>("welcome");
  const [provider, setProvider] = useState<ProviderPreset>(PROVIDERS[0]);
  const [key, setKey] = useState("");
  const [baseURL, setBaseURL] = useState(PROVIDERS[0].baseURL);
  const [model, setModel] = useState(PROVIDERS[0].models[0] ?? "");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testState, setTestState] = useState<{ ok: boolean; message: string } | null>(null);

  useEffect(() => {
    setBaseURL(provider.baseURL);
    setModel(provider.models[0] ?? "");
    setTestState(null);
  }, [provider]);

  const advance = () => setStep(STEPS[Math.min(STEPS.indexOf(step) + 1, STEPS.length - 1)]);

  const pickProvider = (p: ProviderPreset) => {
    setProvider(p);
    setStep("key");
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: provider.id,
          kind: provider.credentialKind,
          label: provider.label,
          secret: key.trim() || undefined,
          baseURL: baseURL || null,
          isActive: true,
        }),
      });
      if (!res.ok) throw new Error("Could not save.");
      await fetch("/api/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ defaultModel: model, defaultProvider: provider.id }),
      });
      toast.success(`${provider.label} connected`);
      setStep("done");
    } catch {
      toast.error("Could not save the provider");
    } finally {
      setSaving(false);
    }
  };

  const test = async () => {
    setTesting(true);
    setTestState(null);
    try {
      const res = await fetch("/api/credentials/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: provider.id }),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string }
        | null;
      setTestState({
        ok: Boolean(data?.ok),
        message: data?.message ?? (data?.ok ? "Connected." : "Could not connect."),
      });
    } catch (error) {
      setTestState({
        ok: false,
        message: error instanceof Error ? error.message : "Could not connect.",
      });
    } finally {
      setTesting(false);
    }
  };

  const progress = (STEPS.indexOf(step) + 1) / STEPS.length;

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <div className="mx-auto flex w-full max-w-[640px] flex-1 flex-col justify-center px-5 py-10 sm:py-16">
        <div className="mb-10 flex items-center gap-2">
          {STEPS.map((s, i) => (
            <span
              key={s}
              className={cn(
                "h-1 rounded-full transition-all duration-300",
                i === STEPS.indexOf(step) ? "w-8 bg-foreground" : "w-4 bg-border",
                i < STEPS.indexOf(step) && "bg-foreground/35",
              )}
            />
          ))}
          <span className="ml-2 font-mono text-[11px] text-muted-foreground">
            {STEPS.indexOf(step) + 1} / {STEPS.length}
          </span>
        </div>
        {step === "welcome" && (
          <div className="animate-rise-in">
            <Logo size={48} />
            <h1 className="mt-7 font-serif text-[42px] leading-[1.08] tracking-tight">
              Your own AI,
              <br />
              your own keys.
            </h1>
            <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-muted-foreground">
              Nova is an interface, not a service. Connect the model providers and tools you
              already pay for — keys are encrypted on the server and never leave your browser.
            </p>
            <div className="mt-8 flex flex-wrap gap-2.5">
              <Button size="lg" onClick={advance}>
                Get started <ArrowRight size={16} />
              </Button>
              <Button size="lg" variant="ghost" onClick={onFinish}>
                Explore the demo first
              </Button>
            </div>
            <ul className="mt-10 space-y-2.5 text-[13.5px] text-muted-foreground">
              {[
                "OpenAI, Anthropic, Gemini, OpenRouter, Groq, DeepSeek and 20+ more",
                "Firecrawl, Tavily, Brave, Exa, Serper and Jina for live web tools",
                "Ollama, LM Studio or vLLM for fully local models",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <Check size={15} className="mt-0.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        )}

        {step === "provider" && (
          <div className="animate-rise-in">
            <h1 className="font-serif text-[32px] leading-tight">Choose a provider</h1>
            <p className="mt-2 text-[14px] text-muted-foreground">
              You can add more providers later in Settings.
            </p>
            <div className="mt-7 grid max-h-[52vh] gap-1.5 overflow-y-auto pr-1 sm:grid-cols-2">
              {PROVIDERS.filter((p) => p.credentialKind === "model").map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => pickProvider(p)}
                  className="flex items-center justify-between gap-3 rounded-lg border bg-card px-3.5 py-3 text-left transition hover:border-foreground/25 hover:bg-accent/50"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-[13.5px] font-medium">{p.label}</span>
                    <span className="mt-0.5 block truncate text-[11.5px] text-muted-foreground">
                      {p.group === "local" ? "Runs on your machine" : p.notes}
                    </span>
                  </span>
                  <ArrowRight size={15} className="shrink-0 text-muted-foreground" />
                </button>
              ))}
            </div>
            <Button variant="ghost" className="mt-5" onClick={() => setStep("welcome")}>
              Back
            </Button>
          </div>
        )}

        {step === "key" && (
          <div className="animate-rise-in">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <Plug size={18} />
              </div>
              <div>
                <h1 className="text-[22px] font-semibold tracking-tight">{provider.label}</h1>
                <p className="text-[13px] text-muted-foreground">{provider.notes}</p>
              </div>
            </div>

            <div className="mt-7 space-y-4">
              <div>
                <label className="mb-1.5 block text-[13px] font-medium" htmlFor="onboard-key">
                  API key
                </label>
                <Input
                  id="onboard-key"
                  type="password"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder={provider.keyPlaceholder}
                  autoComplete="off"
                  className="font-mono text-[13px]"
                />
                <p className="mt-1.5 flex items-center gap-1.5 text-[12px] text-muted-foreground">
                  <KeyRound size={12} /> Encrypted with AES-256-GCM. Never exposed to the browser.
                </p>
              </div>

              {provider.kind === "openai-compatible" && (
                <div>
                  <label className="mb-1.5 block text-[13px] font-medium" htmlFor="onboard-url">
                    Base URL
                  </label>
                  <Input
                    id="onboard-url"
                    value={baseURL}
                    onChange={(e) => setBaseURL(e.target.value)}
                    placeholder="http://localhost:11434/v1"
                    className="font-mono text-[13px]"
                  />
                </div>
              )}

              {provider.models.length > 0 && (
                <div>
                  <label className="mb-1.5 block text-[13px] font-medium" htmlFor="onboard-model">
                    Model
                  </label>
                  <select
                    id="onboard-model"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="h-9 w-full rounded-md border border-input bg-transparent px-2.5 text-[13px] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                  >
                    {provider.models.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {testState && (
                <div
                  className={cn(
                    "flex items-start gap-2 rounded-lg border px-3 py-2.5 text-[13px]",
                    testState.ok
                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                      : "border-destructive/30 bg-destructive/10 text-destructive",
                  )}
                >
                  {testState.ok ? <Check size={15} className="mt-px" /> : <Zap size={15} className="mt-px" />}
                  {testState.message}
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <Button onClick={() => void save()} disabled={saving}>
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                  Connect {provider.label}
                </Button>
                <Button variant="outline" onClick={() => void test()} disabled={testing}>
                  {testing ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                  Test connection
                </Button>
                <Button variant="ghost" onClick={() => setStep("provider")}>
                  Back
                </Button>
              </div>
            </div>
          </div>
        )}

        {step === "done" && (
          <div className="animate-rise-in text-center">
            <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Check size={26} />
            </div>
            <h1 className="mt-6 font-serif text-[34px] leading-tight">You are connected</h1>
            <p className="mx-auto mt-3 max-w-md text-[14px] leading-relaxed text-muted-foreground">
              {provider.label} is now the active provider. Add web tools, agents and more from
              Settings whenever you are ready.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-2.5">
              <Button size="lg" onClick={onFinish}>
                Start chatting <Sparkles size={15} />
              </Button>
              <Button size="lg" variant="outline" onClick={() => window.location.href = "/settings"}>
                Open settings
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
