"use client";

import { useMemo } from "react";
import { Archive, Gauge, Loader2, RotateCcw, Sparkles } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Button } from "./ui/button";
import { Switch } from "./ui/switch";
import { cn } from "@/lib/utils";
import type { ConversationContext } from "@/lib/types";

const SEGMENT_COLORS: Record<string, string> = {
  system: "oklch(0.62 0.02 265)",
  skills: "oklch(0.68 0.13 300)",
  memory: "oklch(0.66 0.14 165)",
  summary: "oklch(0.72 0.13 230)",
  history: "oklch(0.64 0.155 48)",
  attachments: "oklch(0.55 0.02 60)",
};

const fmt = (n: number) =>
  n >= 1000 ? `${(n / 1000).toFixed(n >= 10_000 ? 0 : 1).replace(/\.0$/, "")}k` : String(n);

export default function ContextMeter({
  data,
  busy,
  compacting,
  onCompact,
  onOverride,
  onReset,
}: {
  data: ConversationContext | null;
  busy: boolean;
  compacting: boolean;
  onCompact: () => void;
  onOverride: (patch: Record<string, unknown>) => void;
  onReset: () => void;
}) {
  const breakdown = data?.breakdown ?? null;
  const percent = breakdown ? Math.round(breakdown.ratio * 100) : null;
  const ring = breakdown ? Math.min(100, Math.round(breakdown.ratio * 100)) : 0;

  const stroke = useMemo(() => {
    if (!breakdown) return "";
    const total = Math.max(1, breakdown.contextWindow);
    return breakdown.segments
      .map((s) => `${SEGMENT_COLORS[s.id] ?? "var(--muted-foreground)"} ${((s.tokens / total) * 100).toFixed(3)}%`)
      .join(", ");
  }, [breakdown]);

  const overBudget = (breakdown?.overage ?? 0) > 0;
  const nearLimit = (breakdown?.ratio ?? 0) >= 0.8;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={`Context ${percent ?? 0}% used`}
          className={cn(
            "flex h-8 items-center gap-2 rounded-lg border px-2 text-[12px] tabular-nums outline-none transition",
            busy
              ? "border-brand/40 bg-brand/10 text-foreground"
              : overBudget
                ? "border-destructive/40 text-destructive"
                : nearLimit
                  ? "border-amber-500/40 text-amber-700 dark:text-amber-400"
                  : "text-muted-foreground hover:border-foreground/20 hover:text-foreground",
          )}
        >
          <span
            aria-hidden
            className="size-3.5 rounded-full"
            style={{
              background: `conic-gradient(${stroke || "var(--border)"} 0 ${ring}%, var(--border) ${ring}% 100%)`,
              WebkitMask: "radial-gradient(circle, transparent 45%, black 47%)",
              mask: "radial-gradient(circle, transparent 45%, black 47%)",
            }}
          />
          {percent === null ? "Context" : `${percent}%`}
        </button>
      </PopoverTrigger>

      <PopoverContent align="end" className="w-[400px] p-0">
        <div className="flex items-start gap-2.5 border-b px-4 py-3.5">
          <Gauge size={16} className="mt-0.5 shrink-0 text-muted-foreground" />
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-semibold">Context window</p>
            <p className="mt-0.5 text-[12px] text-muted-foreground">
              {breakdown
                ? `${fmt(breakdown.promptTokens)} of ${fmt(breakdown.contextWindow)} tokens${
                    breakdown.estimated ? " (estimated)" : " (measured)"
                  } · ${fmt(breakdown.outputBudget)} reserved for output`
                : "Send a message to measure this conversation."}
            </p>
          </div>
        </div>

        {breakdown && (
          <div className="space-y-3.5 px-4 py-3.5">
            {/* stacked occupancy bar */}
            <div>
              <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-muted">
                {breakdown.segments.map((s) => (
                  <span
                    key={s.id}
                    title={`${s.label}: ${fmt(s.tokens)} tokens`}
                    style={{
                      width: `${Math.max(1.5, (s.tokens / Math.max(1, breakdown.contextWindow)) * 100)}%`,
                      background: SEGMENT_COLORS[s.id] ?? "var(--muted-foreground)",
                    }}
                  />
                ))}
                {breakdown.headroom > 0 && (
                  <span style={{ width: `${(breakdown.headroom / breakdown.contextWindow) * 100}%` }} />
                )}
              </div>
              {overBudget && (
                <p className="mt-2 text-[12px] text-destructive">
                  Over budget by {fmt(breakdown.overage)} tokens. Compact the conversation or lower
                  the history depth.
                </p>
              )}
            </div>

            {/* legend */}
            <ul className="space-y-1">
              {breakdown.segments.map((s) => (
                <li key={s.id} className="flex items-center gap-2 text-[12.5px]">
                  <span
                    className="size-2 shrink-0 rounded-[2px]"
                    style={{ background: SEGMENT_COLORS[s.id] ?? "var(--muted-foreground)" }}
                  />
                  <span className="min-w-0 flex-1 truncate">{s.label}</span>
                  {s.detail && <span className="text-[11.5px] text-muted-foreground">{s.detail}</span>}
                  <span className="w-12 shrink-0 text-right font-mono text-[11.5px] text-muted-foreground">
                    {fmt(s.tokens)}
                  </span>
                </li>
              ))}
              <li className="flex items-center gap-2 text-[12.5px]">
                <span className="size-2 shrink-0 rounded-[2px] bg-border" />
                <span className="min-w-0 flex-1 truncate">Free space</span>
                <span className="w-12 shrink-0 text-right font-mono text-[11.5px] text-muted-foreground">
                  {fmt(breakdown.headroom)}
                </span>
              </li>
            </ul>

            {/* what the model received last turn */}
            <div className="grid grid-cols-3 gap-2 border-t pt-3.5 text-center">
              <Stat label="History" value={`${data?.includedCount ?? 0}`} hint={`${data?.droppedCount ?? 0} folded`} />
              <Stat label="Memories" value={`${data?.injectedMemories.length ?? 0}`} hint="injected" />
              <Stat label="Skills" value={`${data?.skills.length ?? 0}`} hint="available" />
            </div>

            {(data?.injectedMemories.length ?? 0) > 0 && (
              <div className="space-y-1.5">
                <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Memories in this turn
                </p>
                <ul className="space-y-1">
                  {data!.injectedMemories.slice(0, 4).map((m) => (
                    <li key={m.id} className="flex items-start gap-2 rounded-md bg-muted/60 px-2 py-1.5 text-[12px]">
                      <span className="mt-0.5 size-1.5 shrink-0 rounded-full bg-brand" />
                      <span className="min-w-0 flex-1 line-clamp-2">{m.value}</span>
                      <span className="shrink-0 font-mono text-[10.5px] text-muted-foreground">
                        {Math.round(m.score * 100)}%
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* controls */}
            <div className="space-y-2.5 border-t pt-3.5">
              <Slider
                label="History depth"
                value={data!.settings.maxHistoryMessages}
                min={2}
                max={80}
                suffix=" msgs"
                onChange={(v) => onOverride({ maxHistoryMessages: v })}
              />
              <Slider
                label="Memories"
                value={data!.settings.memoryLimit}
                min={0}
                max={20}
                onChange={(v) => onOverride({ memoryLimit: v })}
              />
              <Slider
                label="Compact at"
                value={Math.round(data!.settings.compactThreshold * 100)}
                min={40}
                max={95}
                suffix="%"
                onChange={(v) => onOverride({ compactThreshold: v / 100 })}
              />
              <div className="flex items-center justify-between">
                <span className="text-[12.5px]">Auto-compact</span>
                <Switch
                  checked={data!.settings.autoCompact}
                  onCheckedChange={(checked) => onOverride({ autoCompact: checked })}
                  aria-label="Auto-compact this conversation"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[12.5px]">Inject memories</span>
                <Switch
                  checked={data!.settings.injectMemories}
                  onCheckedChange={(checked) => onOverride({ injectMemories: checked })}
                  aria-label="Inject memories into this conversation"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[12.5px]">Offer skills</span>
                <Switch
                  checked={data!.settings.includeSkills}
                  onCheckedChange={(checked) => onOverride({ includeSkills: checked })}
                  aria-label="Offer skills in this conversation"
                />
              </div>
            </div>

            <div className="flex gap-2 border-t pt-3.5">
              <Button size="sm" variant="outline" onClick={onCompact} disabled={compacting || busy}>
                {compacting ? <Loader2 size={13} className="animate-spin" /> : <Archive size={13} />}
                Compact now
              </Button>
              <Button size="sm" variant="ghost" onClick={onReset} disabled={compacting}>
                <RotateCcw size={13} /> Reset
              </Button>
              {(data?.summarizedCount ?? 0) > 0 && (
                <span className="ml-auto inline-flex items-center gap-1 self-center text-[11.5px] text-muted-foreground">
                  <Sparkles size={11} />
                  {data!.summarizedCount} summarised
                </span>
              )}
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-lg bg-muted/60 px-2 py-2">
      <p className="font-mono text-[15px] font-medium leading-none">{value}</p>
      <p className="mt-1 text-[10.5px] font-medium uppercase tracking-[0.06em] text-muted-foreground">
        {label}
      </p>
      <p className="text-[10.5px] text-muted-foreground/80">{hint}</p>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  suffix = "",
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 flex items-center justify-between text-[12.5px]">
        {label}
        <span className="font-mono text-[11.5px] text-muted-foreground">
          {value}
          {suffix}
        </span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer accent-foreground"
      />
    </label>
  );
}
