"use client";

import { useEffect, useState } from "react";
import { BarChart3, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { formatTokens } from "@/lib/format";

interface Stats {
  conversations: number;
  messages: number;
  agents: number;
  memories: number;
  tasksOpen: number;
  tasksDone: number;
  byModel: { model: string; count: number; tokens: number }[];
  toolCounts: Record<string, number>;
}

export default function StatsDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    fetch("/api/stats", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => setStats(data))
      .catch(() => setStats(null))
      .finally(() => setLoading(false));
  }, [open]);

  const cards = stats
    ? [
        { label: "Conversations", value: stats.conversations },
        { label: "Messages", value: stats.messages },
        { label: "Agents", value: stats.agents },
        { label: "Memories", value: stats.memories },
        { label: "Tasks open", value: stats.tasksOpen },
        { label: "Tasks done", value: stats.tasksDone },
      ]
    : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 size={16} /> Workspace stats
          </DialogTitle>
          <DialogDescription>Usage recorded from persisted messages.</DialogDescription>
        </DialogHeader>
        <div>
          {loading ? (
            <div className="flex items-center gap-2 py-8 text-[14px] text-muted-foreground">
              <Loader2 size={15} className="animate-spin" /> Loading…
            </div>
          ) : !stats ? (
            <p className="py-8 text-center text-[13px] text-muted-foreground">
              Could not load stats.
            </p>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-2">
                {cards.map((c) => (
                  <div key={c.label} className="rounded-lg border border-border p-3">
                    <p className="text-xl font-semibold">{c.value}</p>
                    <p className="mt-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                      {c.label}
                    </p>
                  </div>
                ))}
              </div>
              <p className="mb-2 mt-5 text-[12px] font-semibold uppercase tracking-wide text-muted-foreground">
                Tokens by model
              </p>
              <div className="divide-y divide-border rounded-lg border border-border">
                {stats.byModel.length === 0 && (
                  <p className="px-3 py-4 text-[13px] text-muted-foreground">
                    No model responses recorded yet.
                  </p>
                )}
                {stats.byModel.map((m) => (
                  <div key={m.model} className="flex items-center gap-3 px-3 py-2">
                    <code className="min-w-0 flex-1 truncate font-mono text-[12px]">{m.model}</code>
                    <span className="text-[12px] text-muted-foreground">{m.count} replies</span>
                    <span className="font-mono text-[12px]">{formatTokens(m.tokens)} tok</span>
                  </div>
                ))}
              </div>
              <p className="mb-2 mt-5 text-[12px] font-semibold uppercase tracking-wide text-muted-foreground">
                Tool calls
              </p>
              <div className="divide-y divide-border rounded-lg border border-border">
                {Object.keys(stats.toolCounts).length === 0 && (
                  <p className="px-3 py-4 text-[13px] text-muted-foreground">
                    No tool calls yet. Connect a model and use an agent with tools.
                  </p>
                )}
                {Object.entries(stats.toolCounts).map(([name, count]) => (
                  <div key={name} className="flex items-center gap-3 px-3 py-2">
                    <span className="min-w-0 flex-1 font-mono text-[12px]">{name}</span>
                    <span className="font-mono text-[12px]">{count}×</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
