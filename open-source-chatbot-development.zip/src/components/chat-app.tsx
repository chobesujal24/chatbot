"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import Sidebar from "./sidebar";
import Header from "./chat-header";
import MessageView from "./message-view";
import Composer from "./composer";
import Hero from "./hero";
import LoginGate from "./login-gate";
import Onboarding from "./onboarding";
import SettingsDialog from "./settings-dialog";
import CommandPalette from "./command-palette";
import AgentsDialog from "./agents-dialog";
import TasksDialog from "./tasks-dialog";
import MemoriesDialog from "./memories-dialog";
import TemplatesDialog from "./templates-dialog";
import StatsDialog from "./stats-dialog";
import ShareDialog from "./share-dialog";
import { AboutDialog, ShortcutsDialog } from "./info-dialogs";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import type { ToolCallView } from "./tool-calls";
import { useTheme } from "./providers";
import { DEFAULT_SETTINGS } from "@/lib/settings";
import {
  DEFAULT_PREFERENCES,
  applyPreferences,
  normalizePreferences,
  type Preferences,
} from "@/lib/preferences-client";
import { findProvider } from "@/lib/providers";
import type { CredentialSummary } from "@/lib/credentials";
import { downloadFile, exportMarkdown } from "@/lib/format";
import { copyToClipboard } from "@/lib/clipboard";
import type {
  Agent,
  Skill,
  ChatMessage,
  ChatRequest,
  ClientAttachment,
  ConversationContext,
  ConversationSummary,
  MemoryItem,
  PromptTemplate,
  Settings,
  TaskItem,
} from "@/lib/types";

const AGENT_KEY = "nova-agent-id";

type Rating = "up" | "down";

interface StreamOptions {
  pendingUser?: string;
  hiddenIds?: string[];
}

interface BootstrapData {
  workspace: { id: string; created: boolean };
  passwordRequired: boolean;
  credentials: CredentialSummary[];
  serverKeys: Record<string, boolean>;
  suggestedProvider: Settings["provider"];
  suggestedModel: string;
  conversations: ConversationSummary[];
  agents: Agent[];
  tasks: TaskItem[];
  memories: MemoryItem[];
  templates: PromptTemplate[];
  feedback: Record<string, Rating>;
  preferences: Record<string, unknown>;
  skills?: Skill[];
  memoryStats?: { total: number; enabled: number; recalled: number };
  shareCount?: number;
}

interface UIMessageChunk {
  type?: string;
  delta?: string;
  toolCallId?: string;
  toolName?: string;
  input?: unknown;
  output?: unknown;
  errorText?: string;
}

export default function ChatApp() {
  const { theme, resolved, setTheme } = useTheme();

  const [dbStatus, setDbStatus] = useState<"loading" | "ready" | "error" | "auth">("loading");
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [prefs, setPrefs] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [credentials, setCredentials] = useState<CredentialSummary[]>([]);

  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [memoryStats, setMemoryStats] = useState<{ total: number; enabled: number; recalled: number } | null>(null);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [templates, setTemplates] = useState<PromptTemplate[]>([]);
  const [feedback, setFeedback] = useState<Record<string, Rating>>({});

  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const [streamingTools, setStreamingTools] = useState<ToolCallView[]>([]);
  const [pendingUser, setPendingUser] = useState<string | null>(null);
  const [hiddenIds, setHiddenIds] = useState<string[]>([]);
  const [conversationContext, setConversationContext] = useState<ConversationContext | null>(null);
  const [compacting, setCompacting] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  // Reveal pacing: providers can burst tokens far faster than reading speed.
  const targetRef = useRef("");
  const revealedRef = useRef(0);
  const revealSpeedRef = useRef(0);

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [agentsOpen, setAgentsOpen] = useState(false);
  const [tasksOpen, setTasksOpen] = useState(false);
  const [memoriesOpen, setMemoriesOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameDraft, setRenameDraft] = useState("");
  const [composerPrefill, setComposerPrefill] = useState<{ text: string; nonce: number } | null>(null);

  /* ------------------------------ Bootstrap -------------------------------- */

  const bootstrap = useCallback(async () => {
    setDbStatus("loading");
    try {
      const res = await fetch("/api/bootstrap", { cache: "no-store" });
      if (res.status === 401) {
        const data = (await res.json().catch(() => null)) as { error?: { code?: string } } | null;
        if (data?.error?.code === "authentication_required") {
          setDbStatus("auth");
          return;
        }
      }
      if (!res.ok) throw new Error("Bootstrap failed");
      const data = (await res.json()) as BootstrapData;
      setWorkspaceId(data.workspace.id);
      setCredentials(data.credentials ?? []);
      setConversations(data.conversations);
      const sorted = [...data.agents].sort(
        (x, y) => Number(y.isDefault) - Number(x.isDefault) || x.name.localeCompare(y.name),
      );
      setAgents(sorted);
      setSkills([]);
      void fetch("/api/skills", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => setSkills((d as { skills: Skill[] } | null)?.skills ?? []));
      setTasks(data.tasks);
      setMemories(data.memories);
      setTemplates(data.templates);
      setFeedback(data.feedback ?? {});
      setSidebarOpen(window.innerWidth >= 1024);
      setSidebarCollapsed(window.localStorage.getItem("nova-rail") === "1");
      setSkills(data.skills ?? []);
      setMemoryStats(data.memoryStats ?? null);
      const normalized = normalizePreferences(data.preferences);
      setPrefs(normalized);
      applyPreferences(normalized);
      const hasProvider = (data.credentials ?? []).some(
        (c) => c.kind === "model" && c.isActive && c.hasKey,
      );
      const forced = new URLSearchParams(window.location.search).get("onboarding") === "1";
      setShowOnboarding(forced || (!hasProvider && !normalized.welcomeDismissed));
      const fallback = sorted.find((a) => a.isDefault) ?? sorted[0] ?? null;
      const storedAgent = window.localStorage.getItem(AGENT_KEY);
      setSelectedAgentId(
        storedAgent && sorted.some((a) => a.id === storedAgent)
          ? storedAgent
          : (fallback?.id ?? null),
      );
      setDbStatus("ready");
    } catch {
      setDbStatus("error");
    }
  }, []);

  useEffect(() => {
    void bootstrap();
  }, [bootstrap]);

  // Deep links from Settings. The agent manager is queued until the workspace is
  // ready, because a first-time visitor is shown onboarding before anything else.
  const pendingAgentsOpen = useRef(false);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("open") === "agents") {
      pendingAgentsOpen.current = true;
      window.history.replaceState(null, "", "/");
    }
  }, []);
  useEffect(() => {
    if (dbStatus === "ready" && !showOnboarding && pendingAgentsOpen.current) {
      pendingAgentsOpen.current = false;
      setAgentsOpen(true);
    }
  }, [dbStatus, showOnboarding]);

  /* ------------------------------- Refresh -------------------------------- */

  const refreshConversations = useCallback(async () => {
    const res = await fetch("/api/conversations", { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to load conversations");
    const data = (await res.json()) as { conversations: ConversationSummary[] };
    setConversations(data.conversations);
  }, []);

  const refreshAgents = useCallback(async () => {
    const res = await fetch("/api/agents", { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to load agents");
    const data = (await res.json()) as { agents: Agent[] };
    const sorted = [...data.agents].sort(
      (x, y) => Number(y.isDefault) - Number(x.isDefault) || x.name.localeCompare(y.name),
    );
    setAgents(sorted);
  }, []);

  const refreshTasks = useCallback(async () => {
    const res = await fetch("/api/tasks", { cache: "no-store" });
    if (res.ok) setTasks(((await res.json()) as { tasks: TaskItem[] }).tasks);
  }, []);
  const refreshMemories = useCallback(async () => {
    const res = await fetch("/api/memories", { cache: "no-store" });
    if (res.ok) setMemories(((await res.json()) as { memories: MemoryItem[] }).memories);
  }, []);
  const refreshTemplates = useCallback(async () => {
    const res = await fetch("/api/templates", { cache: "no-store" });
    if (res.ok) setTemplates(((await res.json()) as { templates: PromptTemplate[] }).templates);
  }, []);
  const fetchMessages = useCallback(async (id: string): Promise<ChatMessage[]> => {
    const res = await fetch(`/api/conversations/${id}/messages`, { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to load messages");
    return ((await res.json()) as { messages: ChatMessage[] }).messages;
  }, []);

  useEffect(() => {
    if (!isStreaming) return;
    const smooth = prefs.reveal === "smooth" && document.documentElement.dataset.animations !== "off";
    if (!smooth) {
      revealSpeedRef.current = 0;
      return;
    }
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(64, now - last);
      last = now;
      const target = targetRef.current;
      const current = revealedRef.current;
      if (current < target.length) {
        // Ramp up with the backlog so long answers do not lag behind forever.
        const backlog = target.length - current;
        const perMs = 0.35 + Math.min(6, backlog / 240);
        revealSpeedRef.current = perMs;
        const next = Math.min(target.length, current + Math.max(2, Math.round(perMs * dt)));
        revealedRef.current = next;
        setStreamingText(target.slice(0, next));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [isStreaming, prefs.reveal]);

  const refreshContext = useCallback(async (id: string | null) => {
    if (!id) {
      setConversationContext(null);
      return;
    }
    try {
      const res = await fetch(`/api/conversations/${id}/context`, { cache: "no-store" });
      if (!res.ok) return setConversationContext(null);
      setConversationContext((await res.json()) as ConversationContext);
    } catch {
      /* keep the last known reading */
    }
  }, []);

  /* ------------------------------ Selection ------------------------------- */

  const selectConversation = useCallback(
    async (id: string) => {
      if (isStreaming) return;
      setActiveId(id);
      if (window.innerWidth < 1024) setSidebarOpen(false);
      const conversation = conversations.find((c) => c.id === id);
      if (conversation?.agentId) {
        setSelectedAgentId(conversation.agentId);
        window.localStorage.setItem(AGENT_KEY, conversation.agentId);
      }
      try {
        setMessages(await fetchMessages(id));
        void refreshContext(id);
      } catch {
        toast.error("Could not load that conversation");
      }
    },
    [conversations, fetchMessages, isStreaming, refreshContext],
  );

  const newChat = useCallback(() => {
    if (isStreaming) abortRef.current?.abort();
    setActiveId(null);
    setMessages([]);
    setConversationContext(null);
    if (window.innerWidth < 1024) setSidebarOpen(false);
  }, [isStreaming]);

  const selectAgent = useCallback(
    (id: string) => {
      setSelectedAgentId(id);
      window.localStorage.setItem(AGENT_KEY, id);
      const agent = agents.find((a) => a.id === id);
      if (agent) toast.success(`Switched to ${agent.name}`);
    },
    [agents],
  );

  /* ----------------------------- Streaming -------------------------------- */

  const activeModelCredential = useMemo(
    () => credentials.find((c) => c.kind === "model" && c.isActive && c.enabled) ?? null,
    [credentials],
  );

  const settings = useMemo<Settings>(() => {
    const providerId = activeModelCredential?.provider ?? "offline";
    const preset = findProvider(providerId);
    const mapped: Settings["provider"] =
      providerId === "openai" || providerId === "anthropic" || providerId === "google"
        ? providerId
        : providerId === "offline"
          ? "offline"
          : "custom";
    const model =
      prefs.defaultModel ||
      (preset?.models[0] ?? (providerId === "offline" ? "offline-demo" : ""));
    return {
      provider: mapped,
      model,
      apiKey: "",
      baseURL: activeModelCredential?.baseURL ?? "",
      systemPrompt: prefs.systemPrompt ?? "",
      temperature: prefs.temperature ?? 0.7,
      maxTokens: prefs.outputBudget ?? 2048,
    };
  }, [activeModelCredential, prefs]);

  const runStream = useCallback(
    async (payload: ChatRequest, options: StreamOptions = {}) => {
      if (isStreaming) return;
      const controller = new AbortController();
      abortRef.current = controller;
      setIsStreaming(true);
      setStreamingText("");
      targetRef.current = "";
      revealedRef.current = 0;
      setStreamingTools([]);
      setPendingUser(options.pendingUser ?? null);
      setHiddenIds(options.hiddenIds ?? []);

      let streamConversationId = payload.conversationId ?? null;
      let aborted = false;

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          // The API key is never sent from JS; it lives in an httpOnly cookie.
          body: JSON.stringify({ ...payload, settings: { ...settings, apiKey: "" } }),
          signal: controller.signal,
        });
        if (!res.ok) {
          const data = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
          throw new Error(data?.error?.message ?? ((await res.text()) || "Chat request failed"));
        }
        const headerId = res.headers.get("x-nova-conversation-id");
        if (headerId) {
          streamConversationId = headerId;
          setActiveId(headerId);
        }
        const streamError = res.headers.get("x-nova-error");
        if (streamError) toast.error(decodeURIComponent(streamError));

        const reader = res.body?.getReader();
        const decoder = new TextDecoder();
        if (reader) {
          let buffer = "";
          const handleLine = (line: string) => {
            const trimmed = line.trim();
            if (!trimmed) return;
            let chunk: UIMessageChunk;
            try {
              chunk = JSON.parse(trimmed) as UIMessageChunk;
            } catch {
              return;
            }
            switch (chunk.type) {
              case "text-delta":
                if (chunk.delta) {
                  if (prefs.reveal === "smooth") {
                    targetRef.current += chunk.delta;
                  } else {
                    setStreamingText((prev) => {
                      targetRef.current = prev + chunk.delta!;
                      revealedRef.current = targetRef.current.length;
                      return targetRef.current;
                    });
                  }
                }
                break;
              case "tool-input-available":
                if (chunk.toolCallId && chunk.toolName) {
                  setStreamingTools((prev) => [
                    ...prev,
                    { id: chunk.toolCallId!, name: chunk.toolName!, input: chunk.input, output: null, status: "running" },
                  ]);
                }
                break;
              case "tool-output-available":
                setStreamingTools((prev) =>
                  prev.map((t) =>
                    t.id === chunk.toolCallId ? { ...t, output: chunk.output, status: "done" as const } : t,
                  ),
                );
                break;
              case "tool-output-error":
                setStreamingTools((prev) =>
                  prev.map((t) =>
                    t.id === chunk.toolCallId
                      ? { ...t, output: chunk.errorText ?? "Tool failed", status: "error" as const }
                      : t,
                  ),
                );
                break;
              case "error":
                toast.error(chunk.errorText ?? "Stream error");
                break;
              default:
                break;
            }
          };
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() ?? "";
            for (const line of lines) handleLine(line);
          }
          handleLine(buffer);
        }
      } catch (error) {
        aborted = controller.signal.aborted;
        if (aborted) toast.message("Generation stopped");
        else toast.error(error instanceof Error ? error.message : "Something went wrong");
      } finally {
        if (aborted) await new Promise((resolve) => setTimeout(resolve, 400));
        if (streamConversationId) {
          try {
            setMessages(await fetchMessages(streamConversationId));
            await refreshConversations();
          } catch {
            /* keep optimistic state */
          }
        }
        void refreshTasks();
        void refreshMemories();
        setIsStreaming(false);
        setStreamingText("");
        targetRef.current = "";
        revealedRef.current = 0;
        setStreamingTools([]);
        setPendingUser(null);
        setHiddenIds([]);
        abortRef.current = null;
        void refreshContext(streamConversationId);
      }
    },
    [fetchMessages, isStreaming, refreshConversations, refreshContext, refreshMemories, refreshTasks, settings],
  );

  const send = useCallback(
    (text: string, attachments: ClientAttachment[]) => {
      void runStream(
        { mode: "send", conversationId: activeId, agentId: selectedAgentId, content: text, attachments, settings },
        { pendingUser: text },
      );
    },
    [activeId, runStream, selectedAgentId, settings],
  );

  const regenerate = useCallback(() => {
    if (!activeId || isStreaming) return;
    const lastUserIndex = messages.map((m) => m.role).lastIndexOf("user");
    if (lastUserIndex < 0) return;
    void runStream(
      { mode: "regenerate", conversationId: activeId, agentId: selectedAgentId, settings },
      { hiddenIds: messages.slice(lastUserIndex + 1).map((m) => m.id) },
    );
  }, [activeId, isStreaming, messages, runStream, selectedAgentId, settings]);

  const editMessage = useCallback(
    (id: string, content: string) => {
      if (!activeId || isStreaming || !content.trim()) return;
      const index = messages.findIndex((m) => m.id === id);
      if (index < 0) return;
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: content.trim() } : m)));
      void runStream(
        {
          mode: "edit",
          conversationId: activeId,
          agentId: selectedAgentId,
          editMessageId: id,
          editContent: content.trim(),
          settings,
        },
        { hiddenIds: messages.slice(index + 1).map((m) => m.id) },
      );
    },
    [activeId, isStreaming, messages, runStream, selectedAgentId, settings],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);

  const compactConversation = useCallback(async () => {
    if (!activeId || compacting) return;
    setCompacting(true);
    try {
      const res = await fetch(`/api/conversations/${activeId}/compact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = (await res.json().catch(() => null)) as {
        ok?: boolean;
        message?: string;
        foldedCount?: number;
        tokensSaved?: number;
        via?: string;
      } | null;
      if (!res.ok || !data?.ok) {
        toast.message(data?.message ?? "Nothing to compact yet.");
        return;
      }
      toast.success(
        `Compacted ${data.foldedCount ?? 0} turn(s) into a summary\nSaved roughly ${(data.tokensSaved ?? 0).toLocaleString()} tokens (${data.via ?? "extractive"}).`,
      );
      await refreshContext(activeId);
      await refreshConversations();
    } catch {
      toast.error("Compaction failed.");
    } finally {
      setCompacting(false);
    }
  }, [activeId, compacting, refreshConversations, refreshContext]);

  const overrideContext = useCallback(
    async (values: Record<string, unknown>) => {
      if (!activeId) return;
      try {
        const res = await fetch(`/api/conversations/${activeId}/context`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(values),
        });
        if (!res.ok) throw new Error("failed");
        await refreshContext(activeId);
      } catch {
        toast.error("Could not update context settings");
      }
    },
    [activeId, refreshContext],
  );

  const resetContextOverrides = useCallback(async () => {
    if (!activeId) return;
    try {
      await fetch(`/api/conversations/${activeId}/context`, { method: "DELETE" });
      await refreshContext(activeId);
      toast.success("Using workspace defaults");
    } catch {
      toast.error("Could not reset context settings");
    }
  }, [activeId, refreshContext]);

  /* ------------------------------ Mutations ------------------------------- */

  const patchConversation = useCallback(
    async (id: string, patch: { title?: string; pinned?: boolean }) => {
      const res = await fetch(`/api/conversations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error("Could not update conversation");
      await refreshConversations();
    },
    [refreshConversations],
  );

  const deleteConversation = useCallback(
    async (id: string) => {
      const res = await fetch(`/api/conversations/${id}`, { method: "DELETE" });
      if (!res.ok) return toast.error("Could not delete conversation");
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeId === id) {
        setActiveId(null);
        setMessages([]);
      }
      toast.success("Conversation deleted");
    },
    [activeId],
  );

  const forkConversation = useCallback(
    async (id: string) => {
      const res = await fetch(`/api/conversations/${id}/fork`, { method: "POST" });
      if (!res.ok) return toast.error("Could not fork conversation");
      const data = (await res.json()) as { conversation: ConversationSummary };
      toast.success("Conversation forked");
      await refreshConversations();
      void selectConversation(data.conversation.id);
    },
    [refreshConversations, selectConversation],
  );

  const deleteMessage = useCallback(async (id: string) => {
    const res = await fetch(`/api/messages/${id}`, { method: "DELETE" });
    if (!res.ok) return toast.error("Could not delete message");
    setMessages((prev) => prev.filter((m) => m.id !== id));
  }, []);

  const rateMessage = useCallback(async (id: string, rating: Rating | null) => {
    setFeedback((prev) => {
      const next = { ...prev };
      if (rating) next[id] = rating;
      else delete next[id];
      return next;
    });
    const res = await fetch(`/api/messages/${id}/feedback`, {
      method: rating ? "POST" : "DELETE",
      headers: { "Content-Type": "application/json" },
      ...(rating ? { body: JSON.stringify({ rating }) } : {}),
    });
    if (!res.ok) toast.error("Could not save feedback");
  }, []);

  const exportChat = useCallback(
    async (id: string, format: "md" | "json") => {
      try {
        const list = id === activeId ? messages : await fetchMessages(id);
        const title = conversations.find((c) => c.id === id)?.title ?? "chat";
        const safe = title.replace(/[^a-z0-9-_]+/gi, "-").slice(0, 50).toLowerCase();
        if (format === "md") {
          downloadFile(`${safe}.md`, exportMarkdown(title, list), "text/markdown");
        } else {
          downloadFile(
            `${safe}.json`,
            JSON.stringify({ title, exportedAt: new Date().toISOString(), messages: list }, null, 2),
            "application/json",
          );
        }
        toast.success(`Exported as ${format === "md" ? "Markdown" : "JSON"}`);
      } catch {
        toast.error("Export failed");
      }
    },
    [activeId, conversations, fetchMessages, messages],
  );

  const exportAll = useCallback(async () => {
    const res = await fetch("/api/data", { cache: "no-store" });
    if (!res.ok) return toast.error("Could not export workspace data");
    const data = await res.json();
    downloadFile("nova-workspace.json", JSON.stringify(data, null, 2), "application/json");
    toast.success("Workspace exported");
  }, []);

  const deleteAll = useCallback(async () => {
    const res = await fetch("/api/data", { method: "DELETE" });
    if (!res.ok) return toast.error("Could not delete workspace data");
    toast.success("All workspace data deleted");
    await bootstrap();
  }, [bootstrap]);

  const copyText = useCallback((text: string) => {
    void copyToClipboard(text).then((ok) =>
      ok ? toast.success("Copied to clipboard") : toast.error("Clipboard unavailable"),
    );
  }, []);

  const persistPreferences = useCallback(
    async (next: Partial<Preferences>) => {
      const merged = { ...prefs, ...next };
      setPrefs(merged);
      applyPreferences(merged);
      try {
        const res = await fetch("/api/preferences", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(merged),
        });
        if (!res.ok) throw new Error("save failed");
      } catch {
        toast.error("Could not save preferences");
      }
    },
    [prefs],
  );

  const updateSettings = useCallback(
    (next: Settings) => {
      void persistPreferences({
        defaultModel: next.model,
        defaultProvider: next.provider,
        temperature: next.temperature,
        outputBudget: next.maxTokens,
        systemPrompt: next.systemPrompt,
      });
      toast.success("Settings saved");
    },
    [persistPreferences],
  );

  const selectModel = useCallback(
    (model: string) => {
      void persistPreferences({ defaultModel: model });
    },
    [persistPreferences],
  );

  const toggleTheme = useCallback(() => setTheme(resolved === "dark" ? "light" : "dark"), [resolved, setTheme]);

  const toggleSidebarCollapsed = useCallback(() => {
    setSidebarCollapsed((prev) => {
      const next = !prev;
      window.localStorage.setItem("nova-rail", next ? "1" : "0");
      return next;
    });
  }, []);

  /* ------------------------------ Shortcuts ------------------------------- */

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const mod = event.metaKey || event.ctrlKey;
      if (mod && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen((v) => !v);
      } else if (mod && event.key.toLowerCase() === "n") {
        event.preventDefault();
        newChat();
      } else if (mod && event.key === "/") {
        event.preventDefault();
        setShortcutsOpen(true);
      } else if (mod && event.key.toLowerCase() === "b") {
        event.preventDefault();
        toggleSidebarCollapsed();
      } else if (mod && event.key === ",") {
        event.preventDefault();
        window.location.href = "/settings";
      } else if (event.key === "Escape" && isStreaming) {
        stop();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isStreaming, newChat, stop, toggleSidebarCollapsed]);

  /* -------------------------------- Render -------------------------------- */

  const visibleMessages = useMemo(
    () => messages.filter((m) => !hiddenIds.includes(m.id)),
    [messages, hiddenIds],
  );
  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;
  const selectedAgent = agents.find((a) => a.id === selectedAgentId) ?? null;
  const offline = !activeModelCredential;
  const openTasks = tasks.filter((t) => t.status === "open").length;
  const isEmpty = visibleMessages.length === 0 && !isStreaming && !pendingUser;

  const providerLabel = activeModelCredential
    ? (findProvider(activeModelCredential.provider)?.label ?? activeModelCredential.provider)
    : "no provider";

  const composerProps = {
    onSend: send,
    isStreaming,
    onStop: stop,
    agents,
    selectedAgent,
    onSelectAgent: selectAgent,
    onOpenAgents: () => setAgentsOpen(true),
    settings,
    onSelectModel: selectModel,
    onOpenSettings: () => setSettingsOpen(true),
    offline,
    prefill: composerPrefill,
    model: settings.model,
    providerLabel,
    hasProvider: Boolean(activeModelCredential),
    prefs,
  };

  if (dbStatus === "auth") {
    return <LoginGate onSuccess={() => void bootstrap()} />;
  }

  if (dbStatus === "ready" && showOnboarding) {
    return (
      <Onboarding
        onFinish={() => {
          setShowOnboarding(false);
          void persistPreferences({ welcomeDismissed: true });
        }}
      />
    );
  }

  return (
    <div className="flex h-dvh overflow-hidden bg-background text-foreground">
      <a
        href="#nova-main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Skip to conversation
      </a>
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelect={selectConversation}
        onNew={newChat}
        onRename={(id, title) => {
          void patchConversation(id, { title }).catch(() => toast.error("Rename failed"));
        }}
        onTogglePin={(id, pinned) => {
          void patchConversation(id, { pinned }).catch(() => toast.error("Could not pin chat"));
        }}
        onDelete={(id) => void deleteConversation(id)}
        onFork={(id) => void forkConversation(id)}
        onExport={(id, format) => void exportChat(id, format)}
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenAgents={() => setAgentsOpen(true)}
        onOpenTasks={() => setTasksOpen(true)}
        onOpenMemories={() => setMemoriesOpen(true)}
        onOpenTemplates={() => setTemplatesOpen(true)}
        onOpenStats={() => setStatsOpen(true)}
        onOpenAbout={() => setAboutOpen(true)}
        onOpenPalette={() => setPaletteOpen(true)}
        offline={offline}
        openTasks={openTasks}
        providerLabel={providerLabel === "no provider" ? null : providerLabel}
        providerKeyPreview={activeModelCredential?.keyPreview ?? null}
        collapsed={sidebarCollapsed}
        onToggleCollapsed={toggleSidebarCollapsed}
        onOpenSkills={() => { window.location.href = "/settings#skills"; }}
        onOpenContext={() => { window.location.href = "/settings#context"; }}
        theme={theme}
        resolvedTheme={resolved}
        onToggleTheme={toggleTheme}
      />

      <main id="nova-main" className="relative flex min-h-0 min-w-0 flex-1 flex-col">
        <Header
          title={activeConversation?.title ?? null}
          activeId={activeId}
          pinned={activeConversation?.pinned ?? false}
          sidebarOpen={sidebarOpen}
          sidebarCollapsed={sidebarCollapsed}
          selectedAgent={selectedAgent}
          model={settings.model}
          providerLabel={providerLabel}
          hasProvider={Boolean(activeModelCredential)}
          onOpenSettings={() => setSettingsOpen(true)}
          context={conversationContext}
          showMeter={prefs.showContextMeter}
          compacting={compacting}
          onCompact={() => void compactConversation()}
          onContextOverride={(values) => void overrideContext(values)}
          onContextReset={() => void resetContextOverrides()}
          onToggleSidebar={() => {
            if (window.innerWidth >= 1024) toggleSidebarCollapsed();
            else setSidebarOpen((v) => !v);
          }}
          onOpenPalette={() => setPaletteOpen(true)}
          onOpenShortcuts={() => setShortcutsOpen(true)}
          onShare={() => setShareOpen(true)}
          onExport={(format) => {
            if (activeId) void exportChat(activeId, format);
          }}
          onFork={() => {
            if (activeId) void forkConversation(activeId);
          }}
          onRename={() => {
            if (!activeConversation) return;
            setRenameDraft(activeConversation.title);
            setRenameOpen(true);
          }}
          onTogglePin={() => {
            if (activeConversation) {
              void patchConversation(activeConversation.id, { pinned: !activeConversation.pinned }).catch(
                () => toast.error("Could not pin chat"),
              );
            }
          }}
          onDelete={() => {
            if (activeId && window.confirm("Delete this conversation?")) void deleteConversation(activeId);
          }}
        />

        {dbStatus === "loading" && (
          <div className="grid flex-1 place-items-center text-muted-foreground">
            <div className="flex items-center gap-2.5 text-[14px]">
              <Loader2 size={17} className="animate-spin" /> Connecting to PostgreSQL…
            </div>
          </div>
        )}
        {dbStatus === "error" && (
          <div className="mx-auto mt-3 flex w-full max-w-[768px] items-center gap-2.5 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-[14px]">
            <AlertCircle size={16} /> Could not load the workspace.{" "}
            <button type="button" onClick={() => void bootstrap()} className="underline underline-offset-2">
              Retry
            </button>
          </div>
        )}
        {dbStatus === "ready" &&
          (isEmpty ? (
            <Hero {...composerProps} onSuggestion={(text) => send(text, [])} />
          ) : (
            <>
              <MessageView
                messages={visibleMessages}
                isStreaming={isStreaming}
                streamingText={streamingText}
                streamingTools={streamingTools}
                pendingUser={pendingUser}
                feedback={feedback}
                prefs={prefs}
                onFeedback={(id, rating) => void rateMessage(id, rating)}
                onCopy={copyText}
                onEditSubmit={editMessage}
                onRegenerate={regenerate}
                onDelete={(id) => void deleteMessage(id)}
              />
              <Composer {...composerProps} variant="dock" />
            </>
          ))}
      </main>

      <span aria-live="polite" className="sr-only">
        {isStreaming ? `Nova is responding${streamingTools.length ? `, using ${streamingTools.length} tools` : ""}` : ""}
      </span>

      <SettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        settings={settings}
        workspaceId={workspaceId}
        onExportAll={() => void exportAll()}
        onDeleteAll={() => void deleteAll()}
        onSave={updateSettings}
      />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        conversations={conversations}
        onSelectConversation={(id) => void selectConversation(id)}
        onNewChat={newChat}
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenAgents={() => setAgentsOpen(true)}
        onOpenTasks={() => setTasksOpen(true)}
        onOpenMemories={() => setMemoriesOpen(true)}
        onOpenTemplates={() => setTemplatesOpen(true)}
        onOpenStats={() => setStatsOpen(true)}
        onOpenFullSettings={() => window.location.href = "/settings"}
        onOpenShortcuts={() => setShortcutsOpen(true)}
        onOpenAbout={() => setAboutOpen(true)}
        onToggleTheme={toggleTheme}
      />
      <AgentsDialog
        open={agentsOpen}
        onOpenChange={setAgentsOpen}
        agents={agents}
        skills={skills}
        selectedId={selectedAgentId}
        onChanged={() => void refreshAgents()}
        onSelect={(id) => {
          selectAgent(id);
          setAgentsOpen(false);
        }}
      />
      <TasksDialog open={tasksOpen} onOpenChange={setTasksOpen} tasks={tasks} onChanged={() => void refreshTasks()} />
      <MemoriesDialog
        open={memoriesOpen}
        onOpenChange={setMemoriesOpen}
        memories={memories}
        onChanged={() => void refreshMemories()}
      />
      <TemplatesDialog
        open={templatesOpen}
        onOpenChange={setTemplatesOpen}
        templates={templates}
        onChanged={() => void refreshTemplates()}
        onInsert={(content) => setComposerPrefill({ text: content, nonce: Date.now() })}
      />
      <StatsDialog open={statsOpen} onOpenChange={setStatsOpen} />
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} conversationId={activeId} />
      <AboutDialog open={aboutOpen} onOpenChange={setAboutOpen} />
      <ShortcutsDialog open={shortcutsOpen} onOpenChange={setShortcutsOpen} />

      <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Rename conversation</DialogTitle>
          </DialogHeader>
          <Input
            autoFocus
            value={renameDraft}
            onChange={(e) => setRenameDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && activeId && renameDraft.trim()) {
                void patchConversation(activeId, { title: renameDraft.trim() });
                setRenameOpen(false);
              }
            }}
            className="text-[14px]"
          />
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setRenameOpen(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={() => {
                if (activeId && renameDraft.trim()) void patchConversation(activeId, { title: renameDraft.trim() });
                setRenameOpen(false);
              }}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
