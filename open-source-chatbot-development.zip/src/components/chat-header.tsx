"use client";

import {
  IconCopy,
  IconDownload,
  IconDots,
  IconFile,
  IconFork,
  IconLink,
  IconPanelLeft,
  IconPanelLeftOpen,
  IconPencil,
  IconPin,
  IconPinOff,
  IconSearch,
  IconSettingsSliders,
  IconTrash,
} from "./sidebar-icons";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { AgentIcon } from "./agent-icon";
import ContextMeter from "./context-meter";
import { cn } from "@/lib/utils";
import type { Agent, ConversationContext } from "@/lib/types";

interface HeaderProps {
  title: string | null;
  activeId: string | null;
  pinned: boolean;
  sidebarOpen: boolean;
  sidebarCollapsed?: boolean;
  selectedAgent: Agent | null;
  model: string;
  providerLabel: string;
  hasProvider: boolean;
  onToggleSidebar: () => void;
  onOpenPalette: () => void;
  onOpenShortcuts: () => void;
  onShare: () => void;
  onExport: (format: "md" | "json") => void;
  onFork: () => void;
  onRename: () => void;
  onTogglePin: () => void;
  onDelete: () => void;
  onOpenSettings: () => void;
  context: ConversationContext | null;
  compacting: boolean;
  onCompact: () => void;
  onContextOverride: (patch: Record<string, unknown>) => void;
  onContextReset: () => void;
  showMeter?: boolean;
}

const iconButton =
  "flex size-8 items-center justify-center rounded-lg text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95";

export default function Header(props: HeaderProps) {
  const showDesktopToggle = props.sidebarCollapsed;

  return (
    <TooltipProvider delayDuration={200}>
      <header className="relative z-20 flex h-14 shrink-0 items-center gap-2 border-b border-border/60 bg-background/80 px-3 backdrop-blur-xl sm:px-4">
        {/* Sidebar Toggle in Main Header */}
        <div className={cn("flex items-center", !showDesktopToggle && "lg:hidden")}>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={props.onToggleSidebar}
                aria-label={props.sidebarCollapsed ? "Expand sidebar" : "Toggle sidebar"}
                className={iconButton}
              >
                {props.sidebarCollapsed ? (
                  <IconPanelLeftOpen size={18} />
                ) : (
                  <IconPanelLeft size={18} />
                )}
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" align="start" className="flex items-center gap-2">
              <span>{props.sidebarCollapsed ? "Expand sidebar" : "Close sidebar"}</span>
              <kbd className="font-mono text-[10px] opacity-60">⌘B</kbd>
            </TooltipContent>
          </Tooltip>
        </div>

        {/* Title & Agent badge */}
        <div className="flex min-w-0 items-center gap-2">
          <h1 className="min-w-0 truncate text-[14.5px] font-medium tracking-[-0.008em] text-foreground">
            {props.title ?? "New conversation"}
          </h1>
          {props.selectedAgent && (
            <span className="hidden shrink-0 items-center gap-1.5 rounded-full border bg-surface-2 px-2 py-[2.5px] text-[11.5px] font-medium text-muted-foreground sm:inline-flex">
              <AgentIcon icon={props.selectedAgent.icon} size={11} />
              {props.selectedAgent.name}
            </span>
          )}
        </div>

        {/* Actions Cluster pinned right */}
        <div className="ml-auto flex shrink-0 items-center gap-1">
          {/* Search Button */}
          <button
            type="button"
            onClick={props.onOpenPalette}
            aria-label="Search conversations"
            title="Search (⌘K)"
            className={cn(iconButton, "sm:hidden")}
          >
            <IconSearch size={16} />
          </button>

          <button
            type="button"
            onClick={props.onOpenPalette}
            className="hidden items-center gap-2 rounded-lg border bg-surface-2 px-2.5 py-1 text-[12px] text-muted-foreground outline-none transition hover:border-foreground/20 hover:text-foreground sm:flex"
          >
            <IconSearch size={13} />
            <span>Search</span>
            <kbd className="rounded border bg-background px-1 py-px font-sans text-[10px]">⌘K</kbd>
          </button>

          {/* Model / Provider status pill */}
          <button
            type="button"
            onClick={props.onOpenSettings}
            className={cn(
              "hidden items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[12px] outline-none transition md:flex",
              props.hasProvider
                ? "bg-surface-2 text-foreground hover:border-foreground/20"
                : "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400",
            )}
            title={props.hasProvider ? "Model & provider settings" : "Connect a provider in Settings"}
          >
            <span
              className={cn(
                "size-1.5 rounded-full",
                props.hasProvider ? "bg-emerald-500" : "bg-amber-500",
              )}
            />
            <span className="max-w-[150px] truncate font-mono text-[11px]">
              {props.hasProvider ? props.model : "No provider"}
            </span>
          </button>

          {/* Context Meter */}
          {props.showMeter !== false && (
            <ContextMeter
              data={props.context}
              busy={false}
              compacting={props.compacting}
              onCompact={props.onCompact}
              onOverride={props.onContextOverride}
              onReset={props.onContextReset}
            />
          )}

          {/* Chat options dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" aria-label="Conversation options" className={iconButton}>
                <IconDots size={18} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onSelect={props.onRename} disabled={!props.activeId}>
                <IconPencil size={15} /> Rename
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={props.onTogglePin} disabled={!props.activeId}>
                {props.pinned ? <IconPinOff size={15} /> : <IconPin size={15} />}
                {props.pinned ? "Unpin" : "Pin to top"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={props.onFork} disabled={!props.activeId}>
                <IconFork size={15} /> Duplicate conversation
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={props.onShare} disabled={!props.activeId}>
                <IconLink size={15} /> Share snapshot
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => props.onExport("md")} disabled={!props.activeId}>
                <IconFile size={15} /> Export as Markdown
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => props.onExport("json")} disabled={!props.activeId}>
                <IconDownload size={15} /> Export as JSON
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={props.onOpenSettings}>
                <IconSettingsSliders size={15} /> Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                variant="destructive"
                disabled={!props.activeId}
                onSelect={props.onDelete}
              >
                <IconTrash size={15} /> Delete conversation
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
    </TooltipProvider>
  );
}
