"use client";

import { useEffect, useState } from "react";
import { Check, Copy, Link2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { copyToClipboard } from "@/lib/clipboard";

export default function ShareDialog({
  open,
  onOpenChange,
  conversationId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conversationId: string | null;
}) {
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open || !conversationId) return;
    setLoading(true);
    fetch(`/api/conversations/${conversationId}/share`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => setToken(data?.link?.token ?? null))
      .finally(() => setLoading(false));
  }, [open, conversationId]);

  const create = async () => {
    if (!conversationId) return;
    const res = await fetch(`/api/conversations/${conversationId}/share`, { method: "POST" });
    if (!res.ok) {
      toast.error("Could not create a share link");
      return;
    }
    const data = (await res.json()) as { link: { token: string } };
    setToken(data.link.token);
    toast.success("Share link created");
  };

  const revoke = async () => {
    if (!conversationId) return;
    const res = await fetch(`/api/conversations/${conversationId}/share`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not revoke the link");
      return;
    }
    setToken(null);
    toast.success("Share link revoked");
  };

  const url = token ? `${window.location.origin}/share/${token}` : "";
  const copy = async () => {
    const ok = await copyToClipboard(url);
    if (!ok) {
      toast.error("Could not copy the link");
      return;
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 size={16} /> Share conversation
          </DialogTitle>
          <DialogDescription>
            Anyone with the link can read a snapshot of this conversation. Links expire
            after 30 days and can be revoked at any time.
          </DialogDescription>
        </DialogHeader>
        {loading ? (
          <p className="text-[13px] text-muted-foreground">Loading…</p>
        ) : token ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 rounded-lg border bg-muted/50 p-2">
              <code className="min-w-0 flex-1 truncate text-[12px]">{url}</code>
              <Button size="sm" variant="outline" onClick={() => void copy()}>
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <div className="flex justify-end">
              <Button size="sm" variant="ghost" onClick={() => void revoke()}>
                <Trash2 size={14} /> Revoke link
              </Button>
            </div>
          </div>
        ) : (
          <Button onClick={() => void create()} disabled={!conversationId}>
            <Link2 size={15} /> Create a share link
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
