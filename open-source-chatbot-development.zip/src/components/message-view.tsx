"use client";

import { useState, type ReactNode } from "react";
import {
  IconCheck,
  IconClose,
  IconCopy,
  IconMemory,
  IconPencil,
  IconRefresh,
  IconSpark,
  IconThumbDown,
  IconThumbUp,
  IconTrash,
} from "./icons";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "./ai-elements/conversation";
import { Shimmer } from "./ai-elements/shimmer";
import { Markdown } from "./markdown";
import { Logo } from "./logo";
import ToolCalls, { type ToolCallView } from "./tool-calls";
import { Button } from "./ui/button";
import { formatDuration, formatTokens, shortTime } from "@/lib/format";
import type { ChatMessage } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";

interface MessageViewProps {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamingText: string;
  streamingTools: ToolCallView[];
  pendingUser: string | null;
  feedback: Record<string, "up" | "down">;
  prefs: Preferences;
  onFeedback: (id: string, rating: "up" | "down" | null) => void;
  onCopy: (text: string) => void;
  onEditSubmit: (id: string, content: string) => void;
  onRegenerate: () => void;
  onDelete: (id: string) => void;
}

function ContextChips({ meta }: { meta?: ChatMessage["contextMeta"] }) {
  if (!meta) return null;
  const memories = meta.injectedMemoryIds?.length ?? 0;
  const usedSkills = meta.usedSkillNames?.length ?? 0;
  if (!memories && !usedSkills && !meta.summarizedMessages && !meta.compacted) return null;
  return (
    <div className="mb-2 flex flex-wrap items-center gap-1.5 text-[11.5px] text-muted-foreground">
      {usedSkills > 0 && (
        <span className="inline-flex items-center gap-1 rounded-full border bg-surface-2 px-2 py-0.5">
          <IconSpark size={10} className="text-brand" />
          {meta.usedSkillNames.slice(0, 2).join(", ")}
          {usedSkills > 2 ? ` +${usedSkills - 2}` : ""}
        </span>
      )}
      {memories > 0 && (
        <span className="inline-flex items-center gap-1 rounded-full border bg-surface-2 px-2 py-0.5" title="Memories injected into this turn">
          <IconMemory size={10} />
          {memories} memor{memories === 1 ? "y" : "ies"}
        </span>
      )}
      {meta.compacted && (
        <span className="inline-flex items-center gap-1 rounded-full border bg-surface-2 px-2 py-0.5" title="Older turns were folded into a summary for this reply">
          compacted {meta.summarizedMessages}
        </span>
      )}
    </div>
  );
}

function ActionButton({
  label,
  onClick,
  active,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "flex size-7 items-center justify-center rounded-md outline-none transition-colors",
        active
          ? "bg-accent text-foreground"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

export default function MessageView(props: MessageViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const lastAssistantId = [...props.messages].reverse().find((m) => m.role === "assistant")?.id;
  const { feedback, prefs } = props;

  const copy = (id: string, text: string) => {
    props.onCopy(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1400);
  };

  const submitEdit = (id: string) => {
    props.onEditSubmit(id, draft);
    setEditingId(null);
  };

  return (
    <Conversation className="min-h-0 flex-1">
      <ConversationContent
        className={cn(
          "nova-thread mx-auto w-full px-4 pb-6 pt-8 sm:px-6",
          prefs.density === "compact" ? "gap-5" : "gap-9",
        )}
      >
        {props.messages.map((message) => {
          const isEditing = editingId === message.id;

          if (message.role === "user") {
            return (
              <div key={message.id} className="animate-message-in group flex flex-col items-end">
                {isEditing ? (
                  <div className="w-full max-w-[88%] rounded-2xl border bg-surface-1 p-3 shadow-sm">
                    <textarea
                      autoFocus
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          submitEdit(message.id);
                        }
                        if (e.key === "Escape") setEditingId(null);
                      }}
                      rows={Math.min(8, Math.max(2, draft.split("\n").length))}
                      className="scroll-slim w-full resize-none bg-transparent px-2 py-1 text-[15px] leading-relaxed outline-none"
                    />
                    <div className="mt-2 flex justify-end gap-2">
                      <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                        <IconClose size={14} /> Cancel
                      </Button>
                      <Button size="sm" onClick={() => submitEdit(message.id)}>
                        Save & resend
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-br-md border bg-surface-2 px-4 py-2.5 text-[15px] leading-relaxed [overflow-wrap:anywhere]">
                    {message.content}
                  </div>
                )}

                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-2 flex flex-wrap justify-end gap-1.5">
                    {message.attachments.map((a) => (
                      <span
                        key={a.name}
                        className="rounded-md border bg-surface-1 px-2 py-1 font-mono text-[11px] text-muted-foreground"
                      >
                        {a.name}
                      </span>
                    ))}
                  </div>
                )}

                {!isEditing && (
                  <div className="mt-1 flex items-center gap-0.5 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
                    <ActionButton label="Copy" onClick={() => copy(message.id, message.content)}>
                      {copiedId === message.id ? <IconCheck size={14} /> : <IconCopy size={14} />}
                    </ActionButton>
                    <ActionButton
                      label="Edit and resend"
                      onClick={() => {
                        setEditingId(message.id);
                        setDraft(message.content);
                      }}
                    >
                      <IconPencil size={14} />
                    </ActionButton>
                    <ActionButton label="Delete" onClick={() => props.onDelete(message.id)}>
                      <IconTrash size={14} />
                    </ActionButton>
                  </div>
                )}
              </div>
            );
          }

          const calls: ToolCallView[] = (message.toolCalls ?? []).map((c) => ({
            id: c.id,
            name: c.name,
            input: c.input,
            output: c.output,
            status: c.status === "error" ? "error" : "done",
          }));
          const isLast = message.id === lastAssistantId;
          const usage = message.usage && message.usage.totalTokens > 0 ? message.usage : null;

          return (
            <div key={message.id} className="animate-message-in group flex gap-3.5">
              <Logo size={26} className="mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex items-baseline gap-2">
                  <span className="text-[13px] font-semibold tracking-tight">Nova</span>
                  {prefs.showTimestamps && (
                    <span className="font-mono text-[10.5px] text-muted-foreground">
                      {shortTime(message.createdAt)}
                    </span>
                  )}
                </div>
                {prefs.showThinking && <ToolCalls calls={calls} />}
                <ContextChips meta={message.contextMeta} />
                <Markdown content={message.content} />

                <div
                  className={cn(
                    "mt-2 flex flex-wrap items-center gap-0.5 transition-opacity focus-within:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100",
                    isLast && !props.isStreaming ? "opacity-100" : "opacity-0",
                  )}
                >
                  <ActionButton label="Copy" onClick={() => copy(message.id, message.content)}>
                    {copiedId === message.id ? <IconCheck size={14} /> : <IconCopy size={14} />}
                  </ActionButton>
                  <ActionButton
                    label="Good response"
                    active={feedback[message.id] === "up"}
                    onClick={() => props.onFeedback(message.id, feedback[message.id] === "up" ? null : "up")}
                  >
                    <IconThumbUp size={14} />
                  </ActionButton>
                  <ActionButton
                    label="Bad response"
                    active={feedback[message.id] === "down"}
                    onClick={() =>
                      props.onFeedback(message.id, feedback[message.id] === "down" ? null : "down")
                    }
                  >
                    <IconThumbDown size={14} />
                  </ActionButton>
                  {isLast && (
                    <ActionButton label="Regenerate" onClick={props.onRegenerate}>
                      <IconRefresh size={14} />
                    </ActionButton>
                  )}
                  <ActionButton label="Delete" onClick={() => props.onDelete(message.id)}>
                    <IconTrash size={14} />
                  </ActionButton>
                  {prefs.showTokenUsage && (message.model || usage) && (
                    <span className="ml-1.5 font-mono text-[10.5px] text-muted-foreground">
                      {message.model}
                      {usage
                        ? ` · ${formatTokens(usage.totalTokens)} tok · ${formatDuration(usage.durationMs)}`
                        : ""}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {props.pendingUser && (
          <div className="animate-message-in flex justify-end">
            <div className="max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-br-md border bg-surface-2 px-4 py-2.5 text-[15px] leading-relaxed [overflow-wrap:anywhere]">
              {props.pendingUser}
            </div>
          </div>
        )}

        {props.isStreaming && (
          <div className="animate-message-in flex gap-3.5">
            <Logo size={26} className="mt-0.5 shrink-0" />
            <div className="min-w-0 flex-1">
              {prefs.showThinking && <ToolCalls calls={props.streamingTools} />}
              {props.streamingText ? (
                <Markdown content={props.streamingText} streaming />
              ) : (
                props.streamingTools.every((t) => t.status !== "running") && (
                  <Shimmer className="text-[15px]" duration={1.6}>
                    Thinking…
                  </Shimmer>
                )
              )}
            </div>
          </div>
        )}
      </ConversationContent>
      <ConversationScrollButton className="bottom-4 border shadow-md" />
    </Conversation>
  );
}
