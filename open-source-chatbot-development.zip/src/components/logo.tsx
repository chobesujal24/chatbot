import { cn } from "@/lib/utils";

/** Nova lettermark — an italic serif "N" on the brand hue. */
export function Logo({ size = 28, className }: { size?: number; className?: string }) {
  return (
    <span
      aria-hidden
      className={cn(
        "inline-flex shrink-0 select-none items-center justify-center rounded-[30%] bg-brand font-serif italic leading-none text-white",
        className,
      )}
      style={{ width: size, height: size, fontSize: Math.round(size * 0.66) }}
    >
      N
    </span>
  );
}
