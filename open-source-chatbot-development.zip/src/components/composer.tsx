"use client";

import { useEffect, useRef, useState, type ChangeEvent, type KeyboardEvent } from "react";
import { toast } from "sonner";
import { IconArrowUp, IconClose, IconPaperclip, IconStop } from "./icons";
import { Button } from "./ui/button";
import { AgentIcon } from "./agent-icon";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import type { Agent, ClientAttachment } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";

interface ComposerProps {
  variant: "hero" | "dock";
  onSend: (text: string, attachments: ClientAttachment[]) => void;
  isStreaming: boolean;
  onStop: () => void;
  agents: Agent[];
  selectedAgent: Agent | null;
  onSelectAgent: (id: string) => void;
  onOpenAgents: () => void;
  model: string;
  providerLabel: string;
  hasProvider: boolean;
  onOpenSettings: () => void;
  prefs: Preferences;
}

const ALLOWED =
  /\.(txt|md|markdown|json|csv|log|js|jsx|ts|tsx|py|rs|go|java|css|html|yml|yaml|sql|xml)$/i;

const DRAFT_KEY = "nova-draft";

const chip =
  "inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-[13px] font-medium text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground data-[state=open]:bg-accent data-[state=open]:text-foreground";

export default function Composer(props: ComposerProps) {
  const [text, setText] = useState("");
  const [attachments, setAttachments] = useState<ClientAttachment[]>([]);
  const [dragging, setDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const hero = props.variant === "hero";

  const resize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  };

  // Restore a saved draft.
  useEffect(() => {
    if (!props.prefs.autosaveDrafts) return;
    const saved = window.localStorage.getItem(DRAFT_KEY);
    if (saved) setText(saved);
  }, [props.prefs.autosaveDrafts]);

  // Persist the draft as you type.
  useEffect(() => {
    if (!props.prefs.autosaveDrafts) return;
    const timer = setTimeout(() => {
      if (text.trim()) window.localStorage.setItem(DRAFT_KEY, text);
      else window.localStorage.removeItem(DRAFT_KEY);
    }, 400);
    return () => clearTimeout(timer);
  }, [text, props.prefs.autosaveDrafts]);

  useEffect(() => {
    if (hero) textareaRef.current?.focus();
  }, [hero]);

  const canSend = text.trim().length > 0 && !props.isStreaming;

  const submit = () => {
    const value = text.trim();
    if (!value || props.isStreaming) return;
    props.onSend(value, attachments);
    setText("");
    setAttachments([]);
    window.localStorage.removeItem(DRAFT_KEY);
    requestAnimationFrame(() => {
      if (textareaRef.current) textareaRef.current.style.height = "auto";
      textareaRef.current?.focus();
    });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key !== "Enter" || event.shiftKey || event.nativeEvent.isComposing) return;
    const modifier = event.metaKey || event.ctrlKey;
    if (props.prefs.sendOnEnter ? !modifier : modifier) {
      event.preventDefault();
      submit();
    }
  };

  const ingestFiles = async (files: File[]) => {
    const limitKb = props.prefs.attachmentLimitKb || 60;
    const next: ClientAttachment[] = [];
    for (const file of files) {
      if (!ALLOWED.test(file.name)) {
        toast.error(`${file.name}: text-based files only`);
        continue;
      }
      if (file.size > limitKb * 1024) {
        toast.error(`${file.name}: max ${limitKb} KB`);
        continue;
      }
      next.push({ name: file.name, content: await file.text() });
    }
    if (next.length > 0) setAttachments((prev) => [...prev, ...next].slice(0, 5));
  };

  const onFiles = async (event: ChangeEvent<HTMLInputElement>) => {
    await ingestFiles(Array.from(event.target.files ?? []));
    event.target.value = "";
  };

  const card = (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragging(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void ingestFiles(Array.from(e.dataTransfer.files ?? []));
      }}
      className={cn(
        dragging && "border-brand ring-2 ring-brand/20",
        "rounded-[1.75rem] border bg-card transition-[border-color,box-shadow] duration-200",
        "shadow-[0_1px_2px_rgb(0_0_0/0.04),0_10px_32px_-14px_rgb(0_0_0/0.14)] dark:shadow-[0_1px_2px_rgb(0_0_0/0.3),0_14px_40px_-16px_rgb(0_0_0/0.6)]",
        "focus-within:border-foreground/25 focus-within:shadow-[0_1px_2px_rgb(0_0_0/0.05),0_16px_44px_-14px_rgb(0_0_0/0.2)]",
      )}
    >
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 px-4 pt-4">
          {attachments.map((a, index) => (
            <span
              key={`${a.name}-${index}`}
              className="inline-flex items-center gap-2 rounded-lg border bg-muted/60 py-1.5 pl-2.5 pr-1.5 text-[13px]"
            >
              <IconPaperclip size={13} className="text-muted-foreground" />
              <span className="max-w-[160px] truncate">{a.name}</span>
              <button
                type="button"
                aria-label={`Remove ${a.name}`}
                onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== index))}
                className="rounded p-0.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <IconClose size={13} />
              </button>
            </span>
          ))}
        </div>
      )}

      <textarea
        ref={textareaRef}
        rows={1}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          resize();
        }}
        onKeyDown={onKeyDown}
        aria-label="Message"
        placeholder={hero ? "Ask Nova anything…" : "Reply to Nova…"}
        className={cn(
          "scroll-slim block w-full resize-none bg-transparent px-5 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground/80",
          hero ? "max-h-[220px] min-h-[64px] pb-1 pt-5" : "max-h-[220px] min-h-[56px] pb-1 pt-4",
        )}
      />

      <div className="flex items-center justify-between gap-2 px-2 pb-2 pt-1">
        <div className="flex min-w-0 items-center gap-1">
          <input
            ref={fileRef}
            type="file"
            multiple
            accept=".txt,.md,.json,.csv,.log,.js,.ts,.tsx,.py,.rs,.go,.css,.html,.yml,.yaml,.sql"
            onChange={onFiles}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            aria-label="Attach a text file"
            title="Attach a text file"
            className="flex size-9 shrink-0 items-center justify-center rounded-full text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground"
          >
            <IconPaperclip size={16} />
          </button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className={chip} aria-label="Choose agent">
                {props.selectedAgent && <AgentIcon icon={props.selectedAgent.icon} size={14} />}
                <span className="max-w-[120px] truncate">
                  {props.selectedAgent?.name ?? "Agent"}
                </span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" side={hero ? "bottom" : "top"} className="w-72 p-1.5">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Agent</DropdownMenuLabel>
              {props.agents.map((agent) => (
                <DropdownMenuItem
                  key={agent.id}
                  onSelect={() => props.onSelectAgent(agent.id)}
                  className="items-start gap-3 rounded-lg p-2.5"
                >
                  <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary">
                    <AgentIcon icon={agent.icon} size={15} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[14px] font-medium">{agent.name}</span>
                    <span className="line-clamp-2 block text-[12px] leading-snug text-muted-foreground">
                      {agent.description}
                    </span>
                  </span>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={props.onOpenAgents} className="rounded-lg">
                Manage agents…
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <button
            type="button"
            onClick={props.onOpenSettings}
            className={cn(chip, "max-w-[160px]")}
            aria-label="Model and provider settings"
            title="Model and provider settings"
          >
            <span className="truncate">
              {props.hasProvider ? props.model : "No provider"}
            </span>
          </button>
        </div>

        {props.isStreaming ? (
          <button
            type="button"
            onClick={props.onStop}
            aria-label="Stop generation"
            title="Stop (Esc)"
            className="flex size-9 shrink-0 items-center justify-center rounded-full bg-foreground text-background outline-none transition hover:opacity-85 active:scale-95"
          >
            <IconStop size={14} />
          </button>
        ) : (
          <button
            type="button"
            onClick={submit}
            disabled={!canSend}
            aria-label="Send message"
            title="Send (Enter)"
            className={cn(
              "flex size-9 shrink-0 items-center justify-center rounded-full outline-none transition active:scale-95",
              canSend
                ? "bg-foreground text-background hover:opacity-90 shadow-xs"
                : "cursor-not-allowed bg-muted text-muted-foreground/50",
            )}
          >
            <IconArrowUp size={17} />
          </button>
        )}
      </div>
    </div>
  );

  if (hero) return card;

  return (
    <div className="relative shrink-0 px-4 pb-3.5 pt-2 sm:px-6">
      <div className="composer-fade pointer-events-none absolute -top-14 left-0 right-0 h-14" />
      <div className="relative mx-auto w-full max-w-[768px]">
        {card}
        <p className="mt-2 text-center text-[11.5px] text-muted-foreground">
          {props.hasProvider
            ? `${props.providerLabel} · ${props.model} — Nova can make mistakes.`
            : "No provider connected. Open Settings to add your API key."}
        </p>
      </div>
    </div>
  );
}
