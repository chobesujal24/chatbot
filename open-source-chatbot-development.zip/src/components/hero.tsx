"use client";

import { useMemo, type ComponentProps } from "react";
import Composer from "./composer";
import { AgentIcon } from "./agent-icon";
import { Logo } from "./logo";
import { Button } from "./ui/button";
import {
  IconCalculator,
  IconCode,
  IconInfo,
  IconPlug,
  IconTemplates,
  type IconProps,
} from "./icons";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";
import type { Agent } from "@/lib/types";

type ComposerProps = ComponentProps<typeof Composer>;

interface HeroProps extends Omit<ComposerProps, "variant"> {
  onSuggestion: (text: string) => void;
  providerLabel: string;
  hasProvider: boolean;
  prefs: Preferences;
}

interface SuggestionItem {
  icon: React.ComponentType<IconProps>;
  label: string;
  prompt: string;
}

const SUGGESTIONS: SuggestionItem[] = [
  { icon: IconCalculator, label: "Calculate (128 + 46) × 3", prompt: "Calculate (128 + 46) * 3" },
  { icon: IconCode, label: "Write a TypeScript retry helper", prompt: "Show me a TypeScript example" },
  { icon: IconTemplates, label: "Show a Markdown table", prompt: "Show me a Markdown table" },
  { icon: IconInfo, label: "What can you do?", prompt: "What can you do?" },
];

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 5) return "Burning the midnight oil";
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function AgentCard({
  agent,
  selected,
  onSelect,
  delay,
}: {
  agent: Agent;
  selected: boolean;
  onSelect: () => void;
  delay: number;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      style={{ animationDelay: `${delay}ms` }}
      className={cn(
        "animate-rise-in group flex items-start gap-3.5 rounded-2xl border p-4 text-left outline-none transition-all duration-200",
        selected
          ? "border-foreground/30 bg-card shadow-sm ring-1 ring-border"
          : "border-border/60 bg-card/60 hover:border-foreground/20 hover:bg-card hover:shadow-xs",
      )}
    >
      <span
        className={cn(
          "flex size-9 shrink-0 items-center justify-center rounded-xl transition-colors",
          selected ? "bg-foreground text-background" : "bg-muted text-foreground/80 group-hover:text-foreground",
        )}
      >
        <AgentIcon icon={agent.icon} size={17} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2 text-[14px] font-medium text-foreground">
          {agent.name}
          <span className="text-[12px] font-normal text-muted-foreground">
            {agent.tools.length} tools
          </span>
        </span>
        <span className="mt-0.5 line-clamp-2 block text-[13px] leading-snug text-muted-foreground">
          {agent.description}
        </span>
      </span>
    </button>
  );
}

export default function Hero({
  onSuggestion,
  providerLabel,
  hasProvider,
  prefs,
  ...composer
}: HeroProps) {
  const hello = useMemo(greeting, []);

  return (
    <div className="grain relative scroll-slim flex min-h-0 flex-1 flex-col items-center overflow-y-auto px-5">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] opacity-[0.5] [background:radial-gradient(60%_60%_at_30%_0%,color-mix(in_oklab,var(--brand)_14%,transparent),transparent_70%)]"
      />
      <div className="relative my-auto w-full max-w-[740px] py-10">
        <div className="animate-rise-in mb-6 flex items-center gap-2.5">
          <Logo size={34} />
          <span className="rounded-full border bg-surface-1/80 px-2.5 py-1 text-[11px] font-medium text-muted-foreground backdrop-blur">
            Bring your own keys
          </span>
        </div>

        <h1
          className="animate-rise-in font-serif text-[40px] leading-[1.08] tracking-[-0.01em] sm:text-[54px]"
          style={{ animationDelay: "60ms" }}
        >
          <span className="text-muted-foreground">{hello}.</span>
          <br />
          What shall we work on?
        </h1>

        {!hasProvider && (
          <div
            className="animate-rise-in mt-7 flex flex-wrap items-center gap-3 rounded-2xl border border-dashed border-border bg-card/40 px-4 py-3.5 backdrop-blur-xs"
            style={{ animationDelay: "100ms" }}
          >
            <span className="flex size-8 items-center justify-center rounded-lg bg-muted text-muted-foreground">
              <IconPlug size={16} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[13.5px] font-medium">No model connected yet</p>
              <p className="text-[12.5px] text-muted-foreground">
                Nova is an interface that connects directly to your own providers.
              </p>
            </div>
            <Button size="sm" onClick={composer.onOpenSettings}>
              Connect a provider
            </Button>
          </div>
        )}

        <div className="animate-rise-in mt-7" style={{ animationDelay: "140ms" }}>
          <Composer
            {...composer}
            variant="hero"
            providerLabel={providerLabel}
            hasProvider={hasProvider}
            prefs={prefs}
          />
        </div>

        <div className="animate-fade-in mt-4 flex flex-wrap gap-2" style={{ animationDelay: "260ms" }}>
          {SUGGESTIONS.map((s) => (
            <button
              key={s.label}
              type="button"
              onClick={() => onSuggestion(s.prompt)}
              className="inline-flex items-center gap-2 rounded-full border bg-card/70 px-3.5 py-2 text-[13px] text-foreground/85 outline-none transition hover:border-foreground/25 hover:bg-card hover:text-foreground active:scale-[0.98]"
            >
              <s.icon size={14} className="text-muted-foreground" />
              <span>{s.label}</span>
            </button>
          ))}
        </div>

        {composer.agents.length > 0 && (
          <div className="mt-11">
            <p
              className="animate-fade-in mb-3 text-[13px] font-medium text-muted-foreground"
              style={{ animationDelay: "300ms" }}
            >
              Choose an agent
            </p>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {composer.agents.slice(0, 6).map((agent, i) => (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  selected={agent.id === composer.selectedAgent?.id}
                  onSelect={() => composer.onSelectAgent(agent.id)}
                  delay={320 + i * 50}
                />
              ))}
            </div>
          </div>
        )}

        {hasProvider && (
          <p
            className="animate-fade-in mt-8 flex items-center gap-2 text-[12.5px] text-muted-foreground"
            style={{ animationDelay: "500ms" }}
          >
            <span className="size-1.5 rounded-full bg-emerald-500" />
            Connected to {providerLabel} · {composer.model}
          </p>
        )}
      </div>
    </div>
  );
}
