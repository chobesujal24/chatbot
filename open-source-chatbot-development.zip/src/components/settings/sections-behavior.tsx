"use client";

import { useMemo } from "react";
import { SlidersHorizontal, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Collapsible, Field, NumberField, Note, Panel, Reveal, Segmented, Slider } from "./ui";
import { TOOL_META } from "@/lib/tool-meta";
import { buildBreakdown } from "@/lib/context";
import { cn } from "@/lib/utils";
import type { Preferences } from "@/lib/preferences-model";

type Patch = (values: Partial<Preferences>) => void;
const kfmt = (v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v));

/* ── Generation ────────────────────────────────────────────────────────────── */

export function ResponseSection({ prefs, patch, hasModel }: { prefs: Preferences; patch: Patch; hasModel: boolean }) {
  const stopList = useMemo(
    () => prefs.stopSequences.split(",").map((s) => s.trim()).filter(Boolean),
    [prefs.stopSequences],
  );

  return (
    <div className="space-y-5">
      {!hasModel && (
        <Note tone="warn">
          These parameters apply as soon as a provider is connected. Nova is currently answering
          from its offline responder.
        </Note>
      )}

      <Panel title="Sampling" hint="Used for every request unless the agent overrides them.">
        <Field label="Temperature" hint="Lower is deterministic, higher is exploratory.">
          <Slider value={prefs.temperature} min={0} max={2} step={0.05} label="Temperature"
            format={(v) => v.toFixed(2)} onChange={(temperature) => patch({ temperature })} className="w-[260px]" />
        </Field>
        <Field label="Top-p" hint="Nucleus sampling. Leave near 1 unless you know why.">
          <Slider value={prefs.topP} min={0.1} max={1} step={0.05} label="Top-p"
            format={(v) => v.toFixed(2)} onChange={(topP) => patch({ topP })} className="w-[260px]" />
        </Field>
        <Field label="Presence penalty" hint="Discourages reusing topics already mentioned.">
          <Slider value={prefs.presencePenalty} min={-2} max={2} step={0.1} label="Presence penalty"
            format={(v) => v.toFixed(1)} onChange={(presencePenalty) => patch({ presencePenalty })} className="w-[260px]" />
        </Field>
        <Field label="Frequency penalty" hint="Discourages repeating the same words.">
          <Slider value={prefs.frequencyPenalty} min={-2} max={2} step={0.1} label="Frequency penalty"
            format={(v) => v.toFixed(1)} onChange={(frequencyPenalty) => patch({ frequencyPenalty })} className="w-[260px]" />
        </Field>
      </Panel>

      <Panel title="Output">
        <Field label="Max output tokens" hint="Hard ceiling per reply.">
          <Slider value={prefs.outputBudget} min={256} max={16384} step={256} label="Output budget"
            format={kfmt} onChange={(outputBudget) => patch({ outputBudget })} className="w-[260px]" />
        </Field>
        <Field label="Retries" hint="Attempts on a transient provider error before failing.">
          <NumberField value={prefs.maxRetries} min={0} max={6} ariaLabel="Retries" onChange={(maxRetries) => patch({ maxRetries })} />
        </Field>
        <Field label="Stop sequences" hint="Comma separated. Generation halts on the first match." align="start">
          <div className="w-[260px] space-y-2">
            <Input value={prefs.stopSequences} onChange={(e) => patch({ stopSequences: e.target.value })}
              placeholder="
, END" className="font-mono text-[12.5px]" />
            {stopList.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {stopList.map((s) => (
                  <span key={s} className="rounded border bg-muted/60 px-1.5 py-0.5 font-mono text-[11px]">
                    {s === "\n" ? "\\n" : s}
                  </span>
                ))}
              </div>
            )}
          </div>
        </Field>
        <Field label="Reveal streaming text" hint="Smooth reveal eases fast token bursts. Off renders immediately.">
          <Segmented ariaLabel="Reveal mode" value={prefs.reveal}
            onChange={(reveal) => patch({ reveal })}
            options={[{ value: "smooth", label: "Smooth" }, { value: "off", label: "Instant" }]} />
        </Field>
      </Panel>

      <Panel title="System prompt" hint="Supports variables the server expands per request." dense>
        <div className="p-2.5">
          <Textarea value={prefs.systemPrompt} onChange={(e) => patch({ systemPrompt: e.target.value })} rows={5}
            placeholder="You are a precise assistant for …" className="resize-y text-[13px]" />
          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <span className="text-[12px] text-muted-foreground">Insert:</span>
            {["{{model}}", "{{agent}}", "{{date}}", "{{memories}}", "{{skills}}"].map((token) => (
              <button key={token} type="button"
                onClick={() => patch({ systemPrompt: `${prefs.systemPrompt}${prefs.systemPrompt.endsWith(" ") || !prefs.systemPrompt ? "" : " "}${token} ` })}
                className="rounded border bg-card px-1.5 py-0.5 font-mono text-[11px] text-muted-foreground transition hover:border-foreground/25 hover:text-foreground active:scale-95">
                {token}
              </button>
            ))}
          </div>
        </div>
      </Panel>
    </div>
  );
}

/* ── Tools ────────────────────────────────────────────────────────────────── */

export function ToolsSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  const off = new Set(prefs.disabledTools);
  const toggle = (name: string, enabled: boolean) => {
    const next = new Set(off);
    if (enabled) next.delete(name);
    else next.add(name);
    patch({ disabledTools: [...next] });
  };
  const groups = ["core", "web", "memory", "skills", "workspace"] as const;

  return (
    <div className="space-y-5">
      <Panel title="Available tools" hint="Turning a tool off here removes it from every agent, including new turns of running chats.">
        <div className="divide-y">
          {groups.map((group) => {
            const items = TOOL_META.filter((t) => t.group === group);
            if (!items.length) return null;
            return (
              <div key={group} className="px-2.5 py-3">
                <p className="mb-2 text-[10.5px] font-semibold uppercase tracking-[0.09em] text-muted-foreground">{group}</p>
                <div className="grid gap-1.5 sm:grid-cols-2">
                  {items.map((tool) => {
                    const enabled = !off.has(tool.name);
                    return (
                      <div key={tool.name} className={cn("flex items-start gap-3 rounded-lg border px-2.5 py-2 transition",
                        enabled ? "border-transparent bg-muted/45" : "border-border bg-card")}>
                        <span className={cn("mt-1 size-2 shrink-0 rounded-full transition-colors", enabled ? "bg-emerald-500" : "bg-muted-foreground/30")} />
                        <span className="min-w-0 flex-1">
                          <span className="block font-mono text-[12px] font-medium">{tool.name}</span>
                          <span className="mt-0.5 block text-[11.5px] leading-snug text-muted-foreground">{tool.description}</span>
                        </span>
                        <Switch checked={enabled} onCheckedChange={(v) => toggle(tool.name, v)} aria-label={`Enable ${tool.name}`} />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      <Panel title="Tool limits">
        <Field label="Web search results" hint="Passed to your search provider per query.">
          <NumberField value={prefs.searchResults} min={1} max={10} ariaLabel="Search results" onChange={(searchResults) => patch({ searchResults })} />
        </Field>
        <Field label="Page read limit" hint="Maximum characters a reader returns per page.">
          <NumberField value={prefs.fetchMaxKb} min={10} max={500} step={10} suffix="KB" ariaLabel="Fetch size limit" onChange={(fetchMaxKb) => patch({ fetchMaxKb })} />
        </Field>
        <Field label="Fetch timeout" hint="Abort a page read after this many seconds.">
          <NumberField value={prefs.fetchTimeoutSec} min={3} max={60} step={1} suffix="s" ariaLabel="Fetch timeout" onChange={(fetchTimeoutSec) => patch({ fetchTimeoutSec })} />
        </Field>
      </Panel>

      <Collapsible title="Sandbox test" hint="Run a single tool exactly as an agent would, against your live configuration."
        badge={<span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">dev</span>}>
        <SandboxTester />
      </Collapsible>
    </div>
  );
}

function SandboxTester() {
  return (
    <div className="space-y-3 p-3">
      <p className="text-[12.5px] leading-relaxed text-muted-foreground">
        Arithmetic runs locally and is exact. Web tools call the provider configured in Integrations,
        so they only work once a key is stored.
      </p>
      <div className="flex flex-wrap gap-1.5">
        {["calculator", "webSearch", "webFetch", "recall"].map((name) => (
          <span key={name} className="rounded-md border bg-card px-2 py-1 font-mono text-[11.5px] text-muted-foreground">{name}</span>
        ))}
      </div>
    </div>
  );
}

/* ── Context ───────────────────────────────────────────────────────────────── */

export function ContextSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  const preview = useMemo(
    () =>
      buildBreakdown({
        system: prefs.systemPrompt || "You are a precise assistant.",
        skillsIndex: prefs.showSkillsIndex ? "# Skills\n- four skills listed in the index" : "",
        memoryBlock: prefs.injectMemories
          ? `# Long-term memory\n${Array.from({ length: prefs.memoryLimit }, (_, i) => `- [fact] example remembered fact ${i + 1}`).join("\n")}`
          : "",
        history: Array.from({ length: Math.min(prefs.maxHistoryMessages, 24) }, () => ({
          role: "user",
          content: "An example conversation turn of roughly forty words of ordinary context.",
        })),
        settings: {
          maxHistoryMessages: prefs.maxHistoryMessages,
          injectMemories: prefs.injectMemories,
          memoryLimit: prefs.memoryLimit,
          includeSkills: prefs.showSkillsIndex,
          autoCompact: prefs.autoCompact,
          compactThreshold: prefs.compactThreshold,
          contextWindow: prefs.contextWindow,
          outputBudget: prefs.outputBudget,
        },
      }),
    [prefs],
  );

  const used = Math.round(preview.promptTokens + prefs.outputBudget);
  const ratio = prefs.contextWindow ? used / prefs.contextWindow : 0;

  return (
    <div className="space-y-5">
      <Panel title="Budget" hint="Everything the model receives, and when old turns get folded away.">
        <Field label="Context window" hint="Your model's window. Drives the meter and compaction maths.">
          <Slider value={prefs.contextWindow} min={8192} max={1_000_000} step={8192} label="Context window"
            format={(v) => `${Math.round(v / 1000)}k`} onChange={(contextWindow) => patch({ contextWindow })} className="w-[280px]" />
        </Field>
        <Field label="History depth" hint="Most recent messages sent with every request.">
          <Slider value={prefs.maxHistoryMessages} min={2} max={80} step={1} label="History depth"
            onChange={(maxHistoryMessages) => patch({ maxHistoryMessages })} className="w-[280px]" />
        </Field>
        <Field label="Compact at" hint="Auto-compaction starts once the window is this full.">
          <Slider value={prefs.compactThreshold} min={0.4} max={0.95} step={0.01} label="Compact threshold"
            format={(v) => `${Math.round(v * 100)}%`} onChange={(compactThreshold) => patch({ compactThreshold })} className="w-[280px]" />
        </Field>
        <Field label="Compact down to" hint="How much room compaction tries to win back.">
          <Slider value={prefs.compactTargetRatio} min={0.2} max={0.9} step={0.01} label="Compact target"
            format={(v) => `${Math.round(v * 100)}%`} onChange={(compactTargetRatio) => patch({ compactTargetRatio })} className="w-[280px]" />
        </Field>
        <Field label="Keep whole exchanges" hint="Fold user and assistant turns in pairs instead of splitting an exchange.">
          <Switch checked={prefs.keepPairs} onCheckedChange={(keepPairs) => patch({ keepPairs })} aria-label="Keep whole exchanges" />
        </Field>
        <Field label="Auto-compact" hint="Off means long threads simply drop older turns.">
          <Switch checked={prefs.autoCompact} onCheckedChange={(autoCompact) => patch({ autoCompact })} aria-label="Auto-compact" />
        </Field>
      </Panel>

      <Panel title="Prompt shape" hint="A sample thread with the current settings." actions={
        <span className={cn("rounded-full px-2 py-0.5 font-mono text-[11px]",
          ratio > 1 ? "bg-destructive/10 text-destructive" : ratio > prefs.compactThreshold ? "bg-amber-500/10 text-amber-700 dark:text-amber-400" : "bg-muted text-muted-foreground")}>
          {Math.round(ratio * 100)}% used
        </span>
      }>
        <div className="space-y-3 p-3">
          <div className="flex h-2 overflow-hidden rounded-full bg-muted">
            {preview.segments.map((s, i) => (
              <Reveal key={s.id} index={i} className="h-full">
                <div className={cn("h-full", SEG[s.id] ?? "bg-muted-foreground")}
                  style={{ width: `${Math.max(2, (s.tokens / Math.max(1, prefs.contextWindow)) * 100)}%`, height: "0.5rem" }} />
              </Reveal>
            ))}
          </div>
          <ul className="flex flex-wrap gap-x-4 gap-y-1.5">
            {preview.segments.map((s) => (
              <li key={s.id} className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
                <span className={cn("size-2 rounded-[2px]", SEG[s.id] ?? "bg-muted-foreground")} />
                {s.label}
                <span className="font-mono">{s.tokens.toLocaleString()}</span>
              </li>
            ))}
            <li className="ml-auto text-[11.5px] text-muted-foreground">
              free <span className="font-mono">{Math.max(0, prefs.contextWindow - used).toLocaleString()}</span>
            </li>
          </ul>
        </div>
      </Panel>

      <Panel title="Meter">
        <Field label="Show the context meter" hint="The ring in the chat header, with per-conversation controls.">
          <Switch checked={prefs.showContextMeter} onCheckedChange={(showContextMeter) => patch({ showContextMeter })} aria-label="Show context meter" />
        </Field>
        <Field label="Trust provider token counts" hint="Use exact counts from the provider once a reply completes, instead of estimates.">
          <Switch checked={prefs.trustProviderTokens} onCheckedChange={(trustProviderTokens) => patch({ trustProviderTokens })} aria-label="Trust provider token counts" />
        </Field>
      </Panel>
    </div>
  );
}

const SEG: Record<string, string> = {
  system: "bg-slate-400",
  skills: "bg-purple-400",
  memory: "bg-teal-400",
  summary: "bg-indigo-400",
  history: "bg-brand",
  attachments: "bg-zinc-400",
};

/* ── Composer ─────────────────────────────────────────────────────────────── */

export function ComposerSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  return (
    <div className="space-y-5">
      <Panel title="Composer">
        <Field label="Enter sends the message" hint="Off: Enter adds a newline and Cmd/Ctrl+Enter sends.">
          <Switch checked={prefs.sendOnEnter} onCheckedChange={(sendOnEnter) => patch({ sendOnEnter })} aria-label="Enter sends" />
        </Field>
        <Field label="Autosave drafts" hint="Keeps unsent text in this browser between visits.">
          <Switch checked={prefs.autosaveDrafts} onCheckedChange={(autosaveDrafts) => patch({ autosaveDrafts })} aria-label="Autosave drafts" />
        </Field>
        <Field label="Attachment size limit" hint="Per text file, before Nova refuses it.">
          <NumberField value={prefs.attachmentLimitKb} min={5} max={500} step={5} suffix="KB" ariaLabel="Attachment limit"
            onChange={(attachmentLimitKb) => patch({ attachmentLimitKb })} />
        </Field>
      </Panel>

      <Panel title="Feedback">
        <Field label="Play a sound when a reply finishes" hint="A short synthesised chime. No audio files are shipped.">
          <Switch checked={prefs.soundOnComplete} onCheckedChange={(soundOnComplete) => patch({ soundOnComplete })} aria-label="Sound on complete" />
        </Field>
        <Field label="Desktop notifications" hint="Asks the browser for permission when enabled.">
          <Switch checked={prefs.notificationsEnabled} onCheckedChange={(notificationsEnabled) => patch({ notificationsEnabled })} aria-label="Desktop notifications" />
        </Field>
      </Panel>
    </div>
  );
}

/* ── Advanced ─────────────────────────────────────────────────────────────── */

export function AdvancedSection({ prefs, patch, onReset }: { prefs: Preferences; patch: Patch; onReset: () => void }) {
  const headerText = useMemo(() => (Object.keys(prefs.customHeaders).length ? JSON.stringify(prefs.customHeaders, null, 2) : ""), [prefs.customHeaders]);

  const applyHeaders = (raw: string) => {
    try {
      const parsed = JSON.parse(raw || "{}") as Record<string, string>;
      patch({ customHeaders: parsed });
    } catch {
      // ignore malformed edits until the field is valid
    }
  };

  return (
    <div className="space-y-5">
      <Panel title="Requests" hint="Applies to model calls made by this deployment.">
        <Field label="Request timeout" hint="Give up on a stalled provider after this long.">
          <NumberField value={prefs.requestTimeout} min={5} max={300} step={5} suffix="s" ariaLabel="Request timeout"
            onChange={(requestTimeout) => patch({ requestTimeout })} />
        </Field>
      </Panel>

      <Panel title="Custom headers" hint="Sent with every model request. OpenRouter and gateways often require a referer or title." dense>
        <div className="p-2.5">
          <Textarea defaultValue={headerText} onChange={(e) => applyHeaders(e.target.value)} rows={5}
            placeholder={'{\n  "HTTP-Referer": "https://example.com",\n  "X-Title": "Nova"\n}'}
            className="resize-y font-mono text-[12.5px]" />
          <p className="mt-2 text-[11.5px] text-muted-foreground">
            Names must be plain tokens. Values are capped at 500 characters.
          </p>
        </div>
      </Panel>

      <Panel title="Danger zone">
        <Field label="Reset all preferences" hint="Restores every workspace default. Conversations, skills and memory are untouched.">
          <Button variant="outline" size="sm" onClick={onReset}>
            <SlidersHorizontal size={13} /> Reset preferences
          </Button>
        </Field>
      </Panel>

      <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
        <Terminal size={13} />
        <span>Preferences are stored per workspace in PostgreSQL, and applied by the server on every request.</span>
      </div>
    </div>
  );
}
