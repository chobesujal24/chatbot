"use client";

import { motion, type Variants } from "framer-motion";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { ChevronDown, ChevronUp, Info } from "lucide-react";
import { cn } from "@/lib/utils";

/* ── Motion vocabulary ───────────────────────────────────────────────────── */

const EASE = [0.22, 1, 0.3, 1] as const;

export const rise: Variants = {
  hidden: { opacity: 0, y: 10 },
  show: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.42, ease: EASE, delay: Math.min(0.32, i * 0.045) },
  }),
};

export function Reveal({
  children,
  index = 0,
  className,
}: {
  children: ReactNode;
  index?: number;
  className?: string;
}) {
  return (
    <motion.div className={className} custom={index} initial="hidden" animate="show" variants={rise}>
      {children}
    </motion.div>
  );
}

/** Shared-layout highlight that slides between list items. */
export function ActivePill({ id }: { id: string }) {
  return (
    <motion.span
      layoutId={id}
      className="absolute inset-0 -z-10 rounded-lg bg-accent"
      transition={{ type: "spring", stiffness: 520, damping: 40, mass: 0.7 }}
    />
  );
}

/* ── Structure ───────────────────────────────────────────────────────────── */

export function SectionIntro({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b pb-5">
      <div className="min-w-0 max-w-2xl">
        <h2 className="text-[22px] font-semibold leading-tight tracking-[-0.02em]">{title}</h2>
        {description && (
          <p className="mt-1.5 text-[13.5px] leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Panel({
  title,
  hint,
  actions,
  children,
  className,
  dense,
}: {
  title?: string;
  hint?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  dense?: boolean;
}) {
  return (
    <section className={cn("overflow-hidden rounded-xl border bg-card", className)}>
      {(title || actions) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-muted/35 px-4 py-2.5">
          <div className="min-w-0">
            {title && <h3 className="text-[13px] font-semibold tracking-tight">{title}</h3>}
            {hint && <p className="mt-0.5 text-[12px] leading-snug text-muted-foreground">{hint}</p>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-1.5">{actions}</div>}
        </header>
      )}
      <div className={cn(dense ? "divide-y" : "p-1.5")}>{children}</div>
    </section>
  );
}

/** Label + hint on the left, control pinned right. Wraps on narrow screens. */
export function Field({
  label,
  hint,
  htmlFor,
  children,
  align = "center",
}: {
  label: ReactNode;
  hint?: ReactNode;
  htmlFor?: string;
  children: ReactNode;
  align?: "center" | "start";
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-2.5 px-2.5 py-3 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center sm:justify-between sm:gap-8",
        align === "start" && "sm:items-start",
      )}
    >
      <div className="min-w-0 flex-1">
        <label htmlFor={htmlFor} className="block cursor-default text-[13.5px] font-medium leading-snug">
          {label}
        </label>
        {hint && (
          <p className="mt-1 max-w-[54ch] text-[12.5px] leading-relaxed text-muted-foreground">{hint}</p>
        )}
      </div>
      <div className="flex shrink-0 items-center justify-start sm:justify-end">{children}</div>
    </div>
  );
}

/* ── Controls ────────────────────────────────────────────────────────────── */

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  ariaLabel,
  size = "md",
}: {
  value: T;
  options: Array<{ value: T; label: string; icon?: ReactNode }>;
  onChange: (value: T) => void;
  ariaLabel?: string;
  size?: "sm" | "md";
}) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className="relative inline-flex rounded-lg border bg-muted/50 p-0.5">
      {options.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(option.value)}
            className={cn(
              "relative isolate inline-flex items-center gap-1.5 rounded-[7px] font-medium outline-none transition-colors",
              size === "sm" ? "px-2 py-1 text-[12px]" : "px-2.5 py-1.5 text-[12.5px]",
              active ? "text-background" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {active && (
              <motion.span
                layoutId={`seg-${ariaLabel ?? "x"}-${options.map((o) => o.value).join("")}`}
                className="absolute inset-0 -z-10 rounded-[7px] bg-foreground"
                transition={{ type: "spring", stiffness: 620, damping: 42, mass: 0.6 }}
              />
            )}
            {option.icon}
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

export function Slider({
  value,
  min,
  max,
  step = 1,
  onChange,
  format,
  marks,
  className,
  label,
}: {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  format?: (value: number) => string;
  marks?: Array<{ at: number; label: string }>;
  className?: string;
  label?: string;
}) {
  const shown = format ? format(value) : String(value);
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className={cn("min-w-[190px]", className)}>
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <div className="pointer-events-none absolute top-1/2 h-1 w-full -translate-y-1/2 overflow-hidden rounded-full bg-border">
            <div
              className="h-full rounded-full bg-brand transition-[width] duration-150 ease-out"
              style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
            />
          </div>
          <input
            type="range"
            aria-label={label}
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            className="nova-range relative w-full"
          />
        </div>
        <span className="w-14 shrink-0 rounded-md border bg-muted/60 py-0.5 text-center font-mono text-[11.5px] tabular-nums">
          {shown}
        </span>
      </div>
      {marks && marks.length > 0 && (
        <div className="mt-1 flex justify-between pl-0.5 pr-14 text-[10.5px] text-muted-foreground/80">
          {marks.map((m) => (
            <span key={m.at}>{m.label}</span>
          ))}
        </div>
      )}
    </div>
  );
}

export function NumberField({
  value,
  min,
  max,
  step = 1,
  onChange,
  suffix,
  ariaLabel,
}: {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  suffix?: string;
  ariaLabel?: string;
}) {
  const set = (next: number) => onChange(Math.min(max, Math.max(min, next)));
  return (
    <div className="inline-flex items-stretch overflow-hidden rounded-lg border bg-card">
      <button
        type="button"
        aria-label="Decrease"
        onClick={() => set(value - step)}
        disabled={value <= min}
        className="px-2 text-muted-foreground transition hover:bg-accent hover:text-foreground disabled:opacity-35"
      >
        <svg width="10" height="2" viewBox="0 0 10 2" fill="none" aria-hidden>
          <path d="M0 1h10" stroke="currentColor" strokeWidth="1.6" />
        </svg>
      </button>
      <input
        aria-label={ariaLabel}
        value={`${value}${suffix ? ` ${suffix}` : ""}`}
        onChange={(e) => {
          const parsed = Number(e.target.value.replace(/[^\d.-]/g, ""));
          if (Number.isFinite(parsed)) set(parsed);
        }}
        className="w-[86px] border-x bg-transparent py-1.5 text-center font-mono text-[12.5px] tabular-nums outline-none"
        readOnly
      />
      <button
        type="button"
        aria-label="Increase"
        onClick={() => set(value + step)}
        disabled={value >= max}
        className="px-2 text-muted-foreground transition hover:bg-accent hover:text-foreground disabled:opacity-35"
      >
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden>
          <path d="M5 1v8M1 5h8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      </button>
    </div>
  );
}

export function Chip({
  active,
  onClick,
  children,
  count,
  title,
}: {
  active?: boolean;
  onClick?: () => void;
  children: ReactNode;
  count?: number;
  title?: string;
}) {
  const Comp = onClick ? "button" : "span";
  return (
    <Comp
      type={onClick ? "button" : undefined}
      onClick={onClick}
      title={title}
      aria-pressed={onClick ? Boolean(active) : undefined}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[11.5px] font-medium transition",
        active
          ? "border-transparent bg-foreground text-background"
          : "bg-card text-muted-foreground",
        onClick && !active && "hover:border-foreground/25 hover:text-foreground",
        onClick && "outline-none active:scale-[0.97]",
      )}
    >
      {children}
      {count !== undefined && (
        <span className={cn("font-mono tabular-nums", active ? "opacity-70" : "opacity-60")}>{count}</span>
      )}
    </Comp>
  );
}

/* ── Data display ────────────────────────────────────────────────────────── */

export function StatTile({
  label,
  value,
  hint,
  index = 0,
  format = (n: number) => n.toLocaleString(),
}: {
  label: string;
  value: number;
  hint?: string;
  index?: number;
  format?: (value: number) => string;
}) {
  const displayed = useCountUp(value);
  return (
    <Reveal index={index}>
      <div className="group rounded-xl border bg-card px-3.5 py-3 transition-colors hover:border-foreground/20">
        <p className="font-mono text-[20px] font-medium leading-none tracking-[-0.02em] tabular-nums">
          {format(displayed)}
        </p>
        <p className="mt-2 text-[10.5px] font-semibold uppercase tracking-[0.07em] text-muted-foreground">
          {label}
        </p>
        {hint && <p className="mt-0.5 text-[11.5px] text-muted-foreground/80">{hint}</p>}
      </div>
    </Reveal>
  );
}

/** Eases a number toward its target so stats feel alive rather than snapped in. */
export function useCountUp(target: number, duration = 520) {
  const [shown, setShown] = useState(target);
  const fromRef = useRef(target);
  useEffect(() => {
    const animationsOff = document.documentElement.dataset.animations === "off";
    if (animationsOff || target === fromRef.current) {
      fromRef.current = target;
      setShown(target);
      return;
    }
    const from = fromRef.current;
    const start = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - (1 - t) ** 3;
      setShown(Math.round(from + (target - from) * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
      else fromRef.current = target;
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);
  return shown;
}

export function Bar({
  segments,
  className,
  animated = true,
}: {
  segments: Array<{ id: string; label: string; tokens: number; color: string }>;
  className?: string;
  animated?: boolean;
}) {
  const total = Math.max(1, segments.reduce((sum, s) => sum + s.tokens, 0));
  return (
    <div className={cn("flex h-2 w-full gap-0.5 overflow-hidden rounded-full bg-muted", className)}>
      {segments.map((segment, i) => (
        <motion.span
          key={segment.id}
          title={`${segment.label}: ${segment.tokens.toLocaleString()} tokens`}
          className="h-full rounded-full"
          style={{ background: segment.color }}
          initial={animated ? { width: 0 } : false}
          animate={{ width: `${(segment.tokens / total) * 100}%` }}
          transition={{ duration: 0.6, ease: EASE, delay: i * 0.05 }}
        />
      ))}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
      className="flex flex-col items-center rounded-xl border border-dashed px-6 py-14 text-center"
    >
      {icon && (
        <span className="mb-3 flex size-11 items-center justify-center rounded-xl bg-muted text-muted-foreground">
          {icon}
        </span>
      )}
      <p className="text-[14px] font-medium">{title}</p>
      {description && (
        <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </motion.div>
  );
}

/* ── Disclosure ──────────────────────────────────────────────────────────── */

export function Collapsible({
  title,
  hint,
  children,
  defaultOpen = false,
  badge,
}: {
  title: string;
  hint?: string;
  children: ReactNode;
  defaultOpen?: boolean;
  badge?: ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="overflow-hidden rounded-xl border bg-card">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-muted/40"
      >
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2 text-[13px] font-semibold">
            {title}
            {badge}
          </span>
          {hint && <span className="mt-0.5 block text-[12px] text-muted-foreground">{hint}</span>}
        </span>
        {open ? <ChevronUp size={15} className="text-muted-foreground" /> : <ChevronDown size={15} className="text-muted-foreground" />}
      </button>
      <motion.div
        id={`disclosure-${title.replace(/\W+/g, "-").toLowerCase()}`}
        initial={false}
        animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
        transition={{ duration: 0.26, ease: EASE }}
        aria-hidden={!open}
        inert={!open}
        className="overflow-hidden"
      >
        <div className="divide-y border-t">{children}</div>
      </motion.div>
    </section>
  );
}

export function Note({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "warn" | "ok" }) {
  return (
    <p
      className={cn(
        "flex items-start gap-2 rounded-lg border px-3 py-2.5 text-[12.5px] leading-relaxed",
        tone === "info" && "border-border bg-muted/45 text-muted-foreground",
        tone === "warn" && "border-amber-500/35 bg-amber-500/10 text-amber-800 dark:text-amber-300",
        tone === "ok" && "border-emerald-500/30 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300",
      )}
    >
      <Info size={13} className="mt-0.5 shrink-0" />
      <span className="min-w-0 flex-1">{children}</span>
    </p>
  );
}

export const CONTROLS = "min-w-[220px] sm:w-[260px]";
