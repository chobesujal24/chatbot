"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  CircleAlert,
  ExternalLink,
  Eye,
  EyeOff,
  Loader2,
  RefreshCw,
  RotateCcw,
  Search,
  Star,
  Trash2,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ActivePill, Field, Note, Segmented } from "./ui";
import { findProvider, providersForKind, type CredentialKind, type ProviderPreset } from "@/lib/providers";
import { cn } from "@/lib/utils";

export interface CredentialRow {
  id: string;
  provider: string;
  kind: CredentialKind;
  label: string;
  hasKey: boolean;
  keyPreview: string;
  baseURL: string | null;
  options: Record<string, unknown>;
  enabled: boolean;
  isActive: boolean;
  updatedAt: string;
}

interface Props {
  kind: CredentialKind;
  credentials: CredentialRow[];
  onChanged: () => void | Promise<void>;
  onUseModel?: (model: string, providerId: string) => void;
  defaultModel?: string;
  focusProvider?: string | null;
}

const TINT: Record<string, string> = {
  openai: "#10a37f",
  anthropic: "#d4a27f",
  google: "#4285f4",
  perplexity: "#20808d",
  ollama: "#8b8b8b",
  lmstudio: "#6c5ce7",
  vllm: "#e17055",
  openrouter: "#7c6cf0",
  deepseek: "#4d6bfe",
  groq: "#f55036",
  together: "#00c2a8",
  xai: "#111111",
  mistral: "#fa5300",
  fireworks: "#e8447a",
  cerebras: "#0f6fff",
  siliconflow: "#7a5af8",
  huggingface: "#ffca28",
  custom: "#64748b",
  firecrawl: "#ff5c1f",
  tavily: "#3fb9a8",
  brave: "#fb9a24",
  exa: "#7c3aed",
  serper: "#2563eb",
  serpapi: "#0ea5e9",
  "jina-search": "#f43f5e",
  you: "#0891b2",
  jina: "#f43f5e",
};

const mark = (label: string) => label.replace(/[^A-Za-z]/g, "").slice(0, 1).toUpperCase() || "•";

const GROUPS: Array<{ id: ProviderPreset["group"]; label: string }> = [
  { id: "hosted", label: "Hosted APIs" },
  { id: "local", label: "Local runtimes" },
  { id: "search", label: "Search" },
  { id: "reader", label: "Readers" },
];

interface TestState {
  ok: boolean;
  message: string;
  latencyMs?: number;
}

export default function SettingsProviders({
  kind,
  credentials,
  onChanged,
  onUseModel,
  defaultModel,
  focusProvider,
}: Props) {
  const presets = useMemo(() => providersForKind(kind), [kind]);
  const stored = useMemo(() => credentials.filter((c) => c.kind === kind), [credentials, kind]);

  const initial = focusProvider && presets.some((p) => p.id === focusProvider) ? focusProvider : (presets[0]?.id ?? "");
  const [selected, setSelected] = useState(initial);
  const [query, setQuery] = useState("");
  const [secret, setSecret] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [baseURL, setBaseURL] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [makeActive, setMakeActive] = useState(false);
  const [saving, setSaving] = useState(false);
  const [justSaved, setJustSaved] = useState(false);
  const [testing, setTesting] = useState(false);
  const [test, setTest] = useState<TestState | null>(null);
  const [models, setModels] = useState<string[]>([]);
  const [modelSource, setModelSource] = useState<"preset" | "provider">("preset");
  const [loadingModels, setLoadingModels] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [error, setError] = useState("");
  const panelRef = useRef<HTMLDivElement>(null);

  const preset = findProvider(selected);
  const row = stored.find((c) => c.provider === selected);
  const presetBase = preset?.baseURL ?? "";
  const savedBase = row?.baseURL ?? presetBase;

  useEffect(() => {
    if (focusProvider && presets.some((p) => p.id === focusProvider)) setSelected(focusProvider);
  }, [focusProvider, presets]);

  // Fresh form per provider: no stale keys, no stale test result.
  useEffect(() => {
    const current = stored.find((c) => c.provider === selected);
    setSecret("");
    setShowKey(false);
    setBaseURL(current?.baseURL ?? (findProvider(selected)?.baseURL ?? ""));
    setEnabled(current?.enabled ?? true);
    setMakeActive(current?.isActive ?? stored.length === 0);
    setTest(null);
    setError("");
    setModels(findProvider(selected)?.models ?? []);
    setModelSource("preset");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected, row?.updatedAt]);

  const dirty =
    secret.trim() !== "" ||
    baseURL.trim() !== savedBase ||
    enabled !== (row?.enabled ?? true) ||
    makeActive !== (row?.isActive ?? false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return presets;
    return presets.filter(
      (p) => p.label.toLowerCase().includes(q) || p.notes.toLowerCase().includes(q) || p.id.includes(q),
    );
  }, [presets, query]);

  const groups = GROUPS.map((g) => ({ ...g, items: filtered.filter((p) => p.group === g.id) })).filter(
    (g) => g.items.length > 0,
  );

  const save = async () => {
    if (!preset) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: preset.id,
          kind,
          label: preset.label,
          secret: secret.trim() || undefined,
          baseURL: baseURL.trim() || null,
          enabled,
          isActive: makeActive,
        }),
      });
      const data = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Could not save.");
      setSecret("");
      setJustSaved(true);
      setTimeout(() => setJustSaved(false), 1400);
      toast.success(`${preset.label} saved`);
      await onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save.");
    } finally {
      setSaving(false);
    }
  };

  const runTest = async () => {
    if (!preset) return;
    setTesting(true);
    setTest(null);
    try {
      const res = await fetch("/api/credentials/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: preset.id }),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; message?: string; latencyMs?: number } | null;
      setTest({
        ok: Boolean(data?.ok),
        message: data?.message ?? (data?.ok ? "Connected." : "Connection failed."),
        latencyMs: data?.latencyMs,
      });
    } catch (e) {
      setTest({ ok: false, message: e instanceof Error ? e.message : "Connection failed." });
    } finally {
      setTesting(false);
    }
  };

  const loadModels = async () => {
    if (!preset) return;
    setLoadingModels(true);
    try {
      const res = await fetch(`/api/credentials/test?provider=${encodeURIComponent(preset.id)}`, { cache: "no-store" });
      const data = (await res.json().catch(() => null)) as { models?: string[]; source?: "preset" | "provider" } | null;
      if (data?.models?.length) {
        setModels(data.models);
        setModelSource(data.source ?? "preset");
      }
    } catch {
      toast.error("Could not load models.");
    } finally {
      setLoadingModels(false);
    }
  };

  const remove = async () => {
    if (!row) return;
    if (!window.confirm(`Remove ${row.label}? Its stored key is deleted.`)) return;
    setRemoving(true);
    try {
      const res = await fetch(`/api/credentials?id=${encodeURIComponent(row.id)}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Could not remove.");
      toast.success(`${row.label} removed`);
      await onChanged();
    } catch {
      setError("Could not remove this provider.");
    } finally {
      setRemoving(false);
    }
  };

  if (!preset) return null;

  const status = row?.hasKey
    ? { tone: "ok", text: row.keyPreview }
    : preset.requiresKey
      ? { tone: "warn", text: "No key stored" }
      : { tone: "neutral", text: "No key needed" };

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,236px)_minmax(0,1fr)]">
      {/* List */}
      <div className="min-w-0">
        <div className="relative mb-2.5">
          <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Filter ${presets.length}`}
            aria-label="Filter providers"
            className="h-8 pl-8 text-[12.5px]"
          />
        </div>
        <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:grid lg:max-h-[62vh] lg:auto-cols-fr lg:grid-cols-1 lg:gap-y-3 lg:overflow-y-auto lg:overflow-x-visible lg:pr-1">
          {groups.map((group) => (
            <div key={group.id} className="flex shrink-0 gap-1 lg:block lg:space-y-px">
              <p className="hidden px-2 pb-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground/70 lg:block">
                {group.label}
              </p>
              {group.items.map((p) => {
                const r = stored.find((c) => c.provider === p.id);
                const active = selected === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setSelected(p.id);
                      panelRef.current?.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    aria-current={active ? "true" : undefined}
                    className={cn(
                      "relative isolate flex w-[178px] shrink-0 items-center gap-2 whitespace-nowrap rounded-lg px-2 py-1.5 text-left text-[12.5px] outline-none transition-colors lg:w-full",
                      active ? "font-medium text-foreground" : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {active && <ActivePill id={`prov-${kind}`} />}
                    <span
                      className="relative z-10 flex size-5 shrink-0 items-center justify-center rounded-[6px] text-[10px] font-bold text-white"
                      style={{ background: TINT[p.id] ?? "var(--muted-foreground)" }}
                    >
                      {mark(p.label)}
                    </span>
                    <span className="relative z-10 min-w-0 flex-1 truncate">{p.label}</span>
                    {r?.isActive && <Star size={11} className="relative z-10 shrink-0 fill-brand text-brand" />}
                    {r?.hasKey && !r.isActive && <span className="relative z-10 size-1.5 shrink-0 rounded-full bg-emerald-500" />}
                  </button>
                );
              })}
            </div>
          ))}
          {groups.length === 0 && (
            <p className="px-2 py-6 text-[12.5px] text-muted-foreground">Nothing matches “{query}”.</p>
          )}
        </div>
      </div>

      {/* Editor */}
      <div ref={panelRef} className="min-w-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={preset.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.24, ease: [0.22, 1, 0.3, 1] }}
            className="space-y-4"
          >
            <header className="flex flex-wrap items-center gap-3">
              <span
                className="flex size-10 shrink-0 items-center justify-center rounded-xl text-[16px] font-bold text-white shadow-sm"
                style={{ background: TINT[preset.id] ?? "var(--muted-foreground)" }}
              >
                {mark(preset.label)}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-[16px] font-semibold tracking-tight">{preset.label}</h3>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium",
                      status.tone === "ok" && "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
                      status.tone === "warn" && "border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-400",
                      status.tone === "neutral" && "text-muted-foreground",
                    )}
                  >
                    <span className={cn("size-1.5 rounded-full", status.tone === "ok" ? "bg-emerald-500" : status.tone === "warn" ? "bg-amber-500" : "bg-muted-foreground")} />
                    {status.text}
                  </span>
                  {preset.freeTier && (
                    <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">{preset.freeTier}</span>
                  )}
                </div>
                <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-muted-foreground">{preset.notes}</p>
              </div>
              <a
                href={preset.docs}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground transition hover:border-foreground/25 hover:text-foreground"
              >
                Get a key <ExternalLink size={11} />
              </a>
            </header>

            <div className="space-y-1 rounded-xl border bg-card p-2.5">
              <Field label="API key" hint="Encrypted with AES-256-GCM. It is never returned to the browser.">
                <div className="relative w-[min(340px,60vw)]">
                  <Input
                    type={showKey ? "text" : "password"}
                    value={secret}
                    onChange={(e) => setSecret(e.target.value.slice(0, 500))}
                    placeholder={row?.hasKey ? `Stored ${row.keyPreview} — paste to replace` : preset.keyPlaceholder}
                    className="h-9 pr-16 font-mono text-[12.5px]"
                    autoComplete="off"
                    spellCheck={false}
                    aria-label={`${preset.label} API key`}
                  />
                  <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-0.5">
                    {secret.length > 0 && (
                      <span className="font-mono text-[10.5px] text-muted-foreground">{secret.length}</span>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowKey((v) => !v)}
                      aria-label={showKey ? "Hide key" : "Show key"}
                      className="rounded p-1 text-muted-foreground hover:text-foreground"
                    >
                      {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>
              </Field>

              <Field
                label="Base URL"
                hint="Any OpenAI-compatible endpoint: proxy, region, tunnel or self-hosted server."
              >
                <div className="flex w-[min(340px,60vw)] items-center gap-1.5">
                  <Input
                    value={baseURL}
                    onChange={(e) => setBaseURL(e.target.value)}
                    placeholder={presetBase || "https://api.example.com/v1"}
                    className="h-9 font-mono text-[12.5px]"
                    spellCheck={false}
                    aria-label={`${preset.label} base URL`}
                  />
                  {baseURL.trim() !== presetBase && presetBase && (
                    <button
                      type="button"
                      onClick={() => setBaseURL(presetBase)}
                      title="Reset to default"
                      aria-label="Reset base URL to default"
                      className="shrink-0 rounded-md p-1.5 text-muted-foreground transition hover:bg-accent hover:text-foreground"
                    >
                      <RotateCcw size={13} />
                    </button>
                  )}
                </div>
              </Field>

              <Field label="Enable this connection" hint="Disabled providers are skipped even when a key exists.">
                <Switch checked={enabled} onCheckedChange={setEnabled} aria-label="Enable provider" />
              </Field>

              <Field label="Make active" hint="Active provider serves new messages in every conversation.">
                <Switch checked={makeActive} onCheckedChange={setMakeActive} aria-label="Make active provider" />
              </Field>

              <div className="flex flex-wrap items-center gap-2 border-t px-2.5 pb-0.5 pt-3">
                <Button size="sm" onClick={() => void save()} disabled={!dirty || saving}>
                  {saving ? <Loader2 size={13} className="animate-spin" /> : justSaved ? <Check size={13} /> : null}
                  {justSaved ? "Saved" : dirty ? "Save" : "No changes"}
                </Button>
                <Button size="sm" variant="outline" onClick={() => void runTest()} disabled={testing || !row || dirty} title={dirty ? "Save before testing" : undefined}>
                  {testing ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
                  Test connection
                </Button>
                {kind === "model" && preset.modelsPath && (
                  <Button size="sm" variant="ghost" onClick={() => void loadModels()} disabled={loadingModels}>
                    <RefreshCw size={13} className={cn(loadingModels && "animate-spin")} />
                    Models
                  </Button>
                )}
                {row && (
                  <Button size="sm" variant="ghost" className="ml-auto hover:text-destructive" onClick={() => void remove()} disabled={removing}>
                    {removing ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                    Remove
                  </Button>
                )}
              </div>

              {error && (
                <div className="mx-1 flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-2.5 py-2 text-[12.5px] text-destructive">
                  <CircleAlert size={13} /> {error}
                </div>
              )}
            </div>

            <AnimatePresence>
              {test && (
                <motion.div
                  initial={{ opacity: 0, y: -6, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.24, ease: [0.22, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <Note tone={test.ok ? "ok" : "warn"}>
                    {test.message}
                    {test.latencyMs !== undefined && <span className="ml-1.5 font-mono text-[11.5px] opacity-80">{test.latencyMs} ms</span>}
                  </Note>
                </motion.div>
              )}
            </AnimatePresence>

            {kind === "model" && models.length > 0 && (
              <div className="rounded-xl border bg-card">
                <div className="flex items-center justify-between border-b px-3 py-2">
                  <p className="text-[12.5px] font-medium">Models</p>
                  <span className="text-[11.5px] text-muted-foreground">
                    {modelSource === "provider" ? "live from endpoint" : "preset"} · {models.length}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 p-3">
                  {models.slice(0, 80).map((m) => {
                    const isDefault = defaultModel === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        disabled={!onUseModel}
                        onClick={() => {
                          onUseModel?.(m, preset.id);
                          toast.success(`${m} set as the default model`);
                        }}
                        aria-pressed={isDefault}
                        className={cn(
                          "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11.5px] transition active:scale-[0.97]",
                          isDefault
                            ? "border-transparent bg-foreground text-background"
                            : "text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                          !onUseModel && "cursor-default",
                        )}
                      >
                        {isDefault && <Check size={11} />}
                        {m}
                      </button>
                    );
                  })}
                </div>
                {onUseModel && (
                  <p className="border-t px-3 py-2 text-[11.5px] text-muted-foreground">
                    Click a model to make it the default for new conversations.
                  </p>
                )}
              </div>
            )}

            {kind !== "model" && (
              <Note>
                {kind === "search"
                  ? "The active search provider powers webSearch. Firecrawl also powers page reading when a key is stored."
                  : "Readers turn a URL into clean markdown. Jina works without a key at lower rate limits."}
              </Note>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

export const KindSwitch = Segmented;
