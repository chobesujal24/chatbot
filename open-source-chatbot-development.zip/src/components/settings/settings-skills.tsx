"use client";

import { useMemo, useState } from "react";
import {
  Check,
  Download,
  FileCode2,
  Loader2,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Markdown } from "../markdown";
import { TOOL_META } from "@/lib/tool-meta";
import { cn } from "@/lib/utils";
import type { Skill } from "@/lib/types";

interface Props {
  skills: Skill[];
  onChanged: () => void | Promise<void>;
}

interface Draft {
  name: string;
  description: string;
  instructions: string;
  emoji: string;
  tools: string[];
  enabled: boolean;
}

const BLANK: Draft = {
  name: "",
  description: "",
  instructions: "",
  emoji: "✦",
  tools: [],
  enabled: true,
};

export default function SettingsSkills({ skills, onChanged }: Props) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [preview, setPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [importing, setImporting] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return skills;
    return skills.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.instructions.toLowerCase().includes(q),
    );
  }, [skills, query]);

  const current = skills.find((s) => s.id === selected) ?? null;
  const editing = draft ?? (current ? toDraft(current) : null);
  const isNew = Boolean(draft);

  const startNew = () => {
    setSelected(null);
    setDraft({ ...BLANK });
    setPreview(false);
  };

  const pick = (skill: Skill) => {
    setDraft(null);
    setSelected(skill.id);
    setPreview(false);
  };

  const patch = (values: Partial<Draft>) =>
    setDraft({ ...(draft ?? (current ? toDraft(current) : BLANK)), ...values });

  const save = async () => {
    if (!editing) return;
    if (!editing.name.trim()) return toast.error("Give the skill a name");
    setSaving(true);
    try {
      const payload = {
        name: editing.name.trim(),
        description: editing.description.trim(),
        instructions: editing.instructions,
        tools: editing.tools.length ? editing.tools : null,
        emoji: editing.emoji || "✦",
        enabled: editing.enabled,
      };
      const res = current
        ? await fetch(`/api/skills/${current.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/skills", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Could not save.");
      toast.success(current ? "Skill updated" : "Skill created");
      setDraft(null);
      await onChanged();
      if (!current) {
        const list = await fetch("/api/skills", { cache: "no-store" }).then((r) => r.json());
        const created = (list.skills as Skill[]).find(
          (s) => s.name === payload.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""),
        );
        if (created) setSelected(created.id);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save.");
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (skill: Skill, enabled: boolean) => {
    const res = await fetch(`/api/skills/${skill.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled }),
    });
    if (!res.ok) return toast.error("Could not update the skill");
    await onChanged();
  };

  const remove = async (skill: Skill) => {
    if (!window.confirm(`Delete the skill "${skill.name}"?`)) return;
    const res = await fetch(`/api/skills/${skill.id}`, { method: "DELETE" });
    if (!res.ok) return toast.error("Could not delete the skill");
    toast.success("Skill deleted");
    if (selected === skill.id) setSelected(null);
    await onChanged();
  };

  const importFile = async (file: File) => {
    setImporting(true);
    try {
      const markdown = await file.text();
      const res = await fetch("/api/skills/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markdown, overwrite: true }),
      });
      const data = (await res.json().catch(() => null)) as {
        skill?: Skill;
        error?: { message?: string };
      } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Import failed.");
      toast.success(`Imported ${data?.skill?.name ?? "skill"}`);
      await onChanged();
      if (data?.skill?.id) setSelected(data.skill.id);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Import failed.");
    } finally {
      setImporting(false);
    }
  };

  const exportFile = (skill: Skill) => {
    const lines = ["---", `name: ${skill.name}`, `description: ${skill.description}`];
    if (skill.emoji && skill.emoji !== "✦") lines.push(`emoji: ${skill.emoji}`);
    if (skill.tools?.length) lines.push(`tools: ${JSON.stringify(skill.tools)}`);
    lines.push("---", "", skill.instructions.trim(), "");
    const blob = new Blob([lines.join("\n")], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${skill.name}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const enabledCount = skills.filter((s) => s.enabled).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        <p className="mr-auto text-[12.5px] text-muted-foreground">
          {enabledCount} of {skills.length} enabled · loaded on demand via{" "}
          <code className="font-mono">loadSkill</code>
        </p>
        <label className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg border px-3 text-[13px] font-medium transition hover:bg-accent">
          {importing ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
          Import SKILL.md
          <input
            type="file"
            accept=".md,.markdown,.txt"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void importFile(file);
              e.target.value = "";
            }}
          />
        </label>
        <Button size="sm" onClick={startNew}>
          <Plus size={14} /> New skill
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <div className="min-w-0">
          <div className="relative mb-2.5">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search skills"
              aria-label="Search skills"
              className="h-9 pl-8 text-[13px]"
            />
          </div>
          <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:block lg:max-h-[58vh] lg:space-y-0.5 lg:overflow-y-auto lg:overflow-x-visible lg:pr-1">
            {filtered.map((skill) => {
              const active = selected === skill.id && !isNew;
              return (
                <button
                  key={skill.id}
                  type="button"
                  onClick={() => pick(skill)}
                  aria-current={active ? "true" : undefined}
                  className={cn(
                    "group relative flex shrink-0 items-start gap-2.5 whitespace-nowrap rounded-lg px-2.5 py-2 text-left text-[13px] outline-none transition-colors lg:w-full lg:whitespace-normal",
                    active
                      ? "bg-accent font-medium text-accent-foreground"
                      : "text-foreground/85 hover:bg-accent/60",
                  )}
                >
                  {active && (
                    <span className="absolute left-0 top-1/2 hidden h-4 w-[2px] -translate-y-1/2 rounded-full bg-brand lg:block" />
                  )}
                  <span className="mt-px text-[14px] leading-none">{skill.emoji}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{skill.name}</span>
                    <span className="mt-0.5 hidden truncate text-[11.5px] text-muted-foreground lg:block">
                      {skill.useCount > 0 ? `used ${skill.useCount}×` : "unused"}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "mt-1.5 size-1.5 shrink-0 rounded-full",
                      skill.enabled ? "bg-emerald-500" : "bg-muted-foreground/30",
                    )}
                    title={skill.enabled ? "Enabled" : "Disabled"}
                  />
                </button>
              );
            })}
            {filtered.length === 0 && (
              <p className="px-2.5 py-6 text-[12.5px] text-muted-foreground">
                {skills.length === 0 ? "No skills yet." : "No skill matches that search."}
              </p>
            )}
          </div>
        </div>

        {editing ? (
          <div className="min-w-0 space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="mr-auto text-[16px] font-semibold tracking-tight">
                {current ? `Edit ${current.emoji} ${current.name}` : "New skill"}
              </h3>
              {current && (
                <>
                  <Button size="xs" variant="ghost" onClick={() => exportFile(current)} aria-label="Export as SKILL.md" title="Export as SKILL.md">
                    <Download size={13} />
                  </Button>
                  <Button size="xs" variant="ghost" className="hover:text-destructive" onClick={() => void remove(current)} aria-label="Delete skill" title="Delete skill">
                    <Trash2 size={13} />
                  </Button>
                </>
              )}
              {isNew && (
                <Button size="xs" variant="ghost" onClick={() => { setDraft(null); setPreview(false); }} aria-label="Cancel">
                  <X size={13} />
                </Button>
              )}
            </div>

            <div className="grid gap-3 sm:grid-cols-[1fr_64px]">
              <div>
                <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-name">
                  Name
                </label>
                <Input
                  id="skill-name"
                  value={editing.name}
                  onChange={(e) => patch({ name: e.target.value })}
                  placeholder="research-brief"
                  className="font-mono text-[13px]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-emoji">
                  Icon
                </label>
                <Input
                  id="skill-emoji"
                  value={editing.emoji}
                  onChange={(e) => patch({ emoji: e.target.value.slice(0, 4) })}
                  className="text-center text-[15px]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-desc">
                When to use it
              </label>
              <Textarea
                id="skill-desc"
                value={editing.description}
                onChange={(e) => patch({ description: e.target.value })}
                rows={2}
                placeholder="One sentence the model reads to decide whether to load this skill."
                className="resize-y text-[13px]"
              />
              <p className="mt-1.5 text-[12px] text-muted-foreground">
                This is the only description the model sees before loading the skill — make the
                trigger condition explicit.
              </p>
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="skill-instructions" className="text-[13px] font-medium">
                  Instructions
                </label>
                <div className="flex items-center gap-1">
                  <span className="mr-1 font-mono text-[11px] text-muted-foreground">
                    {Math.ceil(editing.instructions.length / 4)} tok
                  </span>
                  <Button size="xs" variant={preview ? "secondary" : "ghost"} onClick={() => setPreview((v) => !v)}>
                    <FileCode2 size={12} /> {preview ? "Edit" : "Preview"}
                  </Button>
                </div>
              </div>
              {preview ? (
                <div className="max-h-[340px] min-h-[160px] overflow-y-auto rounded-xl border bg-surface-1 px-4 py-3">
                  {editing.instructions.trim() ? (
                    <Markdown content={editing.instructions} />
                  ) : (
                    <p className="text-[13px] text-muted-foreground">Nothing to preview yet.</p>
                  )}
                </div>
              ) : (
                <Textarea
                  id="skill-instructions"
                  value={editing.instructions}
                  onChange={(e) => patch({ instructions: e.target.value })}
                  rows={12}
                  spellCheck={false}
                  placeholder={"# Skill title\n\nWrite the method the model should follow, as numbered steps and constraints."}
                  className="scroll-slim resize-y font-mono text-[12.5px] leading-relaxed"
                />
              )}
            </div>

            <div>
              <p className="mb-1.5 text-[13px] font-medium">Tool allowlist</p>
              <div className="flex flex-wrap gap-1.5">
                {TOOL_META.map((tool) => {
                  const on = editing.tools.includes(tool.name);
                  return (
                    <button
                      key={tool.name}
                      type="button"
                      onClick={() =>
                        patch({
                          tools: on ? editing.tools.filter((t) => t !== tool.name) : [...editing.tools, tool.name],
                        })
                      }
                      aria-pressed={on}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11.5px] transition",
                        on
                          ? "border-foreground bg-foreground text-background"
                          : "text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                      )}
                    >
                      {on && <Check size={11} />}
                      {tool.name}
                    </button>
                  );
                })}
              </div>
              <p className="mt-1.5 text-[12px] text-muted-foreground">
                {editing.tools.length === 0
                  ? "No restriction — the skill inherits the agent's tools."
                  : `The skill will ask for ${editing.tools.length} specific tool${editing.tools.length === 1 ? "" : "s"}.`}
              </p>
            </div>

            <div className="flex items-center justify-between rounded-xl border px-3.5 py-3">
              <div>
                <p className="text-[13px] font-medium">Enabled</p>
                <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                  Disabled skills are hidden from every agent.
                </p>
              </div>
              <Switch checked={editing.enabled} onCheckedChange={(enabled) => patch({ enabled })} aria-label="Enable skill" />
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={() => void save()} disabled={saving}>
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                {current ? "Save skill" : "Create skill"}
              </Button>
              {current && !isNew && (
                <Button variant="ghost" onClick={() => setDraft(toDraft(current))}>
                  <Pencil size={14} /> Edit as new draft
                </Button>
              )}
            </div>
          </div>
        ) : current ? (
          <div className="min-w-0 space-y-5">
            <div className="flex flex-wrap items-start gap-3">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-muted text-[20px]">
                {current.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="text-[17px] font-semibold tracking-tight">{current.name}</h3>
                <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
                  {current.description || "No description"}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11.5px] text-muted-foreground">
                  <span className="rounded-md border px-1.5 py-0.5 capitalize">{current.source}</span>
                  <span>·</span>
                  <span>{Math.ceil(current.instructions.length / 4)} tokens when loaded</span>
                  <span>·</span>
                  <span>{current.useCount} loads</span>
                  {current.tools?.length ? (
                    <>
                      <span>·</span>
                      <span className="font-mono">{current.tools.join(", ")}</span>
                    </>
                  ) : null}
                </div>
              </div>
              <Switch checked={current.enabled} onCheckedChange={(v) => void toggle(current, v)} aria-label="Enable skill" />
            </div>

            <div className="rounded-xl border bg-surface-1">
              <div className="flex items-center justify-between border-b px-4 py-2.5">
                <p className="text-[12.5px] font-medium">Instructions</p>
                <div className="flex items-center gap-1">
                  <Button size="xs" variant="ghost" onClick={() => exportFile(current)}>
                    <Download size={12} /> Export
                  </Button>
                  <Button size="xs" variant="outline" onClick={() => setDraft(toDraft(current))}>
                    <Pencil size={12} /> Edit
                  </Button>
                </div>
              </div>
              <div className="scroll-slim max-h-[46vh] overflow-y-auto px-4 py-3.5">
                <Markdown content={current.instructions || "_No instructions yet._"} />
              </div>
            </div>

            {current.source === "builtin" && (
              <p className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
                <Sparkles size={12} /> Seeded with Nova. Editing keeps your changes — it will not be
                overwritten by updates.
              </p>
            )}
          </div>
        ) : (
          <div className="flex min-h-[240px] flex-col items-center justify-center rounded-xl border border-dashed px-6 text-center">
            <p className="text-[13.5px] font-medium">No skill selected</p>
            <p className="mt-1 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">
              Pick a skill to read and edit its instructions, or import a <code className="font-mono">SKILL.md</code>{" "}
              file from the Agent Skills format.
            </p>
            <Button size="sm" variant="outline" className="mt-4" onClick={startNew}>
              <Plus size={14} /> Create a skill
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function toDraft(skill: Skill): Draft {
  return {
    name: skill.name,
    description: skill.description,
    instructions: skill.instructions,
    emoji: skill.emoji,
    tools: skill.tools ?? [],
    enabled: skill.enabled,
  };
}
