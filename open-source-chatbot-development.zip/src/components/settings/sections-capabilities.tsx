"use client";

import { useMemo, useState } from "react";
import { Download, Eraser, Pin, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Collapsible, Field, NumberField, Note, Panel, Segmented, Slider } from "./ui";
import SettingsSkills from "./settings-skills";
import SettingsMemory from "./settings-memory";
import { serializeSkillMarkdown } from "@/lib/skills-format";
import type { Preferences } from "@/lib/preferences-model";
import type { Skill } from "@/lib/types";
import type { MemoryStats } from "@/lib/types";

type Patch = (values: Partial<Preferences>) => void;

/* ── Skills ────────────────────────────────────────────────────────────────── */

export function SkillsSection({
  prefs,
  patch,
  skills,
  onChanged,
}: {
  prefs: Preferences;
  patch: Patch;
  skills: Skill[];
  onChanged: () => void;
}) {
  const enabled = skills.filter((s) => s.enabled);
  const cost = useMemo(
    () =>
      enabled.reduce(
        (sum, s) => sum + Math.ceil(40 + (s.description.length + s.name.length + 12) / 4),
        0,
      ),
    [enabled],
  );

  const exportAll = () => {
    if (skills.length === 0) return toast.error("There is nothing to export yet.");
    const bundle = skills
      .map((s) => serializeSkillMarkdown({ name: s.name, description: s.description, instructions: s.instructions, tools: s.tools, emoji: s.emoji }))
      .join("\n\n---\n\n");
    const url = URL.createObjectURL(new Blob([bundle], { type: "text/markdown" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "nova-skills.md";
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${skills.length} skills`);
  };

  return (
    <div className="space-y-5">
      <Panel
        title="Index cost"
        hint="Progressive disclosure: only the index is sent up front. Loading a skill costs its own tokens."
        actions={
          <Button size="xs" variant="ghost" onClick={exportAll}>
            <Download size={12} /> Export all
          </Button>
        }
      >
        <div className="grid grid-cols-3 divide-x">
          <Metric label="Enabled" value={String(enabled.length)} hint={`of ${skills.length}`} />
          <Metric label="Index cost" value={`${cost}`} hint="tokens per request" />
          <Metric label="Loads" value={String(skills.reduce((n, s) => n + s.useCount, 0))} hint="all time" />
        </div>
      </Panel>

      <Panel title="Behaviour">
        <Field label="Offer skills to agents" hint="Adds the index to the system prompt.">
          <Switch checked={prefs.showSkillsIndex} onCheckedChange={(showSkillsIndex) => patch({ showSkillsIndex })} aria-label="Offer skills" />
        </Field>
        <Field label="Auto-load a matching skill" hint="When one skill matches the request strongly, its instructions are attached without waiting for the model to ask.">
          <Switch checked={prefs.autoLoadSkill} onCheckedChange={(autoLoadSkill) => patch({ autoLoadSkill })} aria-label="Auto-load skill" />
        </Field>
        <Field label="Match strength" hint="How closely the request must match a skill's description for auto-load.">
          <Slider value={prefs.skillMatchThreshold} min={0.2} max={0.95} step={0.05} label="Match strength"
            format={(v) => `${Math.round(v * 100)}%`} onChange={(skillMatchThreshold) => patch({ skillMatchThreshold })} className="w-[240px]" />
        </Field>
        <Field label="Skills per turn" hint="Caps how much instruction text one reply can pull in.">
          <NumberField value={prefs.maxSkillsPerTurn} min={1} max={5} ariaLabel="Skills per turn" onChange={(maxSkillsPerTurn) => patch({ maxSkillsPerTurn })} />
        </Field>
      </Panel>

      <section className="mt-5 overflow-hidden rounded-xl border bg-card">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-muted/35 px-4 py-2.5">
          <div className="min-w-0">
            <h3 className="text-[13px] font-semibold tracking-tight">Skill library</h3>
            <p className="mt-0.5 text-[12px] leading-snug text-muted-foreground">
              {skills.length} skills · {enabled.length} enabled. Each skill is one line in the index
              until an agent loads it.
            </p>
          </div>
        </header>
        <div className="p-3.5">
          <SettingsSkills skills={skills} onChanged={onChanged} />
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="px-3.5 py-3">
      <p className="font-mono text-[18px] font-medium leading-none tracking-tight">{value}</p>
      <p className="mt-1.5 text-[10.5px] font-semibold uppercase tracking-[0.07em] text-muted-foreground">{label}</p>
      <p className="text-[11.5px] text-muted-foreground/80">{hint}</p>
    </div>
  );
}

/* ── Memory ───────────────────────────────────────────────────────────────── */

export function MemorySection({
  prefs,
  patch,
  stats,
  onChanged,
  onPrune,
}: {
  prefs: Preferences;
  patch: Patch;
  stats: MemoryStats | null;
  onChanged: () => void;
  onPrune: () => void;
}) {
  const [pruning, setPruning] = useState(false);

  const prune = async () => {
    if (!window.confirm("Disable memories that have never been recalled? They stay in the database and can be switched back on individually.")) return;
    setPruning(true);
    try {
      const res = await fetch("/api/memories/prune", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "disable-unused" }),
      });
      const data = (await res.json().catch(() => null)) as { changed?: number; message?: string } | null;
      if (!res.ok) throw new Error(data?.message ?? "Prune failed.");
      toast.success(`${data?.changed ?? 0} unused memories switched off`);
      onChanged();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Prune failed.");
    } finally {
      setPruning(false);
    }
  };

  return (
    <div className="space-y-5">
      <Panel title="Storage" hint="Nova keeps discrete facts, not transcripts. Recall ranks them, then injects the best few.">
        <div className="grid grid-cols-3 divide-x">
          <Metric label="Stored" value={String(stats?.total ?? 0)} hint={`${stats?.enabled ?? 0} enabled`} />
          <Metric label="Recalled" value={String(stats?.recalled ?? 0)} hint="injections" />
          <Metric label="Cap" value={String(prefs.memoryMaxItems)} hint="before pruning" />
        </div>
      </Panel>

      <Panel title="Retrieval">
        <Field label="Inject memories" hint="Adds ranked memories to the system prompt.">
          <Switch checked={prefs.injectMemories} onCheckedChange={(injectMemories) => patch({ injectMemories })} aria-label="Inject memories" />
        </Field>
        <Field label="Memories per request" hint="0 turns recall off without disabling storage.">
          <Slider value={prefs.memoryLimit} min={0} max={20} step={1} label="Memories per request" onChange={(memoryLimit) => patch({ memoryLimit })} className="w-[240px]" />
        </Field>
        <Field label="Minimum score" hint="Weakly related memories are skipped instead of wasting tokens.">
          <Slider value={prefs.memoryMinScore} min={0.05} max={0.8} step={0.01} label="Minimum score"
            format={(v) => v.toFixed(2)} onChange={(memoryMinScore) => patch({ memoryMinScore })} className="w-[240px]" />
        </Field>
        <Field label="Memory half-life" hint="How quickly old memories lose rank. Shorter forgets faster.">
          <Slider value={prefs.memoryHalfLifeDays} min={1} max={730} step={1} label="Half-life"
            format={(v) => `${v}d`} onChange={(memoryHalfLifeDays) => patch({ memoryHalfLifeDays })} className="w-[240px]" />
        </Field>
        <Field label="Reinforce on recall" hint="Recalled memories get stronger, so useful facts keep winning.">
          <Switch checked={prefs.memoryReinforce} onCheckedChange={(memoryReinforce) => patch({ memoryReinforce })} aria-label="Reinforce on recall" />
        </Field>
      </Panel>

      <Panel title="Writing">
        <Field label="Extract automatically" hint="After each reply, durable facts and corrections are pulled out of what you wrote.">
          <Switch checked={prefs.autoExtractMemories} onCheckedChange={(autoExtractMemories) => patch({ autoExtractMemories })} aria-label="Extract automatically" />
        </Field>
        <Field label="Merge similarity" hint="How alike two statements must be to update the old memory instead of adding a new one.">
          <Slider value={prefs.memoryDedupe} min={0.2} max={0.95} step={0.01} label="Merge similarity"
            format={(v) => v.toFixed(2)} onChange={(memoryDedupe) => patch({ memoryDedupe })} className="w-[240px]" />
        </Field>
        <Field label="Pinned first" hint="Pinned memories are always injected and never decay out.">
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2 py-1 text-[11.5px] text-muted-foreground">
            <Pin size={11} /> Boost +0.15
          </span>
        </Field>
      </Panel>

      <Collapsible title="Maintenance" hint="Bulk actions over the whole memory store.">
        <Field label="Switch off never-recalled memories" hint="Useful when a store fills up with things that never proved relevant.">
          <Button size="sm" variant="outline" onClick={() => void prune()} disabled={pruning}>
            <Eraser size={13} /> {pruning ? "Working…" : "Prune unused"}
          </Button>
        </Field>
      </Collapsible>

      <Note>
        Memory is workspace-scoped: a second browser or profile starts completely empty, and no
        recall ever crosses that boundary.
      </Note>

      <div className="pt-1">
        <SettingsMemory
          autoExtract={prefs.autoExtractMemories}
          onAutoExtractChange={(autoExtractMemories) => patch({ autoExtractMemories })}
          memoryLimit={prefs.memoryLimit}
          onMemoryLimitChange={(memoryLimit) => patch({ memoryLimit })}
          onChanged={onChanged}
        />
      </div>
    </div>
  );
}

/* ── Integrations: web tool defaults ───────────────────────────────────────── */

export function WebSection({
  prefs,
  patch,
  activeSearch,
}: {
  prefs: Preferences;
  patch: Patch;
  activeSearch: string | null;
}) {
  return (
    <div className="space-y-5">
      <Panel title="Web access" hint="Agents use these settings for webSearch and page reading.">
        <Field label="Active search provider" hint={activeSearch ? "Chosen in Integrations." : "No search provider configured yet."}>
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[12px]">
            <Sparkles size={11} />
            {activeSearch ?? "none"}
          </span>
        </Field>
        <Field label="Results per query" hint="More results cost prompt tokens.">
          <NumberField value={prefs.searchResults} min={1} max={10} ariaLabel="Results per query" onChange={(searchResults) => patch({ searchResults })} />
        </Field>
        <Field label="Reader mode" hint="Auto prefers Firecrawl, then Jina, then a direct SSRF-guarded fetch.">
          <Segmented ariaLabel="Reader mode" value="auto"
            onChange={() => undefined}
            options={[{ value: "auto", label: "Auto" }]} />
        </Field>
      </Panel>
    </div>
  );
}
