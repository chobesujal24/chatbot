"use client";

import { motion } from "framer-motion";
import { Check, Monitor, Moon, Sun } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Field, Panel, Segmented, Slider } from "./ui";
import { Markdown } from "@/components/markdown";
import { ACCENT_SWATCHES, type Preferences } from "@/lib/preferences-model";
import { cn } from "@/lib/utils";

const SAMPLE = `## Reply preview

Nova keeps **your** provider's output readable: \`inline code\`, tables and fenced blocks.

\`\`\`python
def area(r: float) -> float:
    return 3.14159 * r * r
\`\`\`
`;

export default function AppearanceSection({
  prefs,
  patch,
}: {
  prefs: Preferences;
  patch: (values: Partial<Preferences>) => void;
}) {
  return (
    <div className="space-y-5">
      <Panel title="Theme" hint="System follows your operating system.">
        <Field label="Colour scheme">
          <Segmented
            ariaLabel="Colour scheme"
            value={prefs.theme}
            onChange={(theme) => patch({ theme })}
            options={[
              { value: "light", label: "Light", icon: <Sun size={12} /> },
              { value: "dark", label: "Dark", icon: <Moon size={12} /> },
              { value: "system", label: "System", icon: <Monitor size={12} /> },
            ]}
          />
        </Field>
      </Panel>

      <Panel title="Accent" hint="Used for the mark, focus rings, the context meter and active rails.">
        <div className="flex flex-wrap items-center gap-2 px-2.5 py-3">
          {ACCENT_SWATCHES.map((swatch) => {
            const active = prefs.accent.toLowerCase() === swatch.value.toLowerCase();
            return (
              <button
                key={swatch.id}
                type="button"
                onClick={() => patch({ accent: swatch.value })}
                aria-label={swatch.label}
                aria-pressed={active}
                title={swatch.label}
                className="relative flex size-9 items-center justify-center rounded-full outline-none transition-transform hover:scale-[1.08] focus-visible:ring-2 focus-visible:ring-ring active:scale-95"
                style={{ background: swatch.value }}
              >
                {active && (
                  <motion.span
                    layoutId="accent-check"
                    className="absolute inset-0 flex items-center justify-center rounded-full"
                    transition={{ type: "spring", stiffness: 500, damping: 34 }}
                  >
                    <Check size={15} className="text-white drop-shadow" />
                  </motion.span>
                )}
              </button>
            );
          })}
          <label className="ml-1 inline-flex items-center gap-2 text-[12px] text-muted-foreground">
            Custom
            <input
              type="color"
              value={prefs.accent}
              onChange={(e) => patch({ accent: e.target.value })}
              aria-label="Custom accent colour"
              className="size-8 cursor-pointer rounded-md border bg-transparent p-0.5"
            />
          </label>
        </div>
      </Panel>

      <Panel title="Typography">
        <Field label="Text size" hint="Applies to messages, the composer and settings.">
          <Segmented
            ariaLabel="Text size"
            value={prefs.fontSize}
            onChange={(fontSize) => patch({ fontSize })}
            options={[
              { value: "sm", label: "S" },
              { value: "md", label: "M" },
              { value: "lg", label: "L" },
            ]}
          />
        </Field>
        <Field label="Message density" hint="Compact tightens spacing between turns.">
          <Segmented
            ariaLabel="Density"
            value={prefs.density}
            onChange={(density) => patch({ density })}
            options={[
              { value: "comfortable", label: "Comfortable" },
              { value: "compact", label: "Compact" },
            ]}
          />
        </Field>
        <Field label="Message column width" hint="Wider reads better on large screens.">
          <Slider value={prefs.messageWidth} min={560} max={1120} step={16} label="Message width"
            format={(v) => `${v}px`} onChange={(messageWidth) => patch({ messageWidth })} className="w-[260px]" />
        </Field>
      </Panel>

      <Panel title="Code blocks">
        <Field label="Highlight theme">
          <Segmented
            size="sm"
            ariaLabel="Code theme"
            value={prefs.codeTheme}
            onChange={(codeTheme) => patch({ codeTheme })}
            options={[
              { value: "github", label: "GitHub" },
              { value: "night-owl", label: "Night Owl" },
              { value: "min-light", label: "Min" },
              { value: "material-theme", label: "Material" },
            ]}
          />
        </Field>
        <Field label="Line numbers">
          <Switch checked={prefs.lineNumbers} onCheckedChange={(lineNumbers) => patch({ lineNumbers })} aria-label="Line numbers" />
        </Field>
      </Panel>

      <Panel title="Motion">
        <Field label="Animations" hint="Transitions, reveals and meter fills. Turning this off also honours the system reduce-motion setting.">
          <Switch checked={prefs.animations} onCheckedChange={(animations) => patch({ animations })} aria-label="Animations" />
        </Field>
      </Panel>

      <Panel title="Message details">
        <Field label="Show timestamps">
          <Switch checked={prefs.showTimestamps} onCheckedChange={(showTimestamps) => patch({ showTimestamps })} aria-label="Show timestamps" />
        </Field>
        <Field label="Show token usage" hint="Tokens and latency under each reply.">
          <Switch checked={prefs.showTokenUsage} onCheckedChange={(showTokenUsage) => patch({ showTokenUsage })} aria-label="Show token usage" />
        </Field>
        <Field label="Show tool and skill activity" hint="The collapsible step timeline.">
          <Switch checked={prefs.showThinking} onCheckedChange={(showThinking) => patch({ showThinking })} aria-label="Show tool activity" />
        </Field>
      </Panel>

      <Panel title="Sidebar">
        <Field label="Open by default">
          <Segmented
            ariaLabel="Sidebar default"
            value={prefs.sidebarDefault}
            onChange={(sidebarDefault) => patch({ sidebarDefault })}
            options={[
              { value: "open", label: "Open" },
              { value: "closed", label: "Closed" },
            ]}
          />
        </Field>
        <Field label="Start collapsed to icons" hint="The 68px rail. You can still expand it per session.">
          <Switch checked={prefs.compactSidebar} onCheckedChange={(compactSidebar) => patch({ compactSidebar })} aria-label="Compact sidebar" />
        </Field>
      </Panel>

      <Panel title="Preview" hint="Everything above renders live, including here.">
        <div className="bg-muted/25 px-3 py-4">
          <div
            className={cn("mx-auto rounded-xl border bg-card p-4 transition-[max-width] duration-300")}
            style={{ maxWidth: prefs.messageWidth }}
          >
            <Markdown content={SAMPLE} />
          </div>
        </div>
      </Panel>
    </div>
  );
}
