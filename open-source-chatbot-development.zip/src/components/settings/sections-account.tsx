"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Database,
  Download,
  KeyRound,
  Link2,
  Loader2,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Collapsible, Field, NumberField, Panel, Reveal, StatTile, Bar, EmptyState } from "./ui";
import type { Preferences } from "@/lib/preferences-model";
import { cn } from "@/lib/utils";

export interface UsageStats {
  conversations: number;
  messages: number;
  agents: number;
  memories: number;
  tasksOpen: number;
  tasksDone: number;
  byModel: Array<{ model: string; count: number; tokens: number }>;
  toolCounts: Record<string, number>;
}

/* ── Usage ─────────────────────────────────────────────────────────────────── */

export function UsageSection({ stats, loading }: { stats: UsageStats | null; loading: boolean }) {
  const [range, setRange] = useState<"all" | "models">("all");
  void setRange;

  if (loading || !stats) {
    return (
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="nova-skeleton h-[86px] rounded-xl" />
        ))}
      </div>
    );
  }

  const tokens = stats.byModel.reduce((sum, m) => sum + m.tokens, 0);
  const calls = Object.values(stats.toolCounts).reduce((a, b) => a + b, 0);
  const tiles = [
    { label: "Conversations", value: stats.conversations, hint: "in this workspace" },
    { label: "Messages", value: stats.messages, hint: "all turns" },
    { label: "Tokens", value: tokens, hint: "reported by providers" },
    { label: "Tool calls", value: calls, hint: "across every turn" },
    { label: "Agents", value: stats.agents, hint: "configured" },
    { label: "Memories", value: stats.memories, hint: "stored facts" },
    { label: "Tasks open", value: stats.tasksOpen, hint: "tracked work" },
    { label: "Tasks done", value: stats.tasksDone, hint: "completed" },
  ];
  const maxTokens = Math.max(1, ...stats.byModel.map((m) => m.tokens));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {tiles.map((tile, i) => (
          <StatTile key={tile.label} label={tile.label} value={tile.value} hint={tile.hint} index={i} />
        ))}
      </div>

      <Panel title="Tokens by model" hint="Only real provider replies are counted. Offline answers are free.">
        {stats.byModel.length === 0 ? (
          <div className="p-3">
            <EmptyState
              icon={<Database size={18} />}
              title="No model usage yet"
              description="Connect a provider in Providers and send a message. Counts appear here from the provider's own token report."
            />
          </div>
        ) : (
          <div className="space-y-3 p-3">
            {stats.byModel.map((row, i) => (
              <Reveal key={row.model} index={i}>
                <div>
                  <div className="mb-1 flex items-center justify-between gap-3">
                    <code className="truncate font-mono text-[12px]">{row.model}</code>
                    <span className="shrink-0 font-mono text-[11.5px] text-muted-foreground">
                      {row.tokens.toLocaleString()} tok · {row.count} replies
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                    <motion.div
                      className="h-full rounded-full bg-brand"
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.max(2, (row.tokens / maxTokens) * 100)}%` }}
                      transition={{ duration: 0.7, ease: [0.22, 1, 0.3, 1], delay: 0.05 + i * 0.06 }}
                    />
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        )}
      </Panel>

      <Panel title="Tool usage" hint="Which capabilities your agents actually reach for.">
        {calls === 0 ? (
          <p className="px-3 py-4 text-[12.5px] text-muted-foreground">No tool calls recorded yet.</p>
        ) : (
          <div className="space-y-3 p-3">
            <Bar
              segments={Object.entries(stats.toolCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([name, count], i) => ({
                  id: name,
                  label: name,
                  tokens: count,
                  color: TOOL_TINTS[i % TOOL_TINTS.length],
                }))}
            />
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(stats.toolCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([name, count]) => (
                  <span key={name} className="inline-flex items-center gap-1.5 rounded-md border bg-muted/50 px-2 py-1 font-mono text-[11.5px] text-muted-foreground">
                    {name}
                    <span className="text-foreground">{count}×</span>
                  </span>
                ))}
            </div>
          </div>
        )}
      </Panel>
    </div>
  );
}

const TOOL_TINTS = ["oklch(0.64 0.155 48)", "oklch(0.62 0.02 265)", "oklch(0.66 0.14 165)", "oklch(0.68 0.13 300)", "oklch(0.72 0.13 230)"];

/* ── Data & privacy ────────────────────────────────────────────────────────── */

export function DataSection({
  prefs,
  patch,
  workspaceId,
  onExportAll,
  onExportSettings,
  onImportSettings,
  onResetPreferences,
  onPurge,
  shareCount,
}: {
  prefs: Preferences;
  patch: (values: Partial<Preferences>) => void;
  workspaceId: string | null;
  onExportAll: () => void;
  onExportSettings: () => void;
  onImportSettings: (file: File) => void;
  onResetPreferences: () => void;
  onPurge: (target: "conversations" | "memories" | "tasks" | "skills" | "all") => void;
  shareCount: number;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [armed, setArmed] = useState<string | null>(null);

  const DangerButton = ({ id, label, onClick }: { id: string; label: string; onClick: () => void }) => (
    <Button
      size="sm"
      variant={armed === id ? "destructive" : "outline"}
      onClick={() => {
        if (armed === id) {
          onClick();
          setArmed(null);
        } else {
          setArmed(id);
          setTimeout(() => setArmed((v) => (v === id ? null : v)), 4000);
        }
      }}
    >
      {armed === id ? "Confirm" : label}
    </Button>
  );

  return (
    <div className="space-y-5">
      <Panel title="Ownership" hint="Everything below is scoped to this workspace only.">
        <div className="space-y-3 p-3">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/35 px-3 py-2.5">
            <div className="min-w-0">
              <p className="text-[12px] font-medium">Workspace id</p>
              <code className="font-mono text-[11.5px] text-muted-foreground">{workspaceId ?? "—"}</code>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[11.5px] text-muted-foreground">
              <KeyRound size={11} /> keys encrypted at rest
            </span>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <Button size="sm" variant="outline" onClick={onExportAll}>
              <Download size={13} /> Export conversations + memory
            </Button>
            <Button size="sm" variant="outline" onClick={onExportSettings}>
              <Download size={13} /> Export settings JSON
            </Button>
            <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload size={13} /> Import settings
            </Button>
            <Button size="sm" variant="ghost" onClick={onResetPreferences}>
              <RotateCcw size={13} /> Reset preferences
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onImportSettings(file);
              e.target.value = "";
            }}
          />
        </div>
      </Panel>

      <Panel title="Sharing" hint="Read-only links are public snapshots; treat them like a published page.">
        <Field label="Active share links" hint="Revoke any link from the conversation menu; it stops working immediately.">
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[12px]">
            <Link2 size={11} /> {shareCount}
          </span>
        </Field>
        <Field label="Link expiry" hint="0 keeps links alive until revoked.">
          <NumberField value={prefs.shareExpiryDays} min={0} max={365} step={1} suffix="days" ariaLabel="Share expiry"
            onChange={(shareExpiryDays) => patch({ shareExpiryDays })} />
        </Field>
        <Field label="Redact attachments in shared copies" hint="File contents stay private; only names are shown.">
          <SwitchLike checked={prefs.shareRedactAttachments} onChange={(v) => patch({ shareRedactAttachments: v })} label="Redact attachments" />
        </Field>
      </Panel>

      <Panel title="Purge" hint="Deletes run immediately against this workspace.">
        <div className="divide-y">
          {[
            { id: "conversations", label: "Delete all conversations", hint: "Includes every message and attachment reference.", target: "conversations" as const },
            { id: "memories", label: "Delete all memories", hint: "Long-term facts are removed for good.", target: "memories" as const },
            { id: "skills", label: "Delete custom skills", hint: "Built-in seeds are restored.", target: "skills" as const },
            { id: "tasks", label: "Delete all tasks", hint: "Agent-written tasks included.", target: "tasks" as const },
            { id: "all", label: "Delete everything", hint: "Purges chats, skills, memory, tasks, templates and shares, then re-seeds agents.", target: "all" as const },
          ].map((row) => (
            <div key={row.id} className="flex flex-wrap items-center justify-between gap-3 px-2.5 py-3">
              <div className="min-w-0">
                <p className={cn("text-[13.5px] font-medium", row.id === "all" && "text-destructive")}>{row.label}</p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">{row.hint}</p>
              </div>
              <DangerButton id={row.id} label="Delete" onClick={() => onPurge(row.target)} />
            </div>
          ))}
        </div>
      </Panel>

      <Collapsible title="What is stored, and where" hint="A plain-language inventory of every table this workspace touches.">
        <div className="space-y-2 p-3 text-[12.5px] leading-relaxed text-muted-foreground">
          {[
            ["Conversations and messages", "content, attachments metadata, tool calls, token usage, compaction summary"],
            ["Skills", "name, description, instructions, tool allowlist, usage counters"],
            ["Memory", "one fact per row with type, importance, confidence, recall counters"],
            ["Credentials", "AES-256-GCM ciphertext only. Plaintext never lands in the database or logs."],
            ["Preferences", "one JSON document per workspace, clamped on write"],
            ["Share links", "random token, optional expiry, no session required to read"],
            ["Rate limits", "fixed-window counters per action and workspace"],
          ].map(([title, detail]) => (
            <div key={title} className="flex gap-2.5 rounded-lg bg-muted/35 px-2.5 py-2">
              <ShieldCheck size={13} className="mt-0.5 shrink-0 text-muted-foreground" />
              <span>
                <span className="font-medium text-foreground">{title}</span> — {detail}
              </span>
            </div>
          ))}
          <p className="flex items-center gap-1.5 pt-1 text-[12px]">
            <Sparkles size={12} /> No analytics, no telemetry, no third-party requests except the providers you configure.
          </p>
        </div>
      </Collapsible>
    </div>
  );
}

function SwitchLike({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn("relative h-5 w-9 shrink-0 rounded-full transition-colors", checked ? "bg-foreground" : "bg-muted-foreground/30")}
    >
      <motion.span layout transition={{ type: "spring", stiffness: 620, damping: 40 }} className={cn("absolute top-0.5 size-4 rounded-full bg-background shadow-sm", checked ? "left-[18px]" : "left-0.5")} />
    </button>
  );
}

export const Busy = ({ show }: { show: boolean }) => (show ? <Loader2 size={13} className="animate-spin" /> : null);
