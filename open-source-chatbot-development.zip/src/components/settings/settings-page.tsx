"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import {
  Archive,
  ArrowLeft,
  BarChart3,
  Bot,
  Brain,
  Check,
  Cpu,
  Gauge,
  Keyboard,
  Loader2,
  MessageSquare,
  Palette,
  Plug,
  Save,
  Search,
  Sparkles,
  Wrench,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/logo";
import { ActivePill, SectionIntro } from "./ui";
import SettingsProviders, { type CredentialRow } from "./settings-providers";
import { AdvancedSection, ComposerSection, ContextSection, ResponseSection, ToolsSection } from "./sections-behavior";
import { MemorySection, SkillsSection, WebSection } from "./sections-capabilities";
import AppearanceSection from "./settings-appearance";
import { DataSection, UsageSection, type UsageStats } from "./sections-account";
import { DEFAULT_PREFERENCES, diffPreferences, normalizePreferences, type Preferences } from "@/lib/preferences-model";
import { applyPreferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";
import type { Agent, MemoryStats, Skill } from "@/lib/types";

const EASE = [0.22, 1, 0.3, 1] as const;

interface SectionDef {
  id: string;
  label: string;
  icon: typeof Sparkles;
  group: string;
  blurb: string;
  keywords: string;
}

const SECTIONS: SectionDef[] = [
  { id: "usage", label: "Usage", icon: BarChart3, group: "Overview", blurb: "What this workspace has used, measured from your own data.", keywords: "tokens cost activity stats counters usage" },
  { id: "providers", label: "Providers", icon: Plug, group: "Connections", blurb: "Bring your own API keys and base URLs. Nova is only a client.", keywords: "api key base url openai anthropic gemini local ollama endpoint model" },
  { id: "integrations", label: "Integrations", icon: Sparkles, group: "Connections", blurb: "Web search and page reading for agents, with your own provider keys.", keywords: "firecrawl tavily brave exa serper serpapi jina search reader fetch web" },
  { id: "skills", label: "Skills", icon: Cpu, group: "Capabilities", blurb: "Instruction packs loaded on demand, in the Agent Skills format.", keywords: "skill md instructions pack workflow progressive disclosure import export" },
  { id: "memory", label: "Memory", icon: Brain, group: "Capabilities", blurb: "Long-term facts, preferences and corrections that survive across chats.", keywords: "remember recall forget fact preference extraction decay half life injection" },
  { id: "context", label: "Context", icon: Archive, group: "Capabilities", blurb: "Exactly what gets sent, and when old turns are folded into a summary.", keywords: "tokens window budget compaction history summarise trim meter" },
  { id: "tools", label: "Tools", icon: Gauge, group: "Capabilities", blurb: "Which tools agents may reach for, and their limits.", keywords: "tools calculator websearch readpage limits enable disable" },
  { id: "generation", label: "Generation", icon: MessageSquare, group: "Behaviour", blurb: "Sampling, output limits, retries and the system prompt.", keywords: "temperature top p penalty tokens retries stop system prompt stream reveal" },
  { id: "composer", label: "Composer", icon: MessageSquare, group: "Behaviour", blurb: "How the input behaves, and how you get notified.", keywords: "enter send draft attachment sound notification" },
  { id: "appearance", label: "Appearance", icon: Palette, group: "Behaviour", blurb: "Theme, accent, typography, density, motion and code styling.", keywords: "theme dark light accent font size density animation motion code theme line numbers width" },
  { id: "data", label: "Data & privacy", icon: Archive, group: "System", blurb: "Export, import, share defaults and irreversible purges.", keywords: "export import delete purge share link privacy redact reset" },
  { id: "advanced", label: "Advanced", icon: Wrench, group: "System", blurb: "Timeouts and extra request headers for gateways.", keywords: "timeout headers gateway openrouter referer advanced" },
  { id: "shortcuts", label: "Shortcuts", icon: Keyboard, group: "System", blurb: "Everything you can do without the mouse.", keywords: "keyboard shortcuts keys hotkeys" },
];

const GROUP_ORDER = ["Overview", "Connections", "Capabilities", "Behaviour", "System"];

const SHORTCUTS: Array<[string, string]> = [
  ["⌘ / Ctrl + K", "Command palette"],
  ["⌘ / Ctrl + N", "New conversation"],
  ["⌘ / Ctrl + ,", "Open settings"],
  ["⌘ / Ctrl + S", "Save settings (here)"],
  ["⌘ / Ctrl + /", "Shortcut list"],
  ["Enter", "Send message"],
  ["Shift + Enter", "New line"],
  ["Esc", "Stop generation, close dialog"],
];

export default function SettingsPage() {
  const [section, setSection] = useState("usage");
  const [prefs, setPrefs] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [saved, setSaved] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [credentials, setCredentials] = useState<CredentialRow[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [memoryStats, setMemoryStats] = useState<MemoryStats | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [stats, setStats] = useState<UsageStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState("");
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [shareCount, setShareCount] = useState(0);

  /* ── Deep links: the hash is the source of truth, live-updated ────────── */
  useEffect(() => {
    const read = () => {
      const hash = window.location.hash.replace(/^#\/?/, "");
      if (SECTIONS.some((s) => s.id === hash)) setSection(hash);
    };
    read();
    window.addEventListener("hashchange", read);
    return () => window.removeEventListener("hashchange", read);
  }, []);

  const go = useCallback((id: string) => {
    setSection(id);
    setQuery("");
    if (window.location.hash !== `#${id}`) {
      window.history[window.history.state ? "pushState" : "replaceState"](null, "", `#${id}`);
    }
    window.scrollTo({ top: 0, behavior: document.documentElement.dataset.animations === "off" ? "auto" : "smooth" });
  }, []);

  /* ── Load ──────────────────────────────────────────────────────────────── */
  const json = async (path: string) => {
    try {
      const res = await fetch(path, { cache: "no-store" });
      return res.ok ? await res.json() : null;
    } catch {
      return null;
    }
  };

  const loadAll = useCallback(async () => {
    // Bootstrap must complete first: on a brand-new browser it is what creates
    // the workspace cookie the other endpoints are scoped by.
    const boot = await json("/api/bootstrap");
    const [sk, mem, st] = await Promise.all([
      json("/api/skills"),
      json("/api/memories"),
      json("/api/stats"),
    ]);
    if (boot) {
      setWorkspaceId(boot.workspace?.id ?? null);
      setCredentials(boot.credentials ?? []);
      setAgents(boot.agents ?? []);
      setShareCount(boot.shareCount ?? 0);
      const next = normalizePreferences(boot.preferences ?? {});
      setPrefs(next);
      setSaved(next);
      applyPreferences(next);
    }
    setSkills(sk?.skills ?? []);
    setMemoryStats(mem?.stats ?? null);
    setStats(st ?? null);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        await loadAll();
      } catch {
        toast.error("Could not load settings.");
      } finally {
        setLoading(false);
      }
    })();
  }, [loadAll]);

  /* ── Editing ───────────────────────────────────────────────────────────── */
  const patch = useCallback((values: Partial<Preferences>) => {
    setPrefs((prev) => {
      const next = { ...prev, ...values };
      applyPreferences(next);
      return next;
    });
  }, []);

  const changed = useMemo(() => Object.keys(diffPreferences(prefs, saved)).length, [prefs, saved]);

  const save = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    try {
      const res = await fetch("/api/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(prefs),
      });
      if (!res.ok) throw new Error("save failed");
      const data = (await res.json().catch(() => null)) as { preferences?: Preferences } | null;
      const canonical = normalizePreferences(data?.preferences ?? prefs);
      setPrefs(canonical);
      setSaved(canonical);
      applyPreferences(canonical);
      toast.success("Settings saved");
    } catch {
      toast.error("Could not save settings.");
    } finally {
      setSaving(false);
    }
  }, [prefs, saving]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        if (changed) void save();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [changed, save]);

  useEffect(() => {
    if (!changed) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [changed]);

  /* ── Actions ──────────────────────────────────────────────────────────── */
  const download = (name: string, data: unknown) => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const refresh = useCallback(() => void loadAll(), [loadAll]);

  const purge = async (target: "conversations" | "memories" | "memories-unused" | "tasks" | "skills" | "templates" | "shares" | "all") => {
    try {
      const res = await fetch("/api/maintenance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target }),
      });
      const data = (await res.json().catch(() => null)) as { removed?: number; changed?: number; message?: string } | null;
      if (!res.ok) throw new Error(data?.message ?? "Action failed.");
      const n = data?.removed ?? data?.changed ?? 0;
      toast.success(n ? `Done — ${n} affected.` : "Done.");
      await loadAll();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed.");
    }
  };

  const model = credentials.find((c) => c.kind === "model" && c.isActive && c.enabled);
  const search = credentials.find((c) => c.kind === "search" && c.isActive && c.enabled);
  const current = SECTIONS.find((s) => s.id === section) ?? SECTIONS[0];

  const q = query.trim().toLowerCase();
  const visible = useMemo(
    () =>
      SECTIONS.filter(
        (s) => !q || s.label.toLowerCase().includes(q) || s.keywords.includes(q) || s.blurb.toLowerCase().includes(q),
      ),
    [q],
  );

  const badges: Record<string, string | number> = {
    providers: credentials.filter((c) => c.kind === "model" && c.hasKey).length,
    integrations: credentials.filter((c) => c.kind !== "model" && c.hasKey).length,
    skills: skills.filter((s) => s.enabled).length,
    memory: memoryStats?.enabled ?? 0,
  };

  return (
    <MotionConfig reducedMotion={prefs.animations ? "user" : "always"}>
      <div className="min-h-dvh bg-background">
        <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-xl">
          <div className="mx-auto flex h-14 max-w-[1180px] items-center gap-3 px-4 sm:px-6">
            <Link
              href="/"
              aria-label="Back to chat"
              className="flex size-8 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
            >
              <ArrowLeft size={17} />
            </Link>
            <Logo size={26} />
            <div className="min-w-0 flex-1">
              <p className="text-[14.5px] font-semibold tracking-tight">Settings</p>
              <p className="truncate font-mono text-[11px] text-muted-foreground">
                {workspaceId ? `workspace ${workspaceId.slice(0, 8)}` : "workspace"}
              </p>
            </div>

            <AnimatePresence initial={false}>
              {changed > 0 && (
                <motion.span
                  key="dirty"
                  initial={{ opacity: 0, scale: 0.92, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.94 }}
                  transition={{ duration: 0.2, ease: EASE }}
                  className="hidden items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-[11.5px] font-medium text-amber-700 dark:text-amber-400 sm:inline-flex"
                >
                  <span className="live-dot size-1.5 rounded-full bg-amber-500" />
                  {changed} unsaved
                </motion.span>
              )}
            </AnimatePresence>

            {changed > 0 ? (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-1.5"
              >
                <button
                  type="button"
                  onClick={() => {
                    setPrefs(saved);
                    applyPreferences(saved);
                  }}
                  className="hidden rounded-full px-2.5 py-1.5 text-[12px] text-muted-foreground transition hover:bg-accent hover:text-foreground sm:block"
                >
                  Discard
                </button>
                <Button size="sm" onClick={() => void save()} disabled={saving}>
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                  Save {changed}
                </Button>
              </motion.div>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1.5 text-[12px] text-muted-foreground">
                <Check size={13} className="text-emerald-600 dark:text-emerald-400" />
                <span className="hidden sm:inline">All changes saved</span>
              </span>
            )}
          </div>
        </header>

        <div className="mx-auto grid max-w-[1180px] gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[224px_minmax(0,1fr)]">
          {/* Rail */}
          <nav aria-label="Settings sections" className="min-w-0 lg:sticky lg:top-[76px] lg:self-start">
            <div className="relative mb-3">
              <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search settings"
                aria-label="Search settings"
                className="h-9 pl-8 text-[13px]"
              />
            </div>

            {loading ? (
              <div className="space-y-1.5">
                {Array.from({ length: 9 }).map((_, i) => (
                  <div key={i} className="nova-skeleton h-9 rounded-lg" />
                ))}
              </div>
            ) : (
              <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:block lg:space-y-4 lg:overflow-visible">
                {GROUP_ORDER.map((group) => {
                  const items = visible.filter((s) => s.group === group);
                  if (items.length === 0) return null;
                  return (
                    <div key={group} className="flex shrink-0 gap-1 lg:block lg:space-y-px">
                      <p className="hidden px-2 pb-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground/70 lg:block">
                        {group}
                      </p>
                      {items.map((s) => {
                        const active = section === s.id;
                        const badge = badges[s.id];
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => go(s.id)}
                            aria-current={active ? "page" : undefined}
                            className={cn(
                              "relative isolate flex w-[168px] shrink-0 items-center gap-2.5 whitespace-nowrap rounded-lg px-2.5 py-2 text-[13.5px] outline-none transition-colors lg:w-full",
                              active
                                ? "bg-foreground font-medium text-background lg:bg-transparent lg:text-accent-foreground"
                                : "text-muted-foreground hover:text-foreground",
                            )}
                          >
                            {active && (
                              <span className="absolute inset-0 -z-10 hidden rounded-lg bg-accent lg:block" />
                            )}
                            <s.icon size={15} className={cn("relative z-10 shrink-0", active ? "text-brand" : "text-muted-foreground")} />
                            <span className="relative z-10 min-w-0 flex-1 truncate">{s.label}</span>
                            {typeof badge === "number" && badge > 0 && (
                              <span className={cn("relative z-10 rounded-full px-1.5 font-mono text-[10.5px]", active ? "bg-background/25 text-background lg:bg-background/80 lg:text-foreground" : "bg-muted text-muted-foreground")}>
                                {badge}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  );
                })}
                {visible.length === 0 && (
                  <p className="px-2 py-4 text-[12.5px] text-muted-foreground">Nothing matches “{query}”.</p>
                )}
              </div>
            )}
          </nav>

          {/* Content */}
          <main className="min-w-0 pb-28">
            <AnimatePresence mode="wait">
              <motion.div
                key={section}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16, ease: EASE }}
              >
                <SectionIntro title={current.label} description={current.blurb} />
                <div className="min-w-0">
                  {section === "usage" && <UsageSection stats={stats} loading={loading} />}
                  {section === "providers" && (
                    <SettingsProviders kind="model" credentials={credentials} onChanged={refresh} onUseModel={(m, id) => patch({ defaultModel: m, defaultProvider: id })} defaultModel={prefs.defaultModel} />
                  )}
                  {section === "integrations" && (
                    <div className="space-y-8">
                      <SettingsProviders kind="search" credentials={credentials} onChanged={refresh} />
                      <div className="border-t pt-8">
                        <SettingsProviders kind="reader" credentials={credentials} onChanged={refresh} />
                      </div>
                      <div className="border-t pt-8">
                        <WebSection prefs={prefs} patch={patch} activeSearch={search?.label ?? null} />
                      </div>
                    </div>
                  )}
                  {section === "skills" && <SkillsSection prefs={prefs} patch={patch} skills={skills} onChanged={refresh} />}
                  {section === "memory" && <MemorySection prefs={prefs} patch={patch} stats={memoryStats} onChanged={refresh} onPrune={() => void purge("memories-unused")} />}
                  {section === "context" && <ContextSection prefs={prefs} patch={patch} />}
                  {section === "tools" && <ToolsSection prefs={prefs} patch={patch} />}
                  {section === "generation" && <ResponseSection prefs={prefs} patch={patch} hasModel={Boolean(model)} />}
                  {section === "composer" && <ComposerSection prefs={prefs} patch={patch} />}
                  {section === "appearance" && <AppearanceSection prefs={prefs} patch={patch} />}
                  {section === "data" && (
                    <DataSection
                      prefs={prefs}
                      patch={patch}
                      workspaceId={workspaceId}
                      shareCount={shareCount}
                      onExportAll={() => void fetch("/api/data", { cache: "no-store" }).then(async (r) => (r.ok ? download("nova-workspace.json", await r.json()) : toast.error("Export failed")))}
                      onExportSettings={() => download("nova-settings.json", prefs)}
                      onImportSettings={async (file) => {
                        try {
                          const parsed = JSON.parse(await file.text()) as Record<string, unknown>;
                          const next = normalizePreferences(parsed);
                          setPrefs(next);
                          applyPreferences(next);
                          const res = await fetch("/api/preferences", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(next) });
                          if (!res.ok) throw new Error("save failed");
                          setSaved(next);
                          toast.success("Settings imported and saved");
                        } catch {
                          toast.error("That file is not a valid settings export.");
                        }
                      }}
                      onResetPreferences={() => {
                        setPrefs(DEFAULT_PREFERENCES);
                        applyPreferences(DEFAULT_PREFERENCES);
                        toast.message("Defaults staged — press Save to apply.");
                      }}
                      onPurge={(target) => void purge(target)}
                    />
                  )}
                  {section === "advanced" && (
                    <div className="space-y-5">
                      <AdvancedSection prefs={prefs} patch={patch} onReset={() => setPrefs(DEFAULT_PREFERENCES)} />
                    </div>
                  )}
                  {section === "shortcuts" && (
                    <section className="overflow-hidden rounded-xl border bg-card">
                      <div className="divide-y">
                        {SHORTCUTS.map(([keys, action], i) => (
                          <motion.div
                            key={keys}
                            initial={{ opacity: 0, x: -6 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.03 * i, duration: 0.25, ease: EASE }}
                            className="flex items-center justify-between gap-4 px-4 py-2.5"
                          >
                            <span className="text-[13px]">{action}</span>
                            <kbd className="rounded-md border bg-muted/60 px-2 py-0.5 font-mono text-[11px] text-muted-foreground">{keys}</kbd>
                          </motion.div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>

            <motion.div
              initial={false}
              animate={{ opacity: changed > 0 ? 1 : 0, y: changed > 0 ? 0 : 16 }}
              transition={{ duration: 0.28, ease: EASE }}
              className={cn(
                "pointer-events-none fixed inset-x-0 bottom-5 z-40 mx-auto hidden w-fit items-center gap-3 rounded-full border bg-card/95 px-4 py-2 shadow-lg backdrop-blur lg:flex",
                changed > 0 ? "pointer-events-auto" : "",
              )}
            >
              <span className="text-[12.5px] font-medium">{changed} unsaved change{changed === 1 ? "" : "s"}</span>
              <button type="button" onClick={() => { setPrefs(saved); applyPreferences(saved); }} className="rounded-full px-2 py-0.5 text-[12px] text-muted-foreground transition hover:bg-accent hover:text-foreground">
                Discard
              </button>
              <Button size="sm" onClick={() => void save()} disabled={saving}>
                {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
                Save
              </Button>
              <span className="font-mono text-[10.5px] text-muted-foreground">⌘S</span>
            </motion.div>
          </main>
        </div>
      </div>
    </MotionConfig>
  );
}


