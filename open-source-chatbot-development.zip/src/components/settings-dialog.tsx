"use client";

import { useEffect, useState } from "react";
import { Database, Download, ExternalLink, Eye, EyeOff, RotateCcw, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { DEFAULT_SETTINGS, PROVIDERS } from "@/lib/settings";
import type { ProviderId, Settings } from "@/lib/types";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settings: Settings;
  workspaceId: string | null;
  onExportAll: () => void;
  onDeleteAll: () => void;
  onSave: (settings: Settings) => void;
}

const fieldLabel = "mb-1.5 block text-[13px] font-medium";
const hint = "mt-1 text-[12px] leading-relaxed text-muted-foreground";
const section = "mt-5 border-t pt-4";

export default function SettingsDialog(props: SettingsDialogProps) {
  const [draft, setDraft] = useState<Settings>(props.settings);
  const [showKey, setShowKey] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (props.open) {
      setDraft({ ...props.settings, apiKey: "" });
    }
  }, [props.open, props.settings]);

  const provider = PROVIDERS.find((p) => p.id === draft.provider);
  const patch = (values: Partial<Settings>) => setDraft((prev) => ({ ...prev, ...values }));

  const changeProvider = (id: ProviderId) => {
    const next = PROVIDERS.find((p) => p.id === id);
    patch({ provider: id, model: next?.models[0] ?? "custom-model" });
  };

  const save = async () => {
    setSaving(true);
    try {
      props.onSave({ ...draft, apiKey: "" });
      props.onOpenChange(false);
    } catch {
      toast.error("Could not save settings");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[88vh] sm:max-w-[600px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Model & settings</DialogTitle>
          <DialogDescription>
            Connect any OpenAI-compatible endpoint, or use a provider API key. Your key is kept
            in an httpOnly cookie and never exposed to browser JavaScript.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className={fieldLabel} htmlFor="provider">Provider</label>
            <select
              id="provider"
              value={draft.provider}
              onChange={(e) => changeProvider(e.target.value as ProviderId)}
              className="h-10 w-full rounded-md border border-input bg-transparent px-3 text-[14px] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
            >
              {PROVIDERS.map((p) => (
                <option key={p.id} value={p.id}>{p.label}</option>
              ))}
            </select>
            <p className={hint}>{provider?.description}</p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className={fieldLabel} htmlFor="model">Model ID</label>
              <Input id="model" value={draft.model} onChange={(e) => patch({ model: e.target.value })} list="model-presets" className="text-[14px]" />
              <datalist id="model-presets">
                {provider?.models.map((m) => <option key={m} value={m} />)}
              </datalist>
            </div>
            <div>
              <label className={fieldLabel} htmlFor="maxTokens">Max output tokens</label>
              <Input id="maxTokens" type="number" min={128} max={16384} value={draft.maxTokens} onChange={(e) => patch({ maxTokens: Number(e.target.value) })} className="text-[14px]" />
            </div>
          </div>

          <div className="rounded-lg border bg-muted/50 px-3.5 py-3 text-[13px] leading-relaxed text-muted-foreground">
            <ShieldCheck size={13} className="mr-1.5 inline" />
            API keys live on the server, encrypted. Add or change them in{" "}
            <a
              href="/settings"
              className="font-medium text-foreground underline underline-offset-2"
            >
              Settings → Providers
            </a>
            .
          </div>

          {draft.provider === "custom" && (
            <div>
              <label className={fieldLabel} htmlFor="baseURL">API base URL</label>
              <Input id="baseURL" value={draft.baseURL} onChange={(e) => patch({ baseURL: e.target.value })} placeholder="http://localhost:11434/v1" className="font-mono text-[13px]" />
              <p className={hint}>Use the Chat Completions endpoint of Ollama, LM Studio, vLLM or OpenRouter.</p>
            </div>
          )}

          <div>
            <label className={fieldLabel} htmlFor="systemPrompt">System prompt</label>
            <Textarea id="systemPrompt" value={draft.systemPrompt} onChange={(e) => patch({ systemPrompt: e.target.value })} rows={4} className="resize-y text-[13px]" />
            <p className={hint}>Agents with their own system prompt override this value.</p>
          </div>

          <div>
            <label className={fieldLabel} htmlFor="temperature">Temperature: {draft.temperature.toFixed(1)}</label>
            <input id="temperature" type="range" min={0} max={2} step={0.1} value={draft.temperature} onChange={(e) => patch({ temperature: Number(e.target.value) })} className="h-1.5 w-full cursor-pointer accent-foreground" />
            <div className="mt-1 flex justify-between text-[12px] text-muted-foreground"><span>Precise</span><span>Creative</span></div>
          </div>

          <div className="rounded-lg border bg-muted/50 p-3 text-[12px] leading-relaxed text-muted-foreground">
            <span className="font-medium text-foreground">No key?</span> Install{" "}
            <a href="https://github.com/ollama/ollama" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-0.5 underline underline-offset-2">
              Ollama <ExternalLink size={11} />
            </a>{" "}
            locally, then choose “OpenAI-compatible” with <code className="font-mono">http://localhost:11434/v1</code>. Or stay in offline demo mode.
          </div>

          <div className={section}>
            <p className="mb-1 flex items-center gap-2 text-[14px] font-medium"><Database size={15} /> Workspace data</p>
            <p className="mb-3 text-[12px] text-muted-foreground">
              Your workspace is isolated by a signed cookie. ID:{" "}
              <code className="font-mono">{props.workspaceId ? `${props.workspaceId.slice(0, 8)}…` : "—"}</code>
            </p>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={props.onExportAll}>
                <Download size={14} /> Export all data
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  if (window.confirm("Permanently delete all conversations, agents, memories, tasks and templates in this workspace? This cannot be undone.")) {
                    props.onDeleteAll();
                    props.onOpenChange(false);
                  }
                }}
              >
                <Trash2 size={14} /> Delete all data
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" size="sm" onClick={() => setDraft(DEFAULT_SETTINGS)} title="Reset to defaults">
            <RotateCcw size={14} /> Reset
          </Button>
          <Button variant="outline" size="sm" onClick={() => props.onOpenChange(false)}>Cancel</Button>
          <Button size="sm" onClick={() => void save()} disabled={saving}>
            {saving ? "Saving…" : "Save settings"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

