"use client";

import { memo, useEffect, useState } from "react";
import { Streamdown } from "streamdown";
import { code } from "@streamdown/code";

/**
 * Shiki themes per selectable code theme. Every name here is part of Shiki's
 * bundled theme set, so no extra network fetch is needed.
 */
const CODE_THEMES: Record<string, [string, string]> = {
  github: ["github-light", "github-dark-default"],
  "night-owl": ["night-owl", "night-owl"],
  "min-light": ["min-light", "min-light"],
  "material-theme": ["material-theme-lighter", "material-theme-darker"],
};

export type CodeThemeName = keyof typeof CODE_THEMES;

/**
 * Reads the theme applied to <html> so this component never needs the whole
 * preferences object drilled through every markdown call site. A
 * MutationObserver keeps already-mounted messages in sync when the setting
 * changes.
 */
function useActiveCodeTheme(): [string, string] {
  const [theme, setTheme] = useState<[string, string]>(CODE_THEMES.github);

  useEffect(() => {
    const root = document.documentElement;
    const read = () => {
      const name = root.dataset.codeTheme ?? "github";
      setTheme(CODE_THEMES[name] ?? CODE_THEMES.github);
    };
    read();
    const observer = new MutationObserver(read);
    observer.observe(root, { attributes: true, attributeFilter: ["data-code-theme"] });
    return () => observer.disconnect();
  }, []);

  return theme;
}

/**
 * Markdown renderer built on vercel/streamdown — designed for streaming AI
 * output (repairs unterminated markdown mid-stream) with Shiki highlighting.
 */
function MarkdownImpl({ content, streaming = false }: { content: string; streaming?: boolean }) {
  const theme = useActiveCodeTheme();

  return (
    <Streamdown
      className="chat-markdown"
      mode={streaming ? "streaming" : "static"}
      isAnimating={streaming}
      animated={streaming}
      plugins={{ code }}
      shikiTheme={theme}
      controls={{ code: true, table: true }}
    >
      {content}
    </Streamdown>
  );
}

export const Markdown = memo(MarkdownImpl);
