"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import {
  IconAgents,
  IconAnalytics,
  IconChat,
  IconChevronDown,
  IconChevronRight,
  IconCompose,
  IconContext,
  IconCopy,
  IconDots,
  IconDownload,
  IconFile,
  IconFork,
  IconInfo,
  IconMemory,
  IconMoon,
  IconPanelLeftClose,
  IconPanelLeftOpen,
  IconPencil,
  IconPin,
  IconPinOff,
  IconSearch,
  IconSettingsSliders,
  IconSkills,
  IconSun,
  IconTasks,
  IconTemplates,
  IconTrash,
} from "./sidebar-icons";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { Logo } from "./logo";
import { groupConversations } from "@/lib/format";
import { useMediaQuery, useMounted } from "@/lib/use-media-query";
import { cn } from "@/lib/utils";
import type { ConversationSummary } from "@/lib/types";
import type { ThemePreference } from "./providers";

export interface SidebarNavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
  badge?: number;
  shortcut?: string;
}

interface SidebarProps {
  conversations: ConversationSummary[];
  activeId: string | null;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDelete: (id: string) => void;
  onFork: (id: string) => void;
  onExport: (id: string, format: "md" | "json") => void;
  onOpenSettings: () => void;
  onOpenAgents: () => void;
  onOpenTasks: () => void;
  onOpenMemories: () => void;
  onOpenTemplates: () => void;
  onOpenStats: () => void;
  onOpenSkills: () => void;
  onOpenContext: () => void;
  onOpenAbout: () => void;
  onOpenPalette: () => void;
  offline: boolean;
  openTasks: number;
  theme: ThemePreference;
  resolvedTheme: "light" | "dark";
  onToggleTheme: () => void;
  providerLabel: string | null;
  providerKeyPreview: string | null;
  collapsed?: boolean;
  onToggleCollapsed: () => void;
}

const GROUPS_KEY = "nova-sidebar-groups";

function RailTooltip({
  label,
  shortcut,
  children,
}: {
  label: string;
  shortcut?: string;
  children: React.ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent side="right" sideOffset={12} className="flex items-center gap-2">
        <span>{label}</span>
        {shortcut && <kbd className="font-mono text-[10px] opacity-60">{shortcut}</kbd>}
      </TooltipContent>
    </Tooltip>
  );
}

export default function Sidebar(props: SidebarProps) {
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<string[]>([]);
  const searchRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const collapsed = Boolean(props.collapsed);
  const mounted = useMounted();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  // Single source of truth for both axes: on desktop the shell never leaves
  // the layout flow; on mobile it slides as a drawer. Framer owns `width` and
  // `x` together so the two can never disagree.
  const shellWidth = collapsed ? 60 : 268;
  const shellX = !mounted || isDesktop ? 0 : props.open ? 0 : -shellWidth;

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(GROUPS_KEY);
      if (raw) setCollapsedGroups(JSON.parse(raw) as string[]);
    } catch {
      /* ignore */
    }
  }, []);

  const toggleGroup = useCallback((label: string) => {
    setCollapsedGroups((prev) => {
      const next = prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label];
      try {
        window.localStorage.setItem(GROUPS_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return props.conversations;
    return props.conversations.filter((c) => c.title.toLowerCase().includes(q));
  }, [props.conversations, query]);

  const groups = useMemo(() => groupConversations(filtered), [filtered]);

  const commitRename = () => {
    if (renamingId && draft.trim()) props.onRename(renamingId, draft.trim());
    setRenamingId(null);
  };

  const onListKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const rows = Array.from(
      listRef.current?.querySelectorAll<HTMLButtonElement>("[data-conv-row]") ?? [],
    );
    if (rows.length === 0) return;
    event.preventDefault();
    const index = rows.findIndex((row) => row === document.activeElement);
    const next = event.key === "ArrowDown" ? index + 1 : index - 1;
    rows[Math.max(0, Math.min(rows.length - 1, next === -1 ? rows.length - 1 : next))]?.focus();
  };

  const workspaceItems: SidebarNavItem[] = [
    { id: "agents", label: "Agents", icon: <IconAgents size={16} />, onClick: props.onOpenAgents },
    { id: "skills", label: "Skills", icon: <IconSkills size={16} />, onClick: props.onOpenSkills },
    { id: "memory", label: "Memory", icon: <IconMemory size={16} />, onClick: props.onOpenMemories },
    { id: "context", label: "Context", icon: <IconContext size={16} />, onClick: props.onOpenContext },
    { id: "tasks", label: "Tasks", icon: <IconTasks size={16} />, onClick: props.onOpenTasks, badge: props.openTasks },
    { id: "templates", label: "Templates", icon: <IconTemplates size={16} />, onClick: props.onOpenTemplates },
    { id: "analytics", label: "Usage", icon: <IconAnalytics size={16} />, onClick: props.onOpenStats },
  ];

  return (
    <TooltipProvider delayDuration={150}>
      {/* Mobile Backdrop */}
      {props.open && (
        <button
          type="button"
          aria-label="Close sidebar"
          onClick={props.onClose}
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Main Sidebar Shell */}
      <motion.aside
        aria-label="Workspace navigation"
        initial={false}
        animate={{ width: shellWidth, x: shellX }}
        transition={{
          type: "spring",
          stiffness: 420,
          damping: 38,
          mass: 0.8,
        }}
        style={{ left: 0 }}
        className={cn(
          "sidebar-shell fixed inset-y-0 z-50 flex shrink-0 flex-col border-r bg-sidebar select-none lg:relative lg:z-0",
        )}
      >
        {/* Top Header: Brand + Collapse/Expand Trigger */}
        <div
          className={cn(
            "flex h-14 shrink-0 items-center border-b border-border/50",
            collapsed ? "justify-center px-0" : "justify-between px-3",
          )}
        >
          {collapsed ? (
            /* Rail Mode Top Trigger: Obvious and clickable to expand */
            <RailTooltip label="Expand sidebar" shortcut="⌘B">
              <button
                type="button"
                onClick={props.onToggleCollapsed}
                aria-label="Expand sidebar"
                className="group flex size-9 items-center justify-center rounded-lg text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95"
              >
                <IconPanelLeftOpen size={18} className="transition-transform group-hover:scale-105" />
              </button>
            </RailTooltip>
          ) : (
            <>
              {/* Expanded Mode: Brand link */}
              <Link
                href="/"
                className="group flex items-center gap-2.5 rounded-lg py-1 outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Logo size={24} className="transition-transform group-hover:scale-105" />
                <span className="text-[15px] font-semibold tracking-tight text-foreground">
                  Nova
                </span>
              </Link>

              {/* Expanded Mode: Prominent Collapse Button */}
              <div className="flex items-center gap-1">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      type="button"
                      onClick={props.onToggleCollapsed}
                      aria-label="Collapse sidebar"
                      className="hidden size-8 items-center justify-center rounded-lg text-muted-foreground outline-none transition-all hover:bg-accent hover:text-foreground active:scale-95 lg:flex"
                    >
                      <IconPanelLeftClose size={17} />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="flex items-center gap-2">
                    <span>Collapse sidebar</span>
                    <kbd className="font-mono text-[10px] opacity-60">⌘B</kbd>
                  </TooltipContent>
                </Tooltip>

                {/* Mobile close button */}
                <button
                  type="button"
                  onClick={props.onClose}
                  aria-label="Close sidebar"
                  className="flex size-8 items-center justify-center rounded-lg text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground lg:hidden"
                >
                  <IconPanelLeftClose size={17} />
                </button>
              </div>
            </>
          )}
        </div>

        {/* Primary Actions: New chat & Search */}
        <div className={cn("shrink-0 space-y-1 pt-2.5", collapsed ? "px-2" : "px-2.5")}>
          {collapsed ? (
            <>
              <RailTooltip label="New chat" shortcut="⌘N">
                <button
                  type="button"
                  onClick={props.onNew}
                  aria-label="New chat"
                  className="flex size-9 w-full items-center justify-center rounded-lg bg-foreground text-background shadow-xs outline-none transition hover:opacity-90 active:scale-95"
                >
                  <IconCompose size={17} />
                </button>
              </RailTooltip>
              <RailTooltip label="Search" shortcut="⌘K">
                <button
                  type="button"
                  onClick={props.onOpenPalette}
                  aria-label="Search conversations"
                  className="flex size-9 w-full items-center justify-center rounded-lg text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground active:scale-95"
                >
                  <IconSearch size={17} />
                </button>
              </RailTooltip>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={props.onNew}
                className="group flex h-9 w-full items-center gap-2.5 rounded-lg border border-transparent bg-foreground px-2.5 text-[13.5px] font-medium text-background shadow-xs outline-none transition hover:opacity-90 active:scale-[0.99] focus-visible:ring-2 focus-visible:ring-ring"
              >
                <IconCompose size={16} />
                <span>New chat</span>
                <kbd className="ml-auto rounded bg-background/20 px-1.5 py-0.5 font-sans text-[10.5px] text-background">
                  ⌘N
                </kbd>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSearching(true);
                  requestAnimationFrame(() => searchRef.current?.focus());
                }}
                className="group flex h-9 w-full items-center gap-2.5 rounded-lg px-2.5 text-[13.5px] text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground active:scale-[0.99] focus-visible:ring-2 focus-visible:ring-ring"
              >
                <IconSearch size={16} className="transition-colors group-hover:text-foreground" />
                <span>Search</span>
                <kbd className="ml-auto font-sans text-[10.5px] text-muted-foreground/70">⌘K</kbd>
              </button>
            </>
          )}
        </div>

        {/* Quick Filter Input (when searching is toggled) */}
        {searching && !collapsed && (
          <div className="px-2.5 pt-2">
            <div className="relative">
              <IconSearch size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onBlur={() => {
                  if (!query) setSearching(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Escape") {
                    setQuery("");
                    setSearching(false);
                  }
                  if (e.key === "Enter") props.onOpenPalette();
                }}
                placeholder="Filter chats…"
                aria-label="Filter conversations"
                className="h-8 w-full rounded-lg border bg-card pl-8 pr-2 text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>
          </div>
        )}

        {/* Workspace Tools Navigation */}
        <div className={cn("shrink-0 pt-3 pb-2", collapsed ? "px-2" : "px-2.5")}>
          {!collapsed && (
            <p className="px-2 pb-1 text-[10px] font-semibold uppercase tracking-[0.09em] text-muted-foreground/70">
              Workspace
            </p>
          )}
          <div className={cn(collapsed ? "flex flex-col items-center gap-1" : "grid grid-cols-2 gap-x-1 gap-y-0.5")}>
            {workspaceItems.map((item) =>
              collapsed ? (
                <RailTooltip key={item.id} label={item.label}>
                  <button
                    type="button"
                    onClick={item.onClick}
                    aria-label={item.label}
                    className="flex size-9 items-center justify-center rounded-lg text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95"
                  >
                    {item.icon}
                  </button>
                </RailTooltip>
              ) : (
                <button
                  key={item.id}
                  type="button"
                  onClick={item.onClick}
                  className="group flex h-8 min-w-0 items-center gap-2 rounded-lg px-2 text-[12.5px] text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="shrink-0 transition-colors group-hover:text-foreground">{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                  {typeof item.badge === "number" && item.badge > 0 && (
                    <span className="ml-auto rounded-full bg-foreground px-1.5 font-mono text-[10px] leading-4 text-background">
                      {item.badge}
                    </span>
                  )}
                </button>
              ),
            )}
          </div>
        </div>

        {/* Divider */}
        <div className={cn("shrink-0 py-1", collapsed ? "px-2" : "px-3")}>
          <div className="h-px w-full bg-border/60" />
        </div>

        {/* Conversations List with Smooth Scroll */}
        <div
          ref={listRef}
          onKeyDown={onListKeyDown}
          className={cn("scroll-slim min-h-0 flex-1 overflow-y-auto pt-1", collapsed ? "px-2" : "px-2.5")}
        >
          {collapsed ? (
            /* Rail Conversations */
            <div className="flex flex-col items-center gap-1 pt-1">
              {props.conversations.slice(0, 14).map((c) => (
                <RailTooltip key={c.id} label={c.title}>
                  <button
                    type="button"
                    onClick={() => props.onSelect(c.id)}
                    aria-label={c.title}
                    aria-current={c.id === props.activeId ? "page" : undefined}
                    className={cn(
                      "relative flex size-9 items-center justify-center rounded-lg transition active:scale-95",
                      c.id === props.activeId
                        ? "bg-accent text-foreground"
                        : "text-muted-foreground hover:bg-accent/70 hover:text-foreground",
                    )}
                  >
                    {c.id === props.activeId && (
                      <span className="absolute -left-1.5 h-4 w-[2px] rounded-full bg-brand" />
                    )}
                    <IconChat size={15} />
                    {c.pinned && (
                      <span className="absolute right-1 top-1 size-1.5 rounded-full bg-brand" />
                    )}
                  </button>
                </RailTooltip>
              ))}
              {props.conversations.length === 0 && (
                <span className="pt-2 text-[10px] text-muted-foreground">—</span>
              )}
            </div>
          ) : groups.length === 0 ? (
            <p className="px-2.5 pt-5 text-[12.5px] leading-relaxed text-muted-foreground">
              {query ? "No chats match that." : "Chats will appear here once you start one."}
            </p>
          ) : (
            /* Grouped Conversation Accordions */
            groups.map((group) => {
              const isCollapsed = collapsedGroups.includes(group.label);
              return (
                <section key={group.label} className="pt-2">
                  <button
                    type="button"
                    onClick={() => toggleGroup(group.label)}
                    aria-expanded={!isCollapsed}
                    className="group flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {isCollapsed ? <IconChevronRight size={12} /> : <IconChevronDown size={12} />}
                    <span className="truncate">{group.label}</span>
                    <span className="ml-auto font-mono text-[10px] opacity-60">{group.items.length}</span>
                  </button>

                  <AnimatePresence initial={false}>
                    {!isCollapsed && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.18, ease: [0.22, 1, 0.3, 1] }}
                        className="overflow-hidden"
                      >
                        <div className="space-y-px pt-0.5">
                          {group.items.map((c) => {
                            const active = c.id === props.activeId;
                            return (
                              <div
                                key={c.id}
                                className={cn(
                                  "group/row relative flex items-center rounded-lg transition-colors",
                                  active ? "bg-accent" : "hover:bg-accent/60",
                                )}
                              >
                                {active && (
                                  <span className="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-brand" />
                                )}
                                {renamingId === c.id ? (
                                  <input
                                    autoFocus
                                    value={draft}
                                    onChange={(e) => setDraft(e.target.value)}
                                    onBlur={commitRename}
                                    onKeyDown={(e) => {
                                      if (e.key === "Enter") commitRename();
                                      if (e.key === "Escape") setRenamingId(null);
                                    }}
                                    aria-label="Rename conversation"
                                    className="mx-1 my-1 h-7 flex-1 rounded-md border bg-card px-2 text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                  />
                                ) : (
                                  <button
                                    type="button"
                                    data-conv-row
                                    onClick={() => props.onSelect(c.id)}
                                    aria-current={active ? "page" : undefined}
                                    className="flex h-8 min-w-0 flex-1 items-center gap-1.5 rounded-lg px-2 text-left text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                  >
                                    {c.pinned && <IconPin size={11} className="shrink-0 text-muted-foreground" />}
                                    <span
                                      className={cn(
                                        "truncate",
                                        active ? "font-medium text-accent-foreground" : "text-foreground/85",
                                      )}
                                    >
                                      {c.title}
                                    </span>
                                  </button>
                                )}
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <button
                                      type="button"
                                      aria-label={`Options for ${c.title}`}
                                      className="mr-1 flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground opacity-0 outline-none transition hover:bg-background hover:text-foreground focus-visible:opacity-100 group-hover/row:opacity-100 data-[state=open]:opacity-100 [@media(hover:none)]:opacity-100"
                                    >
                                      <IconDots size={14} />
                                    </button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="start" side="right" className="w-52">
                                    <DropdownMenuItem
                                      onSelect={() => {
                                        setDraft(c.title);
                                        setRenamingId(c.id);
                                      }}
                                    >
                                      <IconPencil size={14} /> Rename
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => props.onTogglePin(c.id, !c.pinned)}>
                                      {c.pinned ? <IconPinOff size={14} /> : <IconPin size={14} />}
                                      {c.pinned ? "Unpin" : "Pin to top"}
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => props.onFork(c.id)}>
                                      <IconFork size={14} /> Duplicate
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onSelect={() => props.onExport(c.id, "md")}>
                                      <IconFile size={14} /> Export Markdown
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => props.onExport(c.id, "json")}>
                                      <IconDownload size={14} /> Export JSON
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      variant="destructive"
                                      onSelect={() => {
                                        if (window.confirm(`Delete “${c.title}”?`)) props.onDelete(c.id);
                                      }}
                                    >
                                      <IconTrash size={14} /> Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </section>
              );
            })
          )}
        </div>

        {/* Desktop border hover trigger / resize affordance */}
        <div
          onClick={props.onToggleCollapsed}
          title={collapsed ? "Expand sidebar (⌘B)" : "Collapse sidebar (⌘B)"}
          className="group/edge absolute -right-1 top-0 bottom-0 z-30 hidden w-2.5 cursor-pointer lg:block"
        >
          <div className="mx-auto h-full w-[2px] opacity-0 transition-opacity duration-200 group-hover/edge:bg-brand/60 group-hover/edge:opacity-100" />
        </div>

        {/* Footer: Account / Provider Profile card + Collapse trigger */}
        <div className={cn("shrink-0 border-t border-border/50", collapsed ? "p-2" : "p-2.5")}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Account and workspace menu"
                className={cn(
                  "flex w-full items-center rounded-lg outline-none transition hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring",
                  collapsed ? "size-10 justify-center" : "gap-2.5 p-1.5",
                )}
              >
                <span className="relative flex size-7 shrink-0 items-center justify-center rounded-full bg-foreground text-[11px] font-semibold text-background">
                  N
                  <span
                    className={cn(
                      "absolute -bottom-0.5 -right-0.5 size-2.5 rounded-full border-2 border-sidebar",
                      props.providerLabel ? "bg-emerald-500" : "bg-amber-500",
                    )}
                  />
                </span>
                {!collapsed && (
                  <span className="min-w-0 flex-1 text-left">
                    <span className="block truncate text-[12.5px] font-medium text-foreground">
                      {props.providerLabel ?? "No provider"}
                    </span>
                    <span className="block truncate text-[11px] text-muted-foreground">
                      {props.providerKeyPreview ?? "Add your API key"}
                    </span>
                  </span>
                )}
                {!collapsed && <IconDots size={14} className="shrink-0 text-muted-foreground" />}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align={collapsed ? "start" : "end"} side={collapsed ? "right" : "top"} className="w-56">
              <DropdownMenuItem onSelect={props.onOpenSettings}>
                <IconSettingsSliders size={15} /> Settings
                <kbd className="ml-auto font-mono text-[10px] text-muted-foreground">⌘,</kbd>
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={props.onOpenPalette}>
                <IconSearch size={15} /> Command palette
                <kbd className="ml-auto font-mono text-[10px] text-muted-foreground">⌘K</kbd>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={props.onToggleTheme}>
                {props.resolvedTheme === "dark" ? <IconSun size={15} /> : <IconMoon size={15} />}
                Switch to {props.resolvedTheme === "dark" ? "light" : "dark"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={props.onOpenAbout}>
                <IconInfo size={15} /> About & open source
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onSelect={() => {
                  window.localStorage.removeItem("nova-theme");
                  window.location.reload();
                }}
              >
                <IconInfo size={15} /> Reset appearance
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Expanded Bottom Row: Quick collapse button & Theme switch */}
          {!collapsed && (
            <div className="mt-1.5 flex items-center justify-between gap-1 pt-1">
              <button
                type="button"
                onClick={props.onToggleCollapsed}
                aria-label="Collapse sidebar"
                className="group flex h-7 items-center gap-1.5 rounded-md px-2 text-[11.5px] text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground"
              >
                <IconPanelLeftClose size={14} className="transition-transform group-hover:scale-105" />
                <span>Collapse</span>
                <kbd className="ml-1 font-sans text-[10px] opacity-70">⌘B</kbd>
              </button>
              <button
                type="button"
                onClick={props.onToggleTheme}
                aria-label="Toggle theme"
                title="Toggle theme"
                className="flex size-7 items-center justify-center rounded-md text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
              >
                {props.resolvedTheme === "dark" ? <IconSun size={14} /> : <IconMoon size={14} />}
              </button>
            </div>
          )}
        </div>
      </motion.aside>
    </TooltipProvider>
  );
}
