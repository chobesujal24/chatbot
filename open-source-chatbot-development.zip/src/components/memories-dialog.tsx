"use client";

import { useState } from "react";
import { Brain, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import type { MemoryItem } from "@/lib/types";

interface MemoriesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  memories: MemoryItem[];
  onChanged: () => void;
}

export default function MemoriesDialog(props: MemoriesDialogProps) {
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");

  const add = async () => {
    if (!key.trim() || !value.trim()) return;
    const res = await fetch("/api/memories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: key.trim(), value: value.trim() }),
    });
    if (!res.ok) {
      toast.error("Could not save memory");
      return;
    }
    setKey("");
    setValue("");
    props.onChanged();
  };

  const remove = async (id: string) => {
    const res = await fetch(`/api/memories/${id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not delete memory");
      return;
    }
    props.onChanged();
  };

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[85vh] sm:max-w-[520px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain size={16} /> Memory
          </DialogTitle>
          <DialogDescription>
            Durable facts agents can save and recall across conversations.
          </DialogDescription>
        </DialogHeader>
        <div>
          <div className="grid gap-2 sm:grid-cols-[160px_1fr_auto]">
            <Input
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="key"
              className="font-mono text-[13px]"
            />
            <Input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void add();
              }}
              placeholder="value"
              className="text-[14px]"
            />
            <Button size="sm" onClick={() => void add()} disabled={!key.trim() || !value.trim()}>
              <Plus size={14} /> Save
            </Button>
          </div>
          <div className="mt-4 divide-y divide-border rounded-lg border border-border">
            {props.memories.map((m) => (
              <div key={m.id} className="group flex items-start gap-3 px-3 py-2.5">
                <code className="shrink-0 rounded bg-muted px-1.5 py-0.5 font-mono text-[11px]">
                  {m.key}
                </code>
                <span className="min-w-0 flex-1 text-[13px] leading-relaxed">{m.value}</span>
                <button
                  type="button"
                  aria-label="Delete memory"
                  onClick={() => void remove(m.id)}
                  className="rounded p-1 text-muted-foreground opacity-0 transition hover:bg-accent hover:text-destructive group-hover:opacity-100"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
            {props.memories.length === 0 && (
              <p className="py-8 text-center text-[13px] text-muted-foreground">
                Nothing remembered yet.
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
