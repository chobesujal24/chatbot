import type { ProviderId, Settings } from "./types";

export const SETTINGS_KEY = "nova-settings-v2";

export const DEFAULT_SYSTEM_PROMPT =
  "You are Nova, a precise and helpful assistant. Be direct, concise and well-structured. Use Markdown, fenced code blocks with language tags, and tables when they help. State uncertainty honestly.";

export const DEFAULT_SETTINGS: Settings = {
  provider: "offline",
  model: "offline-demo",
  apiKey: "",
  baseURL: "http://localhost:11434/v1",
  systemPrompt: DEFAULT_SYSTEM_PROMPT,
  temperature: 0.7,
  maxTokens: 2048,
};

export const PROVIDERS: {
  id: ProviderId;
  label: string;
  description: string;
  models: string[];
  keyEnv: string | null;
}[] = [
  {
    id: "offline",
    label: "Offline demo",
    description: "Deterministic local answers. No model, no key, no network.",
    models: ["offline-demo"],
    keyEnv: null,
  },
  {
    id: "openai",
    label: "OpenAI",
    description: "GPT models via the official OpenAI API.",
    models: ["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "o4-mini"],
    keyEnv: "OPENAI_API_KEY",
  },
  {
    id: "anthropic",
    label: "Anthropic",
    description: "Claude models via the Anthropic API.",
    models: [
      "claude-3-5-haiku-latest",
      "claude-sonnet-4-5",
      "claude-opus-4-1",
    ],
    keyEnv: "ANTHROPIC_API_KEY",
  },
  {
    id: "google",
    label: "Google",
    description: "Gemini models via the Google Generative AI API.",
    models: ["gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro"],
    keyEnv: "GOOGLE_GENERATIVE_AI_API_KEY",
  },
  {
    id: "custom",
    label: "OpenAI-compatible",
    description: "Ollama, LM Studio, vLLM, OpenRouter or any compatible endpoint.",
    models: ["llama3.2", "qwen2.5", "mistral", "custom-model"],
    keyEnv: null,
  },
];

export function loadSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      provider: parsed.provider ?? DEFAULT_SETTINGS.provider,
      temperature: Number.isFinite(parsed.temperature)
        ? Math.min(2, Math.max(0, Number(parsed.temperature)))
        : DEFAULT_SETTINGS.temperature,
      maxTokens: Number.isFinite(parsed.maxTokens)
        ? Math.min(16384, Math.max(128, Number(parsed.maxTokens)))
        : DEFAULT_SETTINGS.maxTokens,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings) {
  window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function providerLabel(id: ProviderId): string {
  return PROVIDERS.find((p) => p.id === id)?.label ?? id;
}
