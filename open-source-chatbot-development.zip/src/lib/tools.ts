import { db } from "@/db";
import { conversations, memories, messages, tasks } from "@/db/schema";
import { tool, type Tool, type ToolSet } from "ai";
import { and, asc, desc, eq, ilike, sql } from "drizzle-orm";
import { z } from "zod";
import { evaluateMath } from "./offline";
import { safeFetchText } from "./ssrf";
import { slugify } from "./validation";
import { activeCredential, credentialSecret } from "./credentials";
import {
  assertSafeTarget,
  readWithJina,
  scrapeWithFirecrawl,
  searchWithBrave,
  searchWithExa,
  searchWithFirecrawl,
  searchWithJina,
  searchWithSerpApi,
  searchWithSerper,
  searchWithTavily,
  searchWithYou,
} from "./integrations";
import { TOOL_META } from "./tool-meta";
import { loadSkillInstructions } from "./skills";
import { forget, recall, remember } from "./memory";


type Searcher = (
  key: string,
  query: string,
  limit: number,
  baseURL?: string,
) => Promise<{ title: string; url: string; text: string }[]>;

const SEARCHERS: Record<string, Searcher> = {
  firecrawl: searchWithFirecrawl,
  tavily: searchWithTavily,
  brave: searchWithBrave,
  exa: searchWithExa,
  serper: searchWithSerper,
  serpapi: searchWithSerpApi,
  "jina-search": searchWithJina,
  you: searchWithYou,
};

const SEARCH_LABEL: Record<string, string> = {
  firecrawl: "Firecrawl",
  tavily: "Tavily",
  brave: "Brave Search",
  exa: "Exa",
  serper: "Serper",
  serpapi: "SerpApi",
  "jina-search": "Jina",
  you: "You.com",
};

/** Builds the tool set for one agent run, scoped to the calling workspace. */
export interface ToolLimits {
  searchResults?: number;
  fetchMaxKb?: number;
  fetchTimeoutSec?: number;
}

export function buildTools(names: string[], workspaceId: string, limits: ToolLimits = {}): ToolSet {
  const maxResults = Math.min(10, Math.max(1, limits.searchResults ?? 5));
  const maxBytes = Math.min(500, Math.max(10, limits.fetchMaxKb ?? 100)) * 1024;
  const timeoutMs = Math.min(60, Math.max(3, limits.fetchTimeoutSec ?? 12)) * 1000;
  const definitions: Record<string, Tool<any, any, any>> = {
    calculator: tool({
      description: "Evaluate an arithmetic expression exactly. Supports + - * / % ^ and parentheses.",
      inputSchema: z.object({ expression: z.string().describe("The arithmetic expression") }),
      execute: async ({ expression }) => {
        const value = evaluateMath(expression);
        return value === null
          ? { expression, error: "Could not evaluate that expression." }
          : { expression, result: value };
      },
    }),

    currentTime: tool({
      description: "Get the current date and time on the server.",
      inputSchema: z.object({}),
      execute: async () => {
        const now = new Date();
        return {
          iso: now.toISOString(),
          formatted: now.toLocaleString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit",
          }),
        };
      },
    }),

    webSearch: tool({
      description:
        "Search the web and return titles, URLs and snippets. Requires a search provider configured in Settings → Integrations.",
      inputSchema: z.object({
        query: z.string().describe("What to search for"),
        limit: z.number().optional().describe(`Number of results (workspace default ${maxResults}, max 10)`),
      }),
      execute: async ({ query, limit }) => {
        const credential = await activeCredential(workspaceId, "search");
        if (!credential || !credential.secret) {
          return {
            error:
              "No web search provider is configured. Add one in Settings → Integrations (Firecrawl, Tavily, Brave, Exa, Serper, SerpApi, Jina or You.com).",
          };
        }
        const searcher = SEARCHERS[credential.provider];
        if (!searcher) {
          return { error: `Search provider "${credential.provider}" is not supported.` };
        }
        try {
          const results = await searcher(
            credential.secret,
            query,
            Math.min(10, Math.max(1, limit ?? maxResults)),
            credential.baseURL ?? undefined,
          );
          return {
            provider: SEARCH_LABEL[credential.provider] ?? credential.provider,
            query,
            results: results.map((r) => ({
              title: r.title,
              url: r.url,
              snippet: r.text.slice(0, 600),
            })),
          };
        } catch (error) {
          return {
            error: error instanceof Error ? error.message : "Search failed.",
            provider: credential.provider,
          };
        }
      },
    }),

    webFetch: tool({
      description:
        "Read a web page and return clean markdown. Uses Firecrawl or Jina when configured, otherwise falls back to a direct fetch.",
      inputSchema: z.object({
        url: z.string().describe("The full URL to read"),
        maxChars: z.number().optional().describe("Maximum characters to return (default 12000)"),
      }),
      execute: async ({ url, maxChars }) => {
        const limit = Math.min(Math.floor(maxBytes / 5), Math.max(500, maxChars ?? Math.floor(maxBytes / 5)));
        try {
          await assertSafeTarget(url);
        } catch (error) {
          return { url, error: error instanceof Error ? error.message : "Blocked URL." };
        }

        const firecrawl = await credentialSecret(workspaceId, "firecrawl");
        if (firecrawl?.secret) {
          try {
            const doc = await scrapeWithFirecrawl(
              firecrawl.secret,
              url,
              { onlyMainContent: true },
              firecrawl.baseURL ?? undefined,
            );
            return {
              url: doc.url,
              title: doc.title,
              provider: "firecrawl",
              text: doc.markdown.slice(0, limit),
              truncated: doc.markdown.length > limit,
            };
          } catch (error) {
            return {
              url,
              provider: "firecrawl",
              error: error instanceof Error ? error.message : "Firecrawl failed.",
            };
          }
        }

        const jina = await activeCredential(workspaceId, "reader");
        if (jina?.provider === "jina") {
          try {
            const doc = await readWithJina(jina.secret || null, url, jina.baseURL ?? undefined);
            return {
              url: doc.url,
              title: doc.title,
              provider: "jina",
              text: doc.markdown.slice(0, limit),
              truncated: doc.markdown.length > limit,
            };
          } catch (error) {
            return {
              url,
              provider: "jina",
              error: error instanceof Error ? error.message : "Jina reader failed.",
            };
          }
        }

        try {
          const result = await safeFetchText(url, limit);
          return {
            url: result.url,
            provider: "direct",
            text: result.text,
            truncated: result.truncated,
          };
        } catch (error) {
          return { url, error: error instanceof Error ? error.message : "Fetch failed." };
        }
      },
    }),

    fetchUrl: tool({
      description:
        "Fetch a public web page directly and return its text. Private networks and metadata endpoints are blocked.",
      inputSchema: z.object({
        url: z.string().describe("The full URL to fetch"),
        maxChars: z.number().optional().describe("Maximum characters to return (default 8000)"),
      }),
      execute: async ({ url, maxChars }) => {
        try {
          const result = await safeFetchText(url, maxChars ?? Math.floor(maxBytes / 12), { timeoutMs });
          return {
            url: result.url,
            status: result.status,
            truncated: result.truncated,
            text: result.text,
          };
        } catch (error) {
          return { url, error: error instanceof Error ? error.message : "Fetch failed." };
        }
      },
    }),

    searchHistory: tool({
      description: "Search previous conversations in this workspace for relevant context.",
      inputSchema: z.object({
        query: z.string().describe("Keywords to search for"),
        limit: z.number().optional().describe("Maximum results (default 5, max 10)"),
      }),
      execute: async ({ query, limit }) => {
        const rows = await db
          .select({
            role: messages.role,
            content: messages.content,
            createdAt: messages.createdAt,
            conversationTitle: conversations.title,
          })
          .from(messages)
          .innerJoin(conversations, eq(messages.conversationId, conversations.id))
          .where(
            and(
              eq(messages.workspaceId, workspaceId),
              ilike(messages.content, `%${query.replace(/[\\%_]/g, (m) => `\\${m}`)}%`),
            ),
          )
          .orderBy(desc(messages.createdAt))
          .limit(Math.min(10, Math.max(1, limit ?? 5)));
        return {
          query,
          results: rows.map((r) => ({
            conversation: r.conversationTitle,
            role: r.role,
            snippet: r.content.slice(0, 400),
            createdAt: r.createdAt.toISOString(),
          })),
        };
      },
    }),

    saveMemory: tool({
      description: "Save a durable fact or preference to long-term memory for this workspace.",
      inputSchema: z.object({
        key: z.string().describe("Short slug, e.g. preferred-language"),
        value: z.string().describe("The fact or preference to remember"),
      }),
      execute: async ({ key, value }) => {
        const slug = slugify(key);
        await db
          .insert(memories)
          .values({ workspaceId, key: slug, value: value.slice(0, 2000) })
          .onConflictDoUpdate({
            target: [memories.workspaceId, memories.key],
            set: { value: value.slice(0, 2000), updatedAt: new Date() },
          });
        return { saved: slug };
      },
    }),

    recallMemories: tool({
      description: "Read saved long-term memories, optionally filtered by a keyword.",
      inputSchema: z.object({ query: z.string().optional() }),
      execute: async ({ query }) => {
        const rows = await db
          .select({ key: memories.key, value: memories.value })
          .from(memories)
          .where(
            and(
              eq(memories.workspaceId, workspaceId),
              query
                ? sql`(${ilike(memories.key, `%${query}%`)} or ${ilike(memories.value, `%${query}%`)})`
                : sql`true`,
            ),
          )
          .orderBy(asc(memories.key))
          .limit(25);
        return { memories: rows };
      },
    }),

    createTask: tool({
      description: "Add a task to this workspace's task list.",
      inputSchema: z.object({ title: z.string().describe("The task to track") }),
      execute: async ({ title }) => {
        const [row] = await db
          .insert(tasks)
          .values({ workspaceId, title: title.slice(0, 300) })
          .returning();
        return { id: row.id, title: row.title, status: row.status };
      },
    }),

    listTasks: tool({
      description: "List tasks, optionally filtered by status.",
      inputSchema: z.object({ status: z.enum(["open", "done", "all"]).optional() }),
      execute: async ({ status }) => {
        const rows = await db
          .select({ id: tasks.id, title: tasks.title, status: tasks.status })
          .from(tasks)
          .where(
            and(
              eq(tasks.workspaceId, workspaceId),
              status === "open" || status === "done" ? eq(tasks.status, status) : sql`true`,
            ),
          )
          .orderBy(desc(tasks.createdAt))
          .limit(30);
        return { tasks: rows };
      },
    }),

    completeTask: tool({
      description: "Mark a task as completed by its ID.",
      inputSchema: z.object({ id: z.string().describe("The task ID from listTasks or createTask") }),
      execute: async ({ id }) => {
        const [row] = await db
          .update(tasks)
          .set({ status: "done", updatedAt: new Date() })
          .where(and(eq(tasks.id, id), eq(tasks.workspaceId, workspaceId)))
          .returning();
        return row
          ? { id: row.id, title: row.title, status: row.status }
          : { id, error: "Task not found." };
      },
    }),

    loadSkill: tool({
      description:
        "Load the full instructions for one of the available skills. Call this before applying a skill; never guess its contents.",
      inputSchema: z.object({ name: z.string().describe("Exact skill name from the Skills index") }),
      execute: async ({ name }) => {
        const skill = await loadSkillInstructions(workspaceId, name.trim().toLowerCase().replace(/\s+/g, "-"));
        if (!skill) {
          return { error: "No skill with that name is available in this workspace." };
        }
        return {
          name: skill.name,
          description: skill.description,
          instructions: skill.instructions.slice(0, 12000),
          toolHint: skill.tools?.length ? `This skill expects these tools: ${skill.tools.join(", ")}` : undefined,
        };
      },
    }),

    remember: tool({
      description:
        "Save a durable fact, preference or correction to long-term memory. Use when the user states something worth carrying across conversations, or when they correct you.",
      inputSchema: z.object({
        value: z.string().describe("A single self-contained statement"),
        type: z.enum(["preference", "fact", "entity", "procedure", "event"]).optional(),
        importance: z.number().optional().describe("0-1, defaults to 0.5"),
        tags: z.array(z.string()).optional(),
      }),
      execute: async ({ value, type, importance, tags }) => {
        const result = await remember(workspaceId, {
          value,
          type,
          importance,
          tags,
          origin: "agent",
          confidence: 0.8,
        });
        return { status: result.status, key: result.key };
      },
    }),

    recall: tool({
      description: "Search long-term memory for context relevant to a question.",
      inputSchema: z.object({
        query: z.string().describe("What to look up"),
        limit: z.number().optional(),
      }),
      execute: async ({ query, limit }) => {
        const results = await recall(workspaceId, query, Math.min(20, Math.max(1, limit ?? 8)));
        return { query, count: results.length, results };
      },
    }),

    forgetMemory: tool({
      description:
        "Delete a memory that is wrong or obsolete, addressed by its key (shown in the injected memory block or returned by recall).",
      inputSchema: z.object({ key: z.string().describe("Memory key, e.g. preferred-editor") }),
      execute: async ({ key }) => {
        const rows = await db
          .select({ id: memories.id, key: memories.key })
          .from(memories)
          .where(and(eq(memories.workspaceId, workspaceId), eq(memories.key, key.trim().toLowerCase())))
          .limit(1);
        if (rows.length === 0) return { key, error: "No memory with that key." };
        await forget(workspaceId, rows[0].id);
        return { forgot: key };
      },
    }),
  };

  const set: ToolSet = {};
  for (const name of names) {
    if (definitions[name]) set[name] = definitions[name];
  }
  return set;
}

export { TOOL_META as TOOL_DEFINITIONS };
