import type { LanguageModel } from "ai";
import type { ProviderId, Settings } from "./types";
import { findProvider } from "./providers";

export interface ModelResolution {
  model: LanguageModel | null;
  error?: string;
  label: string;
  /** True when the workspace has no model provider configured at all. */
  missingCredentials: boolean;
}

/**
 * Provider SDKs read env vars when imported and throw on empty strings, so we
 * strip injected blanks before loading them.
 */
const PROVIDER_ENV = [
  "OPENAI_API_KEY",
  "OPENAI_BASE_URL",
  "OPENAI_ORGANIZATION",
  "OPENAI_PROJECT",
  "ANTHROPIC_API_KEY",
  "ANTHROPIC_BASE_URL",
  "GOOGLE_GENERATIVE_AI_API_KEY",
  "GOOGLE_API_KEY",
  "GOOGLE_BASE_URL",
];

function sanitizeEnv() {
  for (const name of PROVIDER_ENV) {
    const value = process.env[name];
    if (value !== undefined && value.trim() === "") delete process.env[name];
  }
}

export interface ResolvedCredential {
  provider: string;
  secret: string;
  baseURL: string | null;
  options?: Record<string, unknown>;
}

export interface ModelOptions {
  /** Extra headers sent with every request (OpenRouter referer/title, gateways). */
  headers?: Record<string, string>;
  /** Per-request timeout in seconds. */
  timeout?: number;
}

export async function resolveModel(
  settings: Settings,
  credential: ResolvedCredential | null,
  options: ModelOptions = {},
): Promise<ModelResolution> {
  const label = settings.model || "model";

  if (settings.provider === "offline") {
    return { model: null, label: "offline-demo", missingCredentials: false };
  }

  sanitizeEnv();

  const providerId = (credential?.provider ?? settings.provider) as ProviderId;
  const preset = findProvider(providerId);
  const apiKey = credential?.secret?.trim() ?? "";
  const baseURL = (credential?.baseURL ?? settings.baseURL ?? "").trim();

  if (providerId === "custom" || preset?.kind === "openai-compatible") {
    if (!baseURL) {
      return {
        model: null,
        label,
        missingCredentials: true,
        error: "No base URL configured. Add one in Settings → Providers.",
      };
    }
    const { createOpenAI } = await import("@ai-sdk/openai");
    return {
      model: createOpenAI({
        apiKey: apiKey || "not-required",
        baseURL,
        ...(options.headers && Object.keys(options.headers).length ? { headers: options.headers } : {}),
      }).chat(label),
      label,
      missingCredentials: false,
    };
  }

  if (!apiKey) {
    return {
      model: null,
      label,
      missingCredentials: true,
      error: `No API key stored for ${preset?.label ?? providerId}. Add one in Settings → Providers.`,
    };
  }

  switch (providerId) {
    case "openai": {
      const { createOpenAI } = await import("@ai-sdk/openai");
      const serverBase = process.env.OPENAI_BASE_URL?.trim();
      return {
        model: createOpenAI({
          apiKey,
          ...(serverBase ? { baseURL: serverBase } : {}),
          ...(options.headers && Object.keys(options.headers).length ? { headers: options.headers } : {}),
        }).chat(label),
        label,
        missingCredentials: false,
      };
    }
    case "anthropic": {
      const { createAnthropic } = await import("@ai-sdk/anthropic");
      return {
        model: createAnthropic({ apiKey })(label),
        label,
        missingCredentials: false,
      };
    }
    case "google": {
      const { createGoogle } = await import("@ai-sdk/google");
      return {
        model: createGoogle({ apiKey })(label),
        label,
        missingCredentials: false,
      };
    }
    default:
      return {
        model: null,
        label,
        missingCredentials: true,
        error: `Provider "${providerId}" is not supported.`,
      };
  }
}
