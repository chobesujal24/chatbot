import "server-only";

import { db } from "@/db";
import { credentials } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { decryptValue, encryptValue } from "./crypto";
import { encryptionKey } from "./secrets";
import type { CredentialKind } from "./providers";

export interface StoredCredential {
  id: string;
  provider: string;
  kind: CredentialKind;
  label: string;
  secret: string;
  baseURL: string | null;
  options: Record<string, unknown>;
  enabled: boolean;
  isActive: boolean;
}

/** Public shape — never includes the secret. */
export interface CredentialSummary {
  id: string;
  provider: string;
  kind: CredentialKind;
  label: string;
  hasKey: boolean;
  keyPreview: string;
  baseURL: string | null;
  options: Record<string, unknown>;
  enabled: boolean;
  isActive: boolean;
  updatedAt: string;
}

function decode(row: typeof credentials.$inferSelect): StoredCredential {
  return {
    id: row.id,
    provider: row.provider,
    kind: (row.kind as CredentialKind) ?? "model",
    label: row.label,
    secret: row.secret,
    baseURL: row.baseURL,
    options: row.options ?? {},
    enabled: row.enabled,
    isActive: row.isActive,
  };
}

export async function listCredentials(workspaceId: string): Promise<StoredCredential[]> {
  const rows = await db
    .select()
    .from(credentials)
    .where(eq(credentials.workspaceId, workspaceId))
    .orderBy(credentials.kind, credentials.provider);
  return rows.map(decode);
}

export async function saveCredential(
  workspaceId: string,
  input: {
    provider: string;
    kind: CredentialKind;
    label?: string;
    secret?: string;
    baseURL?: string | null;
    options?: Record<string, unknown>;
    enabled?: boolean;
    isActive?: boolean;
  },
): Promise<StoredCredential> {
  const key = await encryptionKey();
  const existing = await db
    .select()
    .from(credentials)
    .where(
      and(eq(credentials.workspaceId, workspaceId), eq(credentials.provider, input.provider)),
    )
    .limit(1);

  // Only re-encrypt when a new secret was supplied; otherwise keep the stored one.
  let secretPayload = existing[0]?.secret ?? "";
  if (input.secret !== undefined && input.secret !== "") {
    secretPayload = encryptValue(input.secret, key);
  }

  const values = {
    workspaceId,
    provider: input.provider,
    kind: input.kind,
    label: input.label?.trim() || input.provider,
    secret: secretPayload,
    baseURL: input.baseURL ?? existing[0]?.baseURL ?? null,
    options: input.options ?? existing[0]?.options ?? {},
    enabled: input.enabled ?? existing[0]?.enabled ?? true,
    isActive: input.isActive ?? existing[0]?.isActive ?? false,
    updatedAt: new Date(),
  };

  if (existing[0]) {
    if (values.isActive) {
      await db
        .update(credentials)
        .set({ isActive: false })
        .where(
          and(
            eq(credentials.workspaceId, workspaceId),
            eq(credentials.kind, input.kind),
          ),
        );
    }
    const [row] = await db
      .update(credentials)
      .set(values)
      .where(eq(credentials.id, existing[0].id))
      .returning();
    return decode(row);
  }

  if (values.isActive) {
    await db
      .update(credentials)
      .set({ isActive: false })
      .where(
        and(eq(credentials.workspaceId, workspaceId), eq(credentials.kind, input.kind)),
      );
  }
  const [row] = await db.insert(credentials).values(values).returning();
  return decode(row);
}

export async function deleteCredential(
  workspaceId: string,
  id: string,
): Promise<boolean> {
  const deleted = await db
    .delete(credentials)
    .where(and(eq(credentials.id, id), eq(credentials.workspaceId, workspaceId)))
    .returning({ id: credentials.id });
  return deleted.length > 0;
}

/** Decrypted secrets for server-side use only. */
export async function activeCredential(
  workspaceId: string,
  kind: CredentialKind,
): Promise<StoredCredential | null> {
  const rows = await db
    .select()
    .from(credentials)
    .where(
      and(
        eq(credentials.workspaceId, workspaceId),
        eq(credentials.kind, kind),
        eq(credentials.enabled, true),
      ),
    )
    .orderBy(credentials.isActive);
  for (const row of rows) {
    if (row.isActive) {
      const decoded = decode(row);
      return { ...decoded, secret: decryptValue(row.secret, await encryptionKey()) ?? "" };
    }
  }
  return null;
}

export async function credentialSecret(
  workspaceId: string,
  provider: string,
): Promise<{ secret: string; baseURL: string | null; options: Record<string, unknown> } | null> {
  const rows = await db
    .select()
    .from(credentials)
    .where(
      and(
        eq(credentials.workspaceId, workspaceId),
        eq(credentials.provider, provider),
        eq(credentials.enabled, true),
      ),
    )
    .limit(1);
  if (!rows[0]) return null;
  return {
    secret: decryptValue(rows[0].secret, await encryptionKey()) ?? "",
    baseURL: rows[0].baseURL,
    options: rows[0].options ?? {},
  };
}

export function summarize(row: StoredCredential, updatedAt: Date): CredentialSummary {
  const preview = row.secret
    ? row.secret.length > 8
      ? `${row.secret.slice(0, 3)}••••${row.secret.slice(-3)}`
      : "••••"
    : "";
  return {
    id: row.id,
    provider: row.provider,
    kind: row.kind,
    label: row.label,
    hasKey: Boolean(row.secret),
    keyPreview: preview,
    baseURL: row.baseURL,
    options: row.options,
    enabled: row.enabled,
    isActive: row.isActive,
    updatedAt: updatedAt.toISOString(),
  };
}
