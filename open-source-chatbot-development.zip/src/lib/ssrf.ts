import { lookup } from "node:dns/promises";
import http from "node:http";
import https from "node:https";
import { isIP } from "node:net";

const ALLOWED_PORTS = new Set([80, 443, 8080, 8443]);
const MAX_BYTES = 200_000;
const TIMEOUT_MS = 12_000;
const MAX_REDIRECTS = 3;

/** Rejects loopback, private, link-local, metadata and reserved IPv4 ranges. */
export function isBlockedIpv4(ip: string): boolean {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) {
    return true;
  }
  const [a, b] = parts;
  if (a === 0 || a === 10 || a === 127) return true;
  if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT
  if (a === 169 && b === 254) return true; // cloud metadata / link-local
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 192 && b === 0) return true;
  if (a === 198 && (b === 18 || b === 19)) return true;
  if (a >= 224) return true; // multicast + reserved + broadcast
  if (a === 198 && b === 51) return true;
  if (a === 203 && b === 0) return true;
  return false;
}

/** Handles IPv6 forms that embed IPv4 (mapped, NAT64, 6to4). */
export function isBlockedIpv6(ip: string): boolean {
  const lower = ip.toLowerCase().split("%")[0];
  if (lower === "::" || lower === "::1") return true;
  if (/^f[cd]/.test(lower) || /^fe[89ab]/.test(lower)) return true; // fc00::/7, fe80::/10
  if (lower.startsWith("2001:db8")) return true; // documentation
  const mapped = lower.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (mapped) return isBlockedIpv4(mapped[1]);
  const mappedHex = lower.match(/::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (mappedHex) {
    const hi = parseInt(mappedHex[1], 16);
    const lo = parseInt(mappedHex[2], 16);
    return isBlockedIpv4(`${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`);
  }
  const nat64 = lower.match(/^64:ff9b::([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (nat64) {
    const hi = parseInt(nat64[1], 16);
    const lo = parseInt(nat64[2], 16);
    return isBlockedIpv4(`${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`);
  }
  const sixToFour = lower.match(/^2002:([0-9a-f]{1,4}):([0-9a-f]{1,4})/);
  if (sixToFour) {
    const hi = parseInt(sixToFour[1], 16);
    const lo = parseInt(sixToFour[2], 16);
    return isBlockedIpv4(`${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`);
  }
  return false;
}

export function isBlockedAddress(address: string): boolean {
  const version = isIP(address);
  if (version === 4) return isBlockedIpv4(address);
  if (version === 6) return isBlockedIpv6(address);
  return true;
}

interface ValidatedTarget {
  url: URL;
  address: string;
  family: number;
}

/** Resolves the hostname and validates *every* returned address. */
export async function validateTarget(raw: string): Promise<ValidatedTarget> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("Invalid URL.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Only http and https URLs are allowed.");
  }
  if (url.username || url.password) {
    throw new Error("URLs with credentials are not allowed.");
  }
  const port = url.port ? Number(url.port) : url.protocol === "https:" ? 443 : 80;
  if (!ALLOWED_PORTS.has(port)) throw new Error(`Port ${port} is not allowed.`);
  const hostname = url.hostname.replace(/^\[|\]$/g, "");
  if (!hostname) throw new Error("Missing hostname.");

  // A literal IP is validated directly; hostnames are resolved and every
  // answer is checked (defends against DNS answers pointing at metadata IPs).
  let addresses: { address: string; family: number }[];
  if (isIP(hostname)) {
    addresses = [{ address: hostname, family: isIP(hostname) === 6 ? 6 : 4 }];
  } else {
    const resolved = await lookup(hostname, { all: true, verbatim: true }).catch(() => {
      throw new Error("DNS resolution failed.");
    });
    addresses = resolved.map((r) => ({ address: r.address, family: r.family }));
  }
  if (addresses.length === 0 || addresses.some((a) => isBlockedAddress(a.address))) {
    throw new Error("The URL resolves to a blocked address.");
  }
  return { url, address: addresses[0].address, family: addresses[0].family };
}

interface FetchResult {
  url: string;
  status: number;
  contentType: string;
  body: string;
  truncated: boolean;
}

function requestOnce(target: ValidatedTarget, timeoutMs?: number): Promise<FetchResult> {
  const { url, address, family } = target;
  const secure = url.protocol === "https:";
  const options = {
    method: "GET",
    headers: {
      "user-agent": "Nova/1.0 (open-source chat workspace)",
      accept: "text/html,application/json,text/plain,*/*",
      host: url.host,
    },
    timeout: Math.min(60_000, Math.max(3_000, timeoutMs ?? TIMEOUT_MS)),
    // Pin the socket to the IP we validated; Node will not re-resolve the name.
    lookup: (
      _hostname: string,
      _opts: unknown,
      callback: (error: Error | null, address: string, family: number) => void,
    ) => callback(null, address, family),
    ...(secure ? { servername: url.hostname, rejectUnauthorized: true } : {}),
  } as unknown as https.RequestOptions;

  return new Promise((resolve, reject) => {
    const transport = secure ? https : http;
    const req = transport.request(url.toString(), options, (res) => {
      const declared = Number(res.headers["content-length"] ?? 0);
      if (declared > MAX_BYTES) {
        res.destroy();
        reject(new Error("Response is too large."));
        return;
      }
      const chunks: Buffer[] = [];
      let size = 0;
      let truncated = false;
      res.on("data", (chunk: Buffer) => {
        size += chunk.length;
        if (size > MAX_BYTES) {
          truncated = true;
          res.destroy();
        } else {
          chunks.push(chunk);
        }
      });
      res.on("end", () => resolve(finish(res, chunks, truncated)));
      res.on("close", () => {
        if (!res.complete) finish(res, chunks, truncated);
      });
      function finish(response: http.IncomingMessage, buffers: Buffer[], cut: boolean): FetchResult {
        const status = response.statusCode ?? 0;
        return {
          url: url.toString(),
          status,
          contentType: String(response.headers["content-type"] ?? ""),
          location: String(response.headers["location"] ?? ""),
          body: Buffer.concat(buffers).toString("utf8"),
          truncated: cut,
        } as FetchResult & { location: string };
      }
    });
    req.on("timeout", () => req.destroy(new Error("Request timed out.")));
    req.on("error", reject);
    req.end();
  });
}

export function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

/** Fetches an untrusted URL with pinned DNS, manual redirects and size caps. */
export async function safeFetchText(
  rawUrl: string,
  maxChars = 8000,
  options: { timeoutMs?: number } = {},
): Promise<{
  url: string;
  status: number;
  text: string;
  truncated: boolean;
}> {
  const limit = Math.min(20000, Math.max(500, maxChars));
  let current = rawUrl;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const target = await validateTarget(current);
    const result = (await requestOnce(target)) as FetchResult & { location: string };
    if (result.status >= 300 && result.status < 400 && result.location) {
      if (hop === MAX_REDIRECTS) throw new Error("Too many redirects.");
      current = new URL(result.location, result.url).toString();
      continue;
    }
    if (result.status < 200 || result.status >= 300) {
      throw new Error(`HTTP ${result.status}`);
    }
    const text = result.contentType.includes("html")
      ? stripHtml(result.body)
      : result.body;
    return {
      url: result.url,
      status: result.status,
      text: text.slice(0, limit),
      truncated: result.truncated || text.length > limit,
    };
  }
  throw new Error("Too many redirects.");
}
