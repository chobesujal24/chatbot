import { describe, expect, it } from "vitest";
import { deriveTitle, evaluateMath, offlineReply } from "../offline";
import { isBlockedIpv4, isBlockedIpv6, isBlockedAddress, safeFetchText, stripHtml } from "../ssrf";
import { chatSchema, credentialSchema, settingsSchema, slugify, taskPatchSchema } from "../validation";
import { groupConversations, formatTokens, formatDuration } from "../format";

describe("arithmetic parser", () => {
  it("evaluates precedence, parentheses and powers", () => {
    expect(evaluateMath("(128 + 46) * 3")).toBe(522);
    expect(evaluateMath("2 + 3 * 4")).toBe(14);
    expect(evaluateMath("2 ^ 3 ^ 2")).toBe(512);
    expect(evaluateMath("-4 + 10")).toBe(6);
    expect(evaluateMath("10 % 3")).toBe(1);
  });
  it("rejects malformed or non-arithmetic input", () => {
    expect(evaluateMath("2 / 0")).toBeNull();
    expect(evaluateMath("2 + (3")).toBeNull();
    expect(evaluateMath("process.exit(1)")).toBeNull();
    expect(evaluateMath("")).toBeNull();
  });
});

describe("title derivation", () => {
  it("normalises whitespace and truncates", () => {
    expect(deriveTitle("  hello   world  ")).toBe("hello world");
    expect(deriveTitle("a".repeat(100))).toHaveLength(50);
    expect(deriveTitle("line1\nline2")).toBe("line1 line2");
  });
});

describe("SSRF address policy", () => {
  it("blocks loopback, private, link-local and metadata IPv4", () => {
    for (const ip of ["127.0.0.1", "127.1", "10.0.0.1", "172.16.0.1", "192.168.1.1", "169.254.169.254", "100.64.0.1", "0.0.0.0", "224.0.0.1"]) {
      expect(isBlockedIpv4(ip), ip).toBe(true);
    }
  });
  it("allows ordinary public IPv4", () => {
    for (const ip of ["1.1.1.1", "8.8.8.8", "93.184.216.34"]) {
      expect(isBlockedIpv4(ip), ip).toBe(false);
    }
  });
  it("blocks IPv6 loopback, ULA, link-local and embedded private v4", () => {
    for (const ip of ["::1", "::", "fd00::1", "fe80::1", "::ffff:127.0.0.1", "2001:db8::1"]) {
      expect(isBlockedIpv6(ip), ip).toBe(true);
    }
  });
  it("rejects unparseable addresses", () => {
    expect(isBlockedAddress("not-an-ip")).toBe(true);
  });
  it("refuses local targets before any network call", async () => {
    await expect(safeFetchText("http://127.0.0.1/api/health")).rejects.toThrow(/blocked address/);
    await expect(safeFetchText("http://localhost/")).rejects.toThrow(/blocked address/);
    await expect(safeFetchText("file:///etc/passwd")).rejects.toThrow(/Only http and https/);
  });
  it("strips scripts and markup", () => {
    expect(stripHtml("<script>bad()</script><p>Hello &amp; bye</p>")).toContain("Hello & bye");
    expect(stripHtml("<script>bad()</script>")).not.toContain("bad()");
  });
});

describe("request validation", () => {
  it("requires content for send mode", () => {
    const base = { settings: { provider: "offline", model: "offline-demo" } };
    expect(chatSchema.safeParse({ ...base, mode: "send", content: "hi" }).success).toBe(true);
    expect(chatSchema.safeParse({ ...base, mode: "send", content: "" }).success).toBe(false);
  });
  it("requires a conversation for regenerate/edit", () => {
    const base = { settings: { provider: "offline", model: "offline-demo" } };
    expect(chatSchema.safeParse({ ...base, mode: "regenerate" }).success).toBe(false);
    expect(
      chatSchema.safeParse({ ...base, mode: "regenerate", conversationId: "00000000-0000-0000-0000-000000000000" }).success,
    ).toBe(true);
  });
  it("clamps temperature and rejects unknown providers", () => {
    expect(settingsSchema.safeParse({ provider: "openai", temperature: 9 }).success).toBe(false);
    expect(settingsSchema.safeParse({ provider: "bogus" }).success).toBe(false);
    expect(settingsSchema.safeParse({ provider: "offline" }).data?.temperature).toBe(0.7);
  });
  it("allows partial credential updates that preserve the stored key", () => {
    expect(credentialSchema.safeParse({ baseURL: "http://localhost:11434/v1" }).success).toBe(true);
    expect(credentialSchema.safeParse({}).success).toBe(true);
  });
  it("rejects empty task patches", () => {
    expect(taskPatchSchema.safeParse({}).success).toBe(false);
    expect(taskPatchSchema.safeParse({ status: "done" }).success).toBe(true);
  });
  it("slugifies keys", () => {
    expect(slugify("Preferred Language!")).toBe("preferred-language");
    expect(slugify("***")).toBe("note");
  });
});

describe("formatting helpers", () => {
  it("groups conversations by recency", () => {
    const now = new Date().toISOString();
    const old = new Date(Date.now() - 30 * 86400_000).toISOString();
    const conv = (id: string, updatedAt: string, pinned = false) => ({
      id, title: id, pinned, model: null, agentId: null, createdAt: updatedAt, updatedAt,
    });
    const groups = groupConversations([conv("a", now, true), conv("b", now), conv("c", old)]);
    expect(groups.map((g) => g.label)).toEqual(["Pinned", "Today", "Older"]);
  });
  it("formats tokens and duration", () => {
    expect(formatTokens(999)).toBe("999");
    expect(formatTokens(1248)).toBe("1.2k");
    expect(formatDuration(4210)).toBe("4.2s");
    expect(formatDuration(120)).toBe("120ms");
  });
});

describe("offline responder", () => {
  it("answers arithmetic without a model", () => {
    expect(offlineReply("calculate (12 + 8) * 2")).toContain("40");
  });
  it("labels itself honestly", () => {
    expect(offlineReply("who are you")).toContain("offline demo mode");
  });
});
