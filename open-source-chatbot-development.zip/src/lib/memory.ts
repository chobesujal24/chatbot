import "server-only";

import { db } from "@/db";
import { memories, memoryLog, type Memory } from "@/db/schema";
import { and, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import {
  clamp01,
  containment,
  jaccard,
  scoreMemory,
  slugifyMemoryKey,
  tokenize,
  type MemoryType,
  type ScorableMemory,
} from "./memory-core";

/**
 * Storage and retrieval for long-term memory. Ranking, extraction and prompt
 * rendering live in `memory-core` (shared with the UI and tests) and follow the
 * mem0 pattern of discrete records retrieved by relevance, importance and
 * recency.
 */

export {
  MEMORY_TYPES,
  clamp01,
  containment,
  extractCandidates,
  jaccard,
  renderMemoryBlock,
  scoreMemory,
  slugifyMemoryKey,
  tokenize,
  type ExtractedCandidate,
  type MemoryType,
  type RenderableMemory,
  type ScorableMemory,
} from "./memory-core";

export interface RememberInput {
  key?: string;
  value: string;
  type?: MemoryType;
  importance?: number;
  confidence?: number;
  tags?: string[];
  origin?: "user" | "agent" | "extracted" | "manual";
  sourceMessageId?: string | null;
}

/**
 * Upsert with contradiction handling: a highly similar existing record is
 * updated and strengthened instead of duplicated, mirroring mem0's
 * add-vs-update decision.
 */
export async function remember(
  workspaceId: string,
  input: RememberInput,
  options: { dedupe?: number; maxItems?: number } = {},
) {
  const value = input.value.trim().slice(0, 2000);
  if (!value) return { status: "skipped" as const, reason: "empty" as const };

  const incoming = new Set(tokenize(value));
  const existing = await db
    .select()
    .from(memories)
    .where(and(eq(memories.workspaceId, workspaceId), eq(memories.enabled, true)))
    .orderBy(desc(memories.updatedAt))
    .limit(300);

  // Two records describe the same fact when their tokens overlap strongly,
  // either symmetrically (Jaccard) or one-sidedly (containment: a rephrase or a
  // correction of something already known). Merging instead of inserting keeps
  // the store dense, as mem0's add-vs-update decision does.
  let best: { row: Memory; sim: number } | null = null;
  for (const row of existing) {
    const rowTokens = new Set(tokenize(row.value));
    const sim = jaccard(incoming, rowTokens);
    const overlap = containment(incoming, rowTokens);
    const sameSubject = row.type === (input.type ?? "fact");
    const dedupe = options.dedupe ?? 0.5;
    const isSame = sim >= dedupe || (overlap >= Math.min(0.95, dedupe + 0.1) && sim >= dedupe - 0.2 && sameSubject);
    const score = Math.max(sim, overlap);
    if (isSame && (!best || score > best.sim)) best = { row, sim: score };
  }

  const type = input.type ?? "fact";
  const importance = clamp01(input.importance ?? 0.5);
  const confidence = clamp01(input.confidence ?? 0.85);

  if (best) {
    await db
      .update(memories)
      .set({
        value,
        type,
        importance: Math.max(best.row.importance, importance),
        confidence: Math.max(best.row.confidence, confidence),
        tags: input.tags?.length ? input.tags : best.row.tags,
        updatedAt: new Date(),
      })
      .where(eq(memories.id, best.row.id));
    await log(workspaceId, "updated", best.row.key, `Merged a similar memory (overlap ${best.sim.toFixed(2)})`);
    return { status: "updated" as const, id: best.row.id, key: best.row.key };
  }

  const key = slugifyMemoryKey(input.key ?? value);
  const [row] = await db
    .insert(memories)
    .values({
      workspaceId,
      key,
      value,
      type,
      importance,
      confidence,
      origin: input.origin ?? "manual",
      tags: input.tags ?? null,
      enabled: true,
    })
    .onConflictDoUpdate({
      target: [memories.workspaceId, memories.key],
      set: { value, updatedAt: new Date() },
    })
    .returning();

  await log(workspaceId, "added", row.key, value.slice(0, 160));
  return { status: "added" as const, id: row.id, key: row.key };
}

export interface RecallResult {
  id: string;
  key: string;
  value: string;
  type: MemoryType;
  score: number;
}

export async function recall(
  workspaceId: string,
  query: string,
  limit = 6,
  options: {
    minScore?: number;
    types?: MemoryType[];
    halfLifeDays?: number;
    reinforce?: boolean;
  } = {},
): Promise<RecallResult[]> {
  const count = Math.max(0, Math.min(25, Math.round(limit)));
  if (count === 0) return [];

  const rows = await db
    .select()
    .from(memories)
    .where(and(eq(memories.workspaceId, workspaceId), eq(memories.enabled, true)))
    .orderBy(desc(memories.updatedAt))
    .limit(400);
  if (rows.length === 0) return [];

  const queryTokens = new Set(tokenize(query));
  const minScore = options.minScore ?? 0.2;
  const allowedTypes = options.types?.length ? new Set(options.types) : null;

  const scored = rows
    .filter((row) => !allowedTypes || allowedTypes.has(row.type))
    .map((row) => ({
      row,
      score: scoreMemory(row as unknown as ScorableMemory, queryTokens, Date.now(), {
        halfLifeDays: options.halfLifeDays,
      }),
    }))
    .filter((entry) => entry.score >= minScore)
    .sort((a, b) => b.score - a.score)
    .slice(0, count);

  if (scored.length > 0 && options.reinforce !== false) {
    // Reinforcement: recalled memories get stronger, as in mem0.
    void db
      .update(memories)
      .set({ useCount: sql`${memories.useCount} + 1`, lastUsedAt: new Date() })
      .where(inArray(memories.id, scored.map((s) => s.row.id)))
      .catch(() => undefined);
  }

  return scored.map((s) => ({
    id: s.row.id,
    key: s.row.key,
    value: s.row.value,
    type: s.row.type,
    score: Number(s.score.toFixed(3)),
  }));
}

export async function forget(workspaceId: string, id: string) {
  const [row] = await db.select().from(memories).where(eq(memories.id, id)).limit(1);
  if (!row || row.workspaceId !== workspaceId) return false;
  await db.delete(memories).where(eq(memories.id, id));
  await log(workspaceId, "deleted", row.key, row.value.slice(0, 160));
  return true;
}

export async function log(workspaceId: string, action: string, key: string, detail?: string) {
  try {
    await db.insert(memoryLog).values({ workspaceId, action, memoryKey: key, detail: detail ?? null });
  } catch {
    /* the audit trail must never break memory operations */
  }
}

export async function recentLog(workspaceId: string, limit = 12) {
  const rows = await db
    .select()
    .from(memoryLog)
    .where(eq(memoryLog.workspaceId, workspaceId))
    .orderBy(desc(memoryLog.createdAt))
    .limit(limit);
  return rows.map((r) => ({
    id: r.id,
    action: r.action,
    key: r.memoryKey,
    detail: r.detail,
    createdAt: r.createdAt.toISOString(),
  }));
}

export async function memoryStats(workspaceId: string) {
  const [row] = await db
    .select({
      total: sql<number>`count(*)::int`,
      enabled: sql<number>`count(*) filter (where ${memories.enabled})::int`,
      recalled: sql<number>`coalesce(sum(${memories.useCount}), 0)::int`,
    })
    .from(memories)
    .where(eq(memories.workspaceId, workspaceId));
  return { total: row.total, enabled: row.enabled, recalled: row.recalled };
}

export const toMemory = (m: Memory) => ({
  id: m.id,
  key: m.key,
  value: m.value,
  type: m.type,
  origin: m.origin,
  tags: m.tags ?? [],
  confidence: m.confidence,
  importance: m.importance,
  pinned: m.pinned,
  enabled: m.enabled,
  useCount: m.useCount,
  lastUsedAt: m.lastUsedAt?.toISOString() ?? null,
  createdAt: m.createdAt.toISOString(),
  updatedAt: m.updatedAt.toISOString(),
});

export async function searchMemories(workspaceId: string, query: string, limit = 100) {
  const q = query.trim();
  if (!q) {
    const rows = await db
      .select()
      .from(memories)
      .where(eq(memories.workspaceId, workspaceId))
      .orderBy(desc(memories.pinned), desc(memories.updatedAt))
      .limit(limit);
    return rows.map(toMemory);
  }
  const pattern = `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  const rows = await db
    .select()
    .from(memories)
    .where(
      and(
        eq(memories.workspaceId, workspaceId),
        or(ilike(memories.value, pattern), ilike(memories.key, pattern)),
      ),
    )
    .orderBy(desc(memories.updatedAt))
    .limit(limit);
  return rows.map(toMemory);
}
