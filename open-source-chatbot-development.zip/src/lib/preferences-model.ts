/**
 * The single source of truth for workspace preferences.
 * Shared by the settings UI (client) and the request pipeline (server), so a
 * setting can never be saved but ignored.
 */

export type ThemeChoice = "light" | "dark" | "system";
export type FontSize = "sm" | "md" | "lg";
export type Density = "comfortable" | "compact";
export type RevealMode = "off" | "smooth";
export type CodeTheme = "github" | "night-owl" | "min-light" | "material-theme";

export interface Preferences {
  /* Appearance */
  theme: ThemeChoice;
  accent: string;
  fontSize: FontSize;
  density: Density;
  animations: boolean;
  messageWidth: number;
  codeTheme: CodeTheme;
  lineNumbers: boolean;
  showTimestamps: boolean;
  showTokenUsage: boolean;
  showThinking: boolean;
  sidebarDefault: "open" | "closed";
  compactSidebar: boolean;

  /* Composer */
  sendOnEnter: boolean;
  autosaveDrafts: boolean;
  attachmentLimitKb: number;
  soundOnComplete: boolean;
  notificationsEnabled: boolean;

  /* Generation */
  defaultProvider: string;
  defaultModel: string;
  defaultAgentId: string | null;
  systemPrompt: string;
  temperature: number;
  topP: number;
  presencePenalty: number;
  frequencyPenalty: number;
  outputBudget: number;
  maxRetries: number;
  stopSequences: string;
  reveal: RevealMode;

  /* Tools */
  disabledTools: string[];
  searchResults: number;
  fetchMaxKb: number;
  fetchTimeoutSec: number;

  /* Skills */
  showSkillsIndex: boolean;
  autoLoadSkill: boolean;
  skillMatchThreshold: number;
  maxSkillsPerTurn: number;

  /* Memory */
  autoExtractMemories: boolean;
  injectMemories: boolean;
  memoryLimit: number;
  memoryMinScore: number;
  memoryHalfLifeDays: number;
  memoryDedupe: number;
  memoryMaxItems: number;
  memoryReinforce: boolean;

  /* Context control */
  contextWindow: number;
  maxHistoryMessages: number;
  autoCompact: boolean;
  compactThreshold: number;
  compactTargetRatio: number;
  keepPairs: boolean;
  showContextMeter: boolean;
  trustProviderTokens: boolean;

  /* Sharing & data */
  shareExpiryDays: number;
  shareRedactAttachments: boolean;

  /* Advanced */
  customHeaders: Record<string, string>;
  requestTimeout: number;
  welcomeDismissed: boolean;
}

export const DEFAULT_PREFERENCES: Preferences = {
  theme: "system",
  accent: "#d2622a",
  fontSize: "md",
  density: "comfortable",
  animations: true,
  messageWidth: 768,
  codeTheme: "github",
  lineNumbers: true,
  showTimestamps: true,
  showTokenUsage: true,
  showThinking: true,
  sidebarDefault: "open",
  compactSidebar: false,

  sendOnEnter: true,
  autosaveDrafts: true,
  attachmentLimitKb: 60,
  soundOnComplete: false,
  notificationsEnabled: false,

  defaultProvider: "",
  defaultModel: "",
  defaultAgentId: null,
  systemPrompt: "",
  temperature: 0.7,
  topP: 1,
  presencePenalty: 0,
  frequencyPenalty: 0,
  outputBudget: 2048,
  maxRetries: 2,
  stopSequences: "",
  reveal: "smooth",

  disabledTools: [],
  searchResults: 5,
  fetchMaxKb: 100,
  fetchTimeoutSec: 12,

  showSkillsIndex: true,
  autoLoadSkill: false,
  skillMatchThreshold: 0.6,
  maxSkillsPerTurn: 2,

  autoExtractMemories: true,
  injectMemories: true,
  memoryLimit: 6,
  memoryMinScore: 0.22,
  memoryHalfLifeDays: 45,
  memoryDedupe: 0.5,
  memoryMaxItems: 250,
  memoryReinforce: true,

  contextWindow: 128_000,
  maxHistoryMessages: 24,
  autoCompact: true,
  compactThreshold: 0.8,
  compactTargetRatio: 0.55,
  keepPairs: true,
  showContextMeter: true,
  trustProviderTokens: true,

  shareExpiryDays: 30,
  shareRedactAttachments: false,

  customHeaders: {},
  requestTimeout: 60,
  welcomeDismissed: false,
};

const num = (value: unknown, min: number, max: number, fallback: number) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};
const int = (value: unknown, min: number, max: number, fallback: number) =>
  Math.round(num(value, min, max, fallback));

const oneOf = <T extends string>(value: unknown, options: readonly T[], fallback: T): T =>
  typeof value === "string" && (options as readonly string[]).includes(value) ? (value as T) : fallback;

/**
 * Accepts anything the API returns and coerces it into a valid, in-range
 * preference object. Unknown keys are dropped so stale builds cannot corrupt
 * stored settings.
 */
export function normalizePreferences(raw: unknown): Preferences {
  const p = (raw ?? {}) as Record<string, unknown>;
  const d = DEFAULT_PREFERENCES;
  const headers = p.customHeaders;
  const customHeaders: Record<string, string> = {};
  if (headers && typeof headers === "object") {
    for (const [k, v] of Object.entries(headers as Record<string, unknown>)) {
      if (typeof v === "string" && /^[A-Za-z0-9-_]{1,40}$/.test(k)) customHeaders[k] = v.slice(0, 500);
    }
  }

  return {
    theme: oneOf(p.theme, ["light", "dark", "system"] as const, d.theme),
    accent: typeof p.accent === "string" && /^#[0-9a-f]{6}$/i.test(p.accent) ? p.accent : d.accent,
    fontSize: oneOf(p.fontSize, ["sm", "md", "lg"] as const, d.fontSize),
    density: oneOf(p.density, ["comfortable", "compact"] as const, d.density),
    animations: p.animations !== false && p.reduceMotion !== true,
    messageWidth: int(p.messageWidth, 560, 1200, d.messageWidth),
    codeTheme: oneOf(p.codeTheme, ["github", "night-owl", "min-light", "material-theme"] as const, d.codeTheme),
    lineNumbers: p.lineNumbers !== false,
    showTimestamps: p.showTimestamps !== false,
    showTokenUsage: p.showTokenUsage !== false,
    showThinking: p.showThinking !== false,
    sidebarDefault: oneOf(p.sidebarDefault, ["open", "closed"] as const, d.sidebarDefault),
    compactSidebar: p.compactSidebar === true,

    sendOnEnter: p.sendOnEnter !== false,
    autosaveDrafts: p.autosaveDrafts !== false,
    attachmentLimitKb: int(p.attachmentLimitKb, 5, 500, d.attachmentLimitKb),
    soundOnComplete: p.soundOnComplete === true,
    notificationsEnabled: p.notificationsEnabled === true,

    defaultProvider: typeof p.defaultProvider === "string" ? p.defaultProvider.slice(0, 40) : "",
    defaultModel: typeof p.defaultModel === "string" ? p.defaultModel.slice(0, 120) : "",
    defaultAgentId: typeof p.defaultAgentId === "string" ? p.defaultAgentId.slice(0, 40) : null,
    systemPrompt: typeof p.systemPrompt === "string" ? p.systemPrompt.slice(0, 4000) : "",
    temperature: num(p.temperature, 0, 2, d.temperature),
    topP: num(p.topP, 0, 1, d.topP),
    presencePenalty: num(p.presencePenalty, -2, 2, d.presencePenalty),
    frequencyPenalty: num(p.frequencyPenalty, -2, 2, d.frequencyPenalty),
    outputBudget: int(p.outputBudget, 128, 65_536, d.outputBudget),
    maxRetries: int(p.maxRetries, 0, 6, d.maxRetries),
    stopSequences: typeof p.stopSequences === "string" ? p.stopSequences.slice(0, 200) : "",
    reveal: oneOf(p.reveal, ["off", "smooth"] as const, d.reveal),

    disabledTools: Array.isArray(p.disabledTools)
      ? p.disabledTools.filter((t): t is string => typeof t === "string").slice(0, 40)
      : [],
    searchResults: int(p.searchResults, 1, 10, d.searchResults),
    fetchMaxKb: int(p.fetchMaxKb, 10, 500, d.fetchMaxKb),
    fetchTimeoutSec: int(p.fetchTimeoutSec, 3, 60, d.fetchTimeoutSec),

    showSkillsIndex: p.showSkillsIndex !== false,
    autoLoadSkill: p.autoLoadSkill === true,
    skillMatchThreshold: num(p.skillMatchThreshold, 0.2, 0.95, d.skillMatchThreshold),
    maxSkillsPerTurn: int(p.maxSkillsPerTurn, 1, 5, d.maxSkillsPerTurn),

    autoExtractMemories: p.autoExtractMemories !== false,
    injectMemories: p.injectMemories !== false,
    memoryLimit: int(p.memoryLimit, 0, 25, d.memoryLimit),
    memoryMinScore: num(p.memoryMinScore, 0.05, 0.8, d.memoryMinScore),
    memoryHalfLifeDays: int(p.memoryHalfLifeDays, 1, 3650, d.memoryHalfLifeDays),
    memoryDedupe: num(p.memoryDedupe, 0.2, 0.95, d.memoryDedupe),
    memoryMaxItems: int(p.memoryMaxItems, 10, 5000, d.memoryMaxItems),
    memoryReinforce: p.memoryReinforce !== false,

    contextWindow: int(p.contextWindow, 4096, 2_000_000, d.contextWindow),
    maxHistoryMessages: int(p.maxHistoryMessages, 2, 200, d.maxHistoryMessages),
    autoCompact: p.autoCompact !== false,
    compactThreshold: num(p.compactThreshold, 0.3, 0.98, d.compactThreshold),
    compactTargetRatio: num(p.compactTargetRatio, 0.2, 0.9, d.compactTargetRatio),
    keepPairs: p.keepPairs !== false,
    showContextMeter: p.showContextMeter !== false,
    trustProviderTokens: p.trustProviderTokens !== false,

    shareExpiryDays: int(p.shareExpiryDays, 0, 365, d.shareExpiryDays),
    shareRedactAttachments: p.shareRedactAttachments === true,

    customHeaders,
    requestTimeout: int(p.requestTimeout, 5, 300, d.requestTimeout),
    welcomeDismissed: p.welcomeDismissed === true,
  };
}

/** Only the keys that differ from defaults — keeps stored JSON small. */
export function diffPreferences(next: Preferences, base: Preferences): Partial<Preferences> {
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(next) as (keyof Preferences)[]) {
    if (JSON.stringify(next[key]) !== JSON.stringify(base[key])) out[key] = next[key];
  }
  return out as Partial<Preferences>;
}

export const ACCENT_SWATCHES = [
  { id: "ember", label: "Ember", value: "#d2622a" },
  { id: "indigo", label: "Indigo", value: "#5b5bd6" },
  { id: "teal", label: "Teal", value: "#0f8a7e" },
  { id: "rose", label: "Rose", value: "#c2416b" },
  { id: "moss", label: "Moss", value: "#4f7a1f" },
  { id: "amber", label: "Amber", value: "#b8860b" },
  { id: "graphite", label: "Graphite", value: "#475569" },
] as const;
