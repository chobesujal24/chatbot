// Offline demo responder. Deterministic, local, no network and no model.
// The UI labels this mode clearly — it is not presented as a language model.

type Reply = string;

export function evaluateMath(input: string): number | null {
  const expr = input.replace(/\s+/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, "");
  if (!expr || !/^[0-9+\-*/().%^]+$/.test(expr)) return null;
  let pos = 0;
  const peek = () => expr[pos];
  const consume = (ch: string) => (peek() === ch ? ++pos > -1 : false);

  function exprP(): number | null {
    let v = term();
    if (v === null) return null;
    while (peek() === "+" || peek() === "-") {
      const op = expr[pos++];
      const r = term();
      if (r === null) return null;
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }
  function term(): number | null {
    let v = factor();
    if (v === null) return null;
    while (peek() === "*" || peek() === "/" || peek() === "%") {
      const op = expr[pos++];
      const r = factor();
      if (r === null) return null;
      if (op === "*") v *= r;
      else if (op === "/") {
        if (r === 0) return null;
        v /= r;
      } else v %= r;
    }
    return v;
  }
  function factor(): number | null {
    let b = unary();
    if (b === null) return null;
    if (peek() === "^" || (peek() === "*" && expr[pos + 1] === "*")) {
      pos += peek() === "^" ? 1 : 2;
      const e = factor();
      if (e === null) return null;
      b = Math.pow(b, e);
    }
    return b;
  }
  function unary(): number | null {
    if (peek() === "-") {
      pos++;
      const v = unary();
      return v === null ? null : -v;
    }
    if (peek() === "+") {
      pos++;
      return unary();
    }
    return atom();
  }
  function atom(): number | null {
    if (peek() === "(") {
      pos++;
      const v = exprP();
      if (v === null) return null;
      if (!consume(")")) return null;
      return v;
    }
    let num = "";
    while (pos < expr.length && /[0-9.]/.test(expr[pos])) num += expr[pos++];
    if (!num) return null;
    const n = Number(num);
    return Number.isFinite(n) ? n : null;
  }
  const result = exprP();
  return result !== null && pos === expr.length && Number.isFinite(result) ? result : null;
}

function fmt(n: number) {
  return Math.abs(n) >= 1e12 || (Math.abs(n) < 1e-9 && n !== 0)
    ? n.toExponential(6)
    : Number(n.toPrecision(12)).toLocaleString("en-US", { maximumFractionDigits: 10 });
}

function codeSample(lang: string): string {
  if (lang.includes("python"))
    return `Here is a Python example — a small LRU cache built on \`OrderedDict\`:

\`\`\`python
from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.data: OrderedDict[str, int] = OrderedDict()

    def get(self, key: str) -> int:
        if key not in self.data:
            return -1
        self.data.move_to_end(key)
        return self.data[key]

    def put(self, key: str, value: int) -> None:
        self.data[key] = value
        self.data.move_to_end(key)
        if len(self.data) > self.capacity:
            self.data.popitem(last=False)
\`\`\`

\`get\` and \`put\` are both **O(1)**. Ask for TypeScript, Rust or Go as well.`;
  if (lang.includes("rust"))
    return `A Rust example — a generic result helper with error context:

\`\`\`rust
use std::{fmt, fs};

type AppResult<T> = Result<T, AppError>;

#[derive(Debug)]
struct AppError(String);

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "app error: {}", self.0)
    }
}

fn read_config(path: &str) -> AppResult<String> {
    fs::read_to_string(path)
        .map_err(|e| AppError(format!("{}: {}", path, e)))
}
\`\`\`

In a real project you would use \`thiserror\` or \`anyhow\` — both are excellent open-source crates.`;
  if (lang.includes("go"))
    return `A Go example — a bounded worker pool:

\`\`\`go
package main

import (
    "fmt"
    "sync"
)

func worker(id int, jobs <-chan int, results chan<- int, wg *sync.WaitGroup) {
    defer wg.Done()
    for j := range jobs {
        results <- id*1000 + j
    }
}

func main() {
    jobs := make(chan int, 9)
    results := make(chan int, 9)
    var wg sync.WaitGroup

    for w := 1; w <= 3; w++ {
        wg.Add(1)
        go worker(w, jobs, results, &wg)
    }
    for j := 1; j <= 9; j++ { jobs <- j }
    close(jobs)
    wg.Wait()
    close(results)

    for r := range results { fmt.Println(r) }
}
\`\`\``;
  return `A TypeScript example — a typed, abortable retry wrapper:

\`\`\`typescript
type RetryOptions = { retries?: number; delayMs?: number; signal?: AbortSignal };

export async function retry<T>(
  task: (attempt: number) => Promise<T>,
  { retries = 3, delayMs = 250, signal }: RetryOptions = {},
): Promise<T> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    signal?.throwIfAborted();
    try {
      return await task(attempt);
    } catch (error) {
      if (attempt === retries) throw error;
      await new Promise((r) => setTimeout(r, delayMs * 2 ** (attempt - 1)));
    }
  }
  throw new Error("unreachable");
}
\`\`\`

Exponential backoff, typed generics and cooperative cancellation. Ask for Python, Rust or Go too.`;
}

export function offlineReply(raw: string): string {
  const input = raw.trim();
  const lower = input.toLowerCase();

  if (/^[0-9+\-*/().%\s^×÷]+$/.test(input) && /\d/.test(input) && /[+\-*/^×÷]/.test(input)) {
    const value = evaluateMath(input);
    return value === null
      ? "That expression is malformed — check the parentheses and operators."
      : `**${fmt(value)}**\n\nArithmetic is evaluated locally with a small recursive-descent parser.`;
  }

  const match = lower.match(/(?:calculate|compute|evaluate|what(?:'s| is)|solve)\s+(.+)/);
  if (match) {
    const value = evaluateMath(match[1].replace(/[=?]+$/, "").trim());
    if (value !== null)
      return `**${fmt(value)}**\n\nOperators supported: \`+ - * / % ^\` and parentheses.`;
  }

  if (/\b(time|clock)\b/.test(lower))
    return `It is **${new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}** (server local time).`;
  if (/\b(date|today)\b/.test(lower))
    return `Today is **${new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}**.`;
  if (/\b(help|capabilities|what can you do|commands)\b/.test(lower))
    return `Offline demo capabilities:\n\n- **Arithmetic** — \`calculate (128 + 46) * 3\`\n- **Code samples** — \`show me a python example\`\n- **Time and date** — \`what time is it\`\n- **Markdown rendering** — lists, tables, fenced code, links\n\nFor real language-model answers, open **Settings** and connect an OpenAI-compatible endpoint, OpenAI, Anthropic or Google.`;
  if (/\b(code|function|snippet|example|python|typescript|javascript|rust|go|golang)\b/.test(lower) && /\b(write|show|give|example|create|generate|sample|code)\b/.test(lower)) {
    const lang = lower.match(/\b(python|typescript|javascript|rust|go|golang)\b/)?.[0] ?? "typescript";
    return codeSample(lang);
  }
  if (/\b(who are you|what are you|your name)\b/.test(lower))
    return `I am **Nova**, an open-source chat workspace. Right now you are in **offline demo mode**: answers come from a small deterministic responder in \`src/lib/offline.ts\`, not from a language model.\n\nConnect a provider in **Settings** to enable real streaming generation. Conversations are stored in PostgreSQL through Drizzle ORM either way.`;
  if (/\b(table|markdown)\b/.test(lower))
    return `Markdown is rendered with \`react-markdown\` and \`remark-gfm\`, including tables:\n\n| Feature | Source |\n| --- | --- |\n| Streaming | Vercel AI SDK |\n| UI primitives | shadcn/ui + Radix |\n| Database | Drizzle ORM + PostgreSQL |\n| Icons | Lucide |`;
  if (/\b(joke|funny)\b/.test(lower))
    return `A SQL query walks into a bar, sees two tables and asks: "Mind if I JOIN you?"\n\n(That is the entire offline joke database.)`;
  if (/\b(hi|hello|hey)\b/.test(lower) && lower.length < 24)
    return `Hello. This is **offline demo mode** — I can do arithmetic, code samples, time and Markdown. Connect a model in **Settings** for general conversation.`;

  return `You are in **offline demo mode**, so there is no language model behind this response. I received: "${input.length > 160 ? input.slice(0, 157) + "…" : input}".\n\nTo get real answers, open **Settings** and choose a provider:\n\n1. Paste an API key, or point the OpenAI-compatible base URL at a local **Ollama**, **LM Studio** or **vLLM** server.\n2. Pick a model and save. Keys are sent per request and are never written to the database.\n\nMeanwhile, try \`calculate (128 + 46) * 3\`, \`show me a rust example\` or \`what can you do\`.`;
}

export function deriveTitle(message: string): string {
  const clean = message.replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim();
  return clean.length <= 52 ? clean : clean.slice(0, 49).trimEnd() + "…";
}
