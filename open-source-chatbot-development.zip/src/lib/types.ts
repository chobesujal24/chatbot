import type { ToolCallRecord, UsageInfo } from "@/db/schema";

export type Role = "user" | "assistant";
export type ProviderId = "offline" | "openai" | "anthropic" | "google" | "custom";
export type Theme = "light" | "dark" | "system";

export interface ConversationSummary {
  id: string;
  title: string;
  pinned: boolean;
  model: string | null;
  agentId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AttachmentMeta {
  name: string;
  size: number;
}

export interface ContextMeta {
  injectedMemoryIds: string[];
  usedSkillNames: string[];
  historyMessages: number;
  summarizedMessages: number;
  estimatedTokens: number;
  compacted: boolean;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: Role;
  content: string;
  model: string | null;
  attachments: AttachmentMeta[] | null;
  toolCalls: ToolCallRecord[] | null;
  usage: UsageInfo | null;
  contextMeta?: ContextMeta | null;
  seq?: number;
  createdAt: string;
}

export interface Agent {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  model: string | null;
  temperature: number;
  maxSteps: number;
  tools: string[];
  icon: string;
  isDefault: boolean;
  memoryMode?: "auto" | "on" | "off";
  skills?: string[] | null;
  createdAt: string;
  updatedAt: string;
}

export type MemoryType = "preference" | "fact" | "entity" | "procedure" | "event";

export interface MemoryItem {
  id: string;
  key: string;
  value: string;
  type: MemoryType;
  origin: "user" | "agent" | "extracted" | "manual";
  tags: string[];
  confidence: number;
  importance: number;
  pinned: boolean;
  enabled: boolean;
  useCount: number;
  lastUsedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface MemoryStats {
  total: number;
  enabled: number;
  recalled: number;
}

export interface MemoryLogEntry {
  id: string;
  action: string;
  key: string;
  detail: string | null;
  createdAt: string;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  instructions: string;
  tools: string[] | null;
  emoji: string;
  source: string;
  enabled: boolean;
  useCount: number;
  lastUsedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ContextSegment {
  id: string;
  label: string;
  tokens: number;
  detail?: string;
}

export interface ContextBreakdown {
  segments: ContextSegment[];
  promptTokens: number;
  outputBudget: number;
  contextWindow: number;
  ratio: number;
  headroom: number;
  overage: number;
  estimated: boolean;
}

export interface ContextSettings {
  maxHistoryMessages: number;
  injectMemories: boolean;
  memoryLimit: number;
  includeSkills: boolean;
  autoCompact: boolean;
  compactThreshold: number;
  contextWindow: number;
  outputBudget: number;
}

export interface ConversationContext {
  settings: ContextSettings;
  breakdown: ContextBreakdown;
  injectedMemories: Array<{ id: string; key: string; value: string; type: MemoryType; score: number }>;
  skills: Array<{ name: string; description: string; emoji: string }>;
  messageCount: number;
  includedCount: number;
  droppedCount: number;
  summarizedCount: number;
  hasSummary: boolean;
  totalEstimatedTokens: number;
}

export interface TaskItem {
  id: string;
  title: string;
  status: "open" | "done";
  agentId: string | null;
  conversationId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PromptTemplate {
  id: string;
  name: string;
  content: string;
  createdAt: string;
}

export interface SearchHit {
  messageId: string;
  conversationId: string;
  conversationTitle: string;
  role: Role;
  snippet: string;
  createdAt: string;
}

export interface Settings {
  provider: ProviderId;
  model: string;
  apiKey: string;
  baseURL: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
}

export interface ClientAttachment {
  name: string;
  content: string;
}

export interface ChatRequest {
  conversationId?: string | null;
  agentId?: string | null;
  content?: string;
  attachments?: ClientAttachment[];
  mode?: "send" | "regenerate" | "edit";
  editMessageId?: string;
  editContent?: string;
  settings: Settings;
}

export type { ToolCallRecord, UsageInfo };
