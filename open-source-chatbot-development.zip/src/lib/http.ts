import { NextResponse } from "next/server";
import type { ZodType } from "zod";
import { randomUUID } from "node:crypto";
import { currentWorkspace, isAuthorized } from "./workspace";
import { checkRateLimit } from "./rate-limit";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export function errorResponse(error: unknown, requestId: string): NextResponse {
  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: { code: error.code, message: error.message }, requestId },
      { status: error.status, headers: { "x-request-id": requestId } },
    );
  }
  const message = error instanceof Error ? error.message : "Unknown error";
  console.error(`[${requestId}] unhandled`, error);
  return NextResponse.json(
    { error: { code: "internal_error", message: "Internal server error" }, requestId },
    { status: 500, headers: { "x-request-id": requestId } },
  );
}

type RouteContext = unknown;
type Handler<C> = (request: Request, context: C) => Promise<Response>;

/** Wraps a route handler with structured errors and a request id. */
export function route<C extends RouteContext>(handler: Handler<C>) {
  return async (request: Request, context: C): Promise<Response> => {
    const requestId = randomUUID().slice(0, 8);
    try {
      return await handler(request, context);
    } catch (error) {
      return errorResponse(error, requestId);
    }
  };
}

export interface GuardOptions {
  public?: boolean;
  rateLimit?: { bucket: string; limit: number; windowMs: number };
}

/** Verifies origin, authorization and workspace ownership in one place. */
export async function guard(
  request: Request,
  options: GuardOptions = {},
): Promise<{ workspaceId: string }> {
  const method = request.method.toUpperCase();
  if (method !== "GET" && method !== "HEAD" && method !== "OPTIONS") {
    const origin = request.headers.get("origin");
    if (origin) {
      const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
      let sameOrigin = false;
      try {
        sameOrigin = new URL(origin).host === host;
      } catch {
        sameOrigin = false;
      }
      if (!sameOrigin) throw new ApiError(403, "bad_origin", "Cross-origin request refused.");
    }
  }

  if (options.rateLimit) {
    const wsHint = (await currentWorkspace()) ?? "anon";
    const { allowed, retryAfterMs } = await checkRateLimit(
      `${options.rateLimit.bucket}:${wsHint}`,
      options.rateLimit.limit,
      options.rateLimit.windowMs,
    );
    if (!allowed) {
      throw new ApiError(
        429,
        "rate_limited",
        `Too many requests. Try again in ${Math.ceil(retryAfterMs / 1000)}s.`,
      );
    }
  }

  if (options.public) {
    return { workspaceId: (await currentWorkspace()) ?? "" };
  }
  if (!(await isAuthorized())) {
    throw new ApiError(401, "authentication_required", "A passcode is required.");
  }
  const workspaceId = await currentWorkspace();
  if (!workspaceId) {
    throw new ApiError(401, "workspace_required", "Call /api/bootstrap first.");
  }
  return { workspaceId };
}

/** Parses and validates a JSON body. Rejects unknown shapes with a clear 400. */
export async function parseBody<T>(
  request: Request,
  schema: ZodType<T>,
): Promise<T> {
  const raw = await request.text().catch(() => "");
  if (raw.length > 256_000) {
    throw new ApiError(413, "payload_too_large", "Request body is too large.");
  }
  let json: unknown;
  try {
    json = raw ? JSON.parse(raw) : {};
  } catch {
    throw new ApiError(400, "invalid_json", "Request body must be valid JSON.");
  }
  const result = schema.safeParse(json);
  if (!result.success) {
    const first = result.error.issues[0];
    const path = first?.path.join(".");
    throw new ApiError(
      400,
      "validation_error",
      path ? `${path}: ${first?.message}` : (first?.message ?? "Invalid request."),
    );
  }
  return result.data;
}

export const noStore = {
  "Cache-Control": "no-store, no-transform",
};

/** Validates URL search params with the same 400 envelope as request bodies. */
export function parseQuery<T>(request: Request, schema: ZodType<T>): T {
  const url = new URL(request.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const result = schema.safeParse(params);
  if (!result.success) {
    const first = result.error.issues[0];
    throw new ApiError(
      400,
      "validation_error",
      first?.path.length ? `${first.path.join(".")}: ${first.message}` : (first?.message ?? "Invalid query."),
    );
  }
  return result.data;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Path ids are never probed against the database with a malformed value. */
export const isUuid = (value: unknown): value is string =>
  typeof value === "string" && UUID_RE.test(value);

export function requireUuidParam(value: string | null, field = "id"): string {
  if (!isUuid(value)) {
    throw new ApiError(400, "validation_error", `${field} must be a valid id.`);
  }
  return value;
}
