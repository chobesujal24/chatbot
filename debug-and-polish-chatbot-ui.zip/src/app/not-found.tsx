import Link from "next/link";
import { Logo } from "@/components/logo";

export default function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-5 text-center">
      <Logo size={40} />
      <h1 className="font-serif text-4xl">Page not found</h1>
      <p className="text-[14px] text-muted-foreground">
        This page or share link does not exist, or it has expired.
      </p>
      <Link
        href="/"
        className="rounded-lg border bg-card px-4 py-2 text-[14px] font-medium transition hover:bg-accent"
      >
        Back to Nova
      </Link>
    </div>
  );
}
