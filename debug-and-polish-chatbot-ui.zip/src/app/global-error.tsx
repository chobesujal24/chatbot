"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, sans-serif", padding: "3rem", textAlign: "center" }}>
        <h1>Nova is temporarily unavailable</h1>
        <p>An unexpected error occurred while loading the application.</p>
        <button
          type="button"
          onClick={reset}
          style={{ marginTop: "1rem", padding: "0.6rem 1.2rem", cursor: "pointer" }}
        >
          Try again
        </button>
      </body>
    </html>
  );
}
