import { db } from "@/db";
import { conversations, messages, sharedLinks } from "@/db/schema";
import { and, asc, eq, gt, isNull, or } from "drizzle-orm";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import SharedConversation from "@/components/shared-conversation";
import { getPreferences } from "@/lib/preferences";
import { redactAttachedBlocks } from "@/lib/offline";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shared conversation — Nova",
  robots: { index: false, follow: false },
};

export default async function SharePage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  if (!/^[A-Za-z0-9_-]{10,80}$/.test(token)) notFound();

  const [link] = await db
    .select()
    .from(sharedLinks)
    .where(
      and(
        eq(sharedLinks.token, token),
        or(isNull(sharedLinks.expiresAt), gt(sharedLinks.expiresAt, new Date())),
      ),
    )
    .limit(1);
  if (!link) notFound();

  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, link.conversationId))
    .limit(1);
  if (!conversation) notFound();

  const [rows, prefs] = await Promise.all([
    db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversation.id))
      .orderBy(asc(messages.createdAt))
      .limit(500),
    getPreferences(link.workspaceId),
  ]);

  return (
    <SharedConversation
      title={conversation.title}
      messages={rows.map((m) => ({
        id: m.id,
        role: m.role,
        content: prefs.shareRedactAttachments ? redactAttachedBlocks(m.content) : m.content,
        createdAt: m.createdAt.toISOString(),
      }))}
    />
  );
}
