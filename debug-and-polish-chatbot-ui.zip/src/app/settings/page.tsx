import SettingsPage from "@/components/settings/settings-page";

export const metadata = {
  title: "Settings — Nova",
  description: "Providers, integrations, agents, appearance and data controls for Nova.",
};

export default function SettingsRoute() {
  return <SettingsPage />;
}
