"use client";

import { useEffect } from "react";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Unhandled client error", error);
  }, [error]);

  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-5 text-center">
      <h1 className="font-serif text-4xl">Something went wrong</h1>
      <p className="max-w-md text-[14px] text-muted-foreground">
        The workspace hit an unexpected error. Your conversations are stored in the database and
        are safe.
      </p>
      {error.digest && (
        <code className="rounded border bg-muted px-2 py-1 text-[12px] text-muted-foreground">
          ref: {error.digest}
        </code>
      )}
      <Button onClick={reset}>
        <RotateCcw size={15} /> Try again
      </Button>
    </div>
  );
}
