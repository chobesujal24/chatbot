import { db } from "@/db";
import { conversations } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, route, parseQuery } from "@/lib/http";
import { toSummary } from "@/lib/data";
import { conversationCreateSchema, paginationSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const { limit, offset } = parseQuery(request, paginationSchema);
  const rows = await db
    .select()
    .from(conversations)
    .where(eq(conversations.workspaceId, ws))
    .orderBy(desc(conversations.pinned), desc(conversations.updatedAt))
    .limit(limit)
    .offset(offset);
  return NextResponse.json({ conversations: rows.map(toSummary) }, { headers: noStore });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, conversationCreateSchema);
  const [row] = await db
    .insert(conversations)
    .values({ workspaceId: ws, title: body.title?.trim() || "New chat" })
    .returning();
  return NextResponse.json({ conversation: toSummary(row) });
});
