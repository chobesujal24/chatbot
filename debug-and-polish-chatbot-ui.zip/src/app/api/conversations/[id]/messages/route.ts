import { db } from "@/db";
import { messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, route, parseQuery } from "@/lib/http";
import { ownedConversation, toMessage } from "@/lib/data";
import { paginationSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const GET = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  const { limit, offset } = parseQuery(request, paginationSchema);
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt))
    .limit(limit)
    .offset(offset);
  return NextResponse.json({ messages: rows.map(toMessage) }, { headers: noStore });
});
