import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, route } from "@/lib/http";
import { ownedConversation, toSummary } from "@/lib/data";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const POST = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const source = await ownedConversation(ws, id);
  const [copy] = await db
    .insert(conversations)
    .values({
      workspaceId: ws,
      title: `${source.title} (copy)`.slice(0, 200),
      model: source.model,
      agentId: source.agentId,
    })
    .returning();

  const originals = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt))
    .limit(500);
  if (originals.length > 0) {
    await db.insert(messages).values(
      originals.map((m, i) => ({
        workspaceId: ws,
        conversationId: copy.id,
        role: m.role,
        content: m.content,
        model: m.model,
        attachments: m.attachments,
        toolCalls: m.toolCalls,
        usage: m.usage,
        seq: i + 1,
        contextMeta: m.contextMeta,
      })),
    );
  }
  return NextResponse.json({ conversation: toSummary(copy) });
});
