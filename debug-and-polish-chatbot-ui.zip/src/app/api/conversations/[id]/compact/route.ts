import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { generateText } from "ai";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { compactSchema } from "@/lib/validation";
import { ownedConversation } from "@/lib/data";
import { listCredentials } from "@/lib/credentials";
import { getPreferences } from "@/lib/preferences";
import { resolveModel } from "@/lib/model";
import {
  extractiveSummary,
  renderSummaryBlock,
  resolveContextSettings,
} from "@/lib/context";
import { buildBreakdown, estimateTokens } from "@/lib/context";

export const dynamic = "force-dynamic";

/**
 * Compaction: fold the oldest turns into a durable summary that replaces them
 * in the prompt, so a long conversation keeps fitting the context window.
 */
export const POST = route<{ params: Promise<{ id: string }> }>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "compact", limit: 10, windowMs: 60_000 },
  });
  const conversation = await ownedConversation(ws, id);
  const { keepRecent } = await parseBody(request, compactSchema);

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt))
    .limit(400);

  const keep = Math.max(2, keepRecent ?? 8);
  const alreadySummarized = conversation.summarizedCount ?? 0;
  const tail = history.slice(alreadySummarized);
  if (tail.length <= keep + 1) {
    return NextResponse.json({
      ok: false,
      message: "Nothing to compact yet — this conversation is still short.",
      summarizedCount: alreadySummarized,
    });
  }

  const foldCount = tail.length - keep;
  const folded = tail.slice(0, foldCount);
  const prior = conversation.summary
    ? [{ role: "system", content: conversation.summary }]
    : [];
  let summaryText = extractiveSummary([
    ...prior,
    ...folded.map((m) => ({ role: m.role, content: m.content })),
  ]);

  let usedModel = false;
  const prefs = await getPreferences(ws);
  const settings = resolveContextSettings(
    prefs as unknown as Record<string, unknown>,
    conversation.context,
  );
  const credential =
    (await listCredentials(ws)).find((c) => c.kind === "model" && c.isActive && c.enabled) ?? null;
  const candidateModel =
    (conversation.model && conversation.model !== "offline-demo" ? conversation.model : "") ||
    prefs.defaultModel ||
    "";
  const resolution = await resolveModel(
    {
      provider: (credential?.provider ?? "offline") as "offline",
      model: candidateModel,
      apiKey: "",
      baseURL: credential?.baseURL ?? "",
      systemPrompt: "",
      temperature: 0.2,
      maxTokens: 600,
    },
    credential
      ? { provider: credential.provider, secret: credential.secret, baseURL: credential.baseURL }
      : null,
    { headers: prefs.customHeaders, timeout: prefs.requestTimeout },
  );

  if (resolution.model) {
    try {
      const { text } = await generateText({
        model: resolution.model,
        system:
          "Compress the conversation into durable bullet points. Preserve every name, number, file path, decision, correction and open question. No preamble, no commentary. Max 250 words.",
        prompt: [...prior, ...folded.map((m) => ({ role: m.role, content: m.content }))]
          .map((m) => `${m.role}: ${m.content.slice(0, 1500)}`)
          .join("\n")
          .slice(0, 60000),
        maxOutputTokens: Math.min(700, settings.outputBudget),
      });
      if (text.trim().length > 60) {
        summaryText = text.trim();
        usedModel = true;
      }
    } catch {
      /* fall back to the extractive summary */
    }
  }

  if (!summaryText) {
    return NextResponse.json({ ok: false, message: "Nothing worth summarising was found." });
  }

  const summarizedCount = alreadySummarized + foldCount;
  await db
    .update(conversations)
    .set({ summary: summaryText.slice(0, 8000), summarizedCount, updatedAt: new Date() })
    .where(eq(conversations.id, id));

  const remaining = history.slice(alreadySummarized + foldCount);
  const breakdown = buildBreakdown({
    history: remaining.map((m) => ({ role: m.role, content: m.content })),
    summary: renderSummaryBlock(summaryText, summarizedCount),
    settings,
  });

  return NextResponse.json({
    ok: true,
    summarizedCount,
    foldedCount: foldCount,
    via: usedModel ? "model" : "extractive",
    summary: summaryText.slice(0, 8000),
    tokensSaved: folded.reduce((sum, m) => sum + estimateTokens(m.content), 0) - estimateTokens(summaryText),
    promptTokens: breakdown.promptTokens,
    ratio: breakdown.ratio,
    contextWindow: breakdown.contextWindow,
  });
});
