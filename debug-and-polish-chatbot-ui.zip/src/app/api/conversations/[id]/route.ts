import { db } from "@/db";
import { conversations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { ownedConversation, toSummary } from "@/lib/data";
import { conversationPatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  const body = await parseBody(request, conversationPatchSchema);
  const [row] = await db
    .update(conversations)
    .set({ ...body, updatedAt: new Date() })
    .where(eq(conversations.id, id))
    .returning();
  return NextResponse.json({ conversation: toSummary(row) });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedConversation(ws, id);
  await db.delete(conversations).where(eq(conversations.id, id));
  return NextResponse.json({ ok: true });
});
