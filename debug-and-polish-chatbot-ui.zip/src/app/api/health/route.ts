import { db } from "@/db";
import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Liveness + readiness in one endpoint.
 *
 * The HTTP status is always 200 while the process is alive: orchestrators use
 * this probe to decide whether to expose the app, and a temporarily
 * unavailable database must not take the whole preview offline. Database
 * readiness is reported in the body instead.
 */
export async function GET() {
  const started = Date.now();
  let database: "up" | "down" = "down";
  let latencyMs: number | null = null;
  try {
    await Promise.race([
      db.execute(sql`select 1`),
      new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), 4000)),
    ]);
    database = "up";
    latencyMs = Date.now() - started;
  } catch (error) {
    console.error("[health] database check failed", error);
  }

  return NextResponse.json(
    {
      ok: true,
      database,
      latencyMs,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    },
    { status: 200, headers: { "Cache-Control": "no-store" } },
  );
}
