import { db } from "@/db";
import {
  agents,
  conversations,
  credentials,
  memories,
  messages,
  promptTemplates,
  sharedLinks,
  skills,
  tasks,
} from "@/db/schema";
import { and, eq, inArray, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { seedAgents } from "@/lib/workspace";
import { seedSkills } from "@/lib/skills";
import { log } from "@/lib/memory";
import { z } from "zod";

export const dynamic = "force-dynamic";

const target = z.object({
  target: z.enum([
    "conversations",
    "memories",
    "memories-unused",
    "tasks",
    "skills",
    "templates",
    "shares",
    "all",
  ]),
});

/**
 * Bulk maintenance, always scoped to the caller's workspace. Destructive
 * targets delete rows; `memories-unused` only disables them so nothing is lost
 * by accident.
 */
export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "maintenance", limit: 12, windowMs: 60_000 },
  });
  const { target: kind } = await parseBody(request, target);

  switch (kind) {
    case "conversations": {
      const rows = await db.select({ id: conversations.id }).from(conversations).where(eq(conversations.workspaceId, ws));
      if (rows.length) await db.delete(conversations).where(inArray(conversations.id, rows.map((r) => r.id)));
      return NextResponse.json({ ok: true, removed: rows.length, target: kind });
    }
    case "memories": {
      const removed = await db.delete(memories).where(eq(memories.workspaceId, ws)).returning({ id: memories.id });
      await log(ws, "purged", "all", `${removed.length} memories deleted`);
      return NextResponse.json({ ok: true, removed: removed.length, target: kind });
    }
    case "memories-unused": {
      const rows = await db
        .select({ id: memories.id, key: memories.key })
        .from(memories)
        .where(and(eq(memories.workspaceId, ws), eq(memories.useCount, 0), eq(memories.enabled, true)));
      for (const row of rows) {
        await db.update(memories).set({ enabled: false, updatedAt: new Date() }).where(eq(memories.id, row.id));
        await log(ws, "auto-disabled", row.key, "never recalled");
      }
      return NextResponse.json({ ok: true, changed: rows.length, target: kind });
    }
    case "tasks": {
      const removed = await db.delete(tasks).where(eq(tasks.workspaceId, ws)).returning({ id: tasks.id });
      return NextResponse.json({ ok: true, removed: removed.length, target: kind });
    }
    case "skills": {
      const removed = await db
        .delete(skills)
        .where(and(eq(skills.workspaceId, ws), sql`${skills.source} <> 'builtin'`))
        .returning({ id: skills.id });
      await seedSkills(ws);
      return NextResponse.json({ ok: true, removed: removed.length, target: kind });
    }
    case "templates": {
      const removed = await db.delete(promptTemplates).where(eq(promptTemplates.workspaceId, ws)).returning({ id: promptTemplates.id });
      return NextResponse.json({ ok: true, removed: removed.length, target: kind });
    }
    case "shares": {
      const removed = await db.delete(sharedLinks).where(eq(sharedLinks.workspaceId, ws)).returning({ id: sharedLinks.id });
      return NextResponse.json({ ok: true, removed: removed.length, target: kind });
    }
    case "all": {
      const convs = await db.select({ id: conversations.id }).from(conversations).where(eq(conversations.workspaceId, ws));
      if (convs.length) await db.delete(conversations).where(inArray(conversations.id, convs.map((c) => c.id)));
      await db.delete(messages).where(eq(messages.workspaceId, ws));
      await db.delete(memories).where(eq(memories.workspaceId, ws));
      await db.delete(tasks).where(eq(tasks.workspaceId, ws));
      await db.delete(skills).where(eq(skills.workspaceId, ws));
      await db.delete(promptTemplates).where(eq(promptTemplates.workspaceId, ws));
      await db.delete(sharedLinks).where(eq(sharedLinks.workspaceId, ws));
      await db.delete(agents).where(eq(agents.workspaceId, ws));
      await db.delete(credentials).where(eq(credentials.workspaceId, ws));
      await seedAgents(ws);
      await seedSkills(ws);
      return NextResponse.json({ ok: true, conversations: convs.length, target: kind });
    }
    default:
      return NextResponse.json({ ok: false, message: "Unknown target." }, { status: 400 });
  }
});
