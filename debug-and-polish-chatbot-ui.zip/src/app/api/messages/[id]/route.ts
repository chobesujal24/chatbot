import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { ownedMessage } from "@/lib/data";
import { messagePatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedMessage(ws, id);
  const { content } = await parseBody(request, messagePatchSchema);
  await db.update(messages).set({ content }).where(eq(messages.id, id));
  return NextResponse.json({ ok: true });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const target = await ownedMessage(ws, id);
  const siblings = await db
    .select({ id: messages.id })
    .from(messages)
    .where(eq(messages.conversationId, target.conversationId))
    .orderBy(asc(messages.createdAt));
  const index = siblings.findIndex((m) => m.id === id);
  await db.delete(messages).where(eq(messages.id, id));
  // Deleting inside the summarized prefix invalidates the rolling summary;
  // otherwise just clamp the counter to the rows that remain.
  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, target.conversationId))
    .limit(1);
  const summarized = conversation?.summarizedCount ?? 0;
  if (conversation && summarized > 0) {
    if (index >= 0 && index < summarized) {
      await db
        .update(conversations)
        .set({ summary: null, summarizedCount: 0 })
        .where(eq(conversations.id, conversation.id));
    } else if (summarized > siblings.length - 1) {
      await db
        .update(conversations)
        .set({ summarizedCount: Math.max(0, siblings.length - 1) })
        .where(eq(conversations.id, conversation.id));
    }
  }
  return NextResponse.json({ ok: true });
});
