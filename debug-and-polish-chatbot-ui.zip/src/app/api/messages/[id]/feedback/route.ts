import { db } from "@/db";
import { messageFeedback } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { ownedMessage } from "@/lib/data";
import { feedbackSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const POST = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const message = await ownedMessage(ws, id);
  if (message.role !== "assistant") {
    return NextResponse.json({ error: { code: "invalid_target", message: "Only responses can be rated." } }, { status: 400 });
  }
  const { rating } = await parseBody(request, feedbackSchema);
  await db
    .insert(messageFeedback)
    .values({ messageId: id, workspaceId: ws, rating })
    .onConflictDoUpdate({ target: messageFeedback.messageId, set: { rating } });
  return NextResponse.json({ ok: true, rating });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedMessage(ws, id);
  await db.delete(messageFeedback).where(eq(messageFeedback.messageId, id));
  return NextResponse.json({ ok: true });
});
