import { db } from "@/db";
import { memories } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, parseQuery, route } from "@/lib/http";
import { memoryCreateSchema } from "@/lib/validation";
import { memoryStats, recentLog, remember, searchMemories, toMemory } from "@/lib/memory";
import { z } from "zod";

export const dynamic = "force-dynamic";

const listSchema = z.object({
  q: z.string().trim().max(200).optional(),
  type: z.enum(["preference", "fact", "entity", "procedure", "event"]).optional(),
  limit: z.coerce.number().int().min(1).max(500).default(200),
});

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const { q, type, limit } = parseQuery(request, listSchema);
  let rows = await searchMemories(ws, q ?? "", limit);
  if (type) rows = rows.filter((r) => r.type === type);
  const [stats, log] = await Promise.all([memoryStats(ws), recentLog(ws, 8)]);
  return NextResponse.json({ memories: rows, stats, log }, { headers: noStore });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, memoryCreateSchema);
  const result = await remember(ws, {
    key: body.key,
    value: body.value,
    type: body.type,
    importance: body.importance,
    confidence: body.confidence,
    tags: body.tags,
    origin: "manual",
  });

  if (result.status === "skipped") {
    return NextResponse.json(
      { error: { code: "validation_error", message: "Memory value is empty." } },
      { status: 400 },
    );
  }

  const [row] = await db
    .select()
    .from(memories)
    .where(and(eq(memories.workspaceId, ws), eq(memories.key, result.key)))
    .orderBy(desc(memories.updatedAt))
    .limit(1);

  if (row && body.pinned !== undefined) {
    const [updated] = await db
      .update(memories)
      .set({ pinned: body.pinned })
      .where(eq(memories.id, row.id))
      .returning();
    return NextResponse.json({ memory: toMemory(updated), status: result.status });
  }

  return NextResponse.json({
    memory: row ? toMemory(row) : null,
    status: result.status,
    message:
      result.status === "updated"
        ? "Merged into an existing memory that covered the same fact."
        : undefined,
  });
});
