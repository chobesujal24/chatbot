import { db } from "@/db";
import { memories } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { ApiError, guard, parseBody, route } from "@/lib/http";
import { memoryPatchSchema } from "@/lib/validation";
import { forget, log, toMemory } from "@/lib/memory";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

async function owned(ws: string, id: string) {
  const [row] = await db
    .select()
    .from(memories)
    .where(and(eq(memories.id, id), eq(memories.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Memory not found.");
  return row;
}

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const row = await owned(ws, id);
  const body = await parseBody(request, memoryPatchSchema);
  const [updated] = await db
    .update(memories)
    .set({ ...body, updatedAt: new Date() })
    .where(eq(memories.id, id))
    .returning();
  if (body.enabled === false) await log(ws, "disabled", row.key);
  if (body.pinned !== undefined) await log(ws, body.pinned ? "pinned" : "unpinned", row.key);
  return NextResponse.json({ memory: toMemory(updated) });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await owned(ws, id);
  await forget(ws, id);
  return NextResponse.json({ ok: true });
});
