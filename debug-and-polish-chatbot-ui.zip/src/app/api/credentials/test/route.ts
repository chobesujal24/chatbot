import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { credentialSecret } from "@/lib/credentials";
import { findProvider } from "@/lib/providers";
import { credentialTestSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

function serverEnvKey(provider: string): string {
  if (provider === "openai") return process.env.OPENAI_API_KEY?.trim() ?? "";
  if (provider === "anthropic") return process.env.ANTHROPIC_API_KEY?.trim() ?? "";
  if (provider === "google") {
    return (
      process.env.GOOGLE_GENERATIVE_AI_API_KEY?.trim() ||
      process.env.GOOGLE_API_KEY?.trim() ||
      ""
    );
  }
  return "";
}

/** Verifies a stored or draft credential by making the cheapest possible authenticated call. */
export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "credential-test", limit: 30, windowMs: 60_000 },
  });
  const { provider, secret: draftSecret, baseURL: draftBase } = await parseBody(
    request,
    credentialTestSchema,
  );
  const preset = findProvider(provider);
  if (!preset) {
    return NextResponse.json(
      { error: { code: "unknown_provider", message: `Unknown provider "${provider}".` } },
      { status: 400 },
    );
  }

  const stored = await credentialSecret(ws, provider);
  const secret = draftSecret?.trim() || stored?.secret || serverEnvKey(provider);
  const baseURL = (draftBase?.trim() || stored?.baseURL || preset.baseURL || "").replace(/\/$/, "");

  if (!secret && preset.requiresKey) {
    return NextResponse.json({
      ok: false,
      provider,
      message: "No API key provided or stored for this provider yet.",
    });
  }

  if (!baseURL) {
    return NextResponse.json({
      ok: false,
      provider,
      message: "No base URL configured. Enter a valid endpoint URL first.",
    });
  }

  const started = Date.now();
  try {
    if (preset.kind === "openai" || preset.kind === "openai-compatible") {
      // Perplexity does not expose /models; verify with a minimal 1-token chat check or models path when present.
      if (!preset.modelsPath && preset.id === "perplexity") {
        const res = await fetch(`${baseURL}/chat/completions`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${secret}`,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({
            model: preset.models[0] ?? "sonar",
            messages: [{ role: "user", content: "ping" }],
            max_tokens: 1,
          }),
          signal: AbortSignal.timeout(15000),
        });
        if (!res.ok) {
          return NextResponse.json({
            ok: false,
            provider,
            status: res.status,
            message:
              res.status === 401 || res.status === 403
                ? "The API key was rejected."
                : `Provider returned HTTP ${res.status}.`,
          });
        }
        return NextResponse.json({
          ok: true,
          provider,
          latencyMs: Date.now() - started,
          message: "Connected. Perplexity API accepted the key.",
        });
      }

      const url = `${baseURL}${preset.modelsPath ?? "/models"}`;
      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${secret || "not-required"}`,
          "User-Agent": "Nova/1.0",
        },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message:
            res.status === 401 || res.status === 403
              ? "The API key was rejected."
              : `Provider returned HTTP ${res.status}.`,
        });
      }
      const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
      const count = payload?.data?.length ?? 0;
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: `Connected. ${count ? `${count} models available.` : "Endpoint reachable."}`,
      });
    }

    if (preset.kind === "anthropic") {
      const res = await fetch(`${baseURL}/models`, {
        headers: { "x-api-key": secret, "anthropic-version": "2023-06-01" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message: res.status === 401 || res.status === 403 ? "The API key was rejected." : `HTTP ${res.status}.`,
        });
      }
      const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
      const count = payload?.data?.length ?? 0;
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: `Connected. ${count ? `${count} Claude models available.` : "Anthropic API is reachable."}`,
      });
    }

    if (preset.kind === "google") {
      const url = `${baseURL}/models?key=${encodeURIComponent(secret)}`;
      const res = await fetch(url, {
        headers: { "User-Agent": "Nova/1.0" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        return NextResponse.json({
          ok: false,
          provider,
          status: res.status,
          message: res.status === 400 || res.status === 403 ? "The API key was rejected." : `HTTP ${res.status}.`,
        });
      }
      const payload = (await res.json().catch(() => null)) as { models?: { name?: string }[] } | null;
      const count = payload?.models?.length ?? 0;
      return NextResponse.json({
        ok: true,
        provider,
        latencyMs: Date.now() - started,
        message: `Connected. ${count ? `${count} Gemini models available.` : "Gemini API is reachable."}`,
      });
    }

    // Search & page reader providers: use each provider's actual contract.
    let testUrl = `${baseURL}/search`;
    let init: RequestInit = { method: "GET", headers: { "User-Agent": "Nova/1.0" } };

    switch (preset.id) {
      case "firecrawl":
        testUrl = `${baseURL}/v2/search`;
        init = {
          method: "POST",
          headers: {
            Authorization: `Bearer ${secret}`,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({ query: "nova", limit: 1 }),
        };
        break;
      case "tavily":
        testUrl = `${baseURL}/search`;
        init = {
          method: "POST",
          headers: {
            Authorization: `Bearer ${secret}`,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({ query: "nova", max_results: 1, search_depth: "basic" }),
        };
        break;
      case "brave":
        testUrl = `${baseURL}/web/search?q=nova&count=1`;
        init = {
          method: "GET",
          headers: {
            "X-Subscription-Token": secret,
            Accept: "application/json",
            "User-Agent": "Nova/1.0",
          },
        };
        break;
      case "exa":
        testUrl = `${baseURL}/search`;
        init = {
          method: "POST",
          headers: {
            "x-api-key": secret,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({ query: "nova", numResults: 1 }),
        };
        break;
      case "serper":
        testUrl = `${baseURL}/search`;
        init = {
          method: "POST",
          headers: {
            "X-API-KEY": secret,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({ q: "nova", num: 1 }),
        };
        break;
      case "serpapi":
        testUrl = `${baseURL}/search.json?q=nova&num=1&api_key=${encodeURIComponent(secret)}`;
        init = {
          method: "GET",
          headers: { Accept: "application/json", "User-Agent": "Nova/1.0" },
        };
        break;
      case "jina-search":
        testUrl = `${baseURL}/nova`;
        init = {
          method: "GET",
          headers: {
            Authorization: `Bearer ${secret}`,
            Accept: "application/json",
            "User-Agent": "Nova/1.0",
          },
        };
        break;
      case "jina":
        testUrl = `${baseURL}/https://example.com`;
        init = {
          method: "GET",
          headers: {
            ...(secret ? { Authorization: `Bearer ${secret}` } : {}),
            Accept: "application/json",
            "User-Agent": "Nova/1.0",
          },
        };
        break;
      case "you":
        testUrl = `${baseURL}/search`;
        init = {
          method: "POST",
          headers: {
            Authorization: `Bearer ${secret}`,
            "X-API-Key": secret,
            "Content-Type": "application/json",
            "User-Agent": "Nova/1.0",
          },
          body: JSON.stringify({ query: "nova", count: 1 }),
        };
        break;
    }

    const res = await fetch(testUrl, {
      ...init,
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) {
      return NextResponse.json({
        ok: false,
        provider,
        status: res.status,
        message:
          res.status === 401 || res.status === 403 || res.status === 402
            ? "The API key was rejected or has insufficient credits."
            : `Provider returned HTTP ${res.status}.`,
      });
    }
    return NextResponse.json({
      ok: true,
      provider,
      latencyMs: Date.now() - started,
      message: "Connected. The provider accepted the request.",
    });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      provider,
      message: error instanceof Error ? error.message : "Connection failed.",
    });
  }
});

/** Lists the model IDs a provider exposes, using the stored or server key. */
export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const url = new URL(request.url);
  const provider = url.searchParams.get("provider") ?? "";
  const preset = findProvider(provider);
  if (!preset) {
    return NextResponse.json({ error: { code: "unknown_provider", message: "Unknown provider." } }, { status: 400 });
  }
  const stored = await credentialSecret(ws, provider);
  const secret = stored?.secret || serverEnvKey(provider);
  const baseURL = (stored?.baseURL || preset.baseURL || "").replace(/\/$/, "");
  if (!baseURL) {
    return NextResponse.json({ models: preset.models, source: "preset" });
  }
  try {
    if (preset.kind === "anthropic") {
      if (!secret) return NextResponse.json({ models: preset.models, source: "preset" });
      const res = await fetch(`${baseURL}/models`, {
        headers: { "x-api-key": secret, "anthropic-version": "2023-06-01" },
        signal: AbortSignal.timeout(12000),
      });
      if (!res.ok) return NextResponse.json({ models: preset.models, source: "preset" });
      const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
      const models = (payload?.data ?? [])
        .map((m) => m.id)
        .filter((id): id is string => Boolean(id))
        .sort();
      return NextResponse.json({
        models: models.length ? models : preset.models,
        source: models.length ? "provider" : "preset",
      });
    }

    if (preset.kind === "google") {
      if (!secret) return NextResponse.json({ models: preset.models, source: "preset" });
      const res = await fetch(`${baseURL}/models?key=${encodeURIComponent(secret)}`, {
        headers: { "User-Agent": "Nova/1.0" },
        signal: AbortSignal.timeout(12000),
      });
      if (!res.ok) return NextResponse.json({ models: preset.models, source: "preset" });
      const payload = (await res.json().catch(() => null)) as {
        models?: { name?: string; supportedGenerationMethods?: string[] }[];
      } | null;
      const models = (payload?.models ?? [])
        .filter((m) => !m.supportedGenerationMethods || m.supportedGenerationMethods.includes("generateContent"))
        .map((m) => (m.name ?? "").replace(/^models\//, ""))
        .filter(Boolean)
        .sort();
      return NextResponse.json({
        models: models.length ? models : preset.models,
        source: models.length ? "provider" : "preset",
      });
    }

    const res = await fetch(`${baseURL}${preset.modelsPath ?? "/models"}`, {
      headers: {
        Authorization: `Bearer ${secret || "not-required"}`,
        "User-Agent": "Nova/1.0",
      },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) {
      return NextResponse.json({ models: preset.models, source: "preset" });
    }
    const payload = (await res.json().catch(() => null)) as { data?: { id?: string }[] } | null;
    const models = (payload?.data ?? [])
      .map((m) => m.id)
      .filter((id): id is string => Boolean(id))
      .sort();
    return NextResponse.json({
      models: models.length ? models : preset.models,
      source: models.length ? "provider" : "preset",
    });
  } catch {
    return NextResponse.json({ models: preset.models, source: "preset" });
  }
});
