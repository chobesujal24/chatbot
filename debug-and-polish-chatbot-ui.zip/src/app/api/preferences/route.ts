import { db } from "@/db";
import { workspacePreferences } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, route } from "@/lib/http";
import { getPreferences, savePreferences } from "@/lib/preferences";
import { preferencesSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  return NextResponse.json({ preferences: await getPreferences(ws) }, { headers: noStore });
});

/** Full or partial update. Values are normalised and clamped server-side. */
export const PUT = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const values = await parseBody(request, preferencesSchema);
  const preferences = await savePreferences(ws, values);
  return NextResponse.json({ preferences });
});

/** Removes every stored preference, returning the workspace to defaults. */
export const DELETE = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  await db.delete(workspacePreferences).where(eq(workspacePreferences.workspaceId, ws));
  return NextResponse.json({ ok: true });
});
