import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, route, parseQuery } from "@/lib/http";
import { searchQuerySchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const { q, limit } = parseQuery(request, searchQuerySchema);
  // Escape LIKE wildcards and use an explicit ESCAPE clause.
  const pattern = `%${q.replace(/[\\%_]/g, (m) => `\\${m}`)}%`;
  const match = sql`(${messages.content} ilike ${pattern} escape '\\' or ${conversations.title} ilike ${pattern} escape '\\')`;
  const rows = await db
    .select({
      messageId: messages.id,
      conversationId: messages.conversationId,
      role: messages.role,
      content: messages.content,
      createdAt: messages.createdAt,
      conversationTitle: conversations.title,
    })
    .from(messages)
    .innerJoin(conversations, eq(messages.conversationId, conversations.id))
    .where(and(eq(messages.workspaceId, ws), match))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  return NextResponse.json(
    {
      results: rows.map((r) => ({
        messageId: r.messageId,
        conversationId: r.conversationId,
        conversationTitle: r.conversationTitle,
        role: r.role,
        snippet: r.content.slice(0, 220),
        createdAt: r.createdAt.toISOString(),
      })),
    },
    { headers: noStore },
  );
});

