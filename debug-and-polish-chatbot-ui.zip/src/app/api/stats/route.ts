import { db } from "@/db";
import { agents, conversations, memories, messages, tasks } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, route } from "@/lib/http";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const count = async (table: typeof conversations | typeof messages | typeof agents | typeof memories) => {
    const [row] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(table)
      .where(eq(table.workspaceId, ws));
    return row.n;
  };
  const [convs, msgs, ags, mems, openTasks, doneTasks] = await Promise.all([
    count(conversations),
    count(messages),
    count(agents),
    count(memories),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(tasks)
      .where(sql`${tasks.workspaceId} = ${ws} and ${tasks.status} = 'open'`),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(tasks)
      .where(sql`${tasks.workspaceId} = ${ws} and ${tasks.status} = 'done'`),
  ]);
  const byModel = await db
    .select({
      model: messages.model,
      count: sql<number>`count(*)::int`,
      tokens: sql<number>`coalesce(sum((usage->>'totalTokens')::int), 0)::int`,
    })
    .from(messages)
    .where(sql`${messages.workspaceId} = ${ws} and ${messages.role} = 'assistant'`)
    .groupBy(messages.model);
  const toolRows = await db
    .select({ toolCalls: messages.toolCalls })
    .from(messages)
    .where(sql`${messages.workspaceId} = ${ws} and tool_calls is not null`);
  const toolCounts: Record<string, number> = {};
  for (const row of toolRows) {
    for (const call of row.toolCalls ?? []) {
      toolCounts[call.name] = (toolCounts[call.name] ?? 0) + 1;
    }
  }
  return NextResponse.json(
    {
      conversations: convs,
      messages: msgs,
      agents: ags,
      memories: mems,
      tasksOpen: openTasks[0].n,
      tasksDone: doneTasks[0].n,
      byModel: byModel.map((r) => ({ model: r.model ?? "unknown", count: r.count, tokens: r.tokens })),
      toolCounts,
    },
    { headers: noStore },
  );
});
