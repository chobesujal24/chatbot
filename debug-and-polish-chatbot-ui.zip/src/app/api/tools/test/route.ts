import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { buildTools } from "@/lib/tools";
import { getPreferences } from "@/lib/preferences";
import { seedSkills } from "@/lib/skills";
import { toolTestSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

/**
 * Interactive tool sandbox endpoint used by Settings → Tools.
 * Runs a single tool against the caller's live workspace configuration.
 */
export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "tool-test", limit: 30, windowMs: 60_000 },
  });
  const { tool, input } = await parseBody(request, toolTestSchema);
  const prefs = await getPreferences(ws);

  if (tool === "loadSkill") {
    await seedSkills(ws);
  }

  const tools = buildTools([tool], ws, {
    searchResults: prefs.searchResults,
    fetchMaxKb: prefs.fetchMaxKb,
    fetchTimeoutSec: prefs.fetchTimeoutSec,
    readerMode: prefs.readerMode,
    maxSkillsPerTurn: prefs.maxSkillsPerTurn,
    memoryDedupe: prefs.memoryDedupe,
    memoryMaxItems: prefs.memoryMaxItems,
  });

  const target = tools[tool];
  if (!target?.execute) {
    return NextResponse.json(
      { ok: false, error: `Tool "${tool}" is not available.` },
      { status: 400 },
    );
  }

  const trimmed = input.trim();
  let args: Record<string, unknown> = {};
  switch (tool) {
    case "calculator":
      args = { expression: trimmed || "(128 + 46) * 3" };
      break;
    case "currentTime":
      args = {};
      break;
    case "webSearch":
      args = { query: trimmed || "Next.js App Router" };
      break;
    case "webFetch":
    case "fetchUrl":
      args = { url: trimmed || "https://example.com" };
      break;
    case "searchHistory":
    case "recall":
      args = { query: trimmed || "preference" };
      break;
    case "listTasks":
      args = {
        status: trimmed === "open" || trimmed === "done" || trimmed === "all" ? trimmed : "all",
      };
      break;
    case "loadSkill":
      args = { name: trimmed || "research-brief" };
      break;
  }

  const started = Date.now();
  try {
    const output = await target.execute(args as never, {
      toolCallId: "sandbox",
      messages: [],
      abortSignal: request.signal,
      context: undefined,
    });
    const hasToolError =
      output != null &&
      typeof output === "object" &&
      "error" in (output as Record<string, unknown>) &&
      Boolean((output as Record<string, unknown>).error);
    return NextResponse.json({
      ok: !hasToolError,
      tool,
      args,
      latencyMs: Date.now() - started,
      output,
    });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      tool,
      args,
      latencyMs: Date.now() - started,
      output: { error: error instanceof Error ? error.message : "Tool execution failed." },
    });
  }
});
