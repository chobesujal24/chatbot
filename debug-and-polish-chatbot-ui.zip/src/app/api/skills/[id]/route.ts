import { db } from "@/db";
import { skills } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { ApiError, guard, isUuid, parseBody, route } from "@/lib/http";
import { skillPatchSchema } from "@/lib/validation";
import { toSkill } from "@/lib/skills";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

async function owned(ws: string, id: string) {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Skill not found.");
  const [row] = await db
    .select({ id: skills.id })
    .from(skills)
    .where(and(eq(skills.id, id), eq(skills.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Skill not found.");
  return row;
}

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await owned(ws, id);
  const body = await parseBody(request, skillPatchSchema);
  const [row] = await db
    .update(skills)
    .set({ ...body, updatedAt: new Date() })
    .where(eq(skills.id, id))
    .returning();
  return NextResponse.json({ skill: toSkill(row) });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await owned(ws, id);
  await db.delete(skills).where(eq(skills.id, id));
  return NextResponse.json({ ok: true });
});
