import { db } from "@/db";
import { skills } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { skillImportSchema } from "@/lib/validation";
import { parseSkillMarkdown, slugifySkillName, toSkill } from "@/lib/skills";

export const dynamic = "force-dynamic";

/**
 * Imports a SKILL.md file in the Agent Skills format: YAML frontmatter with
 * `name` and `description`, body as the instructions.
 */
export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const { markdown, overwrite } = await parseBody(request, skillImportSchema);
  const parsed = parseSkillMarkdown(markdown);
  const name = slugifySkillName(parsed.name);

  const [existing] = await db
    .select({ id: skills.id })
    .from(skills)
    .where(and(eq(skills.workspaceId, ws), eq(skills.name, name)))
    .limit(1);

  if (existing && !overwrite) {
    return NextResponse.json(
      {
        error: {
          code: "skill_exists",
          message: `A skill named "${name}" already exists. Import again with overwrite to replace it.`,
        },
        skillName: name,
      },
      { status: 409 },
    );
  }

  const values = {
    workspaceId: ws,
    name,
    description: parsed.description,
    instructions: parsed.instructions,
    tools: parsed.tools,
    emoji: parsed.emoji,
    source: "imported",
    enabled: true,
    updatedAt: new Date(),
  };

  const [row] = existing
    ? await db.update(skills).set(values).where(eq(skills.id, existing.id)).returning()
    : await db.insert(skills).values(values).returning();

  return NextResponse.json({ skill: toSkill(row), replaced: Boolean(existing) });
});
