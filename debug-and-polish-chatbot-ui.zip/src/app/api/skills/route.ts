import { db } from "@/db";
import { skills } from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, requireUuidParam, route } from "@/lib/http";
import { skillCreateSchema } from "@/lib/validation";
import { slugifySkillName, toSkill } from "@/lib/skills";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const rows = await db
    .select()
    .from(skills)
    .where(eq(skills.workspaceId, ws))
    .orderBy(asc(skills.name));
  return NextResponse.json({ skills: rows.map(toSkill) });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, skillCreateSchema);
  const name = slugifySkillName(body.name);
  const [row] = await db
    .insert(skills)
    .values({
      workspaceId: ws,
      name,
      description: body.description,
      instructions: body.instructions,
      tools: body.tools ?? null,
      emoji: body.emoji || "✦",
      enabled: body.enabled,
      source: "custom",
    })
    .onConflictDoUpdate({
      target: [skills.workspaceId, skills.name],
      set: {
        description: body.description,
        instructions: body.instructions,
        tools: body.tools ?? null,
        emoji: body.emoji || "✦",
        enabled: body.enabled,
        updatedAt: new Date(),
      },
    })
    .returning();
  return NextResponse.json({ skill: toSkill(row) });
});

export async function DELETE(request: Request) {
  try {
    const { workspaceId: ws } = await guard(request);
    const url = new URL(request.url);
    const id = requireUuidParam(url.searchParams.get("id"));
    if (!id) {
      return NextResponse.json({ error: { code: "missing_id", message: "id is required." } }, { status: 400 });
    }
    const deleted = await db
      .delete(skills)
      .where(and(eq(skills.id, id), eq(skills.workspaceId, ws)))
      .returning({ id: skills.id });
    if (deleted.length === 0) {
      return NextResponse.json({ error: { code: "not_found", message: "Skill not found." } }, { status: 404 });
    }
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: { code: "internal_error", message: "Failed" } }, { status: 500 });
  }
}
