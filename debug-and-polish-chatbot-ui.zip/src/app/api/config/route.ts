import { NextResponse } from "next/server";
import { guard, noStore, route } from "@/lib/http";
import { hasServerKey } from "@/lib/model-server";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  await guard(request, { public: true });
  const serverKeys = {
    openai: hasServerKey("openai"),
    anthropic: hasServerKey("anthropic"),
    google: hasServerKey("google"),
  };
  const suggestedProvider = serverKeys.openai
    ? "openai"
    : serverKeys.anthropic
      ? "anthropic"
      : serverKeys.google
        ? "google"
        : "offline";
  return NextResponse.json({ serverKeys, suggestedProvider }, { headers: noStore });
});
