import { db } from "@/db";
import { tasks } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, route } from "@/lib/http";
import { toTask } from "@/lib/data";
import { taskSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const rows = await db
    .select()
    .from(tasks)
    .where(eq(tasks.workspaceId, ws))
    .orderBy(desc(tasks.createdAt))
    .limit(200);
  return NextResponse.json({ tasks: rows.map(toTask) }, { headers: noStore });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, taskSchema);
  const [row] = await db
    .insert(tasks)
    .values({ workspaceId: ws, title: body.title })
    .returning();
  return NextResponse.json({ task: toTask(row) });
});
