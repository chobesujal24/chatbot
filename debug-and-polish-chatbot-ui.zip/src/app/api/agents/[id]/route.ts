import { db } from "@/db";
import { agents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, parseBody, route } from "@/lib/http";
import { ownedAgent, toAgent } from "@/lib/data";
import { agentPatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export const PATCH = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  await ownedAgent(ws, id);
  const body = await parseBody(request, agentPatchSchema);
  const patch: Partial<typeof agents.$inferInsert> = {};
  if (body.name !== undefined) patch.name = body.name;
  if (body.description !== undefined) patch.description = body.description;
  if (body.systemPrompt !== undefined) patch.systemPrompt = body.systemPrompt;
  if (body.model !== undefined) patch.model = body.model?.trim() || null;
  if (body.temperature !== undefined) patch.temperature = body.temperature;
  if (body.maxSteps !== undefined) patch.maxSteps = body.maxSteps;
  if (body.tools !== undefined) patch.tools = body.tools;
  if (body.icon !== undefined) patch.icon = body.icon;
  if (body.isDefault === true) {
    await db
      .update(agents)
      .set({ isDefault: false })
      .where(eq(agents.workspaceId, ws));
    patch.isDefault = true;
  }
  const [row] = await db
    .update(agents)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(agents.id, id))
    .returning();
  return NextResponse.json({ agent: toAgent(row) });
});

export const DELETE = route<Params>(async (request, { params }) => {
  const { id } = await params;
  const { workspaceId: ws } = await guard(request);
  const agent = await ownedAgent(ws, id);
  await db.delete(agents).where(eq(agents.id, id));
  if (agent.isDefault) {
    const [first] = await db.select().from(agents).where(eq(agents.workspaceId, ws)).limit(1);
    if (first) {
      await db.update(agents).set({ isDefault: true }).where(eq(agents.id, first.id));
    }
  }
  return NextResponse.json({ ok: true });
});
