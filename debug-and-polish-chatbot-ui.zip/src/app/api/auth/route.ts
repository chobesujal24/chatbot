import { NextResponse } from "next/server";
import { ApiError, guard, parseBody, route } from "@/lib/http";
import { createSession, passwordRequired, verifyPassword } from "@/lib/workspace";
import { authSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const POST = route(async (request) => {
  await guard(request, {
    public: true,
    rateLimit: { bucket: "auth", limit: 10, windowMs: 60_000 },
  });
  if (!passwordRequired()) {
    return NextResponse.json({ ok: true, required: false });
  }
  const { password } = await parseBody(request, authSchema);
  if (!(await verifyPassword(password))) {
    throw new ApiError(401, "invalid_password", "Incorrect passcode.");
  }
  await createSession();
  return NextResponse.json({ ok: true, required: true });
});
