import { db } from "@/db";
import { promptTemplates } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, route } from "@/lib/http";
import { ownedTemplate } from "@/lib/data";

export const dynamic = "force-dynamic";

export const DELETE = route<{ params: Promise<{ id: string }> }>(
  async (request, { params }) => {
    const { id } = await params;
    const { workspaceId: ws } = await guard(request);
    await ownedTemplate(ws, id);
    await db.delete(promptTemplates).where(eq(promptTemplates.id, id));
    return NextResponse.json({ ok: true });
  },
);
