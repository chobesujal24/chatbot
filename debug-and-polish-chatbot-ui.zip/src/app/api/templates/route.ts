import { db } from "@/db";
import { promptTemplates } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { guard, noStore, parseBody, route } from "@/lib/http";
import { toTemplate } from "@/lib/data";
import { templateSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const rows = await db
    .select()
    .from(promptTemplates)
    .where(eq(promptTemplates.workspaceId, ws))
    .orderBy(asc(promptTemplates.name))
    .limit(200);
  return NextResponse.json({ templates: rows.map(toTemplate) }, { headers: noStore });
});

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request);
  const body = await parseBody(request, templateSchema);
  const [row] = await db
    .insert(promptTemplates)
    .values({ workspaceId: ws, name: body.name, content: body.content })
    .returning();
  return NextResponse.json({ template: toTemplate(row) });
});
