"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Check, ExternalLink, KeyRound, Loader2, Sparkles, Zap } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "./logo";
import { PROVIDERS, type ProviderPreset } from "@/lib/providers";
import { cn } from "@/lib/utils";

const TINT: Record<string, string> = {
  openai: "#10a37f",
  anthropic: "#d4a27f",
  google: "#4285f4",
  perplexity: "#20808d",
  ollama: "#6b7280",
  lmstudio: "#6c5ce7",
  vllm: "#e17055",
  openrouter: "#7c6cf0",
  deepseek: "#4d6bfe",
  groq: "#f55036",
  together: "#00c2a8",
  xai: "#1f2937",
  mistral: "#fa5300",
  fireworks: "#e8447a",
  cerebras: "#0f6fff",
  siliconflow: "#7a5af8",
  huggingface: "#d99b00",
  custom: "#64748b",
};

const mark = (label: string) => label.replace(/[^A-Za-z]/g, "").slice(0, 1).toUpperCase() || "•";

type Step = "provider" | "key" | "done";

export default function Onboarding({
  open,
  onOpenChange,
  onFinish,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFinish: () => void;
}) {
  const modelProviders = PROVIDERS.filter((p) => p.credentialKind === "model");
  const [step, setStep] = useState<Step>("provider");
  const [provider, setProvider] = useState<ProviderPreset>(modelProviders[0]);
  const [key, setKey] = useState("");
  const [baseURL, setBaseURL] = useState(modelProviders[0].baseURL);
  const [model, setModel] = useState(modelProviders[0].models[0] ?? "");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testState, setTestState] = useState<{ ok: boolean; message: string } | null>(null);

  useEffect(() => {
    if (open) {
      setStep("provider");
      setTestState(null);
    }
  }, [open]);

  useEffect(() => {
    setBaseURL(provider.baseURL);
    setModel(provider.models[0] ?? "");
    setKey("");
    setTestState(null);
  }, [provider]);

  const pickProvider = (p: ProviderPreset) => {
    setProvider(p);
    setStep("key");
  };

  const canConnect = provider.requiresKey
    ? Boolean(key.trim())
    : Boolean(baseURL.trim() || provider.baseURL);

  const save = async () => {
    if (!canConnect) {
      toast.error(provider.requiresKey ? "Paste an API key first" : "Enter a base URL first");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: provider.id,
          kind: provider.credentialKind,
          label: provider.label,
          secret: key.trim() || undefined,
          baseURL: baseURL.trim() || null,
          enabled: true,
          isActive: true,
        }),
      });
      if (!res.ok) throw new Error("Could not save.");
      await fetch("/api/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          defaultModel: model.trim() || provider.models[0] || "",
          defaultProvider: provider.id,
          welcomeDismissed: true,
        }),
      });
      toast.success(`${provider.label} connected`);
      setStep("done");
    } catch {
      toast.error("Could not save the provider");
    } finally {
      setSaving(false);
    }
  };

  const test = async () => {
    setTesting(true);
    setTestState(null);
    try {
      const res = await fetch("/api/credentials/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: provider.id,
          secret: key.trim() || undefined,
          baseURL: baseURL.trim() || undefined,
        }),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; latencyMs?: number }
        | null;
      setTestState({
        ok: Boolean(data?.ok),
        message: `${data?.message ?? (data?.ok ? "Connected." : "Could not connect.")}${
          data?.latencyMs !== undefined ? ` (${data.latencyMs} ms)` : ""
        }`,
      });
    } catch (error) {
      setTestState({
        ok: false,
        message: error instanceof Error ? error.message : "Could not connect.",
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-[580px]">
        {step === "provider" && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2.5">
                <Logo size={28} glow />
                <div>
                  <DialogTitle className="text-[17px]">Connect a model provider</DialogTitle>
                  <DialogDescription className="mt-0.5 text-[12.5px]">
                    Keys are encrypted with AES-256-GCM at rest and never exposed to client scripts.
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="scroll-slim mt-2 grid max-h-[54vh] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
              {modelProviders.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => pickProvider(p)}
                  className="group flex items-center gap-3 rounded-xl border border-border/80 bg-card px-3 py-2.5 text-left transition hover:border-foreground/25 hover:bg-accent/50"
                >
                  <span
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg text-[12px] font-bold text-white shadow-2xs"
                    style={{ background: TINT[p.id] ?? "var(--muted-foreground)" }}
                  >
                    {mark(p.label)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-medium text-foreground">
                      {p.label}
                    </span>
                    <span className="block truncate text-[11px] text-muted-foreground">
                      {p.group === "local" ? "Local runtime · no key needed" : p.notes}
                    </span>
                  </span>
                  <ArrowRight
                    size={14}
                    className="shrink-0 text-muted-foreground/50 transition-transform group-hover:translate-x-0.5 group-hover:text-foreground"
                  />
                </button>
              ))}
            </div>

            <div className="mt-2 flex items-center justify-between border-t pt-3 text-[12px] text-muted-foreground">
              <span>Search & web readers live in Settings → Integrations.</span>
              <Link
                href="/settings#providers"
                onClick={() => onOpenChange(false)}
                className="font-medium text-brand hover:underline"
              >
                Full settings →
              </Link>
            </div>
          </>
        )}

        {step === "key" && (
          <>
            <DialogHeader>
              <div className="flex items-center justify-between gap-3 pr-6">
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setStep("provider")}
                    aria-label="Back to providers"
                    className="flex size-8 items-center justify-center rounded-lg border bg-card text-muted-foreground transition hover:text-foreground"
                  >
                    <ArrowLeft size={14} />
                  </button>
                  <span
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg text-[12px] font-bold text-white shadow-2xs"
                    style={{ background: TINT[provider.id] ?? "var(--muted-foreground)" }}
                  >
                    {mark(provider.label)}
                  </span>
                  <div>
                    <DialogTitle className="text-[16px]">{provider.label}</DialogTitle>
                    <DialogDescription className="text-[12px]">{provider.notes}</DialogDescription>
                  </div>
                </div>
                <a
                  href={provider.docs}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1 text-[11.5px] font-medium text-muted-foreground hover:text-foreground"
                >
                  {provider.requiresKey ? "Get key" : "Docs"} <ExternalLink size={11} />
                </a>
              </div>
            </DialogHeader>

            <div className="mt-2 space-y-4">
              <div>
                <label className="mb-1.5 block text-[12.5px] font-medium" htmlFor="onboard-key">
                  {provider.requiresKey ? "API key" : "API key (optional)"}
                </label>
                <Input
                  id="onboard-key"
                  type="password"
                  autoFocus={provider.requiresKey}
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder={provider.keyPlaceholder}
                  autoComplete="off"
                  className="font-mono text-[13px]"
                />
                <p className="mt-1.5 flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
                  <KeyRound size={11} /> Encrypted with AES-256-GCM. Never sent back to the browser.
                </p>
              </div>

              {(provider.kind === "openai-compatible" || provider.id === "custom") && (
                <div>
                  <label className="mb-1.5 block text-[12.5px] font-medium" htmlFor="onboard-url">
                    Base URL
                  </label>
                  <Input
                    id="onboard-url"
                    value={baseURL}
                    onChange={(e) => setBaseURL(e.target.value)}
                    placeholder={provider.baseURL || "http://localhost:11434/v1"}
                    className="font-mono text-[13px]"
                  />
                </div>
              )}

              <div>
                <label className="mb-1.5 block text-[12.5px] font-medium" htmlFor="onboard-model">
                  Default model ID
                </label>
                <Input
                  id="onboard-model"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder={provider.models[0] || "e.g. llama3.2 or gpt-4o-mini"}
                  className="font-mono text-[13px]"
                />
                {provider.models.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {provider.models.slice(0, 6).map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setModel(m)}
                        className={cn(
                          "rounded-md border px-2 py-0.5 font-mono text-[11px] transition",
                          model === m
                            ? "border-foreground bg-foreground text-background"
                            : "bg-card text-muted-foreground hover:text-foreground",
                        )}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {testState && (
                <div
                  className={cn(
                    "flex items-start gap-2 rounded-xl border px-3 py-2 text-[12.5px]",
                    testState.ok
                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                      : "border-destructive/30 bg-destructive/10 text-destructive",
                  )}
                >
                  {testState.ok ? (
                    <Check size={14} className="mt-0.5 shrink-0" />
                  ) : (
                    <Zap size={14} className="mt-0.5 shrink-0" />
                  )}
                  <span>{testState.message}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2 border-t pt-3.5">
                <Button size="sm" onClick={() => void save()} disabled={saving || !canConnect}>
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                  Save & activate
                </Button>
                <Button size="sm" variant="outline" onClick={() => void test()} disabled={testing || !canConnect}>
                  {testing ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                  Test connection
                </Button>
                <Button size="sm" variant="ghost" className="ml-auto" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </>
        )}

        {step === "done" && (
          <div className="py-4 text-center">
            <DialogHeader className="items-center">
              <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <Check size={22} />
              </div>
              <DialogTitle className="mt-3 text-[19px]">Connected to {provider.label}</DialogTitle>
              <DialogDescription className="max-w-sm text-center text-[13px]">
                {provider.label} is now active{model ? ` with ${model}` : ""}. You are ready to start chatting.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-6 flex justify-center gap-2">
              <Button
                onClick={() => {
                  onOpenChange(false);
                  onFinish();
                }}
              >
                Start chatting <Sparkles size={14} />
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
