"use client";

import { useEffect, useRef, useState, type ChangeEvent, type KeyboardEvent } from "react";
import { toast } from "sonner";
import { ChevronDown, SlidersHorizontal, UploadCloud, X } from "lucide-react";
import { IconArrowUp, IconClose, IconPaperclip, IconStop } from "./icons";
import { AgentIcon } from "./agent-icon";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import type { Agent, ClientAttachment } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";

interface ComposerProps {
  variant: "hero" | "dock";
  onSend: (text: string, attachments: ClientAttachment[]) => void;
  isStreaming: boolean;
  onStop: () => void;
  agents: Agent[];
  selectedAgent: Agent | null;
  onSelectAgent: (id: string) => void;
  onOpenAgents: () => void;
  model: string;
  providerLabel: string;
  hasProvider: boolean;
  onOpenSettings: () => void;
  prefs: Preferences;
  prefill?: { text: string; nonce: number } | null;
  /** Scopes the autosaved draft (e.g. the active conversation id). */
  draftKey?: string | null;
  /** Attachments handed over from the code workspace; merged into the tray. */
  incomingAttachments?: ClientAttachment[] | null;
  onIncomingAttachmentsConsumed?: () => void;
}

const ALLOWED =
  /\.(txt|md|markdown|json|csv|log|js|jsx|ts|tsx|py|rs|go|java|css|html|yml|yaml|sql|xml|env|toml)$/i;

const DRAFT_KEY = "nova-draft";

const pillClass =
  "inline-flex h-8 items-center gap-1.5 rounded-full border border-border/75 bg-muted/45 px-2.5 text-[12px] font-medium text-muted-foreground outline-none transition hover:border-foreground/20 hover:bg-accent hover:text-foreground data-[state=open]:bg-accent data-[state=open]:text-foreground focus-visible:ring-2 focus-visible:ring-ring";

export default function Composer(props: ComposerProps) {
  const [text, setText] = useState("");
  const [attachments, setAttachments] = useState<ClientAttachment[]>([]);
  const [dragging, setDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const hero = props.variant === "hero";

  const resize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  };

  const draftStorageKey = `${DRAFT_KEY}:${props.draftKey ?? "new"}`;

  useEffect(() => {
    if (!props.prefs.autosaveDrafts) {
      setText("");
      return;
    }
    // Switching conversations swaps the draft instead of leaking text across chats.
    setText(window.localStorage.getItem(draftStorageKey) ?? "");
    requestAnimationFrame(() => resize());
  }, [props.prefs.autosaveDrafts, draftStorageKey]);

  useEffect(() => {
    if (!props.prefs.autosaveDrafts) return;
    const timer = setTimeout(() => {
      if (text.trim()) window.localStorage.setItem(draftStorageKey, text);
      else window.localStorage.removeItem(draftStorageKey);
    }, 400);
    return () => clearTimeout(timer);
  }, [text, props.prefs.autosaveDrafts, draftStorageKey]);

  useEffect(() => {
    if (hero) textareaRef.current?.focus();
  }, [hero]);

  useEffect(() => {
    if (!props.prefill?.text) return;
    setText(props.prefill.text);
    requestAnimationFrame(() => {
      resize();
      textareaRef.current?.focus();
    });
  }, [props.prefill?.nonce, props.prefill?.text]);

  // Files sent from the code workspace land in the attachment tray.
  useEffect(() => {
    const incoming = props.incomingAttachments;
    if (!incoming || incoming.length === 0) return;
    setAttachments((prev) => {
      const known = new Set(prev.map((f) => `${f.name}:${f.content.length}`));
      const fresh = incoming.filter((f) => !known.has(`${f.name}:${f.content.length}`));
      return [...prev, ...fresh].slice(0, 5);
    });
    props.onIncomingAttachmentsConsumed?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.incomingAttachments]);

  const canSend = (text.trim().length > 0 || attachments.length > 0) && !props.isStreaming;

  const submit = () => {
    const value = text.trim() || (attachments.length > 0 ? "Please review the attached file(s)." : "");
    if (!value || props.isStreaming) return;
    props.onSend(value, attachments);
    setText("");
    setAttachments([]);
    window.localStorage.removeItem(draftStorageKey);
    requestAnimationFrame(() => {
      if (textareaRef.current) textareaRef.current.style.height = "auto";
      textareaRef.current?.focus();
    });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key !== "Enter" || event.shiftKey || event.nativeEvent.isComposing) return;
    const modifier = event.metaKey || event.ctrlKey;
    if (props.prefs.sendOnEnter ? !modifier : modifier) {
      event.preventDefault();
      submit();
    }
  };

  const ingestFiles = async (files: File[]) => {
    const limitKb = props.prefs.attachmentLimitKb || 60;
    const next: ClientAttachment[] = [];
    for (const file of files) {
      if (!ALLOWED.test(file.name)) {
        toast.error(`${file.name}: text-based files only`);
        continue;
      }
      if (file.size > limitKb * 1024) {
        toast.error(`${file.name}: exceeds ${limitKb} KB limit`);
        continue;
      }
      next.push({ name: file.name, content: await file.text() });
    }
    if (next.length > 0) setAttachments((prev) => [...prev, ...next].slice(0, 5));
  };

  const onFiles = async (event: ChangeEvent<HTMLInputElement>) => {
    await ingestFiles(Array.from(event.target.files ?? []));
    event.target.value = "";
  };

  const approxTokens = Math.ceil(text.length / 4);

  const card = (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragging(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void ingestFiles(Array.from(e.dataTransfer.files ?? []));
      }}
      className={cn(
        "relative rounded-3xl border border-border/85 bg-card transition-all duration-200",
        "ring-1 ring-inset ring-white/50 dark:ring-white/[0.04]",
        hero ? "shadow-md" : "shadow-sm",
        "focus-within:border-foreground/25 focus-within:shadow-lg focus-within:ring-brand/15",
        dragging && "border-dashed border-brand bg-brand/5 ring-2 ring-brand/25",
      )}
    >
      {dragging && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-1.5 rounded-3xl bg-card/92 p-4 text-brand backdrop-blur-xs">
          <UploadCloud size={24} />
          <p className="text-[13px] font-semibold">Drop text or code files to attach</p>
          <p className="text-[11px] text-muted-foreground">
            Up to 5 files · max {props.prefs.attachmentLimitKb || 60} KB each
          </p>
        </div>
      )}

      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-4 pt-3.5">
          {attachments.map((a, index) => (
            <span
              key={`${a.name}-${index}`}
              className="inline-flex items-center gap-1.5 rounded-lg border bg-muted/55 py-1 pl-2.5 pr-1.5 text-[12px]"
            >
              <IconPaperclip size={12} className="text-muted-foreground" />
              <span className="max-w-[160px] truncate font-mono">{a.name}</span>
              <span className="text-[10.5px] text-muted-foreground">
                {Math.max(0.1, Math.round((a.content.length / 1024) * 10) / 10)}KB
              </span>
              <button
                type="button"
                aria-label={`Remove ${a.name}`}
                onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== index))}
                className="rounded p-0.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <IconClose size={12} />
              </button>
            </span>
          ))}
        </div>
      )}

      <textarea
        ref={textareaRef}
        rows={1}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          resize();
        }}
        onKeyDown={onKeyDown}
        aria-label="Message prompt"
        placeholder={hero ? "Message Nova, run a tool, or drop code files…" : "Reply to Nova…"}
        className={cn(
          "scroll-slim block w-full resize-none bg-transparent px-4 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground/65 sm:px-5",
          hero ? "max-h-[220px] min-h-[68px] pb-1.5 pt-4" : "max-h-[220px] min-h-[54px] pb-1 pt-3.5",
        )}
      />

      <div className="flex items-center justify-between gap-2 px-3 pb-2.5 pt-1">
        <div className="flex min-w-0 flex-wrap items-center gap-1.5">
          <input
            ref={fileRef}
            type="file"
            multiple
            accept=".txt,.md,.json,.csv,.log,.js,.ts,.tsx,.py,.rs,.go,.css,.html,.yml,.yaml,.sql,.env,.toml"
            onChange={onFiles}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            aria-label="Attach file"
            title="Attach text or code files"
            className="flex size-8 shrink-0 items-center justify-center rounded-full text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground active:scale-95 focus-visible:ring-2 focus-visible:ring-ring"
          >
            <IconPaperclip size={15} />
          </button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className={pillClass} aria-label="Choose agent">
                {props.selectedAgent && <AgentIcon icon={props.selectedAgent.icon} size={13} />}
                <span className="max-w-[110px] truncate">
                  {props.selectedAgent?.name ?? "Agent"}
                </span>
                <ChevronDown size={11} className="opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" side={hero ? "bottom" : "top"} className="w-72 p-1.5">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Agent persona</DropdownMenuLabel>
              {props.agents.map((agent) => (
                <DropdownMenuItem
                  key={agent.id}
                  onSelect={() => props.onSelectAgent(agent.id)}
                  className="items-start gap-2.5 rounded-lg p-2"
                >
                  <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-md bg-secondary">
                    <AgentIcon icon={agent.icon} size={13} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5 text-[13px] font-medium">
                      {agent.name}
                      {agent.id === props.selectedAgent?.id && (
                        <span className="text-[10px] text-brand">✓</span>
                      )}
                    </span>
                    <span className="line-clamp-2 block text-[11.5px] leading-snug text-muted-foreground">
                      {agent.description || "General-purpose conversation"}
                    </span>
                  </span>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={props.onOpenAgents} className="rounded-lg text-[12.5px]">
                Manage agents…
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <button
            type="button"
            onClick={props.onOpenSettings}
            className={cn(pillClass, "max-w-[175px]")}
            aria-label="Model and generation tuning"
            title="Switch model or tune parameters"
          >
            <SlidersHorizontal size={12} className="shrink-0 opacity-75" />
            <span className="truncate font-mono text-[11.5px]">
              {props.hasProvider ? props.model : "Model tuning"}
            </span>
          </button>

          {text.length > 24 && (
            <span className="hidden font-mono text-[10.5px] text-muted-foreground/75 sm:inline">
              ~{approxTokens} tok
            </span>
          )}

          {text.length > 80 && (
            <button
              type="button"
              onClick={() => {
                setText("");
                window.localStorage.removeItem(draftStorageKey);
              }}
              className="hidden rounded p-1 text-muted-foreground hover:text-foreground sm:inline"
              title="Clear draft"
              aria-label="Clear draft"
            >
              <X size={12} />
            </button>
          )}
        </div>

        {props.isStreaming ? (
          <button
            type="button"
            onClick={props.onStop}
            aria-label="Stop generation"
            title="Stop generation (Esc)"
            className="flex size-9 shrink-0 items-center justify-center rounded-full bg-foreground text-background outline-none transition hover:opacity-85 active:scale-95 focus-visible:ring-2 focus-visible:ring-ring"
          >
            <IconStop size={13} />
          </button>
        ) : (
          <button
            type="button"
            onClick={submit}
            disabled={!canSend}
            aria-label="Send message"
            title={props.prefs.sendOnEnter ? "Send (Enter)" : "Send (⌘Enter)"}
            className={cn(
              "flex size-9 shrink-0 items-center justify-center rounded-full outline-none transition active:scale-95 focus-visible:ring-2 focus-visible:ring-ring",
              canSend
                ? "bg-foreground text-background shadow-xs hover:opacity-90"
                : "cursor-not-allowed bg-muted text-muted-foreground/40",
            )}
          >
            <IconArrowUp size={16} />
          </button>
        )}
      </div>
    </div>
  );

  if (hero) return card;

  return (
    <div className="relative shrink-0 px-4 pb-3.5 pt-2 sm:px-6">
      <div className="composer-fade pointer-events-none absolute -top-14 left-0 right-0 h-14" />
      <div className="relative mx-auto w-full max-w-[768px]">
        {card}
        <p className="mt-1.5 text-center text-[11px] text-muted-foreground/80">
          {props.hasProvider
            ? `${props.providerLabel} · ${props.model} — verify important details.`
            : "Connect an API key or local runtime in Settings to generate responses."}
        </p>
      </div>
    </div>
  );
}
