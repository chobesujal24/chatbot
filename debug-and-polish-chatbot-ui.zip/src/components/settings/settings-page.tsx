"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import {
  Archive,
  ArrowLeft,
  BarChart3,
  Bot,
  Brain,
  Check,
  Cpu,
  Gauge,
  Keyboard,
  Layers,
  Loader2,
  MessageSquare,
  Palette,
  Plug,
  Save,
  Search,
  Sliders,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/logo";
import { ActivePill, Panel, SectionIntro } from "./ui";
import SettingsProviders, { type CredentialRow } from "./settings-providers";
import SettingsAgents from "./settings-agents";
import {
  AdvancedSection,
  ComposerSection,
  ContextSection,
  ResponseSection,
  ToolsSection,
} from "./sections-behavior";
import { MemorySection, SkillsSection, WebSection } from "./sections-capabilities";
import AppearanceSection from "./settings-appearance";
import { DataSection, UsageSection, type UsageStats } from "./sections-account";
import {
  DEFAULT_PREFERENCES,
  diffPreferences,
  normalizePreferences,
  type Preferences,
} from "@/lib/preferences-model";
import { applyPreferences } from "@/lib/preferences-client";
import { findProvider } from "@/lib/providers";
import { cn } from "@/lib/utils";
import type { Agent, MemoryStats, Skill } from "@/lib/types";

const EASE = [0.22, 1, 0.3, 1] as const;

interface SectionDef {
  id: string;
  label: string;
  icon: typeof Sparkles;
  group: string;
  blurb: string;
  keywords: string;
}

const SECTIONS: SectionDef[] = [
  { id: "usage", label: "Usage", icon: BarChart3, group: "Overview", blurb: "Workspace activity, token consumption by model and tool call metrics.", keywords: "tokens cost activity stats counters usage analytics replies" },
  { id: "providers", label: "Providers", icon: Plug, group: "Connections", blurb: "Connect OpenAI, Anthropic, Gemini, OpenRouter, Groq, Ollama or any compatible endpoint.", keywords: "api key base url openai anthropic gemini local ollama lmstudio vllm openrouter groq deepseek endpoint model" },
  { id: "integrations", label: "Integrations", icon: Sparkles, group: "Connections", blurb: "Live web search and clean Markdown page readers for your agents.", keywords: "firecrawl tavily brave exa serper serpapi jina search reader fetch web" },
  { id: "agents", label: "Agents", icon: Bot, group: "Capabilities", blurb: "Reusable personas bundling a system prompt, model override, tools and loop budget.", keywords: "agent persona bot researcher coder analyst default tools steps system prompt" },
  { id: "skills", label: "Skills", icon: Cpu, group: "Capabilities", blurb: "On-demand workflow instruction packs in the Agent Skills (SKILL.md) format.", keywords: "skill md instructions pack workflow progressive disclosure import export" },
  { id: "memory", label: "Memory", icon: Brain, group: "Capabilities", blurb: "Scoped long-term facts, preferences and corrections remembered across chats.", keywords: "remember recall forget fact preference extraction decay half life injection pin" },
  { id: "context", label: "Context", icon: Layers, group: "Capabilities", blurb: "Token window budget, history depth and automatic rolling compaction.", keywords: "tokens window budget compaction history summarise trim meter pairs" },
  { id: "tools", label: "Tools", icon: Gauge, group: "Capabilities", blurb: "Global tool switches, execution limits and an interactive live sandbox.", keywords: "tools calculator websearch webfetch readpage limits enable disable sandbox test" },
  { id: "generation", label: "Generation", icon: Sliders, group: "Behaviour", blurb: "Sampling presets, temperature, output token ceilings, stop sequences and system prompt.", keywords: "temperature top p penalty tokens retries stop system prompt stream reveal model" },
  { id: "composer", label: "Composer", icon: MessageSquare, group: "Behaviour", blurb: "Enter-to-send, draft autosave, attachment limits, completion chime and notifications.", keywords: "enter send draft attachment sound chime notification" },
  { id: "appearance", label: "Appearance", icon: Palette, group: "Behaviour", blurb: "Theme, brand accent, text size, density, code highlighting and live preview.", keywords: "theme dark light accent font size density animation motion code theme line numbers width sidebar" },
  { id: "data", label: "Data & privacy", icon: Archive, group: "System", blurb: "Full workspace JSON export, settings backup, shared link controls and purges.", keywords: "export import delete purge share link privacy redact reset gdpr" },
  { id: "advanced", label: "Advanced", icon: Wrench, group: "System", blurb: "Upstream request timeouts and custom HTTP gateway headers.", keywords: "timeout headers gateway openrouter referer advanced" },
  { id: "shortcuts", label: "Shortcuts", icon: Keyboard, group: "System", blurb: "Keyboard shortcuts for fast navigation without leaving the keyboard.", keywords: "keyboard shortcuts keys hotkeys command palette" },
];

const GROUP_ORDER = ["Overview", "Connections", "Capabilities", "Behaviour", "System"];

const SHORTCUT_GROUPS: Array<{ title: string; items: Array<[string, string]> }> = [
  {
    title: "Navigation",
    items: [
      ["⌘ / Ctrl + K", "Open command palette & global search"],
      ["⌘ / Ctrl + B", "Collapse or expand sidebar"],
      ["⌘ / Ctrl + ,", "Open full settings"],
      ["⌘ / Ctrl + /", "Show keyboard shortcuts"],
      ["/", "Focus settings search (on this page)"],
    ],
  },
  {
    title: "Chat & composer",
    items: [
      ["⌘ / Ctrl + N", "Start a new conversation"],
      ["Enter", "Send message (or newline when disabled)"],
      ["Shift + Enter", "Insert a new line"],
      ["⌘ / Ctrl + Enter", "Send message when Enter-to-send is off"],
      ["Esc", "Stop active generation or close dialog"],
    ],
  },
  {
    title: "Settings",
    items: [
      ["⌘ / Ctrl + S", "Save modified workspace preferences"],
    ],
  },
];

export default function SettingsPage() {
  const [section, setSection] = useState("providers");
  const [prefs, setPrefs] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [saved, setSaved] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [credentials, setCredentials] = useState<CredentialRow[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [memoryStats, setMemoryStats] = useState<MemoryStats | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [stats, setStats] = useState<UsageStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState("");
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [shareCount, setShareCount] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  /* ── Deep links: hash is the source of truth ───────────────────────────── */
  useEffect(() => {
    const read = () => {
      const hash = window.location.hash.replace(/^#\/?/, "");
      if (SECTIONS.some((s) => s.id === hash)) {
        setSection(hash);
      } else if (!hash) {
        setSection("usage");
      }
    };
    read();
    window.addEventListener("hashchange", read);
    return () => window.removeEventListener("hashchange", read);
  }, []);

  const go = useCallback((id: string) => {
    setSection(id);
    if (window.location.hash !== `#${id}`) {
      window.history.pushState(null, "", `#${id}`);
    }
    window.scrollTo({
      top: 0,
      behavior: document.documentElement.dataset.animations === "off" ? "auto" : "smooth",
    });
  }, []);

  /* ── Load ──────────────────────────────────────────────────────────────── */
  const json = async (path: string) => {
    try {
      const res = await fetch(path, { cache: "no-store" });
      return res.ok ? await res.json() : null;
    } catch {
      return null;
    }
  };

  /** Full load, including preferences. Used once on mount and after a reset. */
  const loadAll = useCallback(async () => {
    const boot = await json("/api/bootstrap");
    const [sk, mem, st] = await Promise.all([
      json("/api/skills"),
      json("/api/memories"),
      json("/api/stats"),
    ]);
    if (boot) {
      setWorkspaceId(boot.workspace?.id ?? null);
      setCredentials(boot.credentials ?? []);
      setAgents(boot.agents ?? []);
      setShareCount(boot.shareCount ?? 0);
      const next = normalizePreferences(boot.preferences ?? {});
      setPrefs(next);
      setSaved(next);
    }
    setSkills(sk?.skills ?? boot?.skills ?? []);
    setMemoryStats(mem?.stats ?? boot?.memoryStats ?? null);
    setStats(st ?? null);
  }, []);

  /**
   * Reload of workspace data only. Preferences are deliberately untouched so
   * saving a provider (or a skill) never discards pending preference edits.
   */
  const refresh = useCallback(async () => {
    const [boot, sk, mem, st] = await Promise.all([
      json("/api/bootstrap"),
      json("/api/skills"),
      json("/api/memories"),
      json("/api/stats"),
    ]);
    if (boot) {
      setWorkspaceId(boot.workspace?.id ?? null);
      setCredentials(boot.credentials ?? []);
      setAgents(boot.agents ?? []);
      setShareCount(boot.shareCount ?? 0);
    }
    setSkills(sk?.skills ?? boot?.skills ?? []);
    setMemoryStats(mem?.stats ?? boot?.memoryStats ?? null);
    setStats(st ?? null);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        await loadAll();
      } catch {
        toast.error("Could not load settings.");
      } finally {
        setLoading(false);
      }
    })();
  }, [loadAll]);

  /* ── Editing ───────────────────────────────────────────────────────────── */
  const patch = useCallback((values: Partial<Preferences>) => {
    setPrefs((prev) => ({ ...prev, ...values }));
  }, []);

  useEffect(() => {
    applyPreferences(prefs);
  }, [prefs]);

  const changed = useMemo(() => Object.keys(diffPreferences(prefs, saved)).length, [prefs, saved]);
  const discard = useCallback(() => setPrefs(saved), [saved]);

  const save = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    try {
      const res = await fetch("/api/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(prefs),
      });
      if (!res.ok) throw new Error("save failed");
      const data = (await res.json().catch(() => null)) as { preferences?: Preferences } | null;
      const canonical = normalizePreferences(data?.preferences ?? prefs);
      setPrefs(canonical);
      setSaved(canonical);
      toast.success("Settings saved");
    } catch {
      toast.error("Could not save settings.");
    } finally {
      setSaving(false);
    }
  }, [prefs, saving]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        if (changed) void save();
        return;
      }
      const target = e.target as HTMLElement | null;
      const isField =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable);
      if (!isField && e.key === "/" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [changed, save]);

  useEffect(() => {
    if (!changed) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [changed]);

  /* ── Actions ──────────────────────────────────────────────────────────── */
  const download = (name: string, data: unknown) => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportAll = async () => {
    const data = await json("/api/data");
    if (!data) return toast.error("Could not export workspace data.");
    download("nova-workspace.json", data);
    toast.success("Workspace exported");
  };

  const importSettings = async (file: File) => {
    try {
      const raw = JSON.parse(await file.text()) as Record<string, unknown>;
      const source = (raw.preferences && typeof raw.preferences === "object" ? raw.preferences : raw) as Record<string, unknown>;
      const next = normalizePreferences(source);
      setPrefs(next);
      toast.success("Settings imported — review and click Save changes");
    } catch {
      toast.error("Invalid settings JSON file.");
    }
  };

  const resetPreferences = async () => {
    try {
      const res = await fetch("/api/preferences", { method: "DELETE" });
      if (!res.ok) throw new Error("reset failed");
      setPrefs(DEFAULT_PREFERENCES);
      setSaved(DEFAULT_PREFERENCES);
      toast.success("Preferences restored to defaults");
    } catch {
      toast.error("Could not reset preferences.");
    }
  };

  const purge = async (
    target: "conversations" | "memories" | "memories-unused" | "tasks" | "skills" | "templates" | "shares" | "all",
  ) => {
    try {
      const res = await fetch("/api/maintenance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target }),
      });
      const data = (await res.json().catch(() => null)) as {
        removed?: number;
        changed?: number;
        conversations?: number;
        message?: string;
      } | null;
      if (!res.ok) throw new Error(data?.message ?? "Action failed.");
      const n = data?.removed ?? data?.changed ?? data?.conversations ?? 0;
      toast.success(n ? `Completed — ${n} item${n === 1 ? "" : "s"} affected` : "Completed");
      await refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed.");
    }
  };

  const model = credentials.find((c) => c.kind === "model" && c.isActive && c.enabled);
  const search = credentials.find((c) => c.kind === "search" && c.isActive && c.enabled);
  const reader =
    credentials.find((c) => c.kind === "reader" && c.isActive && c.enabled) ??
    credentials.find((c) => c.provider === "firecrawl" && c.enabled && c.hasKey);
  const current = SECTIONS.find((s) => s.id === section) ?? SECTIONS[0];

  const q = query.trim().toLowerCase();
  const visible = useMemo(
    () =>
      SECTIONS.filter(
        (s) =>
          !q ||
          s.label.toLowerCase().includes(q) ||
          s.keywords.includes(q) ||
          s.blurb.toLowerCase().includes(q) ||
          s.group.toLowerCase().includes(q),
      ),
    [q],
  );

  const isConfigured = (c: CredentialRow) =>
    c.hasKey || findProvider(c.provider)?.requiresKey === false;
  const badges: Record<string, number> = {
    providers: credentials.filter((c) => c.kind === "model" && isConfigured(c)).length,
    integrations: credentials.filter((c) => c.kind !== "model" && isConfigured(c)).length,
    agents: agents.length,
    skills: skills.filter((s) => s.enabled).length,
    memory: memoryStats?.enabled ?? 0,
  };

  return (
    <MotionConfig reducedMotion={prefs.animations ? "user" : "always"}>
      <div className="min-h-dvh bg-background text-foreground">
        <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-xl">
          <div className="mx-auto flex h-14 max-w-[1200px] items-center gap-3 px-4 sm:px-6">
            <Link
              href="/"
              aria-label="Back to chat"
              className="inline-flex h-8 items-center gap-1.5 rounded-lg border bg-card px-2.5 text-[12.5px] font-medium text-muted-foreground transition hover:border-foreground/20 hover:text-foreground active:scale-95"
            >
              <ArrowLeft size={14} />
              <span className="hidden sm:inline">Chat</span>
            </Link>

            <div className="flex min-w-0 flex-1 items-center gap-2.5">
              <Logo size={24} />
              <div className="min-w-0">
                <p className="text-[14.5px] font-semibold leading-tight tracking-tight">Settings</p>
                <p className="truncate font-mono text-[10.5px] text-muted-foreground">
                  {workspaceId ? `workspace ${workspaceId.slice(0, 8)}` : "workspace"}
                </p>
              </div>
            </div>

            {/* Live provider status pill */}
            <button
              type="button"
              onClick={() => go("providers")}
              className={cn(
                "hidden items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-medium transition md:inline-flex",
                model
                  ? "bg-card text-foreground hover:border-foreground/25"
                  : "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400",
              )}
              title="Jump to Providers"
            >
              <span className={cn("size-1.5 rounded-full", model ? "bg-emerald-500" : "bg-amber-500")} />
              <span className="max-w-[180px] truncate">
                {model
                  ? `${model.label}${prefs.defaultModel ? ` · ${prefs.defaultModel}` : ""}`
                  : "Connect provider"}
              </span>
            </button>

            <AnimatePresence initial={false}>
              {changed > 0 && (
                <motion.span
                  key="dirty"
                  initial={{ opacity: 0, scale: 0.92, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.94 }}
                  transition={{ duration: 0.2, ease: EASE }}
                  className="hidden items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-[11.5px] font-medium text-amber-700 dark:text-amber-400 sm:inline-flex"
                >
                  <span className="live-dot size-1.5 rounded-full bg-amber-500" />
                  {changed} unsaved
                </motion.span>
              )}
            </AnimatePresence>

            {changed > 0 ? (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-1.5"
              >
                <button
                  type="button"
                  onClick={discard}
                  disabled={saving}
                  className="hidden rounded-full px-2.5 py-1.5 text-[12px] text-muted-foreground transition hover:bg-accent hover:text-foreground disabled:opacity-50 sm:block"
                >
                  Discard
                </button>
                <Button size="sm" onClick={() => void save()} disabled={saving} aria-keyshortcuts="Meta+S Control+S">
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                  Save changes
                </Button>
              </motion.div>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[12px] text-muted-foreground">
                <Check size={13} className="text-emerald-600 dark:text-emerald-400" />
                <span className="hidden sm:inline">Saved</span>
              </span>
            )}
          </div>
        </header>

        <div className="mx-auto grid max-w-[1200px] gap-8 px-4 py-7 sm:px-6 lg:grid-cols-[232px_minmax(0,1fr)]">
          {/* Navigation Rail */}
          <nav aria-label="Settings sections" className="min-w-0 lg:sticky lg:top-[76px] lg:self-start">
            <div className="relative mb-3">
              <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                ref={searchInputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && visible[0]) {
                    go(visible[0].id);
                  }
                  if (e.key === "Escape") {
                    setQuery("");
                    searchInputRef.current?.blur();
                  }
                }}
                placeholder="Filter settings… (/)"
                aria-label="Search settings"
                className="h-9 pl-8 pr-7 text-[13px]"
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear filter"
                  onClick={() => setQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
                >
                  <X size={13} />
                </button>
              )}
            </div>

            {loading ? (
              <div className="space-y-1.5">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="nova-skeleton h-9 rounded-lg" />
                ))}
              </div>
            ) : (
              <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:block lg:space-y-4 lg:overflow-visible">
                {GROUP_ORDER.map((group) => {
                  const items = visible.filter((s) => s.group === group);
                  if (items.length === 0) return null;
                  return (
                    <div key={group} className="flex shrink-0 gap-1 lg:block lg:space-y-0.5">
                      <p className="hidden px-2.5 pb-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground/70 lg:block">
                        {group}
                      </p>
                      {items.map((s) => {
                        const active = section === s.id;
                        const badge = badges[s.id];
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => go(s.id)}
                            aria-current={active ? "page" : undefined}
                            className={cn(
                              "relative isolate flex shrink-0 items-center gap-2.5 whitespace-nowrap rounded-xl px-3 py-2 text-[13px] outline-none transition-colors lg:w-full",
                              active
                                ? "font-medium text-foreground"
                                : "text-muted-foreground hover:text-foreground",
                            )}
                          >
                            {active && <ActivePill id="settings-nav-pill" />}
                            <s.icon
                              size={15}
                              className={cn("relative z-10 shrink-0", active ? "text-brand" : "text-muted-foreground")}
                            />
                            <span className="relative z-10 min-w-0 flex-1 truncate text-left">{s.label}</span>
                            {typeof badge === "number" && badge > 0 && (
                              <span
                                className={cn(
                                  "relative z-10 rounded-full px-1.5 py-px font-mono text-[10.5px]",
                                  active
                                    ? "bg-background/85 text-foreground shadow-2xs"
                                    : "bg-muted text-muted-foreground",
                                )}
                              >
                                {badge}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  );
                })}
                {visible.length === 0 && (
                  <p className="px-2.5 py-4 text-[12.5px] text-muted-foreground">
                    Nothing matches “{query}”.
                  </p>
                )}
              </div>
            )}
          </nav>

          {/* Section Content */}
          <main className="min-w-0 pb-28">
            <AnimatePresence mode="wait">
              <motion.div
                key={section}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16, ease: EASE }}
              >
                <SectionIntro title={current.label} description={current.blurb} />
                <div className="min-w-0">
                  {section === "usage" && (
                    <UsageSection
                      stats={stats}
                      loading={loading}
                      onRefresh={refresh}
                      onGoProviders={() => go("providers")}
                    />
                  )}
                  {section === "providers" && (
                    <SettingsProviders
                      kind="model"
                      credentials={credentials}
                      onChanged={refresh}
                      onUseModel={(m, id) => patch({ defaultModel: m, defaultProvider: id })}
                      defaultModel={prefs.defaultModel}
                    />
                  )}
                  {section === "integrations" && (
                    <div className="space-y-8">
                      <SettingsProviders kind="search" credentials={credentials} onChanged={refresh} />
                      <div className="border-t pt-8">
                        <SettingsProviders kind="reader" credentials={credentials} onChanged={refresh} />
                      </div>
                      <div className="border-t pt-8">
                        <WebSection
                          prefs={prefs}
                          patch={patch}
                          activeSearch={search?.label ?? null}
                          activeReader={reader?.label ?? null}
                        />
                      </div>
                    </div>
                  )}
                  {section === "agents" && (
                    <SettingsAgents
                      agents={agents}
                      skills={skills}
                      prefs={prefs}
                      patchPrefs={patch}
                      onChanged={refresh}
                    />
                  )}
                  {section === "skills" && (
                    <SkillsSection prefs={prefs} patch={patch} skills={skills} onChanged={refresh} />
                  )}
                  {section === "memory" && (
                    <MemorySection
                      prefs={prefs}
                      patch={patch}
                      stats={memoryStats}
                      onChanged={refresh}
                      onPrune={() => purge("memories-unused")}
                    />
                  )}
                  {section === "context" && <ContextSection prefs={prefs} patch={patch} />}
                  {section === "tools" && <ToolsSection prefs={prefs} patch={patch} />}
                  {section === "generation" && (
                    <ResponseSection
                      prefs={prefs}
                      patch={patch}
                      hasModel={Boolean(model)}
                      activeProviderLabel={model?.label ?? null}
                    />
                  )}
                  {section === "composer" && <ComposerSection prefs={prefs} patch={patch} />}
                  {section === "appearance" && <AppearanceSection prefs={prefs} patch={patch} />}
                  {section === "data" && (
                    <DataSection
                      prefs={prefs}
                      patch={patch}
                      workspaceId={workspaceId}
                      onExportAll={() => void exportAll()}
                      onExportSettings={() => download("nova-settings.json", prefs)}
                      onImportSettings={(file) => void importSettings(file)}
                      onResetPreferences={() => void resetPreferences()}
                      onPurge={(target) => void purge(target)}
                      shareCount={shareCount}
                    />
                  )}
                  {section === "advanced" && (
                    <AdvancedSection prefs={prefs} patch={patch} onReset={() => void resetPreferences()} />
                  )}
                  {section === "shortcuts" && (
                    <div className="space-y-5">
                      {SHORTCUT_GROUPS.map((group) => (
                        <Panel key={group.title} title={group.title} dense>
                          {group.items.map(([keys, desc]) => (
                            <div key={keys} className="flex items-center justify-between gap-4 px-4 py-3 text-[13px]">
                              <span className="text-foreground/90">{desc}</span>
                              <kbd className="shrink-0 rounded-lg border bg-muted/60 px-2.5 py-1 font-mono text-[11.5px] text-foreground shadow-2xs">
                                {keys}
                              </kbd>
                            </div>
                          ))}
                        </Panel>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Floating unsaved dock */}
            <AnimatePresence>
              {changed > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 18 }}
                  transition={{ duration: 0.22, ease: EASE }}
                  className="fixed bottom-5 left-1/2 z-40 flex -translate-x-1/2 items-center gap-3 rounded-full border bg-popover/95 py-2 pl-4 pr-2.5 shadow-lg backdrop-blur-xl"
                >
                  <span className="live-dot size-2 rounded-full bg-amber-500" />
                  <span className="whitespace-nowrap text-[12.5px] font-medium">
                    {changed} unsaved change{changed === 1 ? "" : "s"}
                  </span>
                  <button
                    type="button"
                    onClick={discard}
                    disabled={saving}
                    className="rounded-full px-2.5 py-1 text-[12px] text-muted-foreground transition hover:bg-accent hover:text-foreground disabled:opacity-50"
                  >
                    Discard
                  </button>
                  <Button size="sm" className="rounded-full" onClick={() => void save()} disabled={saving}>
                    {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
                    Save changes
                  </Button>
                  <kbd className="hidden pr-1.5 font-mono text-[10.5px] text-muted-foreground sm:inline">⌘S</kbd>
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </div>
      </div>
    </MotionConfig>
  );
}
