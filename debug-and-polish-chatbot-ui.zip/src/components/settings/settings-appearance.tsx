"use client";

import { motion } from "framer-motion";
import { Check, Monitor, Moon, RotateCcw, Sun, Wrench } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Field, Panel, Segmented, Slider } from "./ui";
import { Markdown } from "@/components/markdown";
import { Logo } from "@/components/logo";
import { ACCENT_SWATCHES, DEFAULT_PREFERENCES, type Preferences } from "@/lib/preferences-model";
import { cn } from "@/lib/utils";

const SAMPLE = `Here is a concise helper with **O(1)** lookups, \`inline code\` and fenced syntax highlighting:

\`\`\`python
def circle_area(radius: float) -> float:
    return 3.1415926535 * radius * radius
\`\`\`
`;

const APPEARANCE_KEYS = [
  "theme",
  "accent",
  "fontSize",
  "density",
  "messageWidth",
  "codeTheme",
  "lineNumbers",
  "animations",
  "showTimestamps",
  "showTokenUsage",
  "showThinking",
  "sidebarDefault",
  "compactSidebar",
] as const;

export default function AppearanceSection({
  prefs,
  patch,
}: {
  prefs: Preferences;
  patch: (values: Partial<Preferences>) => void;
}) {
  const isModified = APPEARANCE_KEYS.some((k) => prefs[k] !== DEFAULT_PREFERENCES[k]);

  const resetAppearance = () => {
    const defaults: Partial<Preferences> = {};
    for (const key of APPEARANCE_KEYS) {
      (defaults as Record<string, unknown>)[key] = DEFAULT_PREFERENCES[key];
    }
    patch(defaults);
  };

  return (
    <div className="space-y-5">
      <Panel
        title="Theme & accent"
        hint="System tracks your OS light/dark schedule automatically."
        actions={
          isModified ? (
            <Button variant="outline" size="xs" onClick={resetAppearance}>
              <RotateCcw size={12} /> Reset appearance
            </Button>
          ) : undefined
        }
      >
        <Field label="Colour scheme">
          <Segmented
            ariaLabel="Colour scheme"
            value={prefs.theme}
            onChange={(theme) => patch({ theme })}
            options={[
              { value: "light", label: "Light", icon: <Sun size={12} /> },
              { value: "dark", label: "Dark", icon: <Moon size={12} /> },
              { value: "system", label: "System", icon: <Monitor size={12} /> },
            ]}
          />
        </Field>

        <Field label="Brand accent" hint="Used for active indicators, focus rings, sliders and context rings." align="start">
          <div className="flex flex-wrap items-center justify-end gap-2">
            {ACCENT_SWATCHES.map((swatch) => {
              const active = prefs.accent.toLowerCase() === swatch.value.toLowerCase();
              return (
                <button
                  key={swatch.id}
                  type="button"
                  onClick={() => patch({ accent: swatch.value })}
                  aria-label={swatch.label}
                  aria-pressed={active}
                  title={swatch.label}
                  className={cn(
                    "group relative inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-medium outline-none transition focus-visible:ring-2 focus-visible:ring-ring",
                    active ? "border-foreground/30 bg-accent text-foreground" : "bg-card text-muted-foreground hover:text-foreground",
                  )}
                >
                  <span
                    className="relative flex size-4 items-center justify-center rounded-full shadow-2xs"
                    style={{ background: swatch.value }}
                  >
                    {active && (
                      <motion.span
                        layoutId="accent-check"
                        className="flex items-center justify-center"
                        transition={{ type: "spring", stiffness: 500, damping: 34 }}
                      >
                        <Check size={10} className="text-white" />
                      </motion.span>
                    )}
                  </span>
                  <span>{swatch.label}</span>
                </button>
              );
            })}
            <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[11.5px] text-muted-foreground hover:text-foreground">
              <input
                type="color"
                value={prefs.accent}
                onChange={(e) => patch({ accent: e.target.value })}
                aria-label="Custom accent colour"
                className="size-4 cursor-pointer rounded-full border-0 bg-transparent p-0"
              />
              <span className="font-mono text-[11px] uppercase">{prefs.accent}</span>
            </label>
          </div>
        </Field>
      </Panel>

      <Panel title="Typography & layout">
        <Field label="Text size" hint="Scales prose across conversations, composer and settings.">
          <Segmented
            ariaLabel="Text size"
            value={prefs.fontSize}
            onChange={(fontSize) => patch({ fontSize })}
            options={[
              { value: "sm", label: "Small", icon: <span className="text-[10px] leading-none">Aa</span> },
              { value: "md", label: "Medium", icon: <span className="text-[12px] leading-none">Aa</span> },
              { value: "lg", label: "Large", icon: <span className="text-[14px] leading-none">Aa</span> },
            ]}
          />
        </Field>
        <Field label="Message density" hint="Compact tightens vertical rhythm between turns.">
          <Segmented
            ariaLabel="Density"
            value={prefs.density}
            onChange={(density) => patch({ density })}
            options={[
              { value: "comfortable", label: "Comfortable" },
              { value: "compact", label: "Compact" },
            ]}
          />
        </Field>
        <Field label="Thread column width" hint="Wider columns fit side-by-side code and wide tables.">
          <Slider
            value={prefs.messageWidth}
            min={560}
            max={1120}
            step={16}
            label="Message width"
            format={(v) => `${v}px`}
            onChange={(messageWidth) => patch({ messageWidth })}
            className="w-[260px]"
          />
        </Field>
      </Panel>

      <Panel title="Code blocks">
        <Field label="Syntax highlight theme">
          <Segmented
            size="sm"
            ariaLabel="Code theme"
            value={prefs.codeTheme}
            onChange={(codeTheme) => patch({ codeTheme })}
            options={[
              { value: "github", label: "GitHub" },
              { value: "night-owl", label: "Night Owl" },
              { value: "min-light", label: "Min" },
              { value: "material-theme", label: "Material" },
            ]}
          />
        </Field>
        <Field label="Show line numbers">
          <Switch checked={prefs.lineNumbers} onCheckedChange={(lineNumbers) => patch({ lineNumbers })} aria-label="Show line numbers" />
        </Field>
      </Panel>

      <Panel title="Message details & motion">
        <Field label="Show timestamps" hint="Displays turn time next to assistant headers.">
          <Switch checked={prefs.showTimestamps} onCheckedChange={(showTimestamps) => patch({ showTimestamps })} aria-label="Show timestamps" />
        </Field>
        <Field label="Show token usage & latency" hint="Displays model ID, tokens and duration below replies.">
          <Switch checked={prefs.showTokenUsage} onCheckedChange={(showTokenUsage) => patch({ showTokenUsage })} aria-label="Show token usage" />
        </Field>
        <Field label="Show tool and skill timeline" hint="Renders collapsible tool step cards above replies.">
          <Switch checked={prefs.showThinking} onCheckedChange={(showThinking) => patch({ showThinking })} aria-label="Show tool and skill activity" />
        </Field>
        <Field label="Interface animations" hint="Smooth transitions, count-ups and streaming carets. Respects OS Reduce Motion.">
          <Switch checked={prefs.animations} onCheckedChange={(animations) => patch({ animations })} aria-label="Interface animations" />
        </Field>
      </Panel>

      <Panel title="Sidebar defaults">
        <Field label="Desktop sidebar on startup">
          <Segmented
            ariaLabel="Sidebar default"
            value={prefs.sidebarDefault}
            onChange={(sidebarDefault) => patch({ sidebarDefault })}
            options={[
              { value: "open", label: "Open" },
              { value: "closed", label: "Closed" },
            ]}
          />
        </Field>
        <Field label="Start collapsed to icon rail" hint="Opens in compact 60px rail mode unless toggled in-session.">
          <Switch checked={prefs.compactSidebar} onCheckedChange={(compactSidebar) => patch({ compactSidebar })} aria-label="Compact sidebar" />
        </Field>
      </Panel>

      <Panel title="Live conversation preview" hint="Reacts immediately to every typography, code and detail toggle above." dense>
        <div className="bg-muted/25 px-4 py-5">
          <div
            className={cn(
              "mx-auto flex flex-col rounded-2xl border bg-background p-4 shadow-xs transition-all duration-300",
              prefs.density === "compact" ? "gap-3.5" : "gap-6",
            )}
            style={{
              maxWidth: prefs.messageWidth,
              fontSize: prefs.fontSize === "sm" ? 14 : prefs.fontSize === "lg" ? 17 : 15,
            }}
          >
            <div className="flex justify-end">
              <div className="max-w-[82%] rounded-2xl rounded-br-md border bg-surface-2 px-3.5 py-2 leading-relaxed">
                Write a clean Python function to compute the area of a circle.
              </div>
            </div>

            <div className="flex gap-3">
              <Logo size={24} className="mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex items-baseline gap-2">
                  <span className="text-[13px] font-semibold">Nova</span>
                  {prefs.showTimestamps && (
                    <span className="font-mono text-[10.5px] text-muted-foreground">10:42 AM</span>
                  )}
                </div>
                {prefs.showThinking && (
                  <div className="mb-2 inline-flex items-center gap-1.5 rounded-lg border bg-surface-2 px-2.5 py-1 text-[11.5px] text-muted-foreground">
                    <Wrench size={11} className="text-brand" />
                    <span>calculator · 1 step completed</span>
                  </div>
                )}
                <Markdown content={SAMPLE} />
                {prefs.showTokenUsage && (
                  <p className="mt-2 font-mono text-[10.5px] text-muted-foreground">
                    {prefs.defaultModel || "gpt-4o-mini"} · 84 tok · 420ms
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}
