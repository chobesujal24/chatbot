"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Check,
  Copy,
  Database,
  Download,
  KeyRound,
  Link2,
  Loader2,
  Plug,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Bar, Collapsible, EmptyState, Field, NumberField, Panel, Reveal, StatTile } from "./ui";
import { copyToClipboard } from "@/lib/clipboard";
import type { Preferences } from "@/lib/preferences-model";
import { cn } from "@/lib/utils";

export interface UsageStats {
  conversations: number;
  messages: number;
  agents: number;
  memories: number;
  tasksOpen: number;
  tasksDone: number;
  byModel: Array<{ model: string; count: number; tokens: number }>;
  toolCounts: Record<string, number>;
}

/* ── Usage ─────────────────────────────────────────────────────────────────── */

export function UsageSection({
  stats,
  loading,
  onRefresh,
  onGoProviders,
}: {
  stats: UsageStats | null;
  loading: boolean;
  onRefresh?: () => void;
  onGoProviders?: () => void;
}) {
  if (loading || !stats) {
    return (
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="nova-skeleton h-[86px] rounded-xl" />
        ))}
      </div>
    );
  }

  const realModels = stats.byModel.filter((m) => m.model !== "offline-demo" && m.model !== "unknown");
  const tokens = realModels.reduce((sum, m) => sum + m.tokens, 0);
  const calls = Object.values(stats.toolCounts).reduce((a, b) => a + b, 0);
  const tiles = [
    { label: "Conversations", value: stats.conversations, hint: "in this workspace" },
    { label: "Messages", value: stats.messages, hint: "user & assistant turns" },
    { label: "Tokens", value: tokens, hint: "reported by providers" },
    { label: "Tool calls", value: calls, hint: "executed by agents" },
    { label: "Agents", value: stats.agents, hint: "configured personas" },
    { label: "Memories", value: stats.memories, hint: "stored facts" },
    { label: "Tasks open", value: stats.tasksOpen, hint: "active items" },
    { label: "Tasks done", value: stats.tasksDone, hint: "completed items" },
  ];
  const maxTokens = Math.max(1, ...realModels.map((m) => m.tokens));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {tiles.map((tile, i) => (
          <StatTile key={tile.label} label={tile.label} value={tile.value} hint={tile.hint} index={i} />
        ))}
      </div>

      <Panel
        title="Tokens by model"
        hint="Aggregated directly from provider usage reports stored with your messages."
        actions={
          onRefresh ? (
            <Button size="xs" variant="ghost" onClick={onRefresh}>
              <RefreshCw size={12} /> Refresh
            </Button>
          ) : undefined
        }
        dense
      >
        {realModels.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon={<Database size={18} />}
              title="No model token usage recorded yet"
              description="Connect a model provider and send your first message. Token usage and reply counts per model appear here automatically."
              action={
                onGoProviders ? (
                  <Button size="sm" variant="outline" onClick={onGoProviders}>
                    <Plug size={13} /> Connect a provider
                  </Button>
                ) : undefined
              }
            />
          </div>
        ) : (
          <div className="space-y-3.5 p-4">
            {realModels
              .slice()
              .sort((a, b) => b.tokens - a.tokens || b.count - a.count)
              .map((row, i) => {
                const share = tokens > 0 ? Math.round((row.tokens / tokens) * 100) : 0;
                const avg = row.count > 0 ? Math.round(row.tokens / row.count) : 0;
                return (
                  <Reveal key={row.model} index={i}>
                    <div>
                      <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
                        <code className="truncate font-mono text-[12.5px] font-medium">{row.model}</code>
                        <span className="shrink-0 font-mono text-[11.5px] text-muted-foreground">
                          {row.tokens.toLocaleString()} tok ({share}%) · {row.count} repl{row.count === 1 ? "y" : "ies"} · ~{avg.toLocaleString()}/reply
                        </span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-muted">
                        <motion.div
                          className="h-full rounded-full bg-brand"
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.max(2, (row.tokens / maxTokens) * 100)}%` }}
                          transition={{ duration: 0.65, ease: [0.22, 1, 0.3, 1], delay: 0.04 + i * 0.05 }}
                        />
                      </div>
                    </div>
                  </Reveal>
                );
              })}
          </div>
        )}
      </Panel>

      <Panel title="Tool call distribution" hint="Frequency of server-side tools invoked across conversations." dense>
        {calls === 0 ? (
          <p className="px-4 py-5 text-[12.5px] text-muted-foreground">
            No tool calls recorded yet. Ask an agent to calculate, search the web, manage tasks or remember a preference.
          </p>
        ) : (
          <div className="space-y-3 p-4">
            <Bar
              segments={Object.entries(stats.toolCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([name, count], i) => ({
                  id: name,
                  label: name,
                  tokens: count,
                  color: TOOL_TINTS[i % TOOL_TINTS.length],
                }))}
            />
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(stats.toolCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([name, count], i) => (
                  <span
                    key={name}
                    className="inline-flex items-center gap-1.5 rounded-lg border bg-muted/40 px-2.5 py-1 font-mono text-[11.5px] text-muted-foreground"
                  >
                    <span className="size-2 rounded-full" style={{ background: TOOL_TINTS[i % TOOL_TINTS.length] }} />
                    {name}
                    <span className="font-semibold text-foreground">{count}×</span>
                  </span>
                ))}
            </div>
          </div>
        )}
      </Panel>
    </div>
  );
}

const TOOL_TINTS = [
  "oklch(0.64 0.155 48)",
  "oklch(0.62 0.14 250)",
  "oklch(0.66 0.14 165)",
  "oklch(0.68 0.13 300)",
  "oklch(0.72 0.13 85)",
];

/* ── Data & privacy ────────────────────────────────────────────────────────── */

export function DataSection({
  prefs,
  patch,
  workspaceId,
  onExportAll,
  onExportSettings,
  onImportSettings,
  onResetPreferences,
  onPurge,
  shareCount,
}: {
  prefs: Preferences;
  patch: (values: Partial<Preferences>) => void;
  workspaceId: string | null;
  onExportAll: () => void;
  onExportSettings: () => void;
  onImportSettings: (file: File) => void;
  onResetPreferences: () => void;
  onPurge: (target: "conversations" | "memories" | "tasks" | "skills" | "shares" | "all") => void;
  shareCount: number;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [armed, setArmed] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const armOrRun = (id: string, onClick: () => void) => {
    if (armed === id) {
      onClick();
      setArmed(null);
    } else {
      setArmed(id);
      setTimeout(() => setArmed((v) => (v === id ? null : v)), 4000);
    }
  };

  const copyWorkspace = async () => {
    if (!workspaceId) return;
    const ok = await copyToClipboard(workspaceId);
    if (ok) {
      setCopiedId(true);
      toast.success("Workspace ID copied");
      setTimeout(() => setCopiedId(false), 1500);
    }
  };

  return (
    <div className="space-y-5">
      <Panel title="Workspace portability" hint="Export or restore your data and workspace preferences anytime." dense>
        <div className="space-y-3 p-3.5">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-muted/35 px-3.5 py-2.5">
            <div className="min-w-0">
              <p className="text-[12px] font-medium">Workspace ID</p>
              <div className="mt-0.5 flex items-center gap-2">
                <code className="truncate font-mono text-[11.5px] text-muted-foreground">{workspaceId ?? "—"}</code>
                {workspaceId && (
                  <button
                    type="button"
                    onClick={() => void copyWorkspace()}
                    className="inline-flex items-center gap-1 rounded border bg-card px-1.5 py-0.5 text-[10.5px] text-muted-foreground hover:text-foreground"
                  >
                    {copiedId ? <Check size={10} /> : <Copy size={10} />}
                    {copiedId ? "Copied" : "Copy"}
                  </button>
                )}
              </div>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[11.5px] text-muted-foreground">
              <KeyRound size={11} className="text-emerald-500" /> AES-256-GCM encrypted keys
            </span>
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <Button size="sm" variant="outline" onClick={onExportAll}>
              <Download size={13} /> Export full workspace JSON
            </Button>
            <Button size="sm" variant="outline" onClick={onExportSettings}>
              <Download size={13} /> Export settings JSON
            </Button>
            <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload size={13} /> Import settings JSON
            </Button>
            <Button size="sm" variant="ghost" onClick={onResetPreferences}>
              <RotateCcw size={13} /> Reset preferences to default
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onImportSettings(file);
              e.target.value = "";
            }}
          />
        </div>
      </Panel>

      <Panel title="Shared snapshots" hint="Read-only public links created from conversations.">
        <Field label="Active share links" hint="Revoking a link makes its public URL return 404 immediately.">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 font-mono text-[12px]">
              <Link2 size={11} /> {shareCount} active
            </span>
            {shareCount > 0 && (
              <DangerActionButton
                armed={armed === "shares"}
                label="Revoke all"
                onClick={() => armOrRun("shares", () => onPurge("shares"))}
              />
            )}
          </div>
        </Field>
        <Field label="Default link expiry" hint="Set to 0 to keep shared links live until manually revoked.">
          <NumberField
            value={prefs.shareExpiryDays}
            min={0}
            max={365}
            step={1}
            suffix="days"
            ariaLabel="Share expiry"
            onChange={(shareExpiryDays) => patch({ shareExpiryDays })}
          />
        </Field>
        <Field label="Redact attached files in shared links" hint="Replaces inline file contents with a privacy notice while keeping filenames visible.">
          <Switch
            checked={prefs.shareRedactAttachments}
            onCheckedChange={(shareRedactAttachments) => patch({ shareRedactAttachments })}
            aria-label="Redact attachments"
          />
        </Field>
      </Panel>

      <Panel title="Irreversible purges" hint="Click once to arm, then click Confirm delete within 4 seconds." dense>
        <div className="divide-y">
          {[
            { id: "conversations", label: "Delete all conversations", hint: "Removes all chat threads, messages, feedback and share links.", target: "conversations" as const },
            { id: "memories", label: "Delete all memories", hint: "Permanently clears all remembered facts and preferences.", target: "memories" as const },
            { id: "skills", label: "Delete custom skills", hint: "Removes custom/imported skills and restores built-in defaults.", target: "skills" as const },
            { id: "tasks", label: "Delete all tasks", hint: "Clears both open and completed tasks.", target: "tasks" as const },
            { id: "all", label: "Factory reset workspace", hint: "Purges conversations, credentials, memories, skills, tasks and shares, then re-seeds defaults.", target: "all" as const },
          ].map((row) => (
            <div key={row.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <p className={cn("text-[13.5px] font-medium", row.id === "all" && "text-destructive")}>{row.label}</p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">{row.hint}</p>
              </div>
              <DangerActionButton
                armed={armed === row.id}
                label="Delete"
                onClick={() => armOrRun(row.id, () => onPurge(row.target))}
              />
            </div>
          ))}
        </div>
      </Panel>

      <Collapsible title="Data storage inventory" hint="Exact breakdown of what Nova persists in PostgreSQL.">
        <div className="space-y-2 p-3.5 text-[12.5px] leading-relaxed text-muted-foreground">
          {[
            ["Conversations & messages", "Turn text, attachment metadata, tool call records, token usage and compaction summaries."],
            ["Credentials", "AES-256-GCM ciphertext derived from AUTH_SECRET. Plaintext API keys never return to the browser."],
            ["Agents & skills", "System prompts, model overrides, tool sets and progressive-disclosure SKILL.md packs."],
            ["Long-term memory", "Discrete facts with type, importance, confidence, pin state and recall counters."],
            ["Workspace preferences", "Validated JSON settings per workspace, enforced server-side."],
            ["Shared links", "Random 144-bit URL tokens with optional expiry timestamps."],
          ].map(([title, detail]) => (
            <div key={title} className="flex gap-2.5 rounded-xl bg-muted/35 px-3 py-2">
              <ShieldCheck size={14} className="mt-0.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <span>
                <span className="font-medium text-foreground">{title}</span> — {detail}
              </span>
            </div>
          ))}
          <p className="flex items-center gap-1.5 pt-1 text-[12px]">
            <Sparkles size={12} /> Zero analytics, zero telemetry, and zero outbound requests except to the providers you configure.
          </p>
        </div>
      </Collapsible>
    </div>
  );
}

function DangerActionButton({
  armed,
  label,
  onClick,
}: {
  armed: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <Button size="sm" variant={armed ? "destructive" : "outline"} onClick={onClick}>
      <Trash2 size={13} />
      {armed ? "Confirm delete" : label}
    </Button>
  );
}

export const Busy = ({ show }: { show: boolean }) => (show ? <Loader2 size={13} className="animate-spin" /> : null);
