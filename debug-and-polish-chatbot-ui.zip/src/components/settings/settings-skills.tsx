"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Check,
  Copy,
  Download,
  FileCode2,
  Loader2,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Markdown } from "../markdown";
import { ActivePill } from "./ui";
import { TOOL_META } from "@/lib/tool-meta";
import { copyToClipboard } from "@/lib/clipboard";
import { serializeSkillMarkdown } from "@/lib/skills-format";
import { cn } from "@/lib/utils";
import type { Skill } from "@/lib/types";

interface Props {
  skills: Skill[];
  onChanged: () => void | Promise<void>;
}

interface Draft {
  name: string;
  description: string;
  instructions: string;
  emoji: string;
  tools: string[];
  enabled: boolean;
}

const BLANK: Draft = {
  name: "",
  description: "",
  instructions: "",
  emoji: "✦",
  tools: [],
  enabled: true,
};

function toDraft(skill: Skill): Draft {
  return {
    name: skill.name,
    description: skill.description,
    instructions: skill.instructions,
    emoji: skill.emoji,
    tools: skill.tools ?? [],
    enabled: skill.enabled,
  };
}

export default function SettingsSkills({ skills, onChanged }: Props) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(skills[0]?.id ?? null);
  const [mode, setMode] = useState<"view" | "edit" | "new">("view");
  const [draft, setDraft] = useState<Draft>(BLANK);
  const [preview, setPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [importing, setImporting] = useState(false);
  const [armedDelete, setArmedDelete] = useState(false);

  useEffect(() => {
    if (mode !== "new" && (!selected || !skills.some((s) => s.id === selected)) && skills.length > 0) {
      setSelected(skills[0].id);
      setMode("view");
    }
  }, [mode, selected, skills]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return skills;
    return skills.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.instructions.toLowerCase().includes(q),
    );
  }, [skills, query]);

  const current = mode === "new" ? null : (skills.find((s) => s.id === selected) ?? null);

  const startNew = () => {
    setMode("new");
    setDraft({ ...BLANK });
    setPreview(false);
    setArmedDelete(false);
  };

  const startEdit = (skill: Skill) => {
    setSelected(skill.id);
    setDraft(toDraft(skill));
    setMode("edit");
    setPreview(false);
    setArmedDelete(false);
  };

  const pick = (skill: Skill) => {
    setSelected(skill.id);
    setMode("view");
    setPreview(false);
    setArmedDelete(false);
  };

  const patch = (values: Partial<Draft>) => setDraft((prev) => ({ ...prev, ...values }));

  const save = async () => {
    if (!draft.name.trim()) {
      toast.error("Give the skill a name");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: draft.name.trim(),
        description: draft.description.trim(),
        instructions: draft.instructions,
        tools: draft.tools.length ? draft.tools : null,
        emoji: draft.emoji || "✦",
        enabled: draft.enabled,
      };
      const res =
        mode === "edit" && current
          ? await fetch(`/api/skills/${current.id}`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            })
          : await fetch("/api/skills", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            });
      const data = (await res.json().catch(() => null)) as {
        skill?: Skill;
        error?: { message?: string };
      } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Could not save.");
      toast.success(mode === "edit" ? "Skill updated" : "Skill created");
      await onChanged();
      if (data?.skill?.id) {
        setSelected(data.skill.id);
      }
      setMode("view");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save.");
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (skill: Skill, enabled: boolean) => {
    const res = await fetch(`/api/skills/${skill.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled }),
    });
    if (!res.ok) return toast.error("Could not update the skill");
    await onChanged();
  };

  const remove = async (skill: Skill) => {
    if (!armedDelete) {
      setArmedDelete(true);
      setTimeout(() => setArmedDelete(false), 4000);
      return;
    }
    setArmedDelete(false);
    const res = await fetch(`/api/skills/${skill.id}`, { method: "DELETE" });
    if (!res.ok) return toast.error("Could not delete the skill");
    toast.success("Skill deleted");
    if (selected === skill.id) setSelected(null);
    setMode("view");
    await onChanged();
  };

  const importFile = async (file: File) => {
    setImporting(true);
    try {
      const markdown = await file.text();
      const res = await fetch("/api/skills/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markdown, overwrite: true }),
      });
      const data = (await res.json().catch(() => null)) as {
        skill?: Skill;
        error?: { message?: string };
      } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Import failed.");
      toast.success(`Imported ${data?.skill?.name ?? "skill"}`);
      await onChanged();
      if (data?.skill?.id) {
        setSelected(data.skill.id);
        setMode("view");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Import failed.");
    } finally {
      setImporting(false);
    }
  };

  const formatSkillMd = (skill: Skill) =>
    serializeSkillMarkdown({
      name: skill.name,
      description: skill.description,
      instructions: skill.instructions,
      tools: skill.tools,
      emoji: skill.emoji,
    });

  const exportFile = (skill: Skill) => {
    const blob = new Blob([formatSkillMd(skill)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${skill.name}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyMd = async (skill: Skill) => {
    const ok = await copyToClipboard(formatSkillMd(skill));
    if (ok) toast.success("Copied SKILL.md to clipboard");
    else toast.error("Clipboard unavailable");
  };

  const enabledCount = skills.filter((s) => s.enabled).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <p className="mr-auto text-[12.5px] text-muted-foreground">
          {enabledCount} of {skills.length} enabled · loaded on demand via{" "}
          <code className="rounded bg-muted px-1 py-0.5 font-mono text-[11.5px]">loadSkill</code>
        </p>
        <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-lg border bg-card px-2.5 text-[12.5px] font-medium transition hover:bg-accent">
          {importing ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
          Import SKILL.md
          <input
            type="file"
            accept=".md,.markdown,.txt"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void importFile(file);
              e.target.value = "";
            }}
          />
        </label>
        <Button size="sm" onClick={startNew}>
          <Plus size={14} /> New skill
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[224px_minmax(0,1fr)]">
        <div className="min-w-0">
          <div className="relative mb-2.5">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search skills"
              aria-label="Search skills"
              className="h-9 pl-8 text-[13px]"
            />
          </div>
          <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:block lg:max-h-[58vh] lg:space-y-0.5 lg:overflow-y-auto lg:overflow-x-visible lg:pr-1">
            {filtered.map((skill) => {
              const active = selected === skill.id && mode !== "new";
              return (
                <button
                  key={skill.id}
                  type="button"
                  onClick={() => pick(skill)}
                  aria-current={active ? "true" : undefined}
                  className={cn(
                    "group relative isolate flex shrink-0 items-start gap-2.5 whitespace-nowrap rounded-xl px-2.5 py-2 text-left text-[13px] outline-none transition-colors lg:w-full lg:whitespace-normal",
                    active ? "font-medium text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {active && <ActivePill id="settings-skill-pill" />}
                  <span className="relative z-10 mt-px text-[14px] leading-none">{skill.emoji}</span>
                  <span className="relative z-10 min-w-0 flex-1">
                    <span className="block truncate">{skill.name}</span>
                    <span className="mt-0.5 hidden truncate text-[11px] text-muted-foreground lg:block">
                      {skill.useCount > 0 ? `used ${skill.useCount}×` : "unused"}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "relative z-10 mt-1.5 size-1.5 shrink-0 rounded-full",
                      skill.enabled ? "bg-emerald-500" : "bg-muted-foreground/30",
                    )}
                    title={skill.enabled ? "Enabled" : "Disabled"}
                  />
                </button>
              );
            })}
            {filtered.length === 0 && (
              <p className="px-2.5 py-6 text-[12.5px] text-muted-foreground">
                {skills.length === 0 ? "No skills yet." : "No skill matches that search."}
              </p>
            )}
          </div>
        </div>

        {mode === "edit" || mode === "new" ? (
          <div className="min-w-0 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="mr-auto text-[16px] font-semibold tracking-tight">
                {mode === "edit" && current ? `Edit ${current.emoji} ${current.name}` : "New skill"}
              </h3>
              <Button
                size="xs"
                variant="ghost"
                onClick={() => {
                  setMode("view");
                  setPreview(false);
                }}
              >
                <X size={13} /> Cancel
              </Button>
            </div>

            <div className="grid gap-3 sm:grid-cols-[1fr_72px]">
              <div>
                <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-name">
                  Name (slug)
                </label>
                <Input
                  id="skill-name"
                  value={draft.name}
                  onChange={(e) => patch({ name: e.target.value })}
                  placeholder="research-brief"
                  className="font-mono text-[13px]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-emoji">
                  Icon
                </label>
                <Input
                  id="skill-emoji"
                  value={draft.emoji}
                  onChange={(e) => patch({ emoji: e.target.value.slice(0, 4) })}
                  className="text-center text-[15px]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-[13px] font-medium" htmlFor="skill-desc">
                Trigger description
              </label>
              <Textarea
                id="skill-desc"
                value={draft.description}
                onChange={(e) => patch({ description: e.target.value })}
                rows={2}
                placeholder="One sentence the model reads to decide whether to load this skill."
                className="resize-y text-[13px]"
              />
              <p className="mt-1 text-[12px] text-muted-foreground">
                Only this summary is sent in the prompt index until an agent calls <code className="font-mono">loadSkill</code>.
              </p>
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="skill-instructions" className="text-[13px] font-medium">
                  Instructions (Markdown)
                </label>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[11px] text-muted-foreground">
                    ~{Math.ceil(draft.instructions.length / 4)} tok
                  </span>
                  <Button size="xs" variant={preview ? "secondary" : "ghost"} onClick={() => setPreview((v) => !v)}>
                    <FileCode2 size={12} /> {preview ? "Edit" : "Preview"}
                  </Button>
                </div>
              </div>
              {preview ? (
                <div className="max-h-[340px] min-h-[160px] overflow-y-auto rounded-xl border bg-surface-1 px-4 py-3">
                  {draft.instructions.trim() ? (
                    <Markdown content={draft.instructions} />
                  ) : (
                    <p className="text-[13px] text-muted-foreground">Nothing to preview yet.</p>
                  )}
                </div>
              ) : (
                <Textarea
                  id="skill-instructions"
                  value={draft.instructions}
                  onChange={(e) => patch({ instructions: e.target.value })}
                  rows={11}
                  spellCheck={false}
                  placeholder={"# Skill title\n\nWrite the method the model should follow, as numbered steps and constraints."}
                  className="scroll-slim resize-y font-mono text-[12.5px] leading-relaxed"
                />
              )}
            </div>

            <div>
              <p className="mb-1.5 text-[13px] font-medium">Tool hints (optional)</p>
              <div className="flex flex-wrap gap-1.5">
                {TOOL_META.map((tool) => {
                  const on = draft.tools.includes(tool.name);
                  return (
                    <button
                      key={tool.name}
                      type="button"
                      onClick={() =>
                        patch({
                          tools: on ? draft.tools.filter((t) => t !== tool.name) : [...draft.tools, tool.name],
                        })
                      }
                      aria-pressed={on}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 font-mono text-[11.5px] transition",
                        on
                          ? "border-foreground bg-foreground text-background"
                          : "text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                      )}
                    >
                      {on && <Check size={11} />}
                      {tool.name}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
              <div>
                <p className="text-[13px] font-medium">Enabled</p>
                <p className="text-[11.5px] text-muted-foreground">
                  Disabled skills are omitted from the agent index.
                </p>
              </div>
              <Switch checked={draft.enabled} onCheckedChange={(enabled) => patch({ enabled })} aria-label="Enable skill" />
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={() => void save()} disabled={saving}>
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                {mode === "edit" ? "Save changes" : "Create skill"}
              </Button>
              <Button variant="ghost" onClick={() => setMode("view")}>
                Cancel
              </Button>
            </div>
          </div>
        ) : current ? (
          <div className="min-w-0 space-y-4">
            <div className="flex flex-wrap items-start gap-3 rounded-xl border bg-surface-1 p-3.5">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-muted text-[19px]">
                {current.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-mono text-[15px] font-semibold tracking-tight">{current.name}</h3>
                  <span className="rounded-full border px-2 py-0.5 text-[10.5px] capitalize text-muted-foreground">
                    {current.source}
                  </span>
                </div>
                <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-muted-foreground">
                  {current.description || "No description"}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                  <span>~{Math.ceil(current.instructions.length / 4)} tokens when loaded</span>
                  <span>·</span>
                  <span>{current.useCount} loads</span>
                  {current.tools?.length ? (
                    <>
                      <span>·</span>
                      <span className="font-mono">{current.tools.join(", ")}</span>
                    </>
                  ) : null}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={current.enabled}
                  onCheckedChange={(v) => void toggle(current, v)}
                  aria-label={`Enable ${current.name}`}
                />
              </div>
            </div>

            <div className="overflow-hidden rounded-xl border bg-surface-1">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/25 px-3.5 py-2">
                <p className="text-[12.5px] font-medium">Instructions</p>
                <div className="flex flex-wrap items-center gap-1">
                  <Button size="xs" variant="ghost" onClick={() => void copyMd(current)}>
                    <Copy size={12} /> Copy
                  </Button>
                  <Button size="xs" variant="ghost" onClick={() => exportFile(current)}>
                    <Download size={12} /> Export
                  </Button>
                  <Button size="xs" variant="outline" onClick={() => startEdit(current)}>
                    <Pencil size={12} /> Edit
                  </Button>
                  <Button
                    size="xs"
                    variant={armedDelete ? "destructive" : "ghost"}
                    className={cn(!armedDelete && "text-muted-foreground hover:text-destructive")}
                    onClick={() => void remove(current)}
                  >
                    <Trash2 size={12} />
                    {armedDelete ? "Confirm" : "Delete"}
                  </Button>
                </div>
              </div>
              <div className="scroll-slim max-h-[44vh] overflow-y-auto px-4 py-3.5">
                <Markdown content={current.instructions || "_No instructions yet._"} />
              </div>
            </div>

            {current.source === "builtin" && (
              <p className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
                <Sparkles size={12} /> Built-in skill. Edits are preserved in your workspace.
              </p>
            )}
          </div>
        ) : (
          <div className="flex min-h-[220px] flex-col items-center justify-center rounded-xl border border-dashed px-6 text-center">
            <p className="text-[13.5px] font-medium">No skills yet</p>
            <p className="mt-1 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">
              Create a reusable workflow pack or import a <code className="font-mono">SKILL.md</code> file.
            </p>
            <Button size="sm" variant="outline" className="mt-4" onClick={startNew}>
              <Plus size={14} /> Create a skill
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
