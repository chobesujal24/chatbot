"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Brain,
  Check,
  History,
  Loader2,
  Pencil,
  Pin,
  Plus,
  RefreshCw,
  Search,
  Slash,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Collapsible, Panel } from "./ui";
import { cn } from "@/lib/utils";
import { relativeTime } from "@/lib/format";
import type { MemoryItem, MemoryLogEntry, MemoryType } from "@/lib/types";

const TYPES: Array<{ id: MemoryType; label: string; tint: string }> = [
  { id: "preference", label: "Preference", tint: "oklch(0.66 0.14 300)" },
  { id: "fact", label: "Fact", tint: "oklch(0.66 0.14 235)" },
  { id: "entity", label: "Entity", tint: "oklch(0.66 0.14 165)" },
  { id: "procedure", label: "Procedure", tint: "oklch(0.7 0.14 80)" },
  { id: "event", label: "Event", tint: "oklch(0.66 0.15 20)" },
];

interface Props {
  onChanged?: () => void;
}

export default function SettingsMemory({ onChanged }: Props) {
  const [items, setItems] = useState<MemoryItem[]>([]);
  const [log, setLog] = useState<MemoryLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [type, setType] = useState<MemoryType | "all">("all");
  const [onlyEnabled, setOnlyEnabled] = useState(false);
  const [adding, setAdding] = useState(false);
  const [draftValue, setDraftValue] = useState("");
  const [draftType, setDraftType] = useState<MemoryType>("preference");
  const [draftImportance, setDraftImportance] = useState(0.8);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [armedId, setArmedId] = useState<string | null>(null);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (query.trim()) params.set("q", query.trim());
        const res = await fetch(`/api/memories?${params}`, { cache: "no-store" });
        if (!res.ok) throw new Error("load failed");
        const data = (await res.json()) as {
          memories: MemoryItem[];
          log: MemoryLogEntry[];
        };
        if (cancelled) return;
        setItems(data.memories);
        setLog(data.log ?? []);
      } catch {
        if (!cancelled) toast.error("Could not load memory");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [query, refresh]);

  const visible = useMemo(
    () =>
      items.filter((m) => {
        if (type !== "all" && m.type !== type) return false;
        if (onlyEnabled && !m.enabled) return false;
        return true;
      }),
    [items, type, onlyEnabled],
  );

  const reload = () => setRefresh((v) => v + 1);

  const add = async () => {
    if (!draftValue.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/memories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          value: draftValue.trim(),
          type: draftType,
          importance: draftImportance,
          confidence: 1,
        }),
      });
      const data = (await res.json().catch(() => null)) as { message?: string } | null;
      if (!res.ok) throw new Error("save failed");
      toast.success(data?.message ?? "Memory stored");
      setDraftValue("");
      setAdding(false);
      reload();
      onChanged?.();
    } catch {
      toast.error("Could not store the memory");
    } finally {
      setSaving(false);
    }
  };

  const act = async (id: string, init: RequestInit, onDone?: () => void) => {
    setBusyId(id);
    try {
      const res = await fetch(`/api/memories/${id}`, init);
      if (!res.ok) throw new Error("failed");
      onDone?.();
      reload();
    } catch {
      toast.error("Could not update that memory");
    } finally {
      setBusyId(null);
      onChanged?.();
    }
  };

  const remove = async (m: MemoryItem) => {
    if (armedId !== m.id) {
      setArmedId(m.id);
      setTimeout(() => setArmedId((cur) => (cur === m.id ? null : cur)), 3500);
      return;
    }
    setArmedId(null);
    await act(m.id, { method: "DELETE" }, () => toast.success("Memory forgotten"));
  };

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: items.length };
    for (const t of TYPES) map[t.id] = items.filter((m) => m.type === t.id).length;
    return map;
  }, [items]);

  return (
    <div className="space-y-4">
      <Panel
        title="Stored memories"
        hint="Browse, pin, edit or manually add facts and preferences."
        actions={
          <div className="flex items-center gap-1.5">
            <Button size="xs" variant="outline" onClick={reload} aria-label="Reload memories">
              <RefreshCw size={12} className={cn(loading && "animate-spin")} />
            </Button>
            <Button size="xs" onClick={() => setAdding((v) => !v)}>
              {adding ? <X size={13} /> : <Plus size={13} />}
              {adding ? "Cancel" : "Add memory"}
            </Button>
          </div>
        }
      >
        <div className="space-y-4 p-3">
          {adding && (
            <div className="space-y-3 rounded-xl border bg-muted/30 p-3.5">
              <textarea
                autoFocus
                value={draftValue}
                onChange={(e) => setDraftValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void add();
                  if (e.key === "Escape") setAdding(false);
                }}
                rows={2}
                placeholder="One self-contained statement, e.g. “Prefers pnpm over npm for TypeScript projects.”"
                className="scroll-slim w-full resize-y rounded-lg border bg-card px-3 py-2 text-[13px] leading-relaxed outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
              />
              <div className="flex flex-wrap items-center gap-2">
                {TYPES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setDraftType(t.id)}
                    aria-pressed={draftType === t.id}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[12px] transition",
                      draftType === t.id
                        ? "border-foreground bg-foreground text-background"
                        : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                    )}
                  >
                    <span className="size-1.5 rounded-full" style={{ background: t.tint }} />
                    {t.label}
                  </button>
                ))}
                <div className="ml-auto flex items-center gap-2">
                  <span className="text-[12px] text-muted-foreground">Importance</span>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={draftImportance}
                    onChange={(e) => setDraftImportance(Number(e.target.value))}
                    className="h-1.5 w-24 cursor-pointer accent-foreground"
                    aria-label="Importance"
                  />
                  <span className="w-8 font-mono text-[11.5px] text-muted-foreground">
                    {draftImportance.toFixed(2)}
                  </span>
                  <Button size="sm" onClick={() => void add()} disabled={!draftValue.trim() || saving}>
                    {saving ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />}
                    Store
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[180px] flex-1">
              <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search memories by text or key…"
                aria-label="Search memory"
                className="h-9 pl-8 text-[13px]"
              />
            </div>
            <label className="flex cursor-pointer items-center gap-2 rounded-lg border bg-card px-2.5 py-1.5 text-[12px] text-muted-foreground">
              <Switch checked={onlyEnabled} onCheckedChange={setOnlyEnabled} size="sm" />
              Enabled only
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <FilterChip label="All" count={counts.all} active={type === "all"} onClick={() => setType("all")} />
            {TYPES.map((t) => (
              <FilterChip
                key={t.id}
                label={t.label}
                tint={t.tint}
                count={counts[t.id] ?? 0}
                active={type === t.id}
                onClick={() => setType(type === t.id ? "all" : t.id)}
              />
            ))}
          </div>

          <div className="space-y-2">
            {loading && items.length === 0 ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-[82px] animate-pulse rounded-xl border bg-muted/40" />
              ))
            ) : visible.length === 0 ? (
              <div className="flex flex-col items-center rounded-xl border border-dashed px-6 py-10 text-center">
                <Brain size={20} className="text-muted-foreground" />
                <p className="mt-2.5 text-[13.5px] font-medium">
                  {items.length === 0 ? "Nothing remembered yet" : "No memory matches those filters"}
                </p>
                <p className="mt-1 max-w-sm text-[12px] leading-relaxed text-muted-foreground">
                  {items.length === 0
                    ? "Say something like “remember I prefer TypeScript” in chat, click Add memory above, or let agents store facts automatically."
                    : "Try selecting All types or clearing your search query."}
                </p>
              </div>
            ) : (
              visible.map((m) => {
                const tint = TYPES.find((t) => t.id === m.type)?.tint ?? "var(--muted-foreground)";
                const isEditing = editingId === m.id;
                const isArmed = armedId === m.id;
                return (
                  <div
                    key={m.id}
                    className={cn(
                      "group relative rounded-xl border bg-surface-1 p-3.5 pl-4 transition",
                      !m.enabled && "opacity-60",
                    )}
                  >
                    <span className="absolute inset-y-3 left-0 w-[3px] rounded-full" style={{ background: tint }} />
                    <div className="flex items-start gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="flex flex-wrap items-center gap-2 text-[11.5px] text-muted-foreground">
                          <span className="inline-flex items-center gap-1.5 font-medium capitalize" style={{ color: tint }}>
                            <span className="size-1.5 rounded-full" style={{ background: tint }} />
                            {m.type}
                          </span>
                          {m.pinned && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-1.5 py-0.5 text-[10.5px] font-medium text-amber-700 dark:text-amber-400">
                              <Pin size={9} /> pinned
                            </span>
                          )}
                          {m.origin !== "manual" && (
                            <span className="rounded-full border px-1.5 py-0.5 text-[10px] uppercase tracking-wide">
                              {m.origin}
                            </span>
                          )}
                          <code className="font-mono text-[10.5px]">{m.key}</code>
                        </p>

                        {isEditing ? (
                          <div className="mt-2 space-y-2">
                            <textarea
                              autoFocus
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              rows={2}
                              className="scroll-slim w-full resize-y rounded-lg border bg-card px-2.5 py-1.5 text-[13px] leading-relaxed outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            />
                            <div className="flex gap-1.5">
                              <Button
                                size="xs"
                                onClick={() =>
                                  void act(
                                    m.id,
                                    {
                                      method: "PATCH",
                                      headers: { "Content-Type": "application/json" },
                                      body: JSON.stringify({ value: editValue.trim() }),
                                    },
                                    () => {
                                      setEditingId(null);
                                      toast.success("Memory updated");
                                    },
                                  )
                                }
                                disabled={!editValue.trim()}
                              >
                                Save
                              </Button>
                              <Button size="xs" variant="ghost" onClick={() => setEditingId(null)}>
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <p className="mt-1.5 text-[13.5px] leading-relaxed">{m.value}</p>
                        )}

                        <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] text-muted-foreground">
                          <Meter label="importance" value={m.importance} />
                          <Meter label="confidence" value={m.confidence} />
                          <span className="inline-flex items-center gap-1">
                            <Slash size={9} className="rotate-90" />
                            {m.useCount} recalled
                          </span>
                          <span>· updated {relativeTime(m.updatedAt)}</span>
                        </div>
                      </div>

                      <div className="flex shrink-0 items-center gap-1">
                        <IconAction
                          label={m.pinned ? "Unpin" : "Pin to top"}
                          active={m.pinned}
                          onClick={() =>
                            void act(m.id, {
                              method: "PATCH",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ pinned: !m.pinned }),
                            })
                          }
                        >
                          <Pin size={13} />
                        </IconAction>
                        <Switch
                          checked={m.enabled}
                          size="sm"
                          aria-label={m.enabled ? "Disable memory" : "Enable memory"}
                          onCheckedChange={(v) =>
                            void act(m.id, {
                              method: "PATCH",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ enabled: v }),
                            })
                          }
                        />
                        <IconAction
                          label="Edit memory"
                          onClick={() => {
                            setEditingId(m.id);
                            setEditValue(m.value);
                          }}
                        >
                          <Pencil size={13} />
                        </IconAction>
                        {isArmed ? (
                          <Button size="xs" variant="destructive" onClick={() => void remove(m)}>
                            Confirm
                          </Button>
                        ) : (
                          <IconAction label="Forget memory" onClick={() => void remove(m)}>
                            <Trash2 size={13} />
                          </IconAction>
                        )}
                      </div>
                    </div>
                    {busyId === m.id && (
                      <span className="absolute right-3 bottom-3 text-muted-foreground">
                        <Loader2 size={13} className="animate-spin" />
                      </span>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </Panel>

      {log.length > 0 && (
        <Collapsible
          title="Memory audit log"
          hint="Recent additions, merges, deletions and auto-pruning events."
          badge={
            <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 font-mono text-[10.5px] text-muted-foreground">
              <History size={10} /> {log.length}
            </span>
          }
        >
          <ul className="divide-y">
            {log.slice(0, 10).map((entry) => (
              <li key={entry.id} className="flex items-start gap-2.5 px-4 py-2.5 text-[12px]">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-muted-foreground/50" />
                <span className="min-w-0 flex-1">
                  <span className="font-medium capitalize">{entry.action}</span>{" "}
                  <code className="font-mono text-[11px] text-muted-foreground">{entry.key}</code>
                  {entry.detail && (
                    <span className="block truncate text-muted-foreground">{entry.detail}</span>
                  )}
                </span>
                <span className="shrink-0 font-mono text-[11px] text-muted-foreground">
                  {relativeTime(entry.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        </Collapsible>
      )}
    </div>
  );
}

function Meter({ label, value }: { label: string; value: number }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span>{label}</span>
      <span className="h-1 w-10 overflow-hidden rounded-full bg-muted">
        <span
          className="block h-full rounded-full bg-foreground/70"
          style={{ width: `${Math.round(Math.min(1, Math.max(0, value)) * 100)}%` }}
        />
      </span>
      <span className="font-mono">{Math.round(value * 100)}%</span>
    </span>
  );
}

function FilterChip({
  label,
  count,
  active,
  tint,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  tint?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[12px] transition",
        active
          ? "border-foreground bg-foreground text-background"
          : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
      )}
    >
      {tint && <span className="size-1.5 rounded-full" style={{ background: tint }} />}
      {label}
      <span className={cn("font-mono text-[11px]", active ? "opacity-80" : "opacity-60")}>{count}</span>
    </button>
  );
}

function IconAction({
  label,
  onClick,
  active,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        "flex size-7 items-center justify-center rounded-md outline-none transition",
        active ? "text-brand" : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}
