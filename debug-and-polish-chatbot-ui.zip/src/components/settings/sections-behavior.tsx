"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Bell,
  Check,
  Loader2,
  Play,
  Plus,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
  Terminal,
  Trash2,
  Volume2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Collapsible, Field, Note, NumberField, Panel, Segmented, Slider } from "./ui";
import { TOOL_GROUP_LABELS, TOOL_META } from "@/lib/tool-meta";
import { buildBreakdown } from "@/lib/context";
import { playCompletionChime } from "@/lib/feedback-sound";
import { cn } from "@/lib/utils";
import type { Preferences } from "@/lib/preferences-model";

type Patch = (values: Partial<Preferences>) => void;
const kfmt = (v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v));

/* ── Generation ────────────────────────────────────────────────────────────── */

const SAMPLING_PRESETS = [
  { id: "precise", label: "Precise", temp: 0.2, topP: 0.9, presence: 0, frequency: 0 },
  { id: "balanced", label: "Balanced", temp: 0.7, topP: 1, presence: 0, frequency: 0 },
  { id: "creative", label: "Creative", temp: 1.1, topP: 1, presence: 0.2, frequency: 0.2 },
] as const;

export function ResponseSection({
  prefs,
  patch,
  hasModel,
  activeProviderLabel,
}: {
  prefs: Preferences;
  patch: Patch;
  hasModel: boolean;
  activeProviderLabel?: string | null;
}) {
  const stopList = useMemo(
    () => prefs.stopSequences.split(",").map((s) => s.trim()).filter(Boolean),
    [prefs.stopSequences],
  );

  return (
    <div className="space-y-5">
      {!hasModel ? (
        <Note tone="warn">
          No model provider is connected yet. These parameters will apply automatically as soon as you connect a provider in{" "}
          <a href="#providers" className="font-medium underline underline-offset-2">
            Providers
          </a>
          .
        </Note>
      ) : (
        <Panel title="Default model" hint="Used for new conversations unless an agent specifies its own model override.">
          <Field
            label="Model ID"
            hint={activeProviderLabel ? `Active provider: ${activeProviderLabel}` : "Picked from your active provider."}
          >
            <Input
              value={prefs.defaultModel}
              onChange={(e) => patch({ defaultModel: e.target.value })}
              placeholder="Provider default model"
              className="h-9 w-[260px] font-mono text-[12.5px]"
              aria-label="Default model ID"
            />
          </Field>
        </Panel>
      )}

      <Panel
        title="Sampling"
        hint="Applied to every turn unless the selected agent overrides temperature."
        actions={
          <div className="flex items-center gap-1">
            {SAMPLING_PRESETS.map((p) => {
              const active =
                Math.abs(prefs.temperature - p.temp) < 0.01 &&
                Math.abs(prefs.topP - p.topP) < 0.01 &&
                Math.abs(prefs.presencePenalty - p.presence) < 0.01 &&
                Math.abs(prefs.frequencyPenalty - p.frequency) < 0.01;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() =>
                    patch({
                      temperature: p.temp,
                      topP: p.topP,
                      presencePenalty: p.presence,
                      frequencyPenalty: p.frequency,
                    })
                  }
                  className={cn(
                    "rounded-md border px-2 py-0.5 text-[11px] font-medium transition",
                    active
                      ? "border-foreground bg-foreground text-background"
                      : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                  )}
                >
                  {p.label}
                </button>
              );
            })}
          </div>
        }
      >
        <Field label="Temperature" hint="Lower is deterministic and analytical; higher is more varied.">
          <Slider
            value={prefs.temperature}
            min={0}
            max={2}
            step={0.05}
            label="Temperature"
            format={(v) => v.toFixed(2)}
            onChange={(temperature) => patch({ temperature })}
            className="w-[260px]"
          />
        </Field>
        <Field label="Top-p" hint="Nucleus sampling probability mass. Leave at 1.00 when tuning temperature.">
          <Slider
            value={prefs.topP}
            min={0.1}
            max={1}
            step={0.05}
            label="Top-p"
            format={(v) => v.toFixed(2)}
            onChange={(topP) => patch({ topP })}
            className="w-[260px]"
          />
        </Field>
        <Field label="Presence penalty" hint="Encourages introducing new concepts rather than revisiting prior ones.">
          <Slider
            value={prefs.presencePenalty}
            min={-2}
            max={2}
            step={0.1}
            label="Presence penalty"
            format={(v) => v.toFixed(1)}
            onChange={(presencePenalty) => patch({ presencePenalty })}
            className="w-[260px]"
          />
        </Field>
        <Field label="Frequency penalty" hint="Reduces verbatim word and phrase repetition.">
          <Slider
            value={prefs.frequencyPenalty}
            min={-2}
            max={2}
            step={0.1}
            label="Frequency penalty"
            format={(v) => v.toFixed(1)}
            onChange={(frequencyPenalty) => patch({ frequencyPenalty })}
            className="w-[260px]"
          />
        </Field>
      </Panel>

      <Panel title="Output & streaming">
        <Field label="Max output tokens" hint="Hard ceiling per assistant reply.">
          <Slider
            value={prefs.outputBudget}
            min={256}
            max={16384}
            step={256}
            label="Output budget"
            format={kfmt}
            onChange={(outputBudget) => patch({ outputBudget })}
            className="w-[260px]"
          />
        </Field>
        <Field label="Automatic retries" hint="Retry count on transient upstream network or rate-limit errors.">
          <NumberField
            value={prefs.maxRetries}
            min={0}
            max={6}
            ariaLabel="Retries"
            onChange={(maxRetries) => patch({ maxRetries })}
          />
        </Field>
        <Field label="Stop sequences" hint="Comma-separated (max 4). Use \\n for newline." align="start">
          <div className="w-[260px] space-y-2">
            <Input
              value={prefs.stopSequences}
              onChange={(e) => patch({ stopSequences: e.target.value })}
              placeholder="e.g. \\n\\n###, END_TURN"
              className="h-9 font-mono text-[12.5px]"
              aria-label="Stop sequences"
            />
            {stopList.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {stopList.slice(0, 4).map((s, idx) => (
                  <span
                    key={`${s}-${idx}`}
                    className="inline-flex items-center gap-1 rounded-md border bg-muted/60 px-1.5 py-0.5 font-mono text-[11px]"
                  >
                    {s}
                    <button
                      type="button"
                      aria-label={`Remove stop sequence ${s}`}
                      onClick={() => {
                        const next = stopList.filter((_, i) => i !== idx).join(", ");
                        patch({ stopSequences: next });
                      }}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <X size={10} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </Field>
        <Field label="Streaming reveal pacing" hint="Smooth eases fast token bursts for comfortable reading; Instant renders chunks immediately.">
          <Segmented
            ariaLabel="Reveal mode"
            value={prefs.reveal}
            onChange={(reveal) => patch({ reveal })}
            options={[
              { value: "smooth", label: "Smooth" },
              { value: "off", label: "Instant" },
            ]}
          />
        </Field>
      </Panel>

      <Panel
        title="Workspace system prompt"
        hint="Fallback instructions used when an agent has no custom system prompt. Variables expand on the server per turn."
        actions={
          <span className="font-mono text-[11px] text-muted-foreground">
            ~{Math.ceil((prefs.systemPrompt?.length ?? 0) / 4)} tok
          </span>
        }
        dense
      >
        <div className="p-3">
          <Textarea
            value={prefs.systemPrompt}
            onChange={(e) => patch({ systemPrompt: e.target.value })}
            rows={5}
            placeholder="You are Nova, a precise and thoughtful engineering assistant…"
            className="resize-y text-[13px]"
          />
          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <span className="text-[12px] text-muted-foreground">Insert variable:</span>
            {["{{model}}", "{{agent}}", "{{date}}", "{{memories}}", "{{skills}}"].map((token) => (
              <button
                key={token}
                type="button"
                onClick={() =>
                  patch({
                    systemPrompt: `${prefs.systemPrompt}${
                      prefs.systemPrompt.endsWith(" ") || !prefs.systemPrompt ? "" : " "
                    }${token}`,
                  })
                }
                className="rounded-md border bg-card px-2 py-0.5 font-mono text-[11px] text-muted-foreground transition hover:border-foreground/25 hover:text-foreground active:scale-95"
              >
                {token}
              </button>
            ))}
            {prefs.systemPrompt && (
              <button
                type="button"
                onClick={() => patch({ systemPrompt: "" })}
                className="ml-auto text-[11.5px] text-muted-foreground hover:text-foreground"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </Panel>
    </div>
  );
}

/* ── Tools ────────────────────────────────────────────────────────────────── */

const SANDBOX_TOOLS: Array<{
  id: string;
  label: string;
  placeholder: string;
  defaultInput: string;
  needsInput: boolean;
}> = [
  { id: "calculator", label: "calculator", placeholder: "(128 + 46) * 3", defaultInput: "(128 + 46) * 3", needsInput: true },
  { id: "currentTime", label: "currentTime", placeholder: "No input required", defaultInput: "", needsInput: false },
  { id: "webSearch", label: "webSearch", placeholder: "Search query, e.g. PostgreSQL 17", defaultInput: "Next.js App Router", needsInput: true },
  { id: "webFetch", label: "webFetch", placeholder: "https://example.com", defaultInput: "https://example.com", needsInput: true },
  { id: "fetchUrl", label: "fetchUrl", placeholder: "https://example.com", defaultInput: "https://example.com", needsInput: true },
  { id: "recall", label: "recall", placeholder: "Keyword to recall from memory", defaultInput: "preference", needsInput: true },
  { id: "searchHistory", label: "searchHistory", placeholder: "Keyword in past chats", defaultInput: "hello", needsInput: true },
  { id: "listTasks", label: "listTasks", placeholder: "all | open | done", defaultInput: "all", needsInput: true },
  { id: "loadSkill", label: "loadSkill", placeholder: "Skill slug, e.g. research-brief", defaultInput: "research-brief", needsInput: true },
];

export function ToolsSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  const off = new Set(prefs.disabledTools);
  const toggle = (name: string, enabled: boolean) => {
    const next = new Set(off);
    if (enabled) next.delete(name);
    else next.add(name);
    patch({ disabledTools: [...next] });
  };
  const groups = ["core", "web", "memory", "skills", "workspace"] as const;
  const enabledCount = TOOL_META.length - TOOL_META.filter((t) => off.has(t.name)).length;

  return (
    <div className="space-y-5">
      <Panel
        title="Global tool switches"
        hint="Disabling a tool here blocks every agent from calling it, even in existing threads."
        actions={
          <div className="flex items-center gap-2">
            <span className="font-mono text-[11.5px] text-muted-foreground">
              {enabledCount}/{TOOL_META.length} enabled
            </span>
            {off.size > 0 && (
              <Button size="xs" variant="outline" onClick={() => patch({ disabledTools: [] })}>
                <RotateCcw size={11} /> Enable all
              </Button>
            )}
          </div>
        }
        dense
      >
        <div className="divide-y">
          {groups.map((group) => {
            const items = TOOL_META.filter((t) => t.group === group);
            if (!items.length) return null;
            return (
              <div key={group} className="px-3.5 py-3">
                <p className="mb-2 text-[10.5px] font-semibold uppercase tracking-[0.09em] text-muted-foreground">
                  {TOOL_GROUP_LABELS[group] ?? group}
                </p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {items.map((tool) => {
                    const enabled = !off.has(tool.name);
                    return (
                      <div
                        key={tool.name}
                        className={cn(
                          "flex items-start gap-3 rounded-xl border px-3 py-2.5 transition",
                          enabled ? "border-border/60 bg-muted/35" : "border-border bg-card opacity-75",
                        )}
                      >
                        <span
                          className={cn(
                            "mt-1.5 size-2 shrink-0 rounded-full transition-colors",
                            enabled ? "bg-emerald-500" : "bg-muted-foreground/30",
                          )}
                        />
                        <span className="min-w-0 flex-1">
                          <span className="block font-mono text-[12px] font-medium">{tool.name}</span>
                          <span className="mt-0.5 block text-[11.5px] leading-snug text-muted-foreground">
                            {tool.description}
                          </span>
                        </span>
                        <Switch
                          checked={enabled}
                          onCheckedChange={(v) => toggle(tool.name, v)}
                          aria-label={`Enable ${tool.name}`}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      <Panel title="Execution limits">
        <Field label="Web search results" hint="Default result count requested from your search provider.">
          <NumberField
            value={prefs.searchResults}
            min={1}
            max={10}
            ariaLabel="Search results"
            onChange={(searchResults) => patch({ searchResults })}
          />
        </Field>
        <Field label="Page read size cap" hint="Maximum payload read per page before clean truncation.">
          <NumberField
            value={prefs.fetchMaxKb}
            min={10}
            max={500}
            step={10}
            suffix="KB"
            ariaLabel="Fetch size limit"
            onChange={(fetchMaxKb) => patch({ fetchMaxKb })}
          />
        </Field>
        <Field label="Page fetch timeout" hint="Abort stalled page fetches after this many seconds.">
          <NumberField
            value={prefs.fetchTimeoutSec}
            min={3}
            max={60}
            step={1}
            suffix="s"
            ariaLabel="Fetch timeout"
            onChange={(fetchTimeoutSec) => patch({ fetchTimeoutSec })}
          />
        </Field>
      </Panel>

      <Collapsible
        title="Interactive tool sandbox"
        hint="Execute any tool directly on the server against your live workspace configuration."
        defaultOpen
        badge={
          <span className="rounded-full bg-brand/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-brand">
            live
          </span>
        }
      >
        <SandboxTester />
      </Collapsible>
    </div>
  );
}

function SandboxTester() {
  const [toolId, setToolId] = useState(SANDBOX_TOOLS[0].id);
  const [input, setInput] = useState(SANDBOX_TOOLS[0].defaultInput);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<{
    ok: boolean;
    latencyMs: number;
    output: unknown;
  } | null>(null);

  const activeSpec = SANDBOX_TOOLS.find((t) => t.id === toolId) ?? SANDBOX_TOOLS[0];

  const run = async () => {
    setRunning(true);
    try {
      const res = await fetch("/api/tools/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tool: toolId, input }),
      });
      const data = (await res.json().catch(() => null)) as {
        ok?: boolean;
        latencyMs?: number;
        output?: unknown;
        error?: { message?: string };
      } | null;
      if (!res.ok) {
        setResult({
          ok: false,
          latencyMs: 0,
          output: { error: data?.error?.message ?? `HTTP ${res.status}` },
        });
        return;
      }
      setResult({
        ok: Boolean(data?.ok),
        latencyMs: data?.latencyMs ?? 0,
        output: data?.output ?? null,
      });
    } catch (e) {
      setResult({
        ok: false,
        latencyMs: 0,
        output: { error: e instanceof Error ? e.message : "Request failed" },
      });
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-3 p-3.5">
      <div className="flex flex-wrap gap-1.5">
        {SANDBOX_TOOLS.map((t) => {
          const active = t.id === toolId;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setToolId(t.id);
                setInput(t.defaultInput);
                setResult(null);
              }}
              aria-pressed={active}
              className={cn(
                "rounded-lg border px-2.5 py-1 font-mono text-[11.5px] transition",
                active
                  ? "border-foreground bg-foreground text-background"
                  : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
              )}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Input
          value={input}
          disabled={!activeSpec.needsInput}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void run();
          }}
          placeholder={activeSpec.placeholder}
          aria-label="Tool test input"
          className="h-9 min-w-[220px] flex-1 font-mono text-[12.5px]"
        />
        <Button size="sm" onClick={() => void run()} disabled={running}>
          {running ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
          Run {activeSpec.label}
        </Button>
      </div>

      {result && (
        <div className="overflow-hidden rounded-xl border bg-muted/25">
          <div className="flex items-center justify-between border-b px-3 py-1.5 text-[11.5px]">
            <span
              className={cn(
                "inline-flex items-center gap-1.5 font-medium",
                result.ok ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400",
              )}
            >
              <span className={cn("size-1.5 rounded-full", result.ok ? "bg-emerald-500" : "bg-amber-500")} />
              {result.ok ? "Completed" : "Returned warning / error"}
            </span>
            <span className="font-mono text-muted-foreground">{result.latencyMs} ms</span>
          </div>
          <pre className="scroll-slim max-h-[240px] overflow-auto p-3 font-mono text-[11.5px] leading-relaxed text-foreground">
            {JSON.stringify(result.output, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}

/* ── Context ───────────────────────────────────────────────────────────────── */

export function ContextSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  const preview = useMemo(
    () =>
      buildBreakdown({
        system: prefs.systemPrompt || "You are Nova, a precise assistant.",
        skillsIndex: prefs.showSkillsIndex ? "# Skills\n- four skills listed in the index" : "",
        memoryBlock: prefs.injectMemories
          ? `# Long-term memory\n${Array.from({ length: prefs.memoryLimit }, (_, i) => `- [fact] example remembered fact ${i + 1}`).join("\n")}`
          : "",
        history: Array.from({ length: Math.min(prefs.maxHistoryMessages, 24) }, () => ({
          role: "user",
          content: "An example conversation turn of roughly forty words of ordinary context.",
        })),
        settings: {
          maxHistoryMessages: prefs.maxHistoryMessages,
          injectMemories: prefs.injectMemories,
          memoryLimit: prefs.memoryLimit,
          includeSkills: prefs.showSkillsIndex,
          autoCompact: prefs.autoCompact,
          compactThreshold: prefs.compactThreshold,
          contextWindow: prefs.contextWindow,
          outputBudget: prefs.outputBudget,
        },
      }),
    [prefs],
  );

  const used = Math.round(preview.promptTokens + prefs.outputBudget);
  const ratio = prefs.contextWindow ? used / prefs.contextWindow : 0;

  return (
    <div className="space-y-5">
      <Panel title="Window & compaction budget" hint="Controls prompt assembly and when older messages are summarised.">
        <Field label="Model context window" hint="Your model's total token capacity. Drives the header meter and compaction threshold.">
          <Slider
            value={prefs.contextWindow}
            min={8192}
            max={1_000_000}
            step={8192}
            label="Context window"
            format={(v) => `${Math.round(v / 1000)}k`}
            onChange={(contextWindow) => patch({ contextWindow })}
            className="w-[280px]"
          />
        </Field>
        <Field label="History depth" hint="Maximum uncompacted messages sent per turn.">
          <Slider
            value={prefs.maxHistoryMessages}
            min={2}
            max={80}
            step={1}
            label="History depth"
            onChange={(maxHistoryMessages) => patch({ maxHistoryMessages })}
            className="w-[280px]"
          />
        </Field>
        <Field label="Auto-compact trigger" hint="Compaction runs once prompt + output budget reaches this share of the window.">
          <Slider
            value={prefs.compactThreshold}
            min={0.4}
            max={0.95}
            step={0.01}
            label="Compact threshold"
            format={(v) => `${Math.round(v * 100)}%`}
            onChange={(compactThreshold) => patch({ compactThreshold })}
            className="w-[280px]"
          />
        </Field>
        <Field label="Post-compaction target" hint="Target occupancy after folding older turns into the rolling summary.">
          <Slider
            value={prefs.compactTargetRatio}
            min={0.2}
            max={0.9}
            step={0.01}
            label="Compact target"
            format={(v) => `${Math.round(v * 100)}%`}
            onChange={(compactTargetRatio) => patch({ compactTargetRatio })}
            className="w-[280px]"
          />
        </Field>
        <Field label="Keep user/assistant pairs intact" hint="Never slice mid-exchange or start history with an orphan assistant turn.">
          <Switch checked={prefs.keepPairs} onCheckedChange={(keepPairs) => patch({ keepPairs })} aria-label="Keep whole exchanges" />
        </Field>
        <Field label="Automatic compaction" hint="Summarises dropped turns instead of discarding them silently.">
          <Switch checked={prefs.autoCompact} onCheckedChange={(autoCompact) => patch({ autoCompact })} aria-label="Auto-compact" />
        </Field>
      </Panel>

      <Panel
        title="Simulated prompt occupancy"
        hint="Live preview of token allocation using your current settings."
        actions={
          <span
            className={cn(
              "rounded-full px-2.5 py-0.5 font-mono text-[11px]",
              ratio > 1
                ? "bg-destructive/10 text-destructive"
                : ratio > prefs.compactThreshold
                  ? "bg-amber-500/10 text-amber-700 dark:text-amber-400"
                  : "bg-muted text-muted-foreground",
            )}
          >
            {Math.round(ratio * 100)}% of {Math.round(prefs.contextWindow / 1000)}k
          </span>
        }
      >
        <div className="space-y-3 p-3.5">
          <div className="flex h-2.5 w-full gap-0.5 overflow-hidden rounded-full bg-muted">
            {preview.segments.map((s) => (
              <div
                key={s.id}
                title={`${s.label}: ${s.tokens.toLocaleString()} tok`}
                className={cn("h-full rounded-full transition-[width] duration-300", SEG[s.id] ?? "bg-muted-foreground")}
                style={{ width: `${Math.max(1.5, (s.tokens / Math.max(1, prefs.contextWindow)) * 100)}%` }}
              />
            ))}
            <div
              title={`Output reserve: ${prefs.outputBudget.toLocaleString()} tok`}
              className="h-full rounded-full bg-amber-500/60 transition-[width] duration-300"
              style={{ width: `${Math.max(1.5, (prefs.outputBudget / Math.max(1, prefs.contextWindow)) * 100)}%` }}
            />
          </div>
          <ul className="flex flex-wrap gap-x-4 gap-y-1.5">
            {preview.segments.map((s) => (
              <li key={s.id} className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
                <span className={cn("size-2 rounded-[2px]", SEG[s.id] ?? "bg-muted-foreground")} />
                {s.label}
                <span className="font-mono text-foreground">{s.tokens.toLocaleString()}</span>
              </li>
            ))}
            <li className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
              <span className="size-2 rounded-[2px] bg-amber-500/60" />
              Output reserve
              <span className="font-mono text-foreground">{prefs.outputBudget.toLocaleString()}</span>
            </li>
            <li className="ml-auto text-[11.5px] text-muted-foreground">
              Headroom <span className="font-mono text-foreground">{Math.max(0, prefs.contextWindow - used).toLocaleString()}</span>
            </li>
          </ul>
        </div>
      </Panel>

      <Panel title="Header meter">
        <Field label="Show context meter in chat header" hint="Displays real-time prompt occupancy and per-conversation overrides.">
          <Switch checked={prefs.showContextMeter} onCheckedChange={(showContextMeter) => patch({ showContextMeter })} aria-label="Show context meter" />
        </Field>
        <Field label="Prefer provider-reported token counts" hint="Replaces local token estimates with exact usage once a turn completes.">
          <Switch checked={prefs.trustProviderTokens} onCheckedChange={(trustProviderTokens) => patch({ trustProviderTokens })} aria-label="Trust provider token counts" />
        </Field>
      </Panel>
    </div>
  );
}

const SEG: Record<string, string> = {
  system: "bg-slate-500",
  skills: "bg-purple-500",
  memory: "bg-teal-500",
  summary: "bg-indigo-500",
  history: "bg-brand",
  attachments: "bg-zinc-500",
};

/* ── Composer ─────────────────────────────────────────────────────────────── */

export function ComposerSection({ prefs, patch }: { prefs: Preferences; patch: Patch }) {
  const [notifPerm, setNotifPerm] = useState<NotificationPermission | "unsupported">("default");

  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      setNotifPerm("unsupported");
    } else {
      setNotifPerm(Notification.permission);
    }
  }, []);

  const toggleNotifications = async (next: boolean) => {
    if (!next) {
      patch({ notificationsEnabled: false });
      return;
    }
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "default") {
        const perm = await Notification.requestPermission();
        setNotifPerm(perm);
        if (perm === "denied") {
          toast.error("Notifications are blocked in your browser settings.");
          patch({ notificationsEnabled: false });
          return;
        }
      } else if (Notification.permission === "denied") {
        toast.error("Notifications are blocked in your browser settings.");
        return;
      }
    }
    patch({ notificationsEnabled: true });
  };

  return (
    <div className="space-y-5">
      <Panel title="Input & attachments">
        <Field label="Press Enter to send" hint="When off, Enter inserts a newline and Cmd/Ctrl + Enter sends.">
          <Switch checked={prefs.sendOnEnter} onCheckedChange={(sendOnEnter) => patch({ sendOnEnter })} aria-label="Enter sends" />
        </Field>
        <Field label="Autosave unsent drafts" hint="Preserves in-progress composer text locally across reloads.">
          <Switch checked={prefs.autosaveDrafts} onCheckedChange={(autosaveDrafts) => patch({ autosaveDrafts })} aria-label="Autosave drafts" />
        </Field>
        <Field label="Max attachment size" hint="Per text or code file attached via drag-and-drop or file picker.">
          <NumberField
            value={prefs.attachmentLimitKb}
            min={5}
            max={500}
            step={5}
            suffix="KB"
            ariaLabel="Attachment limit"
            onChange={(attachmentLimitKb) => patch({ attachmentLimitKb })}
          />
        </Field>
      </Panel>

      <Panel title="Completion feedback">
        <Field label="Play completion chime" hint="Synthesises a soft two-note tone via Web Audio when a reply finishes.">
          <div className="flex items-center gap-2">
            <Button
              size="xs"
              variant="outline"
              onClick={() => playCompletionChime()}
              title="Preview completion sound"
            >
              <Volume2 size={12} /> Preview
            </Button>
            <Switch
              checked={prefs.soundOnComplete}
              onCheckedChange={(soundOnComplete) => patch({ soundOnComplete })}
              aria-label="Sound on complete"
            />
          </div>
        </Field>
        <Field
          label="Desktop notifications"
          hint="Notifies you when a backgrounded reply finishes."
        >
          <div className="flex items-center gap-2">
            {notifPerm !== "unsupported" && (
              <span className="inline-flex items-center gap-1 rounded-full border bg-muted/50 px-2 py-0.5 text-[11px] text-muted-foreground">
                <Bell size={10} />
                {notifPerm === "granted" ? "Allowed" : notifPerm === "denied" ? "Blocked" : "Ask on enable"}
              </span>
            )}
            <Switch
              checked={prefs.notificationsEnabled}
              onCheckedChange={(v) => void toggleNotifications(v)}
              aria-label="Desktop notifications"
            />
          </div>
        </Field>
      </Panel>
    </div>
  );
}

/* ── Advanced ─────────────────────────────────────────────────────────────── */

export function AdvancedSection({ prefs, patch, onReset }: { prefs: Preferences; patch: Patch; onReset: () => void }) {
  const [newHeaderName, setNewHeaderName] = useState("");
  const [newHeaderValue, setNewHeaderValue] = useState("");
  const entries = useMemo(() => Object.entries(prefs.customHeaders), [prefs.customHeaders]);
  const validName = /^[A-Za-z0-9-_]{1,40}$/.test(newHeaderName.trim());

  const addHeader = () => {
    const k = newHeaderName.trim();
    if (!/^[A-Za-z0-9-_]{1,40}$/.test(k)) {
      toast.error("Header name may only contain letters, digits, hyphens and underscores.");
      return;
    }
    patch({
      customHeaders: {
        ...prefs.customHeaders,
        [k]: newHeaderValue.slice(0, 500),
      },
    });
    setNewHeaderName("");
    setNewHeaderValue("");
  };

  const removeHeader = (key: string) => {
    const next = { ...prefs.customHeaders };
    delete next[key];
    patch({ customHeaders: next });
  };

  const updateHeaderValue = (key: string, value: string) => {
    patch({
      customHeaders: {
        ...prefs.customHeaders,
        [key]: value.slice(0, 500),
      },
    });
  };

  return (
    <div className="space-y-5">
      <Panel title="Network & timeouts" hint="Applied to upstream model requests initiated by the server.">
        <Field label="Upstream request timeout" hint="Aborts a stalled provider stream after this many seconds.">
          <NumberField
            value={prefs.requestTimeout}
            min={5}
            max={300}
            step={5}
            suffix="s"
            ariaLabel="Request timeout"
            onChange={(requestTimeout) => patch({ requestTimeout })}
          />
        </Field>
      </Panel>

      <Panel
        title="Custom HTTP headers"
        hint="Sent with every model call (OpenAI, Anthropic, Gemini & OpenAI-compatible gateways)."
        actions={
          <Button
            size="xs"
            variant="outline"
            onClick={() =>
              patch({
                customHeaders: {
                  ...prefs.customHeaders,
                  "HTTP-Referer": typeof window !== "undefined" ? window.location.origin : "https://nova.local",
                  "X-Title": "Nova AI Workspace",
                },
              })
            }
          >
            <Sparkles size={11} /> + OpenRouter preset
          </Button>
        }
        dense
      >
        <div className="space-y-3 p-3.5">
          {entries.length > 0 ? (
            <div className="space-y-2">
              {entries.map(([key, value]) => (
                <div key={key} className="flex flex-wrap items-center gap-2">
                  <code className="flex h-9 min-w-[150px] items-center rounded-lg border bg-muted/45 px-3 font-mono text-[12px]">
                    {key}
                  </code>
                  <Input
                    value={value}
                    onChange={(e) => updateHeaderValue(key, e.target.value)}
                    placeholder="Header value"
                    className="h-9 min-w-[180px] flex-1 font-mono text-[12px]"
                    aria-label={`Value for header ${key}`}
                  />
                  <Button
                    size="icon-sm"
                    variant="ghost"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => removeHeader(key)}
                    aria-label={`Remove header ${key}`}
                  >
                    <Trash2 size={13} />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[12.5px] text-muted-foreground">
              No custom headers configured. Add gateway headers (such as <code className="font-mono">HTTP-Referer</code>,{" "}
              <code className="font-mono">X-Title</code> or Cloudflare AI Gateway headers) below.
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 border-t pt-3">
            <Input
              value={newHeaderName}
              onChange={(e) => setNewHeaderName(e.target.value)}
              placeholder="Header-Name"
              aria-label="New header name"
              className="h-9 w-[170px] font-mono text-[12px]"
            />
            <Input
              value={newHeaderValue}
              onChange={(e) => setNewHeaderValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && validName) addHeader();
              }}
              placeholder="Header value"
              aria-label="New header value"
              className="h-9 min-w-[180px] flex-1 font-mono text-[12px]"
            />
            <Button size="sm" variant="outline" disabled={!validName} onClick={addHeader}>
              <Plus size={13} /> Add header
            </Button>
          </div>
        </div>
      </Panel>

      <Panel title="Reset defaults">
        <Field label="Restore default preferences" hint="Resets all workspace settings to factory defaults. Conversations, keys, skills and memories are untouched.">
          <Button variant="outline" size="sm" onClick={onReset}>
            <SlidersHorizontal size={13} /> Reset all preferences
          </Button>
        </Field>
      </Panel>

      <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
        <Terminal size={13} />
        <span>Preferences are stored per workspace in PostgreSQL and enforced server-side on every request.</span>
      </div>
    </div>
  );
}
