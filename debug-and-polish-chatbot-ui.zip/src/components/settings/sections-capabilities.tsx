"use client";

import { useMemo, useState } from "react";
import { Download, Eraser, Globe, Pin, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Collapsible, Field, NumberField, Note, Panel, Segmented, Slider } from "./ui";
import SettingsSkills from "./settings-skills";
import SettingsMemory from "./settings-memory";
import { serializeSkillMarkdown } from "@/lib/skills-format";
import type { Preferences } from "@/lib/preferences-model";
import type { MemoryStats, Skill } from "@/lib/types";

type Patch = (values: Partial<Preferences>) => void;

/* ── Skills ────────────────────────────────────────────────────────────────── */

export function SkillsSection({
  prefs,
  patch,
  skills,
  onChanged,
}: {
  prefs: Preferences;
  patch: Patch;
  skills: Skill[];
  onChanged: () => void;
}) {
  const enabled = skills.filter((s) => s.enabled);
  const cost = useMemo(
    () =>
      enabled.reduce(
        (sum, s) => sum + Math.ceil(40 + (s.description.length + s.name.length + 12) / 4),
        0,
      ),
    [enabled],
  );

  const exportAll = () => {
    if (skills.length === 0) return toast.error("There is nothing to export yet.");
    const bundle = skills
      .map((s) =>
        serializeSkillMarkdown({
          name: s.name,
          description: s.description,
          instructions: s.instructions,
          tools: s.tools,
          emoji: s.emoji,
        }),
      )
      .join("\n\n---\n\n");
    const url = URL.createObjectURL(new Blob([bundle], { type: "text/markdown" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "nova-skills.md";
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${skills.length} skills`);
  };

  return (
    <div className="space-y-5">
      <Panel
        title="Index cost"
        hint="Progressive disclosure: only the one-line skill index is sent up front; full instructions load on demand."
        actions={
          <Button size="xs" variant="outline" onClick={exportAll}>
            <Download size={12} /> Export all
          </Button>
        }
        dense
      >
        <div className="grid grid-cols-3 divide-x">
          <Metric label="Enabled" value={String(enabled.length)} hint={`of ${skills.length} total`} />
          <Metric label="Index cost" value={`~${cost}`} hint="tokens / turn" />
          <Metric label="Total loads" value={String(skills.reduce((n, s) => n + s.useCount, 0))} hint="all time" />
        </div>
      </Panel>

      <Panel title="Behaviour">
        <Field label="Offer skills to agents" hint="Includes the enabled skill index in the system prompt.">
          <Switch checked={prefs.showSkillsIndex} onCheckedChange={(showSkillsIndex) => patch({ showSkillsIndex })} aria-label="Offer skills" />
        </Field>
        <Field label="Auto-load strongly matching skill" hint="Attaches a skill's instructions immediately when the user prompt closely matches its trigger.">
          <Switch checked={prefs.autoLoadSkill} onCheckedChange={(autoLoadSkill) => patch({ autoLoadSkill })} aria-label="Auto-load skill" />
        </Field>
        <Field label="Auto-load match threshold" hint="Minimum similarity score required for automatic attachment.">
          <Slider
            value={prefs.skillMatchThreshold}
            min={0.2}
            max={0.95}
            step={0.05}
            label="Match strength"
            format={(v) => `${Math.round(v * 100)}%`}
            onChange={(skillMatchThreshold) => patch({ skillMatchThreshold })}
            className="w-[240px]"
          />
        </Field>
        <Field label="Max skills per turn" hint="Hard cap on how many skills an agent may load in a single turn.">
          <NumberField
            value={prefs.maxSkillsPerTurn}
            min={1}
            max={5}
            ariaLabel="Skills per turn"
            onChange={(maxSkillsPerTurn) => patch({ maxSkillsPerTurn })}
          />
        </Field>
      </Panel>

      <section className="overflow-hidden rounded-2xl border bg-card shadow-xs">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-muted/30 px-4 py-3">
          <div className="min-w-0">
            <h3 className="text-[13.5px] font-semibold tracking-tight">Skill library</h3>
            <p className="mt-0.5 text-[12px] leading-snug text-muted-foreground">
              Read, author or import Agent Skills (<code className="font-mono">SKILL.md</code>) packs.
            </p>
          </div>
        </header>
        <div className="p-4">
          <SettingsSkills skills={skills} onChanged={onChanged} />
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="px-4 py-3">
      <p className="font-mono text-[19px] font-medium leading-none tracking-tight tabular-nums">{value}</p>
      <p className="mt-1.5 text-[10.5px] font-semibold uppercase tracking-[0.07em] text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-[11.5px] text-muted-foreground/80">{hint}</p>
    </div>
  );
}

/* ── Memory ───────────────────────────────────────────────────────────────── */

export function MemorySection({
  prefs,
  patch,
  stats,
  onChanged,
  onPrune,
}: {
  prefs: Preferences;
  patch: Patch;
  stats: MemoryStats | null;
  onChanged: () => void;
  onPrune: () => Promise<void> | void;
}) {
  const [pruning, setPruning] = useState(false);
  const [armedPrune, setArmedPrune] = useState(false);

  const handlePrune = async () => {
    if (!armedPrune) {
      setArmedPrune(true);
      setTimeout(() => setArmedPrune(false), 4000);
      return;
    }
    setArmedPrune(false);
    setPruning(true);
    try {
      await onPrune();
    } finally {
      setPruning(false);
    }
  };

  return (
    <div className="space-y-5">
      <Panel
        title="Overview"
        hint="Nova stores discrete facts and preferences, ranks them per turn, and injects only the highest-scoring items."
        dense
      >
        <div className="grid grid-cols-3 divide-x">
          <Metric label="Stored" value={String(stats?.total ?? 0)} hint={`${stats?.enabled ?? 0} enabled`} />
          <Metric label="Recalled" value={String(stats?.recalled ?? 0)} hint="total injections" />
          <Metric label="Store cap" value={String(prefs.memoryMaxItems)} hint="active limit" />
        </div>
      </Panel>

      <Panel title="Retrieval & ranking">
        <Field label="Inject memories into turns" hint="Adds top-ranked memories to the system prompt automatically.">
          <Switch checked={prefs.injectMemories} onCheckedChange={(injectMemories) => patch({ injectMemories })} aria-label="Inject memories" />
        </Field>
        <Field label="Memories per request" hint="0 disables automatic injection while keeping the recall tool available.">
          <Slider
            value={prefs.memoryLimit}
            min={0}
            max={20}
            step={1}
            label="Memories per request"
            onChange={(memoryLimit) => patch({ memoryLimit })}
            className="w-[240px]"
          />
        </Field>
        <Field label="Minimum relevance score" hint="Skip weakly related memories instead of spending context tokens.">
          <Slider
            value={prefs.memoryMinScore}
            min={0.05}
            max={0.8}
            step={0.01}
            label="Minimum score"
            format={(v) => v.toFixed(2)}
            onChange={(memoryMinScore) => patch({ memoryMinScore })}
            className="w-[240px]"
          />
        </Field>
        <Field label="Decay half-life" hint="How quickly older memories lose rank unless reinforced or pinned.">
          <Slider
            value={prefs.memoryHalfLifeDays}
            min={1}
            max={730}
            step={1}
            label="Half-life"
            format={(v) => `${v}d`}
            onChange={(memoryHalfLifeDays) => patch({ memoryHalfLifeDays })}
            className="w-[240px]"
          />
        </Field>
        <Field label="Reinforce on recall" hint="Recalled memories gain strength so helpful facts stay surfaced.">
          <Switch checked={prefs.memoryReinforce} onCheckedChange={(memoryReinforce) => patch({ memoryReinforce })} aria-label="Reinforce on recall" />
        </Field>
      </Panel>

      <Panel title="Extraction & storage limits">
        <Field label="Automatic extraction" hint="Extracts durable preferences, facts and corrections from your messages after each turn.">
          <Switch checked={prefs.autoExtractMemories} onCheckedChange={(autoExtractMemories) => patch({ autoExtractMemories })} aria-label="Extract automatically" />
        </Field>
        <Field label="Merge similarity" hint="Statements above this overlap update an existing memory instead of creating a duplicate.">
          <Slider
            value={prefs.memoryDedupe}
            min={0.2}
            max={0.95}
            step={0.01}
            label="Merge similarity"
            format={(v) => v.toFixed(2)}
            onChange={(memoryDedupe) => patch({ memoryDedupe })}
            className="w-[240px]"
          />
        </Field>
        <Field label="Maximum active memories" hint="Oldest unpinned, low-recall memories are auto-disabled once this cap is reached.">
          <NumberField
            value={prefs.memoryMaxItems}
            min={10}
            max={5000}
            step={25}
            ariaLabel="Maximum active memories"
            onChange={(memoryMaxItems) => patch({ memoryMaxItems })}
          />
        </Field>
        <Field label="Pinned priority" hint="Pinned memories bypass decay and receive a permanent ranking boost.">
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[11.5px] text-muted-foreground">
            <Pin size={11} /> Boost +0.15
          </span>
        </Field>
      </Panel>

      <SettingsMemory onChanged={onChanged} />

      <Collapsible title="Maintenance" hint="Non-destructive cleanup actions for large memory stores.">
        <Field label="Disable never-recalled memories" hint="Switches off memories with 0 recalls. They remain in PostgreSQL and can be re-enabled anytime.">
          <Button
            size="sm"
            variant={armedPrune ? "destructive" : "outline"}
            onClick={() => void handlePrune()}
            disabled={pruning}
          >
            <Eraser size={13} />
            {pruning ? "Working…" : armedPrune ? "Confirm disable unused" : "Disable unused"}
          </Button>
        </Field>
      </Collapsible>

      <Note>
        Memory is strictly isolated to this workspace. Another browser or profile never sees or recalls these records.
      </Note>
    </div>
  );
}

/* ── Integrations: web tool defaults ───────────────────────────────────────── */

export function WebSection({
  prefs,
  patch,
  activeSearch,
  activeReader,
}: {
  prefs: Preferences;
  patch: Patch;
  activeSearch: string | null;
  activeReader?: string | null;
}) {
  return (
    <div className="space-y-5">
      <Panel title="Web tool behaviour" hint="Controls how agents run webSearch, webFetch and fetchUrl.">
        <Field label="Active search provider" hint={activeSearch ? "Serving webSearch queries." : "Connect a provider above to enable webSearch."}>
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[12px]">
            <Sparkles size={11} className={activeSearch ? "text-emerald-500" : "text-muted-foreground"} />
            {activeSearch ?? "Not connected"}
          </span>
        </Field>
        <Field label="Active page reader" hint="Firecrawl or Jina converts pages into clean Markdown.">
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-[12px]">
            <Globe size={11} className={activeReader ? "text-emerald-500" : "text-muted-foreground"} />
            {activeReader ?? "Direct fetch fallback"}
          </span>
        </Field>
        <Field label="Results per search query" hint="Default result count passed to your search provider.">
          <NumberField
            value={prefs.searchResults}
            min={1}
            max={10}
            ariaLabel="Results per query"
            onChange={(searchResults) => patch({ searchResults })}
          />
        </Field>
        <Field label="Page reader strategy" hint="Auto prefers Firecrawl (if stored), then Jina Reader, then SSRF-guarded direct fetch.">
          <Segmented
            size="sm"
            ariaLabel="Reader mode"
            value={prefs.readerMode}
            onChange={(readerMode) => patch({ readerMode })}
            options={[
              { value: "auto", label: "Auto" },
              { value: "firecrawl", label: "Firecrawl" },
              { value: "jina", label: "Jina" },
              { value: "direct", label: "Direct" },
            ]}
          />
        </Field>
      </Panel>
    </div>
  );
}
