"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Bot,
  Check,
  Copy,
  Loader2,
  Plus,
  Search,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { AgentIcon } from "../agent-icon";
import { AGENT_ICONS } from "@/lib/agent-icons";
import { TOOL_GROUP_LABELS, TOOL_META } from "@/lib/tool-meta";
import { ActivePill, Field, Panel, Segmented, Slider } from "./ui";
import { cn } from "@/lib/utils";
import type { Agent, Skill } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-model";

type MemoryMode = "auto" | "on" | "off";

interface Draft {
  name: string;
  description: string;
  systemPrompt: string;
  model: string;
  temperature: number;
  maxSteps: number;
  tools: string[];
  icon: string;
  memoryMode: MemoryMode;
  skills: string[] | null;
}

const BLANK: Draft = {
  name: "",
  description: "",
  systemPrompt: "",
  model: "",
  temperature: 0.7,
  maxSteps: 5,
  tools: ["calculator", "currentTime"],
  icon: "bot",
  memoryMode: "auto",
  skills: null,
};

function toDraft(agent: Agent): Draft {
  return {
    name: agent.name,
    description: agent.description,
    systemPrompt: agent.systemPrompt,
    model: agent.model ?? "",
    temperature: agent.temperature,
    maxSteps: agent.maxSteps,
    tools: [...agent.tools],
    icon: agent.icon || "bot",
    memoryMode: (agent.memoryMode ?? "auto") as MemoryMode,
    skills: agent.skills ? [...agent.skills] : null,
  };
}

export default function SettingsAgents({
  agents,
  skills,
  prefs,
  patchPrefs,
  onChanged,
}: {
  agents: Agent[];
  skills: Skill[];
  prefs: Preferences;
  patchPrefs: (values: Partial<Preferences>) => void;
  onChanged: () => void | Promise<void>;
}) {
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(agents[0]?.id ?? null);
  const [newDraft, setNewDraft] = useState<Draft | null>(null);
  const [edits, setEdits] = useState<Partial<Draft>>({});
  const [saving, setSaving] = useState(false);
  const [armedDelete, setArmedDelete] = useState(false);

  useEffect(() => {
    if (!newDraft && (!selectedId || !agents.some((a) => a.id === selectedId)) && agents.length > 0) {
      const def = agents.find((a) => a.isDefault) ?? agents[0];
      setSelectedId(def.id);
      setEdits({});
    }
  }, [agents, newDraft, selectedId]);

  const current = useMemo(
    () => (newDraft ? null : agents.find((a) => a.id === selectedId) ?? null),
    [agents, newDraft, selectedId],
  );

  const form: Draft | null = useMemo(() => {
    if (newDraft) return newDraft;
    if (!current) return null;
    return { ...toDraft(current), ...edits };
  }, [current, edits, newDraft]);

  const dirty = useMemo(() => {
    if (newDraft) return true;
    if (!current || !form) return false;
    return JSON.stringify(toDraft(current)) !== JSON.stringify(form);
  }, [current, form, newDraft]);

  const patch = (values: Partial<Draft>) => {
    if (newDraft) {
      setNewDraft((prev) => ({ ...(prev ?? BLANK), ...values }));
    } else {
      setEdits((prev) => ({ ...prev, ...values }));
    }
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return agents;
    return agents.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.description.toLowerCase().includes(q) ||
        a.tools.some((t) => t.toLowerCase().includes(q)),
    );
  }, [agents, query]);

  const startNew = (seed?: Partial<Draft>) => {
    setSelectedId(null);
    setEdits({});
    setArmedDelete(false);
    setNewDraft({ ...BLANK, ...seed });
  };

  const selectAgent = (agent: Agent) => {
    setNewDraft(null);
    setEdits({});
    setArmedDelete(false);
    setSelectedId(agent.id);
  };

  const save = async () => {
    if (!form) return;
    if (!form.name.trim()) {
      toast.error("Give the agent a name");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        systemPrompt: form.systemPrompt,
        model: form.model.trim() || null,
        temperature: form.temperature,
        maxSteps: form.maxSteps,
        tools: form.tools,
        icon: form.icon,
        memoryMode: form.memoryMode,
        skills: form.skills,
      };
      const res = newDraft
        ? await fetch("/api/agents", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch(`/api/agents/${current!.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = (await res.json().catch(() => null)) as {
        agent?: Agent;
        error?: { message?: string };
      } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Could not save agent.");
      toast.success(newDraft ? "Agent created" : "Agent updated");
      const createdId = data?.agent?.id;
      setNewDraft(null);
      setEdits({});
      await onChanged();
      if (createdId) setSelectedId(createdId);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save agent.");
    } finally {
      setSaving(false);
    }
  };

  const makeDefault = async (agent: Agent) => {
    try {
      const res = await fetch(`/api/agents/${agent.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isDefault: true }),
      });
      if (!res.ok) throw new Error("Failed");
      patchPrefs({ defaultAgentId: agent.id });
      toast.success(`${agent.name} set as default agent`);
      await onChanged();
    } catch {
      toast.error("Could not set default agent");
    }
  };

  const remove = async () => {
    if (!current) return;
    if (!armedDelete) {
      setArmedDelete(true);
      setTimeout(() => setArmedDelete(false), 4000);
      return;
    }
    setArmedDelete(false);
    const res = await fetch(`/api/agents/${current.id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not delete agent");
      return;
    }
    if (prefs.defaultAgentId === current.id) {
      patchPrefs({ defaultAgentId: null });
    }
    toast.success(`Deleted ${current.name}`);
    setSelectedId(null);
    await onChanged();
  };

  const toggleTool = (name: string) => {
    if (!form) return;
    const has = form.tools.includes(name);
    patch({ tools: has ? form.tools.filter((t) => t !== name) : [...form.tools, name] });
  };

  // The server's isDefault flag is the source of truth; the preference mirrors it.
  const defaultAgent = agents.find((a) => a.isDefault) ?? agents.find((a) => a.id === prefs.defaultAgentId) ?? null;

  return (
    <div className="space-y-5">
      <Panel
        title="Workspace default"
        hint="Used for new conversations when no specific agent is chosen."
        actions={
          <Button size="sm" onClick={() => startNew()}>
            <Plus size={14} /> New agent
          </Button>
        }
      >
        <Field label="Default agent for new chats" hint="Switchable per message inside the composer.">
          <select
            aria-label="Default agent"
            value={defaultAgent?.id ?? ""}
            onChange={(e) => {
              const chosen = agents.find((a) => a.id === e.target.value);
              if (chosen) void makeDefault(chosen);
            }}
            className="h-9 min-w-[200px] rounded-lg border border-input bg-card px-3 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {agents.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} ({a.tools.length} tools)
              </option>
            ))}
          </select>
        </Field>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-[236px_minmax(0,1fr)]">
        {/* Agent list */}
        <div className="min-w-0">
          <div className="relative mb-2.5">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`Search ${agents.length} agents`}
              aria-label="Search agents"
              className="h-9 pl-8 text-[13px]"
            />
          </div>

          <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:block lg:max-h-[62vh] lg:space-y-1 lg:overflow-y-auto lg:pr-1">
            {filtered.map((agent) => {
              const active = !newDraft && selectedId === agent.id;
              return (
                <button
                  key={agent.id}
                  type="button"
                  onClick={() => selectAgent(agent)}
                  aria-current={active ? "true" : undefined}
                  className={cn(
                    "relative isolate flex w-[184px] shrink-0 items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-[13px] outline-none transition-colors lg:w-full",
                    active ? "font-medium text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {active && <ActivePill id="settings-agent-pill" />}
                  <span
                    className={cn(
                      "relative z-10 flex size-7 shrink-0 items-center justify-center rounded-lg",
                      active ? "bg-foreground text-background" : "bg-muted text-foreground/80",
                    )}
                  >
                    <AgentIcon icon={agent.icon} size={14} />
                  </span>
                  <span className="relative z-10 min-w-0 flex-1">
                    <span className="block truncate">{agent.name}</span>
                    <span className="hidden truncate text-[11px] text-muted-foreground lg:block">
                      {agent.tools.length} tools · {agent.maxSteps} steps
                    </span>
                  </span>
                  {agent.isDefault && (
                    <Star size={12} className="relative z-10 shrink-0 fill-brand text-brand" />
                  )}
                </button>
              );
            })}
            {filtered.length === 0 && (
              <p className="px-2.5 py-6 text-[12.5px] text-muted-foreground">
                No agents match “{query}”.
              </p>
            )}
          </div>
        </div>

        {/* Agent editor */}
        <div className="min-w-0">
          {form ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card px-4 py-3 shadow-xs">
                <div className="flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-xl bg-foreground text-background">
                    <AgentIcon icon={form.icon} size={18} />
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-[15.5px] font-semibold tracking-tight">
                        {newDraft ? "Create new agent" : current?.name}
                      </h3>
                      {current?.isDefault && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-brand/30 bg-brand/10 px-2 py-0.5 text-[10.5px] font-medium text-brand">
                          <Star size={10} className="fill-current" /> Default
                        </span>
                      )}
                      {dirty && !newDraft && (
                        <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[10.5px] font-medium text-amber-700 dark:text-amber-400">
                          Modified
                        </span>
                      )}
                    </div>
                    <p className="text-[12px] text-muted-foreground">
                      {newDraft
                        ? "Configure tools, prompt and loop budget for a reusable persona."
                        : `${form.tools.length} tools enabled · ${form.maxSteps} max steps`}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {current && !current.isDefault && (
                    <Button size="xs" variant="outline" onClick={() => void makeDefault(current)}>
                      <Star size={12} /> Set default
                    </Button>
                  )}
                  {current && (
                    <Button
                      size="xs"
                      variant="ghost"
                      onClick={() =>
                        startNew({
                          ...toDraft(current),
                          name: `${current.name} (Copy)`,
                        })
                      }
                      title="Duplicate agent"
                    >
                      <Copy size={12} /> Duplicate
                    </Button>
                  )}
                  {newDraft && (
                    <Button
                      size="xs"
                      variant="ghost"
                      onClick={() => {
                        setNewDraft(null);
                        if (agents[0]) setSelectedId(agents[0].id);
                      }}
                    >
                      <X size={12} /> Cancel
                    </Button>
                  )}
                </div>
              </div>

              <Panel title="Identity">
                <Field label="Name" htmlFor="agent-ed-name">
                  <Input
                    id="agent-ed-name"
                    value={form.name}
                    onChange={(e) => patch({ name: e.target.value })}
                    placeholder="e.g. Security Reviewer"
                    className="h-9 w-[260px] text-[13px]"
                  />
                </Field>
                <Field label="Icon" hint="Displayed in the composer, header and agent cards.">
                  <div className="flex flex-wrap gap-1.5">
                    {AGENT_ICONS.map((icon) => {
                      const active = form.icon === icon;
                      return (
                        <button
                          key={icon}
                          type="button"
                          onClick={() => patch({ icon })}
                          aria-label={`Icon ${icon}`}
                          aria-pressed={active}
                          className={cn(
                            "flex size-8 items-center justify-center rounded-lg border transition",
                            active
                              ? "border-foreground bg-foreground text-background"
                              : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                          )}
                        >
                          <AgentIcon icon={icon} size={15} />
                        </button>
                      );
                    })}
                  </div>
                </Field>
                <Field label="Description" hint="Shown when choosing an agent in chat." align="start">
                  <Input
                    value={form.description}
                    onChange={(e) => patch({ description: e.target.value })}
                    placeholder="Concise summary of what this agent specialises in"
                    className="h-9 w-[min(360px,65vw)] text-[13px]"
                  />
                </Field>
              </Panel>

              <Panel title="Model & execution" hint="Leave Model blank to inherit your active workspace model.">
                <Field label="Model override" hint="Optional model ID specific to this agent.">
                  <div className="flex w-[260px] items-center gap-1.5">
                    <Input
                      value={form.model}
                      onChange={(e) => patch({ model: e.target.value })}
                      placeholder={prefs.defaultModel || "Inherit workspace model"}
                      className="h-9 font-mono text-[12.5px]"
                    />
                    {form.model && (
                      <button
                        type="button"
                        onClick={() => patch({ model: "" })}
                        title="Clear override"
                        className="rounded-md p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
                      >
                        <X size={13} />
                      </button>
                    )}
                  </div>
                </Field>
                <Field label="Temperature" hint="Lower is analytical; higher is creative.">
                  <Slider
                    value={form.temperature}
                    min={0}
                    max={2}
                    step={0.05}
                    label="Agent temperature"
                    format={(v) => v.toFixed(2)}
                    onChange={(temperature) => patch({ temperature })}
                    className="w-[240px]"
                  />
                </Field>
                <Field label="Max tool steps" hint="Maximum tool-call turns per reply before answering.">
                  <Slider
                    value={form.maxSteps}
                    min={1}
                    max={20}
                    step={1}
                    label="Max tool steps"
                    onChange={(maxSteps) => patch({ maxSteps })}
                    className="w-[240px]"
                  />
                </Field>
                <Field label="Long-term memory" hint="Auto lets the agent save, recall and forget facts.">
                  <Segmented
                    size="sm"
                    ariaLabel="Memory mode"
                    value={form.memoryMode}
                    onChange={(memoryMode) => patch({ memoryMode })}
                    options={[
                      { value: "auto", label: "Auto" },
                      { value: "on", label: "Read/Save" },
                      { value: "off", label: "Off" },
                    ]}
                  />
                </Field>
              </Panel>

              <Panel title="System prompt" hint="Overrides the workspace system prompt. Variables expand per request." dense>
                <div className="p-3">
                  <Textarea
                    value={form.systemPrompt}
                    onChange={(e) => patch({ systemPrompt: e.target.value })}
                    rows={5}
                    placeholder="You are a focused specialist…"
                    className="resize-y text-[13px]"
                  />
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11.5px] text-muted-foreground">Insert variable:</span>
                    {["{{agent}}", "{{model}}", "{{date}}", "{{memories}}", "{{skills}}"].map((tok) => (
                      <button
                        key={tok}
                        type="button"
                        onClick={() =>
                          patch({
                            systemPrompt: `${form.systemPrompt}${
                              !form.systemPrompt || form.systemPrompt.endsWith(" ") ? "" : " "
                            }${tok}`,
                          })
                        }
                        className="rounded border bg-muted/40 px-1.5 py-0.5 font-mono text-[11px] text-muted-foreground transition hover:border-foreground/25 hover:text-foreground"
                      >
                        {tok}
                      </button>
                    ))}
                  </div>
                </div>
              </Panel>

              <Panel title="Tools" hint="Tools disabled globally in Settings → Tools remain blocked.">
                <div className="divide-y">
                  {(["core", "web", "memory", "workspace"] as const).map((group) => {
                    const items = TOOL_META.filter((t) => t.group === group);
                    if (!items.length) return null;
                    return (
                      <div key={group} className="px-3 py-3">
                        <p className="mb-2 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                          {TOOL_GROUP_LABELS[group]}
                        </p>
                        <div className="grid gap-1.5 sm:grid-cols-2">
                          {items.map((tool) => {
                            const checked = form.tools.includes(tool.name);
                            const globallyOff = prefs.disabledTools.includes(tool.name);
                            return (
                              <button
                                key={tool.name}
                                type="button"
                                onClick={() => toggleTool(tool.name)}
                                aria-pressed={checked}
                                className={cn(
                                  "flex items-start gap-2.5 rounded-xl border px-3 py-2 text-left transition",
                                  checked
                                    ? "border-foreground/25 bg-accent/60"
                                    : "border-border/70 bg-card hover:border-foreground/20",
                                  globallyOff && "opacity-55",
                                )}
                              >
                                <span
                                  className={cn(
                                    "mt-1 flex size-4 shrink-0 items-center justify-center rounded border text-[10px]",
                                    checked
                                      ? "border-foreground bg-foreground text-background"
                                      : "border-muted-foreground/40",
                                  )}
                                >
                                  {checked && <Check size={10} />}
                                </span>
                                <span className="min-w-0 flex-1">
                                  <span className="flex items-center gap-1.5 font-mono text-[12px] font-medium">
                                    {tool.name}
                                    {globallyOff && (
                                      <span className="rounded bg-amber-500/15 px-1 py-px font-sans text-[10px] text-amber-700 dark:text-amber-400">
                                        disabled globally
                                      </span>
                                    )}
                                  </span>
                                  <span className="mt-0.5 block text-[11.5px] leading-snug text-muted-foreground">
                                    {tool.description}
                                  </span>
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Panel>

              {skills.length > 0 && (
                <Panel title="Skills scope" hint="Restrict this agent to specific skills, or allow all enabled skills.">
                  <Field label="Allow all enabled workspace skills">
                    <Switch
                      checked={form.skills === null}
                      onCheckedChange={(all) => patch({ skills: all ? null : skills.filter((s) => s.enabled).map((s) => s.name) })}
                      aria-label="Allow all skills"
                    />
                  </Field>
                  {form.skills !== null && (
                    <div className="flex flex-wrap gap-1.5 px-3 py-3">
                      {skills.map((s) => {
                        const active = form.skills?.includes(s.name) ?? false;
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => {
                              const list = form.skills ?? [];
                              patch({
                                skills: active ? list.filter((n) => n !== s.name) : [...list, s.name],
                              });
                            }}
                            aria-pressed={active}
                            className={cn(
                              "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[12px] transition",
                              active
                                ? "border-foreground bg-foreground text-background"
                                : "bg-card text-muted-foreground hover:text-foreground",
                            )}
                          >
                            <span>{s.emoji}</span>
                            <span className="font-mono">{s.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </Panel>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <Button onClick={() => void save()} disabled={!dirty || saving}>
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                  {newDraft ? "Create agent" : dirty ? "Save agent" : "Saved"}
                </Button>
                {dirty && !newDraft && (
                  <Button variant="ghost" size="sm" onClick={() => setEdits({})}>
                    Discard edits
                  </Button>
                )}
                {current && agents.length > 1 && (
                  <Button
                    size="sm"
                    variant={armedDelete ? "destructive" : "ghost"}
                    className={cn("ml-auto", !armedDelete && "text-muted-foreground hover:text-destructive")}
                    onClick={() => void remove()}
                  >
                    <Trash2 size={13} />
                    {armedDelete ? `Confirm delete "${current.name}"` : "Delete agent"}
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center rounded-2xl border border-dashed px-6 py-14 text-center">
              <Bot size={22} className="text-muted-foreground" />
              <p className="mt-3 text-[14px] font-medium">Select an agent or create a new one</p>
              <Button size="sm" className="mt-4" onClick={() => startNew()}>
                <Plus size={14} /> New agent
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
