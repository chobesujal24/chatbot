"use client";

import Link from "next/link";
import { Keyboard, Settings2 } from "lucide-react";
import {
  IconDownload,
  IconDots,
  IconFile,
  IconFork,
  IconLink,
  IconPanelLeft,
  IconPanelLeftOpen,
  IconPencil,
  IconPin,
  IconPinOff,
  IconSearch,
  IconSettingsSliders,
  IconTrash,
} from "./sidebar-icons";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { Code2 } from "lucide-react";
import { AgentIcon } from "./agent-icon";
import ContextMeter from "./context-meter";
import { cn } from "@/lib/utils";
import type { Agent, ConversationContext } from "@/lib/types";

interface HeaderProps {
  title: string | null;
  activeId: string | null;
  isHome?: boolean;
  pinned: boolean;
  sidebarOpen: boolean;
  sidebarCollapsed?: boolean;
  selectedAgent: Agent | null;
  model: string;
  providerLabel: string;
  hasProvider: boolean;
  onToggleSidebar: () => void;
  onOpenPalette: () => void;
  onOpenShortcuts: () => void;
  onShare: () => void;
  onExport: (format: "md" | "json") => void;
  onFork: () => void;
  onRename: () => void;
  onTogglePin: () => void;
  onDelete: () => void;
  onOpenSettings: () => void;
  context: ConversationContext | null;
  compacting: boolean;
  onCompact: () => void;
  onContextOverride: (patch: Record<string, unknown>) => void;
  onContextReset: () => void;
  showMeter?: boolean;
  codePanelOpen?: boolean;
  onToggleCodePanel?: () => void;
}

const iconButton =
  "flex size-8 items-center justify-center rounded-lg text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95 focus-visible:ring-2 focus-visible:ring-ring";

export default function Header(props: HeaderProps) {
  const showDesktopToggle = props.sidebarCollapsed;
  const isHome = Boolean(props.isHome);

  return (
    <TooltipProvider delayDuration={200}>
      <header
        className={cn(
          "relative z-20 flex h-13 shrink-0 items-center justify-between gap-3 px-3 sm:px-5",
          isHome
            ? "border-b border-transparent bg-transparent"
            : "border-b border-border/70 bg-background/85 backdrop-blur-xl",
        )}
      >
        {/* Left cluster */}
        <div className="flex min-w-0 items-center gap-2">
          <div className={cn("flex items-center", !showDesktopToggle && "lg:hidden")}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={props.onToggleSidebar}
                  aria-label={props.sidebarCollapsed ? "Expand sidebar" : "Toggle sidebar"}
                  className={iconButton}
                >
                  {props.sidebarCollapsed ? (
                    <IconPanelLeftOpen size={18} />
                  ) : (
                    <IconPanelLeft size={18} />
                  )}
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" align="start" className="flex items-center gap-2">
                <span>{props.sidebarCollapsed ? "Expand sidebar" : "Toggle sidebar"}</span>
                <kbd className="font-mono text-[10px] opacity-60">⌘B</kbd>
              </TooltipContent>
            </Tooltip>
          </div>

          {!isHome && (
            <div className="flex min-w-0 items-center gap-2">
              <h1 className="min-w-0 truncate text-[14px] font-semibold tracking-[-0.01em] text-foreground">
                {props.title ?? "Conversation"}
              </h1>
              {props.selectedAgent && (
                <span className="hidden shrink-0 items-center gap-1.5 rounded-full border border-border/70 bg-muted/40 px-2.5 py-0.5 text-[11px] font-medium text-muted-foreground sm:inline-flex">
                  <AgentIcon icon={props.selectedAgent.icon} size={11} />
                  <span>{props.selectedAgent.name}</span>
                </span>
              )}
              {props.pinned && (
                <span className="hidden shrink-0 rounded-full bg-brand/10 px-2 py-0.5 text-[10px] font-medium text-brand md:inline">
                  Pinned
                </span>
              )}
            </div>
          )}
        </div>

        {/* Right cluster */}
        {isHome ? (
          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              onClick={props.onOpenPalette}
              aria-label="Command palette"
              className="inline-flex h-8 items-center gap-2 rounded-lg border border-border/70 bg-card/70 px-2.5 text-[12px] text-muted-foreground shadow-2xs backdrop-blur-sm transition hover:border-foreground/20 hover:bg-card hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
            >
              <IconSearch size={13} />
              <span className="hidden sm:inline">Command</span>
              <kbd className="rounded bg-muted/70 px-1.5 py-px font-mono text-[10px]">⌘K</kbd>
            </button>

            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={props.onOpenShortcuts}
                  aria-label="Keyboard shortcuts"
                  className={iconButton}
                >
                  <Keyboard size={15} />
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                Shortcuts <kbd className="ml-1 font-mono text-[10px] opacity-60">⌘/</kbd>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/settings" aria-label="Workspace settings" className={iconButton}>
                  <Settings2 size={15} />
                </Link>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                Settings <kbd className="ml-1 font-mono text-[10px] opacity-60">⌘,</kbd>
              </TooltipContent>
            </Tooltip>
          </div>
        ) : (
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              type="button"
              onClick={props.onOpenPalette}
              aria-label="Search conversations"
              title="Search (⌘K)"
              className={iconButton}
            >
              <IconSearch size={16} />
            </button>

            <button
              type="button"
              onClick={props.onOpenSettings}
              className={cn(
                "hidden items-center gap-2 rounded-lg border px-2.5 py-1 text-[12px] outline-none transition md:flex focus-visible:ring-2 focus-visible:ring-ring",
                props.hasProvider
                  ? "bg-card text-foreground shadow-2xs hover:border-foreground/25"
                  : "border-amber-500/35 bg-amber-500/10 text-amber-800 dark:text-amber-300",
              )}
              title={props.hasProvider ? "Model & quick tuning" : "Connect a provider"}
            >
              <span
                className={cn(
                  "size-1.5 shrink-0 rounded-full",
                  props.hasProvider ? "bg-emerald-500" : "bg-amber-500",
                )}
              />
              <span className="max-w-[150px] truncate font-mono text-[11px]">
                {props.hasProvider ? props.model : "Connect key"}
              </span>
            </button>

            {props.onToggleCodePanel && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={props.onToggleCodePanel}
                    aria-label="Toggle code workspace"
                    aria-pressed={props.codePanelOpen}
                    title="Code workspace"
                    className={cn(
                      "flex size-8 items-center justify-center rounded-lg outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring",
                      props.codePanelOpen
                        ? "bg-accent text-foreground"
                        : "text-muted-foreground hover:bg-accent hover:text-foreground",
                    )}
                  >
                    <Code2 size={15} />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom">Code workspace</TooltipContent>
              </Tooltip>
            )}

            {props.showMeter !== false && (
              <ContextMeter
                data={props.context}
                busy={false}
                compacting={props.compacting}
                onCompact={props.onCompact}
                onOverride={props.onContextOverride}
                onReset={props.onContextReset}
              />
            )}

            {props.activeId && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={props.onShare}
                    aria-label="Share conversation"
                    className={cn(iconButton, "hidden sm:flex")}
                  >
                    <IconLink size={15} />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom">Share snapshot</TooltipContent>
              </Tooltip>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  aria-label="Conversation options"
                  className={cn(iconButton, "data-[state=open]:bg-accent data-[state=open]:text-foreground")}
                >
                  <IconDots size={17} />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 p-1">
                <DropdownMenuItem onSelect={props.onRename} disabled={!props.activeId} className="rounded-lg">
                  <IconPencil size={14} /> Rename
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onTogglePin} disabled={!props.activeId} className="rounded-lg">
                  {props.pinned ? <IconPinOff size={14} /> : <IconPin size={14} />}
                  {props.pinned ? "Unpin from top" : "Pin to top"}
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onFork} disabled={!props.activeId} className="rounded-lg">
                  <IconFork size={14} /> Duplicate conversation
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onShare} disabled={!props.activeId} className="rounded-lg">
                  <IconLink size={14} /> Share snapshot
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => props.onExport("md")} disabled={!props.activeId} className="rounded-lg">
                  <IconFile size={14} /> Export as Markdown
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => props.onExport("json")} disabled={!props.activeId} className="rounded-lg">
                  <IconDownload size={14} /> Export as JSON
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={props.onOpenSettings} className="rounded-lg">
                  <IconSettingsSliders size={14} /> Model & quick tuning…
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  variant="destructive"
                  disabled={!props.activeId}
                  onSelect={props.onDelete}
                  className="rounded-lg"
                >
                  <IconTrash size={14} /> Delete conversation
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </header>
    </TooltipProvider>
  );
}
