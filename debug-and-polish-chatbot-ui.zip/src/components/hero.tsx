"use client";

import { useMemo, type ComponentProps } from "react";
import Link from "next/link";
import {
  ArrowUpRight,
  Code2,
  Database,
  Layers,
  LineChart,
  Plus,
  Sparkles,
} from "lucide-react";
import Composer from "./composer";
import { AgentIcon } from "./agent-icon";
import { Logo } from "./logo";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";

type ComposerProps = ComponentProps<typeof Composer>;

interface HeroProps extends Omit<ComposerProps, "variant"> {
  onSuggestion: (text: string) => void;
  onOpenQuickSetup?: () => void;
  providerLabel: string;
  hasProvider: boolean;
  prefs: Preferences;
  /** True when the code workspace is docked, so the hero must fit a narrower column. */
  compact?: boolean;
}

interface StarterCard {
  id: string;
  icon: typeof Code2;
  tint: string;
  title: string;
  subtitle: string;
  prompt: string;
}

const STARTERS: StarterCard[] = [
  {
    id: "retry",
    icon: Code2,
    tint: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    title: "Typed retry utility with backoff",
    subtitle: "AbortSignal cancellation, jitter & unit tests",
    prompt:
      "Write an abortable, exponential-backoff retry utility in TypeScript with clean generics, jitter, AbortSignal cancellation, and Vitest unit tests.",
  },
  {
    id: "sql",
    icon: Database,
    tint: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    title: "PostgreSQL indexing trade-offs",
    subtitle: "B-tree vs GIN vs BRIN with DDL benchmarks",
    prompt:
      "Compare B-tree, GIN, GiST and BRIN indexing strategies in PostgreSQL for a high-ingest event table. Include concrete DDL and query plans in a Markdown table.",
  },
  {
    id: "economics",
    icon: LineChart,
    tint: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    title: "Model throughput & token budget",
    subtitle: "TPM capacity and monthly cost breakdown",
    prompt:
      "Calculate the monthly token volume, peak tokens-per-minute (TPM), and cost comparison for 25,000 daily requests averaging 500 input tokens and 650 output tokens.",
  },
  {
    id: "audit",
    icon: Layers,
    tint: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
    title: "Next.js + Drizzle architecture audit",
    subtitle: "Security, pooling & streaming checklist",
    prompt:
      "Create a structured production readiness checklist and task list for a Next.js App Router + Drizzle ORM application covering SSRF, pooling, and streaming UX.",
  },
];

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 5) return "Late night session";
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

export default function Hero({
  onSuggestion,
  onOpenQuickSetup,
  providerLabel,
  hasProvider,
  prefs,
  compact = false,
  ...composer
}: HeroProps) {
  const greeting = useMemo(() => getGreeting(), []);

  return (
    <div className="relative scroll-slim flex min-h-0 flex-1 flex-col items-center overflow-y-auto px-4 sm:px-6">
      {/* Vertically balanced focal container */}
      <div
        className={cn(
          "relative my-auto w-full py-8 sm:py-12",
          compact ? "max-w-[560px]" : "max-w-[700px]",
        )}
      >
        {/* Centered Header Emblem + Single Unified Connection Pill */}
        <div className="animate-rise-in flex flex-col items-center text-center">
          {hasProvider ? (
            <button
              type="button"
              onClick={composer.onOpenSettings}
              className="group mb-5 inline-flex items-center gap-2 rounded-full border border-border/80 bg-card py-1 pl-1.5 pr-3 text-[12px] text-muted-foreground transition hover:border-foreground/20 hover:text-foreground"
            >
              <Logo size={18} />
              <span className="size-1.5 rounded-full bg-emerald-500" />
              <span className="font-medium text-foreground">{providerLabel}</span>
              <span className="opacity-40">·</span>
              <span className="max-w-[160px] truncate font-mono text-[11px]">{composer.model}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onOpenQuickSetup ?? composer.onOpenSettings}
              className="group mb-5 inline-flex items-center gap-2 rounded-full border border-border/80 bg-card py-1 pl-1.5 pr-3 text-[12px] text-muted-foreground transition hover:border-foreground/20 hover:text-foreground"
            >
              <Logo size={18} />
              <span className="font-medium text-foreground">Connect API key or local Ollama</span>
              <span className="inline-flex items-center gap-0.5 font-medium text-brand">
                Setup <ArrowUpRight size={12} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </span>
            </button>
          )}

          <h1
            className={cn(
              "font-serif leading-[1.1] tracking-[-0.02em] text-foreground",
              compact ? "text-[28px] sm:text-[32px]" : "text-[34px] sm:text-[42px]",
            )}
          >
            {greeting}, what shall we work on?
          </h1>
          <p className="mt-3 max-w-md text-[14px] leading-relaxed text-muted-foreground">
            Multi-step agents, persistent memory, and live tools — powered directly by your own models.
          </p>
        </div>

        {/* Centerpiece Composer */}
        <div className="animate-rise-in mt-6" style={{ animationDelay: "50ms" }}>
          <Composer
            {...composer}
            variant="hero"
            providerLabel={providerLabel}
            hasProvider={hasProvider}
            prefs={prefs}
          />
        </div>

        {/* Compact Agent Persona Pill Bar */}
        {composer.agents.length > 0 && (
          <div
            className="animate-fade-in mt-4 flex flex-wrap items-center justify-center gap-1.5"
            style={{ animationDelay: "100ms" }}
          >
            {composer.agents.slice(0, 5).map((agent) => {
              const selected = agent.id === composer.selectedAgent?.id;
              return (
                <button
                  key={agent.id}
                  type="button"
                  onClick={() => composer.onSelectAgent(agent.id)}
                  aria-pressed={selected}
                  title={agent.description || agent.name}
                  className={cn(
                    "inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-[12px] font-medium outline-none transition active:scale-[0.98]",
                    selected
                      ? "border-foreground bg-foreground text-background"
                      : "border-border/70 bg-card text-muted-foreground hover:border-foreground/20 hover:text-foreground",
                  )}
                >
                  <AgentIcon icon={agent.icon} size={12} />
                  <span>{agent.name}</span>
                </button>
              );
            })}
            <button
              type="button"
              onClick={composer.onOpenAgents}
              title="Create or edit agents"
              className="inline-flex h-7 items-center gap-1 rounded-full border border-dashed border-border bg-transparent px-2.5 text-[11.5px] text-muted-foreground transition hover:border-foreground/25 hover:text-foreground"
            >
              <Plus size={11} />
              <span>Agents</span>
            </button>
          </div>
        )}

        {/* Starter prompts — plain editorial rows, no coloured tiles */}
        <div
          className="animate-rise-in mt-8 divide-y divide-border/70 border-y border-border/70"
          style={{ animationDelay: "140ms" }}
        >
          {STARTERS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => onSuggestion(s.prompt)}
              className="group flex w-full items-center gap-3 py-2.5 text-left outline-none transition-colors hover:bg-muted/40 focus-visible:ring-2 focus-visible:ring-ring"
            >
              <s.icon size={15} className="shrink-0 text-muted-foreground/70" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13.5px] font-medium text-foreground">
                  {s.title}
                </span>
                <span className="block truncate text-[12px] text-muted-foreground">
                  {s.subtitle}
                </span>
              </span>
              <ArrowUpRight
                size={14}
                className="shrink-0 text-muted-foreground/40 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-foreground"
              />
            </button>
          ))}
        </div>

        {/* Quiet Footer Hint */}
        <div
          className="animate-fade-in mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-[11.5px] text-muted-foreground/80"
          style={{ animationDelay: "200ms" }}
        >
          <span className="inline-flex items-center gap-1">
            <Sparkles size={11} className="text-brand" /> AES-256-GCM encrypted keys
          </span>
          <span className="opacity-40">·</span>
          <Link href="/settings#providers" className="hover:text-foreground hover:underline">
            18 cloud & local providers
          </Link>
          <span className="opacity-40">·</span>
          <Link href="/settings#integrations" className="hover:text-foreground hover:underline">
            Live web search & readers
          </Link>
        </div>
      </div>
    </div>
  );
}
