import { cn } from "@/lib/utils";

/**
 * Nova geometric brand mark — faceted 4-point star + orbital core rendered on
 * a layered gradient squircle. Crisp at every pixel size with zero font shift.
 */
export function Logo({
  size = 28,
  className,
  glow = false,
}: {
  size?: number;
  className?: string;
  glow?: boolean;
}) {
  const iconSize = Math.round(size * 0.56);
  return (
    <span
      aria-hidden
      className={cn(
        "relative inline-flex shrink-0 select-none items-center justify-center rounded-[28%] text-white shadow-xs transition-transform duration-200",
        "bg-[linear-gradient(145deg,color-mix(in_oklab,var(--brand)_92%,white)_0%,var(--brand)_48%,color-mix(in_oklab,var(--brand)_72%,black)_100%)]",
        "ring-1 ring-inset ring-white/25 dark:ring-white/20",
        glow && "shadow-[0_4px_24px_-4px_color-mix(in_oklab,var(--brand)_55%,transparent)]",
        className,
      )}
      style={{ width: size, height: size }}
    >
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 24 24"
        fill="none"
        className="relative z-10 drop-shadow-[0_1px_1px_rgba(0,0,0,0.22)]"
      >
        <path
          d="M12 2.25C12.55 7.4 16.6 11.45 21.75 12C16.6 12.55 12.55 16.6 12 21.75C11.45 16.6 7.4 12.55 2.25 12C7.4 11.45 11.45 7.4 12 2.25Z"
          fill="currentColor"
        />
        <circle cx="18.5" cy="5.5" r="1.45" fill="currentColor" fillOpacity="0.88" />
      </svg>
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 rounded-[28%] bg-gradient-to-b from-white/22 via-transparent to-black/12"
      />
    </span>
  );
}
