"use client";

import { useEffect, useState } from "react";
import { Check, Copy, ExternalLink, Link2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { copyToClipboard } from "@/lib/clipboard";

interface SharedLinkInfo {
  token: string;
  expiresAt?: string | null;
}

export default function ShareDialog({
  open,
  onOpenChange,
  conversationId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conversationId: string | null;
}) {
  const [link, setLink] = useState<SharedLinkInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open || !conversationId) return;
    setLoading(true);
    fetch(`/api/conversations/${conversationId}/share`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => setLink(data?.link ?? null))
      .finally(() => setLoading(false));
  }, [open, conversationId]);

  const create = async () => {
    if (!conversationId) return;
    const res = await fetch(`/api/conversations/${conversationId}/share`, { method: "POST" });
    if (!res.ok) {
      toast.error("Could not create a share link");
      return;
    }
    const data = (await res.json()) as { link: SharedLinkInfo };
    setLink(data.link);
    toast.success("Share link created");
  };

  const revoke = async () => {
    if (!conversationId) return;
    const res = await fetch(`/api/conversations/${conversationId}/share`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not revoke the link");
      return;
    }
    setLink(null);
    toast.success("Share link revoked");
  };

  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const url = link?.token ? `${origin}/share/${link.token}` : "";

  const copy = async () => {
    const ok = await copyToClipboard(url);
    if (!ok) {
      toast.error("Could not copy the link");
      return;
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const expiryText = link?.expiresAt
    ? `Expires ${new Date(link.expiresAt).toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
      })}`
    : "Never expires unless revoked";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 size={16} /> Share conversation
          </DialogTitle>
          <DialogDescription>
            Anyone with the link can read a snapshot of this conversation. Configure default expiry
            and attachment redaction in Settings → Data & privacy.
          </DialogDescription>
        </DialogHeader>
        {loading ? (
          <p className="text-[13px] text-muted-foreground">Loading…</p>
        ) : link?.token ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 rounded-xl border bg-muted/50 p-2">
              <code className="min-w-0 flex-1 truncate px-1.5 text-[12px]">{url}</code>
              <Button size="sm" variant="outline" onClick={() => void copy()}>
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <div className="flex items-center justify-between text-[12px] text-muted-foreground">
              <span>{expiryText}</span>
              <div className="flex items-center gap-1">
                <Button size="xs" variant="ghost" asChild>
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    Open <ExternalLink size={12} />
                  </a>
                </Button>
                <Button
                  size="xs"
                  variant="ghost"
                  className="text-muted-foreground hover:text-destructive"
                  onClick={() => void revoke()}
                >
                  <Trash2 size={13} /> Revoke
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <Button onClick={() => void create()} disabled={!conversationId}>
            <Link2 size={15} /> Create share link
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
