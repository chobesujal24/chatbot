"use client";

import { useEffect, useRef, useState } from "react";
import { Command } from "cmdk";
import {
  IconAgents,
  IconAnalytics,
  IconChat,
  IconCompose,
  IconFork,
  IconMemory,
  IconMoon,
  IconSearch,
  IconSliders,
  IconTasks,
  IconTemplates,
  type IconProps,
} from "./icons";
import { Dialog, DialogContent, DialogTitle } from "./ui/dialog";
import type { ConversationSummary, SearchHit } from "@/lib/types";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conversations: ConversationSummary[];
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onOpenSettings: () => void;
  onOpenAgents: () => void;
  onOpenTasks: () => void;
  onOpenMemories: () => void;
  onOpenTemplates: () => void;
  onOpenStats: () => void;
  onOpenFullSettings: () => void;
  onOpenShortcuts: () => void;
  onOpenAbout: () => void;
  onToggleTheme: () => void;
}

const groupHeading =
  "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wide [&_[cmdk-group-heading]]:text-muted-foreground";

interface ActionItem {
  label: string;
  icon: React.ComponentType<IconProps>;
  fn: () => void;
  hint: string;
}

export default function CommandPalette(props: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!props.open) {
      setQuery("");
      setHits([]);
    }
  }, [props.open]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const q = query.trim();
    if (q.length < 2) {
      setHits([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`, {
          cache: "no-store",
        });
        if (res.ok) {
          const data = (await res.json()) as { results: SearchHit[] };
          setHits(data.results);
        }
      } catch {
        /* ignore */
      }
    }, 200);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  const run = (fn: () => void) => {
    props.onOpenChange(false);
    fn();
  };

  const actions: ActionItem[] = [
    { label: "New chat", icon: IconCompose, fn: props.onNewChat, hint: "⌘N" },
    { label: "Agents", icon: IconAgents, fn: props.onOpenAgents, hint: "" },
    { label: "Tasks", icon: IconTasks, fn: props.onOpenTasks, hint: "" },
    { label: "Memory", icon: IconMemory, fn: props.onOpenMemories, hint: "" },
    { label: "Prompt templates", icon: IconTemplates, fn: props.onOpenTemplates, hint: "" },
    { label: "Workspace analytics", icon: IconAnalytics, fn: props.onOpenStats, hint: "" },
    { label: "Model & settings", icon: IconSliders, fn: props.onOpenSettings, hint: "" },
    { label: "All settings", icon: IconSliders, fn: props.onOpenFullSettings, hint: "⌘," },
    { label: "Toggle theme", icon: IconMoon, fn: props.onToggleTheme, hint: "" },
    { label: "Keyboard shortcuts", icon: IconSliders, fn: props.onOpenShortcuts, hint: "⌘/" },
    { label: "About & open source", icon: IconFork, fn: props.onOpenAbout, hint: "" },
  ];

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="top-[16%] max-w-[540px] translate-y-0 gap-0 overflow-hidden p-0 shadow-lg">
        <DialogTitle className="sr-only">Command palette</DialogTitle>
        <Command loop className="bg-popover text-popover-foreground">
          <div className="flex items-center gap-2.5 border-b border-border px-3.5">
            <IconSearch size={16} className="text-muted-foreground" />
            <Command.Input
              autoFocus
              value={query}
              onValueChange={setQuery}
              placeholder="Search chats, messages, or run a command…"
              className="h-12 w-full bg-transparent text-[13.5px] outline-none placeholder:text-muted-foreground/70"
            />
          </div>
          <Command.List className="scroll-slim max-h-[340px] overflow-y-auto p-1.5">
            <Command.Empty className="px-3 py-8 text-center text-[12.5px] text-muted-foreground">
              No results found.
            </Command.Empty>
            <Command.Group heading="Actions" className={groupHeading}>
              {actions.map((item) => (
                <Command.Item
                  key={item.label}
                  value={`action ${item.label}`}
                  onSelect={() => run(item.fn)}
                  className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] outline-none select-none transition-colors aria-selected:bg-accent aria-selected:text-accent-foreground"
                >
                  <item.icon size={15} className="text-muted-foreground" />
                  <span>{item.label}</span>
                  {item.hint && (
                    <kbd className="ml-auto font-mono text-[10.5px] text-muted-foreground/80">
                      {item.hint}
                    </kbd>
                  )}
                </Command.Item>
              ))}
            </Command.Group>
            {props.conversations.length > 0 && (
              <Command.Group heading="Conversations" className={`mt-1 ${groupHeading}`}>
                {props.conversations.slice(0, 30).map((c) => (
                  <Command.Item
                    key={c.id}
                    value={`chat ${c.title}`}
                    onSelect={() => run(() => props.onSelectConversation(c.id))}
                    className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] outline-none select-none transition-colors aria-selected:bg-accent aria-selected:text-accent-foreground"
                  >
                    <IconChat size={15} className="shrink-0 text-muted-foreground" />
                    <span className="truncate">{c.title}</span>
                  </Command.Item>
                ))}
              </Command.Group>
            )}
            {hits.length > 0 && (
              <Command.Group heading="Messages" className={`mt-1 ${groupHeading}`}>
                {hits.map((hit) => (
                  <Command.Item
                    key={hit.messageId}
                    value={`message ${hit.conversationTitle} ${hit.snippet}`}
                    onSelect={() => run(() => props.onSelectConversation(hit.conversationId))}
                    className="flex cursor-pointer items-start gap-2.5 rounded-lg px-2.5 py-2 text-[13px] outline-none select-none transition-colors aria-selected:bg-accent aria-selected:text-accent-foreground"
                  >
                    <IconSearch size={14} className="mt-0.5 shrink-0 text-muted-foreground" />
                    <span className="min-w-0">
                      <span className="block truncate text-[12.5px] font-medium">
                        {hit.conversationTitle}
                      </span>
                      <span className="block truncate text-[11.5px] text-muted-foreground">
                        {hit.snippet}
                      </span>
                    </span>
                  </Command.Item>
                ))}
              </Command.Group>
            )}
          </Command.List>
          <div className="flex items-center justify-between border-t border-border px-3.5 py-2 text-[11px] text-muted-foreground">
            <span>↑↓ navigate · ↵ select</span>
            <span>esc to close</span>
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
