"use client";

import { ExternalLink, GitFork } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

const SOURCES = [
  { name: "Next.js", repo: "vercel/next.js", note: "App Router, route handlers, React Server Components" },
  { name: "Vercel AI SDK", repo: "vercel/ai", note: "streamText + provider abstraction" },
  { name: "shadcn/ui", repo: "shadcn-ui/ui", note: "button, dialog, dropdown-menu, input, textarea, tooltip, switch (vendored from GitHub)" },
  { name: "Radix UI", repo: "radix-ui/primitives", note: "accessible primitives behind shadcn/ui" },
  { name: "Tailwind CSS", repo: "tailwindlabs/tailwindcss", note: "utility-first styling" },
  { name: "Drizzle ORM", repo: "drizzle-team/drizzle-orm", note: "typed PostgreSQL queries" },
  { name: "PostgreSQL", repo: "postgres/postgres", note: "conversation + message storage" },
  { name: "Streamdown", repo: "vercel/streamdown", note: "streaming-safe Markdown renderer" },
  { name: "AI Elements", repo: "vercel/ai-elements", note: "Conversation + Shimmer components (vendored from GitHub)" },
  { name: "use-stick-to-bottom", repo: "stackblitz-labs/use-stick-to-bottom", note: "smooth auto-scroll while streaming" },
  { name: "Shiki", repo: "shikijs/shiki", note: "code syntax highlighting" },
  { name: "Geist", repo: "vercel/geist-font", note: "UI typeface" },
  { name: "Instrument Serif", repo: "Instrument/instrument-serif", note: "display typeface" },
  { name: "Motion", repo: "motiondivision/motion", note: "shimmer animation" },
  { name: "cmdk", repo: "pacocoursey/cmdk", note: "command palette" },
  { name: "Lucide", repo: "lucide-icons/lucide", note: "icon set" },
  { name: "sonner", repo: "emilkowalski/sonner", note: "toast notifications" },
];

const SHORTCUTS = [
  { keys: "⌘ / Ctrl + K", action: "Open command palette & global search" },
  { keys: "⌘ / Ctrl + N", action: "Start a new chat" },
  { keys: "⌘ / Ctrl + B", action: "Collapse or expand sidebar" },
  { keys: "⌘ / Ctrl + ,", action: "Open full settings" },
  { keys: "⌘ / Ctrl + /", action: "Show keyboard shortcuts" },
  { keys: "Enter", action: "Send message" },
  { keys: "Shift + Enter", action: "New line in composer" },
  { keys: "Esc", action: "Stop generation / close dialog" },
];

export function AboutDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] sm:max-w-[600px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitFork size={16} /> Built from GitHub
          </DialogTitle>
          <DialogDescription>
            Every dependency in this project is open source. The UI primitives are vendored
            directly from the shadcn/ui GitHub repository and adapted only for import paths.
          </DialogDescription>
        </DialogHeader>
        <div>
          <div className="divide-y divide-border rounded-lg border border-border">
            {SOURCES.map((s) => (
              <a
                key={s.repo}
                href={`https://github.com/${s.repo}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 px-3 py-2.5 transition hover:bg-accent"
              >
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1.5 text-[14px] font-medium">
                    {s.name}
                    <ExternalLink size={11} className="text-muted-foreground" />
                  </p>
                  <p className="mt-0.5 text-[12px] text-muted-foreground">{s.note}</p>
                </div>
                <code className="shrink-0 font-mono text-[11px] text-muted-foreground">
                  {s.repo}
                </code>
              </a>
            ))}
          </div>
          <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
            No proprietary UI kit, no hosted proxy service, and zero mock responses. Connect your
            own API keys or local runtime in Settings — keys are encrypted with AES-256-GCM at rest
            and never exposed to client scripts.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function ShortcutsDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle>Keyboard shortcuts</DialogTitle>
          <DialogDescription>Move around without leaving the keyboard.</DialogDescription>
        </DialogHeader>
        <div>
          <div className="divide-y divide-border rounded-lg border border-border">
            {SHORTCUTS.map((s) => (
              <div key={s.keys} className="flex items-center justify-between px-3 py-2.5">
                <span className="text-[13px]">{s.action}</span>
                <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[11px]">
                  {s.keys}
                </kbd>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
