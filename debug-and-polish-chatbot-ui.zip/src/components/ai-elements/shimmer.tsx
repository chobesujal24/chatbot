"use client";

import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import type { CSSProperties } from "react";
import { memo, useMemo } from "react";

export interface TextShimmerProps {
  children: string;
  as?: "p" | "span";
  className?: string;
  duration?: number;
  spread?: number;
}

const ShimmerComponent = ({
  children,
  as = "p",
  className,
  duration = 2,
  spread = 2,
}: TextShimmerProps) => {
  const dynamicSpread = useMemo(
    () => (children?.length ?? 0) * spread,
    [children, spread],
  );

  const sharedClass = cn(
    "relative inline-block bg-[length:250%_100%,auto] bg-clip-text text-transparent",
    "[--bg:linear-gradient(90deg,#0000_calc(50%-var(--spread)),var(--color-background),#0000_calc(50%+var(--spread)))] [background-repeat:no-repeat,padding-box]",
    className,
  );

  const sharedStyle = {
    "--spread": `${dynamicSpread}px`,
    backgroundImage:
      "var(--bg), linear-gradient(var(--color-muted-foreground), var(--color-muted-foreground))",
  } as CSSProperties;

  if (as === "span") {
    return (
      <motion.span
        animate={{ backgroundPosition: "0% center" }}
        className={sharedClass}
        initial={{ backgroundPosition: "100% center" }}
        style={sharedStyle}
        transition={{ duration, ease: "linear", repeat: Number.POSITIVE_INFINITY }}
      >
        {children}
      </motion.span>
    );
  }

  return (
    <motion.p
      animate={{ backgroundPosition: "0% center" }}
      className={sharedClass}
      initial={{ backgroundPosition: "100% center" }}
      style={sharedStyle}
      transition={{ duration, ease: "linear", repeat: Number.POSITIVE_INFINITY }}
    >
      {children}
    </motion.p>
  );
};

export const Shimmer = memo(ShimmerComponent);
