"use client";

import {
  IconAgents,
  IconAnalytics,
  IconCode,
  IconGlobe,
  IconMemory,
  IconSearch,
  IconSpark,
  IconWrench,
  type IconProps,
} from "./icons";

const ICONS: Record<string, React.ComponentType<IconProps>> = {
  bot: IconAgents,
  search: IconSearch,
  code: IconCode,
  chart: IconAnalytics,
  sparkles: IconSpark,
  brain: IconMemory,
  wrench: IconWrench,
  globe: IconGlobe,
};

export function AgentIcon({
  icon,
  size = 15,
  className,
}: {
  icon: string | null | undefined;
  size?: number;
  className?: string;
}) {
  const Icon = ICONS[icon ?? "bot"] ?? IconAgents;
  return <Icon size={size} className={className} />;
}
