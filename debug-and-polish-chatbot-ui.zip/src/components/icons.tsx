"use client";

/**
 * Nova icon set — hand-drawn SVG paths on a 24×24 grid, 1.6 stroke,
 * round caps/joins. Consistent optical weight across all navigation and tools.
 */
import type { SVGProps } from "react";

export type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Svg({ size = 18, children, ...rest }: IconProps & { children: React.ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

/* ── Sidebar & Panel Navigation ──────────────────────────────────────────── */

export const IconPanelLeft = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M9.5 4.5v15" />
  </Svg>
);

export const IconPanelLeftClose = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M9.5 4.5v15" />
    <path d="m14.5 9.5-2.5 2.5 2.5 2.5" />
  </Svg>
);

export const IconPanelLeftOpen = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M9.5 4.5v15" />
    <path d="m13 14.5 2.5-2.5-2.5-2.5" />
  </Svg>
);

export const IconRail = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M9 4.5v15" />
    <path d="M6.25 9h.5M6.25 12h.5M6.25 15h.5" />
  </Svg>
);

/* ── Primary navigation ──────────────────────────────────────────────────── */

export const IconChat = (p: IconProps) => (
  <Svg {...p}>
    <path d="M20.2 11.8a7.8 7.8 0 0 1-8.2 7.7 8.8 8.8 0 0 1-2.6-.4l-4.4 1.2 1.2-4.2a7.6 7.6 0 0 1-1-3.8A7.8 7.8 0 0 1 13 4.5h.5a7.8 7.8 0 0 1 6.7 7.3z" />
    <circle cx="9" cy="11.8" r=".8" fill="currentColor" stroke="none" />
    <circle cx="12.5" cy="11.8" r=".8" fill="currentColor" stroke="none" />
    <circle cx="16" cy="11.8" r=".8" fill="currentColor" stroke="none" />
  </Svg>
);

export const IconCompose = (p: IconProps) => (
  <Svg {...p}>
    <path d="M19.5 12.5V18a2.5 2.5 0 0 1-2.5 2.5H6A2.5 2.5 0 0 1 3.5 18V7A2.5 2.5 0 0 1 6 4.5h5.5" />
    <path d="m14.5 4.5 4 4-7.5 7.5-3.5.8.8-3.5z" />
  </Svg>
);

export const IconSearch = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="10.8" cy="10.8" r="6.3" />
    <path d="m15.5 15.5 4.2 4.2" />
  </Svg>
);

export const IconChevronLeft = (p: IconProps) => (
  <Svg {...p}>
    <path d="m14 7-5 5 5 5" />
  </Svg>
);

export const IconChevronRight = (p: IconProps) => (
  <Svg {...p}>
    <path d="m10 7 5 5-5 5" />
  </Svg>
);

export const IconChevronDown = (p: IconProps) => (
  <Svg {...p}>
    <path d="m7 10 5 5 5-5" />
  </Svg>
);

export const IconArrowUp = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 19V5" />
    <path d="m6 11 6-6 6 6" />
  </Svg>
);

export const IconStop = (p: IconProps) => (
  <Svg {...p}>
    <rect x="7.5" y="7.5" width="9" height="9" rx="2" fill="currentColor" stroke="none" />
  </Svg>
);

export const IconPaperclip = (p: IconProps) => (
  <Svg {...p}>
    <path d="m21.4 11.1-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5" />
  </Svg>
);

export const IconCode = (p: IconProps) => (
  <Svg {...p}>
    <path d="m8 6-6 6 6 6M16 6l6 6-6 6M14 4l-4 16" />
  </Svg>
);

export const IconGlobe = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 3.5a13.5 13.5 0 0 1 0 17M12 3.5a13.5 13.5 0 0 0 0 17M3.5 12h17" />
  </Svg>
);

export const IconWrench = (p: IconProps) => (
  <Svg {...p}>
    <path d="M14.7 6.3a4.2 4.2 0 0 0-5.4 5.4l-5.6 5.6a1.5 1.5 0 0 0 2.1 2.1l5.6-5.6a4.2 4.2 0 0 0 5.4-5.4l-3.2-.2 1.4-1.4z" />
  </Svg>
);

export const IconCalculator = (p: IconProps) => (
  <Svg {...p}>
    <rect x="4.5" y="3.5" width="15" height="17" rx="2.5" />
    <path d="M8 7.5h8M8 11.5h2M14 11.5h2M8 15.5h2M14 15.5h2" />
  </Svg>
);

export const IconClock = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5v4.5l3 2" />
  </Svg>
);

/* ── Workspace sections ──────────────────────────────────────────────────── */

export const IconAgents = (p: IconProps) => (
  <Svg {...p}>
    <rect x="4" y="7.5" width="16" height="11.5" rx="3" />
    <path d="M12 4.2v3.3" />
    <circle cx="8.8" cy="12.5" r="1.1" fill="currentColor" stroke="none" />
    <circle cx="15.2" cy="12.5" r="1.1" fill="currentColor" stroke="none" />
    <path d="M9.5 15.8h5" />
  </Svg>
);

export const IconSkills = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 3.8l2 4.7 4.7 2-4.7 2-2 4.7-2-4.7-4.7-2 4.7-2z" />
    <path d="M18.5 16.5l.8 1.8 1.8.8-1.8.8-.8 1.8-.8-1.8-1.8-.8 1.8-.8z" />
  </Svg>
);

export const IconMemory = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 3.6 20 7.4 12 11.2 4 7.4z" />
    <path d="m4 12 8 3.8 8-3.8" />
    <path d="m4 16.4 8 3.8 8-3.8" />
  </Svg>
);

export const IconContext = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 15.5a7.5 7.5 0 1 1 15 0" />
    <path d="m12 15.5 3.5-4" />
    <path d="M4.5 19h15" />
  </Svg>
);

export const IconTasks = (p: IconProps) => (
  <Svg {...p}>
    <path d="m4.2 7.6 1.8 1.8 3.2-3.4" />
    <path d="m4.2 15.6 1.8 1.8 3.2-3.4" />
    <path d="M12.2 7.2h7.6M12.2 15.2h7.6" />
  </Svg>
);

export const IconTemplates = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3.8" y="4.2" width="6.8" height="6.8" rx="1.8" />
    <rect x="13.4" y="4.2" width="6.8" height="6.8" rx="1.8" />
    <rect x="3.8" y="13.4" width="6.8" height="6.4" rx="1.8" />
    <path d="M14.5 16.8h5M17 14.3v5" />
  </Svg>
);

export const IconAnalytics = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 19.5V13.5" />
    <path d="M9.5 19.5V8.5" />
    <path d="M14.5 19.5v-7.5" />
    <path d="M19.5 19.5V4.5" />
  </Svg>
);

export const IconSliders = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 7.5h9.5M18 7.5h1.5" />
    <path d="M4.5 16.5h3.5M12 16.5h7.5" />
    <circle cx="16" cy="7.5" r="2" />
    <circle cx="10" cy="16.5" r="2" />
  </Svg>
);

/* ── Row actions & controls ──────────────────────────────────────────────── */

export const IconDots = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="5.5" cy="12" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="18.5" cy="12" r="1.2" fill="currentColor" stroke="none" />
  </Svg>
);

export const IconPin = (p: IconProps) => (
  <Svg {...p}>
    <path d="M9 4.5h6l-.8 4.2 2.8 2.8H7l2.8-2.8z" />
    <path d="M12 11.5v8" />
  </Svg>
);

export const IconPinOff = (p: IconProps) => (
  <Svg {...p}>
    <path d="M9 4.5h6l-.8 4.2 2.8 2.8H7l2.8-2.8z" />
    <path d="M12 11.5v8" />
    <path d="m4.2 4.2 15.6 15.6" />
  </Svg>
);

export const IconPencil = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 19.5h3.5L19 8.5a2.1 2.1 0 0 0-3-3L5 16z" />
    <path d="m14.5 6.5 3 3" />
  </Svg>
);

export const IconTrash = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 7h15" />
    <path d="M9.5 7V5a1.5 1.5 0 0 1 1.5-1.5h2a1.5 1.5 0 0 1 1.5 1.5V7" />
    <path d="M6.5 7l.8 11.2a1.8 1.8 0 0 0 1.8 1.6h5.8a1.8 1.8 0 0 0 1.8-1.6L17.5 7" />
    <path d="M10.2 11v5.5M13.8 11v5.5" />
  </Svg>
);

export const IconCopy = (p: IconProps) => (
  <Svg {...p}>
    <rect x="9" y="9" width="11" height="11" rx="2.5" />
    <path d="M15 5.5A2.5 2.5 0 0 0 12.5 3H6.5A2.5 2.5 0 0 0 4 5.5v6A2.5 2.5 0 0 0 6.5 14" />
  </Svg>
);

export const IconFork = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="7" cy="5.5" r="2.2" />
    <circle cx="7" cy="18.5" r="2.2" />
    <circle cx="17" cy="9.5" r="2.2" />
    <path d="M7 7.7v8.6" />
    <path d="M17 11.7c0 3-2.2 4-4.8 4.4" />
    <path d="M7 9.5h5.5A2.5 2.5 0 0 0 15 9.5" />
  </Svg>
);

export const IconDownload = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 4.5v10.5" />
    <path d="m7.5 10.5 4.5 4.5 4.5-4.5" />
    <path d="M4.8 19.5h14.4" />
  </Svg>
);

export const IconFile = (p: IconProps) => (
  <Svg {...p}>
    <path d="M13.5 3.8H7a2 2 0 0 0-2 2v12.4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9.3z" />
    <path d="M13.5 4v5.3h5.3" />
    <path d="M8.5 13.2h7M8.5 16.5h4.8" />
  </Svg>
);

export const IconLink = (p: IconProps) => (
  <Svg {...p}>
    <path d="M10 14a3.5 3.5 0 0 0 5 0l2.5-2.5a3.5 3.5 0 1 0-5-5l-1 1" />
    <path d="M14 10a3.5 3.5 0 0 0-5 0l-2.5 2.5a3.5 3.5 0 1 0 5 5l1-1" />
  </Svg>
);

export const IconSun = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="4.2" />
    <path d="M12 2.8v2.4M12 18.8v2.4M4.2 12H1.8M22.2 12h-2.4M6.2 6.2 4.5 4.5M19.5 19.5l-1.7-1.7M17.8 6.2l1.7-1.7M4.5 19.5l1.7-1.7" />
  </Svg>
);

export const IconMoon = (p: IconProps) => (
  <Svg {...p}>
    <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" />
  </Svg>
);

export const IconInfo = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11v5.5" />
    <circle cx="12" cy="7.8" r="1" fill="currentColor" stroke="none" />
  </Svg>
);

export const IconKey = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="8" cy="16" r="3.5" />
    <path d="m10.5 13.5 7.2-7.2" />
    <path d="m15.5 5.5 3 3M13.2 7.8l3 3" />
  </Svg>
);

export const IconPlug = (p: IconProps) => (
  <Svg {...p}>
    <path d="M9 4v4M15 4v4" />
    <path d="M6.5 8h11v3.5a5.5 5.5 0 0 1-11 0z" />
    <path d="M12 16.5v4" />
  </Svg>
);

export const IconCheck = (p: IconProps) => (
  <Svg {...p}>
    <path d="m5 12.5 4.5 4.5 9.5-9.5" />
  </Svg>
);

export const IconClose = (p: IconProps) => (
  <Svg {...p}>
    <path d="m6.5 6.5 11 11M17.5 6.5l-11 11" />
  </Svg>
);

export const IconRefresh = (p: IconProps) => (
  <Svg {...p}>
    <path d="M20 11A8.2 8.2 0 0 0 6.2 6.2L4 8.5" />
    <path d="M4 4v4.5h4.5" />
    <path d="M4 13a8.2 8.2 0 0 0 13.8 4.8l2.2-2.3" />
    <path d="M20 20v-4.5h-4.5" />
  </Svg>
);

export const IconThumbUp = (p: IconProps) => (
  <Svg {...p}>
    <path d="M7 10v10M7 14l3.5-8.5a1.8 1.8 0 0 1 3.5 1.4L13 10h5.5a2 2 0 0 1 2 2.3l-1.5 6a2 2 0 0 1-2 1.7H7" />
  </Svg>
);

export const IconThumbDown = (p: IconProps) => (
  <Svg {...p}>
    <path d="M7 14V4M7 10l3.5 8.5a1.8 1.8 0 0 0 3.5-1.4L13 14h5.5a2 2 0 0 0 2-2.3l-1.5-6a2 2 0 0 0-2-1.7H7" />
  </Svg>
);

export const IconGauge = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 18a7.5 7.5 0 1 1 15 0" />
    <path d="M12 18V11.5" />
    <circle cx="12" cy="18" r="1.3" fill="currentColor" stroke="none" />
  </Svg>
);

export const IconSpark = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 4l1.8 4.6 4.6 1.8-4.6 1.8L12 16.8l-1.8-4.6L5.6 10.4l4.6-1.8z" />
  </Svg>
);

export const ICONS = {
  panelLeft: IconPanelLeft,
  panelLeftClose: IconPanelLeftClose,
  panelLeftOpen: IconPanelLeftOpen,
  rail: IconRail,
  chat: IconChat,
  compose: IconCompose,
  search: IconSearch,
  agents: IconAgents,
  skills: IconSkills,
  memory: IconMemory,
  context: IconContext,
  tasks: IconTasks,
  templates: IconTemplates,
  analytics: IconAnalytics,
  settings: IconSliders,
  sun: IconSun,
  moon: IconMoon,
  pin: IconPin,
  pinOff: IconPinOff,
  pencil: IconPencil,
  trash: IconTrash,
  copy: IconCopy,
  fork: IconFork,
  download: IconDownload,
  file: IconFile,
  link: IconLink,
  info: IconInfo,
  key: IconKey,
  plug: IconPlug,
  check: IconCheck,
  close: IconClose,
  gauge: IconGauge,
  spark: IconSpark,
  dots: IconDots,
  arrowUp: IconArrowUp,
  stop: IconStop,
  paperclip: IconPaperclip,
  refresh: IconRefresh,
  thumbUp: IconThumbUp,
  thumbDown: IconThumbDown,
  chevronLeft: IconChevronLeft,
  chevronRight: IconChevronRight,
  chevronDown: IconChevronDown,
} as const;

export type IconName = keyof typeof ICONS;
