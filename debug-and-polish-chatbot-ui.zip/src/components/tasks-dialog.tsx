"use client";

import { useState } from "react";
import { ListChecks, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { cn } from "@/lib/utils";
import type { TaskItem } from "@/lib/types";

interface TasksDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tasks: TaskItem[];
  onChanged: () => void;
}

export default function TasksDialog(props: TasksDialogProps) {
  const [title, setTitle] = useState("");

  const add = async () => {
    if (!title.trim()) return;
    const res = await fetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: title.trim() }),
    });
    if (!res.ok) {
      toast.error("Could not add task");
      return;
    }
    setTitle("");
    props.onChanged();
  };

  const toggle = async (task: TaskItem) => {
    const res = await fetch(`/api/tasks/${task.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: task.status === "open" ? "done" : "open" }),
    });
    if (!res.ok) {
      toast.error("Could not update task");
      return;
    }
    props.onChanged();
  };

  const remove = async (id: string) => {
    const res = await fetch(`/api/tasks/${id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not delete task");
      return;
    }
    props.onChanged();
  };

  const open = props.tasks.filter((t) => t.status === "open");
  const done = props.tasks.filter((t) => t.status === "done");

  const row = (task: TaskItem) => (
    <div key={task.id} className="group flex items-center gap-2.5 px-3 py-2">
      <input
        type="checkbox"
        checked={task.status === "done"}
        onChange={() => void toggle(task)}
        className="h-3.5 w-3.5 shrink-0 accent-foreground"
        aria-label={task.status === "done" ? "Reopen task" : "Complete task"}
      />
      <span
        className={cn(
          "min-w-0 flex-1 text-[14px]",
          task.status === "done" && "text-muted-foreground line-through",
        )}
      >
        {task.title}
      </span>
      <button
        type="button"
        aria-label="Delete task"
        onClick={() => void remove(task.id)}
                  className="rounded p-1 text-muted-foreground opacity-0 transition hover:bg-accent hover:text-destructive focus-visible:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100"
      >
        <Trash2 size={13} />
      </button>
    </div>
  );

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[85vh] sm:max-w-[520px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListChecks size={16} /> Tasks
          </DialogTitle>
          <DialogDescription>
            Shared with agents — they can create and complete tasks with their tools.
          </DialogDescription>
        </DialogHeader>
        <div>
          <div className="flex gap-2">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void add();
              }}
              placeholder="New task…"
              className="text-[14px]"
            />
            <Button size="sm" onClick={() => void add()} disabled={!title.trim()}>
              <Plus size={14} /> Add
            </Button>
          </div>
          <div className="mt-4 divide-y divide-border rounded-lg border border-border">
            {open.map(row)}
            {done.map(row)}
            {props.tasks.length === 0 && (
              <p className="py-8 text-center text-[13px] text-muted-foreground">
                No tasks yet. Ask an agent to track something.
              </p>
            )}
          </div>
          <p className="mt-3 text-[12px] text-muted-foreground">
            {open.length} open · {done.length} done
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
