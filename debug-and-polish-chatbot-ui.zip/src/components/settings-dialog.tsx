"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowUpRight,
  Check,
  Loader2,
  Plug,
  RefreshCw,
  RotateCcw,
  SlidersHorizontal,
  Star,
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { findProvider } from "@/lib/providers";
import type { CredentialSummary } from "@/lib/credentials";
import { DEFAULT_PREFERENCES, type Preferences } from "@/lib/preferences-model";
import { cn } from "@/lib/utils";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  credentials: CredentialSummary[];
  serverKeys?: Record<string, boolean>;
  prefs: Preferences;
  onSwitchProvider: (provider: string, defaultModel?: string) => Promise<void>;
  onSavePrefs: (patch: Partial<Preferences>) => Promise<void>;
}

const fieldLabel = "mb-1.5 block text-[13px] font-medium";
const hint = "mt-1 text-[12px] leading-relaxed text-muted-foreground";

export default function SettingsDialog({
  open,
  onOpenChange,
  credentials,
  serverKeys = {},
  prefs,
  onSwitchProvider,
  onSavePrefs,
}: SettingsDialogProps) {
  const modelCreds = useMemo(
    () => credentials.filter((c) => c.kind === "model" && c.enabled),
    [credentials],
  );
  const activeCred = useMemo(
    () => modelCreds.find((c) => c.isActive) ?? null,
    [modelCreds],
  );

  const serverFallback = serverKeys.openai
    ? "openai"
    : serverKeys.anthropic
      ? "anthropic"
      : serverKeys.google
        ? "google"
        : null;

  const currentProviderId = activeCred?.provider ?? serverFallback ?? "";
  const preset = findProvider(currentProviderId);

  const [model, setModel] = useState(prefs.defaultModel);
  const [temperature, setTemperature] = useState(prefs.temperature);
  const [outputBudget, setOutputBudget] = useState(prefs.outputBudget);
  const [systemPrompt, setSystemPrompt] = useState(prefs.systemPrompt);
  const [models, setModels] = useState<string[]>(preset?.models ?? []);
  const [loadingModels, setLoadingModels] = useState(false);
  const [saving, setSaving] = useState(false);
  const [switching, setSwitching] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setModel(prefs.defaultModel || preset?.models[0] || "");
      setTemperature(prefs.temperature);
      setOutputBudget(prefs.outputBudget);
      setSystemPrompt(prefs.systemPrompt);
      setModels(preset?.models ?? []);
    }
  }, [open, prefs, preset]);

  const loadLiveModels = async () => {
    if (!currentProviderId) return;
    setLoadingModels(true);
    try {
      const res = await fetch(`/api/credentials/test?provider=${encodeURIComponent(currentProviderId)}`, {
        cache: "no-store",
      });
      const data = (await res.json().catch(() => null)) as { models?: string[] } | null;
      if (data?.models?.length) {
        setModels(data.models);
        toast.success(`Loaded ${data.models.length} models`);
      }
    } catch {
      toast.error("Could not load models");
    } finally {
      setLoadingModels(false);
    }
  };

  const handleSwitch = async (cred: CredentialSummary) => {
    setSwitching(cred.provider);
    try {
      const nextPreset = findProvider(cred.provider);
      const nextModel = nextPreset?.models[0] ?? model;
      await onSwitchProvider(cred.provider, nextModel);
      setModel(nextModel);
      setModels(nextPreset?.models ?? []);
    } finally {
      setSwitching(null);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await onSavePrefs({
        defaultModel: model.trim(),
        temperature,
        outputBudget: Math.min(65536, Math.max(128, outputBudget)),
        systemPrompt,
      });
      toast.success("Model & generation settings saved");
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-[580px]">
        <DialogHeader>
          <div className="flex items-start justify-between gap-3 pr-6">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <SlidersHorizontal size={17} /> Model & quick tuning
              </DialogTitle>
              <DialogDescription className="mt-1">
                Switch active provider, choose a model or tune generation parameters.
              </DialogDescription>
            </div>
            <Link
              href="/settings"
              onClick={() => onOpenChange(false)}
              className="inline-flex shrink-0 items-center gap-1 rounded-lg border bg-card px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground transition hover:border-foreground/25 hover:text-foreground"
            >
              All settings <ArrowUpRight size={12} />
            </Link>
          </div>
        </DialogHeader>

        <div className="space-y-5">
          {/* Connected providers switcher */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-medium">Active model provider</span>
              <Link
                href="/settings#providers"
                onClick={() => onOpenChange(false)}
                className="text-[12px] font-medium text-brand hover:underline"
              >
                + Add or manage keys →
              </Link>
            </div>

            {modelCreds.length > 0 ? (
              <div className="grid gap-1.5 sm:grid-cols-2">
                {modelCreds.map((c) => {
                  const active = c.isActive;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        if (!active) void handleSwitch(c);
                      }}
                      disabled={switching === c.provider}
                      className={cn(
                        "flex items-center justify-between gap-2.5 rounded-xl border px-3 py-2.5 text-left transition",
                        active
                          ? "border-foreground/30 bg-accent text-foreground shadow-2xs"
                          : "bg-card text-muted-foreground hover:border-foreground/20 hover:text-foreground",
                      )}
                    >
                      <span className="min-w-0">
                        <span className="flex items-center gap-1.5 truncate text-[13px] font-medium">
                          {c.label}
                          {active && <Star size={11} className="shrink-0 fill-brand text-brand" />}
                        </span>
                        <span className="block truncate font-mono text-[11px] text-muted-foreground">
                          {c.keyPreview || c.baseURL || "Configured"}
                        </span>
                      </span>
                      {switching === c.provider ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : active ? (
                        <Check size={14} className="shrink-0 text-emerald-500" />
                      ) : null}
                    </button>
                  );
                })}
              </div>
            ) : serverFallback ? (
              <div className="flex items-center gap-2.5 rounded-xl border bg-muted/40 px-3.5 py-2.5 text-[12.5px]">
                <span className="size-2 rounded-full bg-emerald-500" />
                <span>
                  Using server-configured <strong>{findProvider(serverFallback)?.label ?? serverFallback}</strong> key.
                </span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-500/35 bg-amber-500/10 px-3.5 py-3 text-[12.5px] text-amber-800 dark:text-amber-300">
                <span className="flex items-center gap-2">
                  <Plug size={14} /> No model provider connected yet.
                </span>
                <Button size="xs" asChild>
                  <Link href="/settings#providers" onClick={() => onOpenChange(false)}>
                    Connect provider
                  </Link>
                </Button>
              </div>
            )}
          </div>

          {/* Model ID & Max tokens */}
          <div className="grid gap-3 sm:grid-cols-[1fr_150px]">
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="text-[13px] font-medium" htmlFor="quick-model">
                  Model ID
                </label>
                {preset?.modelsPath && currentProviderId && (
                  <button
                    type="button"
                    onClick={() => void loadLiveModels()}
                    disabled={loadingModels}
                    className="inline-flex items-center gap-1 text-[11.5px] text-muted-foreground hover:text-foreground"
                  >
                    <RefreshCw size={11} className={cn(loadingModels && "animate-spin")} />
                    Load live models
                  </button>
                )}
              </div>
              <Input
                id="quick-model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder={preset?.models[0] || "e.g. gpt-4o-mini"}
                className="font-mono text-[13px]"
              />
              {models.length > 0 && (
                <div className="scroll-slim mt-2 flex max-h-[84px] flex-wrap gap-1 overflow-y-auto">
                  {models.slice(0, 24).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setModel(m)}
                      className={cn(
                        "rounded-md border px-2 py-0.5 font-mono text-[11px] transition",
                        model === m
                          ? "border-foreground bg-foreground text-background"
                          : "bg-card text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className={fieldLabel} htmlFor="quick-tokens">
                Max output tokens
              </label>
              <Input
                id="quick-tokens"
                type="number"
                min={128}
                max={65536}
                step={256}
                value={outputBudget}
                onChange={(e) => setOutputBudget(Number(e.target.value) || 2048)}
                className="font-mono text-[13px]"
              />
            </div>
          </div>

          {/* Temperature */}
          <div>
            <div className="mb-1.5 flex items-center justify-between text-[13px] font-medium">
              <label htmlFor="quick-temp">Temperature</label>
              <span className="font-mono text-[12px] text-muted-foreground">{temperature.toFixed(2)}</span>
            </div>
            <input
              id="quick-temp"
              type="range"
              min={0}
              max={2}
              step={0.05}
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="nova-range w-full"
            />
            <div className="mt-0.5 flex justify-between text-[11.5px] text-muted-foreground">
              <span>Precise (0.0)</span>
              <span>Balanced (0.7)</span>
              <span>Creative (2.0)</span>
            </div>
          </div>

          {/* System prompt */}
          <div>
            <label className={fieldLabel} htmlFor="quick-sys">
              Workspace system prompt
            </label>
            <Textarea
              id="quick-sys"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              rows={3}
              placeholder="Fallback instructions used when an agent has no custom prompt…"
              className="resize-y text-[13px]"
            />
            <p className={hint}>
              Agents with their own system prompt override this value. Configure agents, memory and context in{" "}
              <Link href="/settings" onClick={() => onOpenChange(false)} className="underline underline-offset-2">
                Settings
              </Link>
              .
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setTemperature(DEFAULT_PREFERENCES.temperature);
              setOutputBudget(DEFAULT_PREFERENCES.outputBudget);
              setSystemPrompt(DEFAULT_PREFERENCES.systemPrompt);
            }}
          >
            <RotateCcw size={13} /> Defaults
          </Button>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={() => void save()} disabled={saving}>
            {saving ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
