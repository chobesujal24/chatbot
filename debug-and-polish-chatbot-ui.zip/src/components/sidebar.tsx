"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { toast } from "sonner";
import { MessageSquarePlus, Plug, Settings2 } from "lucide-react";
import {
  IconAgents,
  IconAnalytics,
  IconChat,
  IconChevronDown,
  IconChevronRight,
  IconCompose,
  IconDots,
  IconDownload,
  IconFile,
  IconFork,
  IconInfo,
  IconMemory,
  IconMoon,
  IconPanelLeftClose,
  IconPanelLeftOpen,
  IconPencil,
  IconPin,
  IconPinOff,
  IconSearch,
  IconSettingsSliders,
  IconSkills,
  IconSun,
  IconTasks,
  IconTemplates,
  IconTrash,
} from "./sidebar-icons";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { Logo } from "./logo";
import { groupConversations } from "@/lib/format";
import { useMediaQuery, useMounted } from "@/lib/use-media-query";
import { cn } from "@/lib/utils";
import type { ConversationSummary } from "@/lib/types";
import type { ThemePreference } from "./providers";

export interface SidebarNavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
  badge?: number;
}

interface SidebarProps {
  conversations: ConversationSummary[];
  activeId: string | null;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDelete: (id: string) => void;
  onFork: (id: string) => void;
  onExport: (id: string, format: "md" | "json") => void;
  onOpenSettings: () => void;
  onOpenQuickSetup?: () => void;
  onOpenAgents: () => void;
  onOpenTasks: () => void;
  onOpenMemories: () => void;
  onOpenTemplates: () => void;
  onOpenStats: () => void;
  onOpenSkills: () => void;
  onOpenContext: () => void;
  onOpenAbout: () => void;
  onOpenPalette: () => void;
  offline: boolean;
  openTasks: number;
  theme: ThemePreference;
  resolvedTheme: "light" | "dark";
  onToggleTheme: () => void;
  providerLabel: string | null;
  providerKeyPreview: string | null;
  collapsed?: boolean;
  onToggleCollapsed: () => void;
}

const GROUPS_KEY = "nova-sidebar-groups";

function RailTooltip({
  label,
  shortcut,
  children,
}: {
  label: string;
  shortcut?: string;
  children: React.ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent side="right" sideOffset={12} className="flex items-center gap-2">
        <span>{label}</span>
        {shortcut && <kbd className="font-mono text-[10px] opacity-60">{shortcut}</kbd>}
      </TooltipContent>
    </Tooltip>
  );
}

export default function Sidebar(props: SidebarProps) {
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [collapsedGroups, setCollapsedGroups] = useState<string[]>([]);
  const listRef = useRef<HTMLDivElement>(null);
  const pendingDelete = useRef<{ id: string; at: number } | null>(null);

  const requestDelete = useCallback(
    (c: ConversationSummary) => {
      const pending = pendingDelete.current;
      if (pending && pending.id === c.id && Date.now() - pending.at < 4000) {
        pendingDelete.current = null;
        props.onDelete(c.id);
      } else {
        pendingDelete.current = { id: c.id, at: Date.now() };
        toast.message("Click Delete again to confirm");
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [props.onDelete],
  );
  const collapsed = Boolean(props.collapsed);
  const mounted = useMounted();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const shellWidth = collapsed ? 60 : 256;
  const shellX = !mounted || isDesktop ? 0 : props.open ? 0 : -shellWidth;

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(GROUPS_KEY);
      if (raw) setCollapsedGroups(JSON.parse(raw) as string[]);
    } catch {
      /* ignore */
    }
  }, []);

  const toggleGroup = useCallback((label: string) => {
    setCollapsedGroups((prev) => {
      const next = prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label];
      try {
        window.localStorage.setItem(GROUPS_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return props.conversations;
    return props.conversations.filter((c) => c.title.toLowerCase().includes(q));
  }, [props.conversations, query]);

  const groups = useMemo(() => groupConversations(filtered), [filtered]);

  const commitRename = () => {
    if (renamingId && draft.trim()) props.onRename(renamingId, draft.trim());
    setRenamingId(null);
  };

  const onListKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const rows = Array.from(
      listRef.current?.querySelectorAll<HTMLButtonElement>("[data-conv-row]") ?? [],
    );
    if (rows.length === 0) return;
    event.preventDefault();
    const index = rows.findIndex((row) => row === document.activeElement);
    const next = event.key === "ArrowDown" ? index + 1 : index - 1;
    rows[Math.max(0, Math.min(rows.length - 1, next === -1 ? rows.length - 1 : next))]?.focus();
  };

  const workspaceItems: SidebarNavItem[] = [
    { id: "agents", label: "Agents", icon: <IconAgents size={15} />, onClick: props.onOpenAgents },
    { id: "skills", label: "Skills", icon: <IconSkills size={15} />, onClick: props.onOpenSkills },
    { id: "memory", label: "Memory", icon: <IconMemory size={15} />, onClick: props.onOpenMemories },
    { id: "tasks", label: "Tasks", icon: <IconTasks size={15} />, onClick: props.onOpenTasks, badge: props.openTasks },
    { id: "templates", label: "Templates", icon: <IconTemplates size={15} />, onClick: props.onOpenTemplates },
  ];

  return (
    <TooltipProvider delayDuration={150}>
      {props.open && (
        <button
          type="button"
          aria-label="Close sidebar"
          onClick={props.onClose}
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs lg:hidden"
        />
      )}

      <motion.aside
        aria-label="Workspace navigation"
        initial={false}
        animate={{ width: shellWidth, x: shellX }}
        transition={{
          type: "spring",
          stiffness: 420,
          damping: 38,
          mass: 0.8,
        }}
        style={{ left: 0 }}
        className={cn(
          "sidebar-shell fixed inset-y-0 z-50 flex shrink-0 flex-col border-r border-border/60 bg-sidebar select-none lg:relative lg:z-0 lg:border-r-0 lg:py-2",
        )}
      >
        {/* Top Brand Row */}
        <div
          className={cn(
            "flex h-13 shrink-0 items-center",
            collapsed ? "justify-center px-0" : "justify-between px-3.5",
          )}
        >
          {collapsed ? (
            <RailTooltip label="Expand sidebar" shortcut="⌘B">
              <button
                type="button"
                onClick={props.onToggleCollapsed}
                aria-label="Expand sidebar"
                className="group flex size-9 items-center justify-center rounded-xl text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95 focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Logo size={24} className="group-hover:hidden" />
                <IconPanelLeftOpen size={17} className="hidden group-hover:block" />
              </button>
            </RailTooltip>
          ) : (
            <>
              <Link
                href="/"
                className="group flex items-center gap-2.5 rounded-xl py-1 outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Logo size={25} />
                <span className="text-[15px] font-semibold tracking-[-0.015em] text-foreground">
                  Nova
                </span>
              </Link>

              <div className="flex items-center gap-1">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      type="button"
                      onClick={props.onToggleCollapsed}
                      aria-label="Collapse sidebar"
                      className="hidden size-7 items-center justify-center rounded-lg text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground active:scale-95 lg:flex"
                    >
                      <IconPanelLeftClose size={16} />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="flex items-center gap-2">
                    <span>Collapse</span>
                    <kbd className="font-mono text-[10px] opacity-60">⌘B</kbd>
                  </TooltipContent>
                </Tooltip>

                <button
                  type="button"
                  onClick={props.onClose}
                  aria-label="Close sidebar"
                  className="flex size-7 items-center justify-center rounded-lg text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground lg:hidden"
                >
                  <IconPanelLeftClose size={16} />
                </button>
              </div>
            </>
          )}
        </div>

        {/* Primary Actions */}
        <div className={cn("shrink-0 space-y-1.5 pt-2", collapsed ? "px-2" : "px-3")}>
          {collapsed ? (
            <>
              <RailTooltip label="New chat" shortcut="⌘N">
                <button
                  type="button"
                  onClick={props.onNew}
                  aria-label="New chat"
                  className="flex size-9 w-full items-center justify-center rounded-xl bg-foreground text-background shadow-xs outline-none transition hover:opacity-90 active:scale-95"
                >
                  <IconCompose size={16} />
                </button>
              </RailTooltip>
              <RailTooltip label="Search" shortcut="⌘K">
                <button
                  type="button"
                  onClick={props.onOpenPalette}
                  aria-label="Search conversations"
                  className="flex size-9 w-full items-center justify-center rounded-xl text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground active:scale-95"
                >
                  <IconSearch size={16} />
                </button>
              </RailTooltip>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={props.onNew}
                className="group flex h-9 w-full items-center gap-2 rounded-xl bg-foreground px-3 text-[13px] font-medium text-background shadow-xs outline-none transition hover:opacity-92 active:scale-[0.99] focus-visible:ring-2 focus-visible:ring-ring"
              >
                <MessageSquarePlus size={15} />
                <span>New chat</span>
                <kbd className="ml-auto font-mono text-[10px] opacity-65">⌘N</kbd>
              </button>

              {props.conversations.length > 3 ? (
                <div className="relative">
                  <IconSearch size={13} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Escape") setQuery("");
                    }}
                    placeholder="Filter chats…"
                    aria-label="Filter conversations"
                    className="h-8 w-full rounded-xl border border-border/70 bg-background/70 pl-8 pr-2 text-[12.5px] outline-none transition placeholder:text-muted-foreground/70 focus:border-foreground/25 focus:bg-background"
                  />
                </div>
              ) : null}
            </>
          )}
        </div>

        {/* Clean Single-Column Workspace Navigation */}
        <div className={cn("shrink-0 pt-3 pb-1.5", collapsed ? "px-2" : "px-3")}>
          {!collapsed && (
            <p className="px-2 pb-1 text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground/65">
              Studio
            </p>
          )}
          <div className={cn(collapsed ? "flex flex-col items-center gap-1" : "space-y-0.5")}>
            {workspaceItems.map((item) =>
              collapsed ? (
                <RailTooltip key={item.id} label={item.label}>
                  <button
                    type="button"
                    onClick={item.onClick}
                    aria-label={item.label}
                    className="relative flex size-9 items-center justify-center rounded-xl text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground active:scale-95"
                  >
                    {item.icon}
                    {typeof item.badge === "number" && item.badge > 0 && (
                      <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-brand" />
                    )}
                  </button>
                </RailTooltip>
              ) : (
                <button
                  key={item.id}
                  type="button"
                  onClick={item.onClick}
                  className="group flex h-8 w-full items-center gap-2.5 rounded-lg px-2 text-[12.5px] text-muted-foreground outline-none transition hover:bg-accent/80 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="shrink-0 text-muted-foreground/80 transition-colors group-hover:text-foreground">
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                  {typeof item.badge === "number" && item.badge > 0 && (
                    <span className="ml-auto rounded-full bg-brand/15 px-1.5 py-px font-mono text-[10px] font-medium text-brand">
                      {item.badge}
                    </span>
                  )}
                </button>
              ),
            )}
          </div>
        </div>

        {/* Subtle Divider */}
        <div className={cn("shrink-0 py-1.5", collapsed ? "px-2.5" : "px-4")}>
          <div className="h-px w-full bg-border/60" />
        </div>

        {/* Conversations List */}
        <div
          ref={listRef}
          onKeyDown={onListKeyDown}
          className={cn("scroll-slim min-h-0 flex-1 overflow-y-auto pb-2", collapsed ? "px-2" : "px-3")}
        >
          {collapsed ? (
            <div className="flex flex-col items-center gap-1 pt-0.5">
              {props.conversations.slice(0, 14).map((c) => (
                <RailTooltip key={c.id} label={c.title}>
                  <button
                    type="button"
                    onClick={() => props.onSelect(c.id)}
                    aria-label={c.title}
                    aria-current={c.id === props.activeId ? "page" : undefined}
                    className={cn(
                      "relative flex size-9 items-center justify-center rounded-xl transition active:scale-95",
                      c.id === props.activeId
                        ? "bg-accent text-foreground"
                        : "text-muted-foreground hover:bg-accent/70 hover:text-foreground",
                    )}
                  >
                    {c.id === props.activeId && (
                      <span className="absolute -left-1 h-4 w-[2px] rounded-full bg-brand" />
                    )}
                    <IconChat size={15} />
                    {c.pinned && (
                      <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-brand" />
                    )}
                  </button>
                </RailTooltip>
              ))}
            </div>
          ) : groups.length === 0 ? (
            <div className="mt-2 rounded-xl border border-dashed border-border/70 bg-background/40 px-3.5 py-5 text-center">
              <span className="mx-auto flex size-7 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <IconChat size={14} />
              </span>
              <p className="mt-2 text-[12px] font-medium text-foreground/80">
                {query ? "No matching chats" : "No history yet"}
              </p>
              <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">
                {query ? "Try another keyword." : "Threads save automatically to PostgreSQL."}
              </p>
            </div>
          ) : (
            groups.map((group) => {
              const isCollapsed = collapsedGroups.includes(group.label);
              return (
                <section key={group.label} className="pt-1.5 first:pt-0">
                  <button
                    type="button"
                    onClick={() => toggleGroup(group.label)}
                    aria-expanded={!isCollapsed}
                    className="group flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-[10.5px] font-semibold uppercase tracking-[0.06em] text-muted-foreground/70 outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {isCollapsed ? <IconChevronRight size={11} /> : <IconChevronDown size={11} />}
                    <span className="truncate">{group.label}</span>
                    <span className="ml-auto font-mono text-[10px] opacity-60">{group.items.length}</span>
                  </button>

                  <AnimatePresence initial={false}>
                    {!isCollapsed && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.18, ease: [0.22, 1, 0.3, 1] }}
                        className="overflow-hidden"
                      >
                        <div className="space-y-0.5 pt-0.5">
                          {group.items.map((c) => {
                            const active = c.id === props.activeId;
                            return (
                              <div
                                key={c.id}
                                className={cn(
                                  "group/row relative flex items-center rounded-lg transition-colors",
                                  active ? "bg-accent shadow-2xs" : "hover:bg-accent/60",
                                )}
                              >
                                {active && (
                                  <span className="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-brand" />
                                )}
                                {renamingId === c.id ? (
                                  <input
                                    autoFocus
                                    value={draft}
                                    onChange={(e) => setDraft(e.target.value)}
                                    onBlur={commitRename}
                                    onKeyDown={(e) => {
                                      if (e.key === "Enter") commitRename();
                                      if (e.key === "Escape") setRenamingId(null);
                                    }}
                                    aria-label="Rename conversation"
                                    className="mx-1 my-1 h-7 flex-1 rounded-md border bg-card px-2 text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                  />
                                ) : (
                                  <button
                                    type="button"
                                    data-conv-row
                                    onClick={() => props.onSelect(c.id)}
                                    aria-current={active ? "page" : undefined}
                                    className="flex h-8 min-w-0 flex-1 items-center gap-1.5 rounded-lg px-2.5 text-left text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                  >
                                    {c.pinned && <IconPin size={11} className="shrink-0 text-brand" />}
                                    <span
                                      className={cn(
                                        "truncate",
                                        active ? "font-medium text-accent-foreground" : "text-foreground/85",
                                      )}
                                    >
                                      {c.title}
                                    </span>
                                  </button>
                                )}
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <button
                                      type="button"
                                      aria-label={`Options for ${c.title}`}
                                      className="mr-1 flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground opacity-0 outline-none transition hover:bg-background hover:text-foreground focus-visible:opacity-100 group-hover/row:opacity-100 data-[state=open]:opacity-100 [@media(hover:none)]:opacity-100"
                                    >
                                      <IconDots size={14} />
                                    </button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="start" side="right" className="w-52 p-1">
                                    <DropdownMenuItem
                                      onSelect={() => {
                                        setDraft(c.title);
                                        setRenamingId(c.id);
                                      }}
                                      className="rounded-lg"
                                    >
                                      <IconPencil size={14} /> Rename
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onSelect={() => props.onTogglePin(c.id, !c.pinned)}
                                      className="rounded-lg"
                                    >
                                      {c.pinned ? <IconPinOff size={14} /> : <IconPin size={14} />}
                                      {c.pinned ? "Unpin" : "Pin to top"}
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => props.onFork(c.id)} className="rounded-lg">
                                      <IconFork size={14} /> Duplicate
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onSelect={() => props.onExport(c.id, "md")} className="rounded-lg">
                                      <IconFile size={14} /> Export Markdown
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => props.onExport(c.id, "json")} className="rounded-lg">
                                      <IconDownload size={14} /> Export JSON
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      variant="destructive"
                                      onSelect={() => {
                                        if (window.confirm(`Delete “${c.title}”?`)) props.onDelete(c.id);
                                      }}
                                      className="rounded-lg"
                                    >
                                      <IconTrash size={14} /> Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </section>
              );
            })
          )}
        </div>

        {/* Clean Single-Row Footer */}
        <div className={cn("shrink-0 border-t border-border/50", collapsed ? "p-2" : "px-3 py-2.5")}>
          {collapsed ? (
            <div className="flex flex-col items-center gap-1">
              <RailTooltip label={props.resolvedTheme === "dark" ? "Light mode" : "Dark mode"}>
                <button
                  type="button"
                  onClick={props.onToggleTheme}
                  aria-label="Toggle theme"
                  className="flex size-9 items-center justify-center rounded-xl text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
                >
                  {props.resolvedTheme === "dark" ? <IconSun size={15} /> : <IconMoon size={15} />}
                </button>
              </RailTooltip>
              <RailTooltip label="Settings" shortcut="⌘,">
                <button
                  type="button"
                  onClick={props.onOpenSettings}
                  aria-label="Settings"
                  className="flex size-9 items-center justify-center rounded-xl text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
                >
                  <Settings2 size={15} />
                </button>
              </RailTooltip>
            </div>
          ) : (
            <div className="flex items-center gap-1">
              {props.providerLabel ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      type="button"
                      className="flex min-w-0 flex-1 items-center gap-2 rounded-lg px-2 py-1.5 text-left outline-none transition hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <span className="size-2 shrink-0 rounded-full bg-emerald-500" />
                      <span className="min-w-0 flex-1 truncate text-[12px] font-medium text-foreground">
                        {props.providerLabel}
                      </span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" side="top" className="w-52 p-1">
                    <DropdownMenuItem onSelect={props.onOpenSettings} className="rounded-lg">
                      <IconSettingsSliders size={14} /> Settings
                      <kbd className="ml-auto font-mono text-[10px] text-muted-foreground">⌘,</kbd>
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={props.onOpenStats} className="rounded-lg">
                      <IconAnalytics size={14} /> Usage analytics
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={props.onOpenAbout} className="rounded-lg">
                      <IconInfo size={14} /> About & open source
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <button
                  type="button"
                  onClick={props.onOpenQuickSetup ?? props.onOpenSettings}
                  className="flex min-w-0 flex-1 items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12px] font-medium text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <Plug size={13} className="shrink-0 text-brand" />
                  <span className="truncate">Connect provider</span>
                </button>
              )}

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={props.onToggleTheme}
                    aria-label="Toggle theme"
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
                  >
                    {props.resolvedTheme === "dark" ? <IconSun size={14} /> : <IconMoon size={14} />}
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top">
                  {props.resolvedTheme === "dark" ? "Switch to light" : "Switch to dark"}
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={props.onOpenSettings}
                    aria-label="Settings"
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-accent hover:text-foreground active:scale-95"
                  >
                    <Settings2 size={14} />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top">
                  Settings <kbd className="ml-1 font-mono text-[10px] opacity-60">⌘,</kbd>
                </TooltipContent>
              </Tooltip>
            </div>
          )}
        </div>
      </motion.aside>
    </TooltipProvider>
  );
}
