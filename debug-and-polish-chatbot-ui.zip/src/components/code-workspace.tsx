"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  FileCode2,
  FileJson,
  FileText,
  Play,
  Plus,
  Send,
  Terminal,
  Trash2,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  buildPreviewDocument,
  detectSandboxLanguage,
  SANDBOX_LANG_LABEL,
  withSandboxToken,
  type SandboxLanguage,
  type WorkspaceFile,
} from "@/lib/code-sandbox";
import { cn } from "@/lib/utils";

export type { WorkspaceFile } from "@/lib/code-sandbox";

type Language = SandboxLanguage;

function fileIcon(language: Language) {
  if (language === "json") return FileJson;
  if (language === "markdown" || language === "text") return FileText;
  return FileCode2;
}

const STARTER_FILES: WorkspaceFile[] = [
  {
    id: "starter-index",
    name: "index.html",
    language: "html",
    content: `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Nova Sandbox</title>
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
    <main class="card">
      <h1>Hello from the Nova sandbox</h1>
      <p>Edit the files on the left, press Run, then ask Nova to improve them.</p>
      <button id="cta" type="button">Count to 3</button>
      <output id="log"></output>
    </main>
    <script src="app.js"></script>
  </body>
</html>
`,
  },
  {
    id: "starter-styles",
    name: "styles.css",
    language: "css",
    content: `:root {
  color-scheme: light dark;
  font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: Canvas;
  color: CanvasText;
}

.card {
  display: grid;
  gap: 0.75rem;
  padding: 1.75rem;
  border: 1px solid color-mix(in oklab, CanvasText 15%, transparent);
  border-radius: 16px;
  max-width: 32rem;
}

button {
  justify-self: start;
  padding: 0.5rem 0.9rem;
  border-radius: 999px;
  border: 1px solid color-mix(in oklab, CanvasText 25%, transparent);
  background: color-mix(in oklab, CanvasText 8%, transparent);
  color: inherit;
  font: inherit;
  cursor: pointer;
}

output {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.85rem;
  opacity: 0.75;
}
`,
  },
  {
    id: "starter-app",
    name: "app.js",
    language: "javascript",
    content: `const cta = document.getElementById("cta");
const log = document.getElementById("log");

let count = 0;
cta.addEventListener("click", () => {
  count += 1;
  log.textContent = "Count: " + count;
  console.log("Clicked", count, "time(s)");
});
`,
  },
];

/* ── Component ─────────────────────────────────────────────────────────────── */

interface Props {
  open: boolean;
  onClose: () => void;
  /** Files are handed to the composer as attachments for the next message. */
  onSendToNova: (files: WorkspaceFile[]) => void;
  storageKey?: string;
}

const STORAGE_PREFIX = "nova-code-workspace:";

export default function CodeWorkspace({ open, onClose, onSendToNova, storageKey = "default" }: Props) {
  const [files, setFiles] = useState<WorkspaceFile[]>(STARTER_FILES);
  const [activeId, setActiveId] = useState<string>(STARTER_FILES[0].id);
  const [runDoc, setRunDoc] = useState<string>("");
  const [consoleLines, setConsoleLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [newFileName, setNewFileName] = useState("");
  const [adding, setAdding] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const frameRef = useRef<HTMLIFrameElement>(null);
  const tokenRef = useRef<string>("");
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const active = useMemo(() => files.find((f) => f.id === activeId) ?? files[0] ?? null, [files, activeId]);

  /* Persistence — a workspace survives reloads, scoped per browser + workspace. */
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(`${STORAGE_PREFIX}${storageKey}`);
      if (!raw) return;
      const parsed = JSON.parse(raw) as WorkspaceFile[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        setFiles(parsed);
        setActiveId(parsed[0].id);
      }
    } catch {
      /* ignore malformed workspace */
    }
  }, [storageKey]);

  useEffect(() => {
    try {
      window.localStorage.setItem(`${STORAGE_PREFIX}${storageKey}`, JSON.stringify(files));
    } catch {
      /* storage may be unavailable */
    }
  }, [files, storageKey]);

  /* Console capture from the sandboxed preview. */
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.source !== frameRef.current?.contentWindow) return;
      const data = event.data as { source?: string; token?: string; level?: string; text?: string };
      if (data?.source !== "nova-sandbox" || data.token !== tokenRef.current) return;
      const prefix = data.level === "error" ? "✕" : data.level === "warn" ? "!" : "›";
      setConsoleLines((prev) => [...prev.slice(-60), `${prefix} ${data.text ?? ""}`]);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  const run = useCallback(() => {
    const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
    tokenRef.current = token;
    setConsoleLines([]);
    setRunning(true);
    setRunDoc(withSandboxToken(buildPreviewDocument(files), token));
  }, [files]);

  const updateActive = useCallback(
    (content: string) => {
      setFiles((prev) => prev.map((f) => (f.id === activeId ? { ...f, content } : f)));
    },
    [activeId],
  );

  const addFile = () => {
    const name = newFileName.trim();
    if (!name) return;
    if (files.some((f) => f.name === name)) {
      setNewFileName("");
      setAdding(false);
      return;
    }
    const file: WorkspaceFile = {
      id: `file-${Date.now()}`,
      name,
      language: detectSandboxLanguage(name),
      content: "",
    };
    setFiles((prev) => [...prev, file]);
    setActiveId(file.id);
    setNewFileName("");
    setAdding(false);
  };

  const renameFile = (file: WorkspaceFile) => {
    const name = renameValue.trim();
    setRenamingId(null);
    if (!name || name === file.name) return;
    if (files.some((f) => f.id !== file.id && f.name === name)) return;
    setFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, name, language: detectSandboxLanguage(name) } : f)));
  };

  const deleteFile = (file: WorkspaceFile) => {
    setFiles((prev) => {
      const next = prev.filter((f) => f.id !== file.id);
      if (file.id === activeId) setActiveId(next[0]?.id ?? "");
      return next;
    });
  };

  const onEditorKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Tab") {
      event.preventDefault();
      const el = event.currentTarget;
      const start = el.selectionStart;
      const end = el.selectionEnd;
      const next = `${el.value.slice(0, start)}  ${el.value.slice(end)}`;
      updateActive(next);
      requestAnimationFrame(() => {
        el.selectionStart = el.selectionEnd = start + 2;
      });
    }
  };

  const syncScroll = (el: HTMLTextAreaElement) => {
    if (gutterRef.current) gutterRef.current.scrollTop = el.scrollTop;
  };

  if (!open) return null;

  const lineCount = active ? active.content.split("\n").length : 1;

  return (
    <aside
      aria-label="Code workspace"
      className="flex h-full w-full shrink-0 flex-col border-l border-border/70 bg-card/60 lg:w-[min(640px,52vw)]"
    >
      {/* Header */}
      <div className="flex h-12 shrink-0 items-center gap-2 border-b border-border/70 px-3">
        <FileCode2 size={15} className="text-brand" />
        <span className="text-[13px] font-semibold">Code workspace</span>
        <span className="rounded-full border bg-muted/50 px-2 py-0.5 font-mono text-[10.5px] text-muted-foreground">
          sandboxed
        </span>
        <div className="ml-auto flex items-center gap-1">
          <Button
            size="xs"
            variant="outline"
            onClick={() => onSendToNova(files)}
            disabled={files.length === 0}
            title="Attach every file to your next message"
          >
            <Send size={12} /> Send to Nova
          </Button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close code workspace"
            className="flex size-7 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-accent hover:text-foreground"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-rows-[auto_minmax(0,1fr)] lg:grid-cols-[168px_minmax(0,1fr)] lg:grid-rows-1">
        {/* File tree */}
        <div className="flex min-h-0 flex-col border-b border-border/70 lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between px-3 py-2">
            <span className="text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
              Files
            </span>
            <button
              type="button"
              onClick={() => setAdding((v) => !v)}
              aria-label="New file"
              className="rounded p-0.5 text-muted-foreground transition hover:bg-accent hover:text-foreground"
            >
              <Plus size={13} />
            </button>
          </div>

          {adding && (
            <div className="px-2 pb-2">
              <Input
                autoFocus
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") addFile();
                  if (e.key === "Escape") setAdding(false);
                }}
                placeholder="main.py"
                className="h-7 font-mono text-[11.5px]"
                aria-label="New file name"
              />
            </div>
          )}

          <div className="scroll-slim min-h-0 flex-1 overflow-y-auto px-1.5 pb-2">
            {files.map((file) => {
              const Icon = fileIcon(file.language);
              const isActive = file.id === activeId;
              return (
                <div key={file.id} className="group/file relative">
                  {renamingId === file.id ? (
                    <Input
                      autoFocus
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") renameFile(file);
                        if (e.key === "Escape") setRenamingId(null);
                      }}
                      onBlur={() => renameFile(file)}
                      className="h-7 my-0.5 mx-1 w-[calc(100%-0.5rem)] font-mono text-[11.5px]"
                      aria-label="Rename file"
                    />
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setActiveId(file.id);
                      }}
                      className={cn(
                        "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12px] outline-none transition",
                        isActive
                          ? "bg-accent font-medium text-accent-foreground"
                          : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                      )}
                    >
                      <Icon size={13} className="shrink-0 opacity-70" />
                      <span className="min-w-0 flex-1 truncate font-mono">{file.name}</span>
                    </button>
                  )}
                  <button
                    type="button"
                    aria-label={`Delete ${file.name}`}
                    onClick={() => deleteFile(file)}
                    className="absolute right-1.5 top-1.5 hidden rounded p-0.5 text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive group-hover/file:block"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              );
            })}
            {files.length === 0 && (
              <p className="px-2 py-4 text-[11.5px] text-muted-foreground">
                No files yet. Add one to start.
              </p>
            )}
          </div>

          <div className="border-t border-border/70 px-3 py-2 text-[10.5px] leading-snug text-muted-foreground">
            Files stay in this browser. “Send to Nova” attaches them to your next message.
          </div>
        </div>

        {/* Editor + preview */}
        <div className="flex min-h-0 flex-col">
          <div className="flex h-10 shrink-0 items-center gap-2 border-b border-border/70 px-3">
            <span className="truncate font-mono text-[11.5px] text-muted-foreground">
              {active?.name ?? "No file selected"}
            </span>
            {active && (
              <span className="rounded border bg-muted/50 px-1.5 py-px font-mono text-[10px] text-muted-foreground">
                {SANDBOX_LANG_LABEL[active.language]}
              </span>
            )}
            <div className="ml-auto flex items-center gap-1.5">
              <Button size="xs" variant="outline" onClick={run} disabled={!files.length}>
                {running ? <Play size={11} /> : <Play size={11} />}
                Run
              </Button>
            </div>
          </div>

          <div className="grid min-h-0 flex-1 grid-rows-2 lg:grid-cols-2 lg:grid-rows-1">
            {/* Editor */}
            <div className="relative flex min-h-0 flex-col border-b border-border/70 lg:border-b-0 lg:border-r">
              <div ref={gutterRef} className="pointer-events-none absolute inset-y-0 left-0 w-9 overflow-hidden border-r border-border/50 bg-muted/25 pt-3 text-right font-mono text-[11px] leading-[1.55] text-muted-foreground/50">
                {Array.from({ length: lineCount }, (_, i) => (
                  <div key={i} className="pr-1.5">
                    {i + 1}
                  </div>
                ))}
              </div>
              <textarea
                ref={editorRef}
                value={active?.content ?? ""}
                onChange={(e) => updateActive(e.target.value)}
                onKeyDown={onEditorKeyDown}
                onScroll={(e) => syncScroll(e.currentTarget)}
                spellCheck={false}
                aria-label="Code editor"
                placeholder="Write code here…"
                className="scroll-slim min-h-0 flex-1 resize-none bg-transparent py-3 pl-12 pr-3 font-mono text-[12px] leading-[1.55] outline-none placeholder:text-muted-foreground/40"
              />
            </div>

            {/* Preview + console */}
            <div className="flex min-h-0 flex-col bg-muted/20">
              <div className="flex h-8 shrink-0 items-center gap-1.5 border-b border-border/70 px-3 text-[11px] font-medium text-muted-foreground">
                <Play size={11} /> Preview
                <span className="ml-auto font-mono text-[10px] opacity-70">sandboxed · opaque origin</span>
              </div>
              <div className="min-h-0 flex-1">
                {runDoc ? (
                  <iframe
                    ref={frameRef}
                    title="Sandbox preview"
                    sandbox="allow-scripts"
                    srcDoc={runDoc}
                    className="h-full min-h-[140px] w-full border-0 bg-white"
                  />
                ) : (
                  <div className="flex h-full min-h-[140px] items-center justify-center px-4 text-center text-[11.5px] text-muted-foreground">
                    Press <span className="mx-1 font-medium text-foreground">Run</span> to execute the
                    workspace in an isolated sandbox.
                  </div>
                )}
              </div>

              {consoleLines.length > 0 && (
                <div className="max-h-[120px] shrink-0 overflow-y-auto border-t border-border/70 bg-background/60 px-3 py-2">
                  <p className="mb-1 flex items-center gap-1 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                    <Terminal size={10} /> Console
                  </p>
                  {consoleLines.map((line, i) => (
                    <p
                      key={i}
                      className={cn(
                        "truncate font-mono text-[11px] leading-relaxed",
                        line.startsWith("✕") ? "text-destructive" : "text-muted-foreground",
                      )}
                    >
                      {line}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}


