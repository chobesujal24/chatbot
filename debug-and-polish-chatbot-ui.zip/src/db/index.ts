import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * The pool is created lazily and never throws at import time. A module-scope
 * throw here would fail `next build`/`next start` in any environment where the
 * variable is not injected during the build phase, which takes the whole preview
 * down with a transport-level error.
 */
const DEFAULT_URL = "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

function resolveConnectionString(): string {
  const raw = process.env.DATABASE_URL?.trim();
  if (raw) return raw;
  if (process.env.NODE_ENV !== "test") {
    console.warn(
      "[db] DATABASE_URL is not set; falling back to the local development database.",
    );
  }
  return DEFAULT_URL;
}

const globalForDb = globalThis as typeof globalThis & {
  __novaPool?: Pool;
};

export const pool =
  globalForDb.__novaPool ??
  new Pool({
    connectionString: resolveConnectionString(),
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 8_000,
    allowExitOnIdle: false,
  });

// Never let an idle-client error crash the process.
pool.on("error", (error) => {
  console.error("[db] idle client error", error);
});

if (process.env.NODE_ENV !== "production") {
  globalForDb.__novaPool = pool;
}

export const db = drizzle(pool);
