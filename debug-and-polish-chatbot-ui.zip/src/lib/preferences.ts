import "server-only";

import { db } from "@/db";
import { workspacePreferences } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  DEFAULT_PREFERENCES,
  normalizePreferences,
  type Preferences,
} from "./preferences-model";

export type { Preferences };
export { DEFAULT_PREFERENCES, normalizePreferences };

/**
 * Stored preferences are normalised on the way out, so a value written by an
 * older build (or a hand-edited row) can never produce an out-of-range request.
 */
export async function getPreferences(workspaceId: string): Promise<Preferences> {
  try {
    const [row] = await db
      .select()
      .from(workspacePreferences)
      .where(eq(workspacePreferences.workspaceId, workspaceId))
      .limit(1);
    return normalizePreferences(row?.preferences ?? {});
  } catch {
    return { ...DEFAULT_PREFERENCES };
  }
}

export async function savePreferences(
  workspaceId: string,
  values: Record<string, unknown>,
): Promise<Preferences> {
  const current = await getPreferences(workspaceId);
  const next = normalizePreferences({ ...current, ...values });
  await db
    .insert(workspacePreferences)
    .values({ workspaceId, preferences: next as unknown as Record<string, unknown>, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: workspacePreferences.workspaceId,
      set: { preferences: next as unknown as Record<string, unknown>, updatedAt: new Date() },
    });
  return next;
}
