import { db } from "@/db";
import {
  agents,
  conversations,
  memories,
  messages,
  promptTemplates,
  sharedLinks,
  tasks,
  type Agent,
  type Conversation,
  type Memory,
  type Message,
  type PromptTemplate,
  type SharedLink,
  type Task,
} from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { ApiError, isUuid } from "./http";

export const toSummary = (c: Conversation) => ({
  id: c.id,
  title: c.title,
  pinned: c.pinned,
  model: c.model,
  agentId: c.agentId,
  createdAt: c.createdAt.toISOString(),
  updatedAt: c.updatedAt.toISOString(),
});

export const toMessage = (m: Message) => ({
  id: m.id,
  conversationId: m.conversationId,
  role: m.role,
  content: m.content,
  model: m.model,
  attachments: m.attachments,
  toolCalls: m.toolCalls,
  usage: m.usage,
  seq: m.seq,
  contextMeta: m.contextMeta,
  createdAt: m.createdAt.toISOString(),
});

export const toAgent = (a: Agent) => ({
  id: a.id,
  name: a.name,
  description: a.description,
  systemPrompt: a.systemPrompt,
  model: a.model,
  temperature: a.temperature,
  maxSteps: a.maxSteps,
  tools: a.tools ?? [],
  memoryMode: a.memoryMode ?? "auto",
  skills: a.skills ?? null,
  icon: a.icon,
  isDefault: a.isDefault,
  createdAt: a.createdAt.toISOString(),
  updatedAt: a.updatedAt.toISOString(),
});

export const toMemory = (m: Memory) => ({
  id: m.id,
  key: m.key,
  value: m.value,
  type: m.type,
  origin: m.origin,
  tags: m.tags ?? [],
  confidence: m.confidence,
  importance: m.importance,
  pinned: m.pinned,
  enabled: m.enabled,
  useCount: m.useCount,
  lastUsedAt: m.lastUsedAt?.toISOString() ?? null,
  createdAt: m.createdAt.toISOString(),
  updatedAt: m.updatedAt.toISOString(),
});

export const toTask = (t: Task) => ({
  id: t.id,
  title: t.title,
  status: t.status,
  agentId: t.agentId,
  conversationId: t.conversationId,
  createdAt: t.createdAt.toISOString(),
  updatedAt: t.updatedAt.toISOString(),
});

export const toTemplate = (t: PromptTemplate) => ({
  id: t.id,
  name: t.name,
  content: t.content,
  createdAt: t.createdAt.toISOString(),
});

export const toSharedLink = (s: SharedLink) => ({
  id: s.id,
  token: s.token,
  conversationId: s.conversationId,
  createdAt: s.createdAt.toISOString(),
  expiresAt: s.expiresAt?.toISOString() ?? null,
});

/** Every mutation verifies ownership before touching a row. */
export async function ownedConversation(ws: string, id: string): Promise<Conversation> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Conversation not found.");
  return row;
}

export async function ownedAgent(ws: string, id: string): Promise<Agent> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(agents)
    .where(and(eq(agents.id, id), eq(agents.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Agent not found.");
  return row;
}

export async function ownedMessage(ws: string, id: string): Promise<Message> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(messages)
    .where(and(eq(messages.id, id), eq(messages.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Message not found.");
  return row;
}

export async function ownedTask(ws: string, id: string): Promise<Task> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.id, id), eq(tasks.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Task not found.");
  return row;
}

export async function ownedMemory(ws: string, id: string): Promise<Memory> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(memories)
    .where(and(eq(memories.id, id), eq(memories.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Memory not found.");
  return row;
}

export async function ownedTemplate(ws: string, id: string): Promise<PromptTemplate> {
  if (!isUuid(id)) throw new ApiError(404, "not_found", "Not found.");
  const [row] = await db
    .select()
    .from(promptTemplates)
    .where(and(eq(promptTemplates.id, id), eq(promptTemplates.workspaceId, ws)))
    .limit(1);
  if (!row) throw new ApiError(404, "not_found", "Template not found.");
  return row;
}

export async function ownedSharedLink(ws: string, conversationId: string): Promise<SharedLink | null> {
  const [row] = await db
    .select()
    .from(sharedLinks)
    .where(
      and(
        eq(sharedLinks.conversationId, conversationId),
        eq(sharedLinks.workspaceId, ws),
      ),
    )
    .limit(1);
  return row ?? null;
}
