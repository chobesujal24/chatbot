import type { ContextSettings } from "@/db/schema";

/**
 * Context control: an explicit budget model over everything that goes into the
 * prompt. Segments are reported to the UI in the spirit of the `Context`
 * component from `vercel/ai-elements`, and compaction summarises old turns so a
 * long conversation keeps fitting the window.
 */

export interface ResolvedContextSettings {
  maxHistoryMessages: number;
  injectMemories: boolean;
  memoryLimit: number;
  includeSkills: boolean;
  autoCompact: boolean;
  /** Ratio of the window above which compaction runs (0-1). */
  compactThreshold: number;
  compactTargetRatio?: number;
  keepPairs?: boolean;
  contextWindow: number;
  outputBudget: number;
}

export const BASE_CONTEXT_SETTINGS: ResolvedContextSettings = {
  maxHistoryMessages: 24,
  injectMemories: true,
  memoryLimit: 6,
  includeSkills: true,
  autoCompact: true,
  compactThreshold: 0.8,
  contextWindow: 128_000,
  outputBudget: 2048,
};

export function resolveContextSettings(
  prefs: Record<string, unknown> | undefined,
  conversation?: ContextSettings | null,
): ResolvedContextSettings {
  // The settings page writes these as flat keys; a nested `contextSettings`
  // object is accepted too. Conversation-level overrides always win.
  const pick = (source: Record<string, unknown> | undefined) =>
    source
      ? Object.fromEntries(
          Object.entries({
            maxHistoryMessages: source.maxHistoryMessages,
            injectMemories: source.injectMemories,
            memoryLimit: source.memoryLimit,
            includeSkills: source.includeSkills ?? source.showSkillsIndex,
            autoCompact: source.autoCompact,
            compactThreshold: source.compactThreshold,
            compactTargetRatio: source.compactTargetRatio,
            keepPairs: source.keepPairs,
            contextWindow: source.contextWindow,
            outputBudget: source.outputBudget,
          }).filter(([, value]) => value !== undefined),
        )
      : {};

  const merged = {
    ...BASE_CONTEXT_SETTINGS,
    compactTargetRatio: 0.55,
    keepPairs: true,
    ...pick(prefs),
    ...pick(prefs?.contextSettings as Record<string, unknown> | undefined),
    ...pick(conversation as unknown as Record<string, unknown>),
  };

  return {
    maxHistoryMessages: clampInt(merged.maxHistoryMessages, 2, 200, 24),
    injectMemories: merged.injectMemories !== false,
    memoryLimit: clampInt(merged.memoryLimit, 0, 25, 6),
    includeSkills: merged.includeSkills !== false,
    autoCompact: merged.autoCompact !== false,
    compactThreshold: clampRatio(merged.compactThreshold, 0.3, 0.98, 0.8),
    compactTargetRatio: clampRatio(merged.compactTargetRatio, 0.2, 0.9, 0.55),
    keepPairs: merged.keepPairs !== false,
    contextWindow: clampInt(merged.contextWindow, 4096, 2_000_000, 128_000),
    outputBudget: clampInt(merged.outputBudget, 128, 65_536, 2048),
  };
}

const clampInt = (value: unknown, min: number, max: number, fallback: number) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
};

/** Ratios keep their decimals — rounding 0.8 up to 1 once broke auto-compaction. */
const clampRatio = (value: unknown, min: number, max: number, fallback: number) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

/**
 * Token estimate. Roughly 4 characters per token for prose; CJK and emoji are
 * counted per character, which keeps long mixed-language threads honest.
 */
export function estimateTokens(text: string): number {
  if (!text) return 0;
  let wide = 0;
  let ascii = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0) ?? 0;
    if (code > 0x2e80) wide += 1;
    else ascii += 1;
  }
  return Math.ceil(wide + ascii / 4);
}

export interface ContextSegment {
  id: string;
  label: string;
  tokens: number;
  detail?: string;
}

export interface ContextBreakdown {
  segments: ContextSegment[];
  promptTokens: number;
  outputBudget: number;
  contextWindow: number;
  ratio: number;
  headroom: number;
  overage: number;
  estimated: boolean;
}

export function buildBreakdown(input: {
  system?: string;
  skillsIndex?: string;
  memoryBlock?: string;
  summary?: string | null;
  history?: Array<{ role: string; content: string }>;
  attachments?: string;
  settings: ResolvedContextSettings;
  /** Exact counts from the provider when available. */
  measuredPromptTokens?: number | null;
}): ContextBreakdown {
  const segments: ContextSegment[] = [];
  const push = (id: string, label: string, text: string | undefined, detail?: string) => {
    const tokens = estimateTokens(text ?? "");
    if (tokens > 0) segments.push({ id, label, tokens, detail });
  };

  push("system", "System prompt", input.system);
  push("skills", "Skills index", input.skillsIndex);
  push("memory", "Memory", input.memoryBlock);
  push("summary", "Conversation summary", input.summary ?? undefined);
  const historyTokens = (input.history ?? []).reduce(
    (sum, m) => sum + estimateTokens(m.content) + 4,
    0,
  );
  if (historyTokens > 0) {
    segments.push({
      id: "history",
      label: "Message history",
      tokens: historyTokens,
      detail: `${input.history?.length ?? 0} messages`,
    });
  }
  push("attachments", "Attachments", input.attachments);

  const promptTokens =
    input.measuredPromptTokens ?? segments.reduce((sum, s) => sum + s.tokens, 0);
  const total = promptTokens + input.settings.outputBudget;
  const ratio = input.settings.contextWindow ? total / input.settings.contextWindow : 0;

  return {
    segments,
    promptTokens,
    outputBudget: input.settings.outputBudget,
    contextWindow: input.settings.contextWindow,
    ratio: Math.min(1.5, Number(ratio.toFixed(4))),
    headroom: Math.max(0, input.settings.contextWindow - total),
    overage: Math.max(0, total - input.settings.contextWindow),
    estimated: input.measuredPromptTokens == null,
  };
}

/* ── History windowing ───────────────────────────────────────────────────── */

export interface HistoryPlan<T> {
  included: T[];
  dropped: T[];
  summarizedCount: number;
}

/**
 * Drop the rows already folded into the conversation summary, then keep the
 * most recent turns within the budget.
 */
export function planHistory<T extends { role?: string; content: string; createdAt: Date }>(
  all: T[],
  settings: ResolvedContextSettings,
  summarizedCount: number,
): HistoryPlan<T> {
  const tail = all.slice(Math.max(0, summarizedCount));
  if (tail.length <= settings.maxHistoryMessages) {
    return { included: tail, dropped: [], summarizedCount };
  }
  let cutIndex = tail.length - settings.maxHistoryMessages;
  // Never start the window with an orphan assistant turn when keepPairs is on.
  if (settings.keepPairs !== false && tail[cutIndex]?.role === "assistant" && cutIndex < tail.length - 1) {
    cutIndex += 1;
  }
  return {
    included: tail.slice(cutIndex),
    dropped: tail.slice(0, cutIndex),
    summarizedCount,
  };
}

/* ── Compaction ──────────────────────────────────────────────────────────── */

const MAX_SUMMARY_CHARS = 4000;

/**
 * Deterministic extractive summary used when no model is connected. It favours
 * user intent, entities, numbers and decisions so the replacement block keeps
 * the facts a follow-up question would otherwise need.
 */
export function extractiveSummary(messages: Array<{ role: string; content: string }>): string {
  const bullets: string[] = [];
  const seen = new Set<string>();

  const add = (line: string) => {
    const clean = line.replace(/\s+/g, " ").trim().slice(0, 220);
    if (clean.length < 12) return;
    const fingerprint = clean.toLowerCase().slice(0, 60);
    if (seen.has(fingerprint)) return;
    seen.add(fingerprint);
    bullets.push(clean);
  };

  for (const message of messages) {
    const body = message.content
      .replace(/```[\s\S]*?```/g, " [code] ")
      .replace(/^#+\s*/gm, "")
      .replace(/[*_>`|]/g, "")
      .trim();
    // Greetings and one-word replies carry nothing worth keeping.
    if (body.length < 24) continue;

    const sentences = body
      .split(/(?<=[.!?])\s+|\n+/)
      .map((s) => s.trim())
      .filter(Boolean);

    if (message.role === "user") {
      add(`Requested: ${sentences[0] ?? body}`);
      const numbers = body.match(/\$?\d[\d.,]*\s?(%|k|m|bn|gb|mb|ms|s)?/gi);
      if (numbers?.length) add(`Figures mentioned: ${numbers.slice(0, 8).join(", ")}`);
    } else {
      add(`Answered: ${sentences[0] ?? body}`);
      const decisions = sentences.find((s) =>
        /\b(you should|the fix|recommend|next step|conclusion|answer is|use |avoid )\b/i.test(s),
      );
      if (decisions) add(`Key point: ${decisions}`);
    }

    if (bullets.length > 60) break;
  }

  if (bullets.length === 0) return "";
  const kept: string[] = [];
  let size = 0;
  for (const bullet of bullets) {
    size += bullet.length + 3;
    if (size > MAX_SUMMARY_CHARS) break;
    kept.push(bullet);
  }
  return kept.map((b) => `- ${b}`).join("\n");
}

export function renderSummaryBlock(summary: string, count: number): string {
  return [
    `# Conversation summary`,
    "",
    `The first ${count} message${count === 1 ? "" : "s"} of this conversation were compacted into the notes below. Use them as established context; do not restate that they are a summary.`,
    "",
    summary.trim(),
  ].join("\n");
}

export function shouldCompact(breakdown: ContextBreakdown, settings: ResolvedContextSettings) {
  return settings.autoCompact && breakdown.ratio >= settings.compactThreshold;
}

/** How many of the included messages to fold away so the ratio drops below target. */
export function compactionTargets<T>(
  included: T[],
  settings: ResolvedContextSettings,
  fixedTokens: number,
  targetRatio = 0.55,
): number {
  if (included.length <= 4) return 0;
  const budget = Math.floor(settings.contextWindow * targetRatio) - fixedTokens - settings.outputBudget;
  if (budget <= 0) return included.length - 2;
  let running = 0;
  let keepFrom = 0;
  for (let i = included.length - 1; i >= 0; i--) {
    const item = included[i] as { content?: string };
    running += estimateTokens(item?.content ?? "") + 4;
    if (running > budget) {
      keepFrom = i + 1;
      break;
    }
  }
  // Always keep at least the last two turns, and compact in pairs.
  const drop = Math.max(0, keepFrom - (keepFrom % 2));
  return Math.min(drop, Math.max(0, included.length - 2));
}

export const conversationSummaryState = (c: { summary: string | null; summarizedCount: number | null }) => ({
  hasSummary: Boolean(c.summary),
  summarizedCount: c.summarizedCount ?? 0,
});
