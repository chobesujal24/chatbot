import "server-only";

import { createHash, randomBytes } from "node:crypto";
import { db } from "@/db";
import { appSecrets } from "@/db/schema";
import { eq } from "drizzle-orm";

let cached: string | null = null;

/**
 * The application secret used to sign cookies and derive the credential
 * encryption key. Set AUTH_SECRET in production so every instance agrees.
 */
export async function appSecret(): Promise<string> {
  const fromEnv = process.env.AUTH_SECRET?.trim();
  if (fromEnv) return fromEnv;
  if (cached) return cached;
  const value = randomBytes(32).toString("hex");
  await db
    .insert(appSecrets)
    .values({ id: "app-secret", value })
    .onConflictDoNothing();
  const [row] = await db
    .select({ value: appSecrets.value })
    .from(appSecrets)
    .where(eq(appSecrets.id, "app-secret"))
    .limit(1);
  cached = row?.value ?? value;
  return cached;
}

/** 256-bit key derived from the app secret, used for credential encryption. */
export async function encryptionKey(): Promise<Buffer> {
  const secret = await appSecret();
  return createHash("sha256").update(`nova-credential:v1:${secret}`).digest();
}
