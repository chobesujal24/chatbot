// Pure SKILL.md parsing and prompt rendering.
// Client-safe (no server imports) so the UI and unit tests can use it directly.

/**
 * Format follows the Agent Skills spec used by `anthropics/skills`:
 * YAML frontmatter with `name` + `description`, markdown body as instructions.
 */

export interface ParsedSkillFile {
  name: string;
  description: string;
  instructions: string;
  tools: string[] | null;
  emoji: string;
}

export interface SkillSummary {
  name: string;
  description: string;
  emoji: string;
}

export interface SkillLike extends SkillSummary {
  instructions?: string;
}

export function parseSkillMarkdown(raw: string): ParsedSkillFile {
  const text = raw.replace(/\r\n/g, "\n").trim();
  const match = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(text);
  let frontmatter = "";
  let body = text;
  if (match) {
    frontmatter = match[1];
    body = match[2].trim();
  }

  const fields: Record<string, string> = {};
  for (const line of frontmatter.split("\n")) {
    const kv = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line.trim());
    if (kv) fields[kv[1].toLowerCase()] = kv[2].trim().replace(/^["']|["']$/g, "");
  }

  const listField = (value?: string): string[] | null => {
    if (!value) return null;
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map(String);
    } catch {
      /* not JSON */
    }
    const parts = value
      .replace(/^\[|\]$/g, "")
      .split(",")
      .map((s) => s.trim().replace(/^["']|["']$/g, ""))
      .filter(Boolean);
    return parts.length ? parts : null;
  };

  const heading = /^#\s+(.+)$/m.exec(body)?.[1]?.trim();
  const firstParagraph = body
    .split("\n")
    .map((l) => l.trim())
    .find((l) => l && !l.startsWith("#"));

  const name = fields.name || heading || "Untitled skill";
  const description = fields.description || firstParagraph?.slice(0, 240) || "";

  return {
    name: name.slice(0, 80),
    description: description.slice(0, 600),
    instructions: body.slice(0, 40000),
    tools: listField(fields.tools ?? fields["allowed-tools"] ?? fields["allowed_tools"]),
    emoji: (fields.emoji || "✦").slice(0, 8),
  };
}

export function serializeSkillMarkdown(skill: {
  name: string;
  description: string;
  instructions: string;
  tools?: string[] | null;
  emoji?: string;
}): string {
  const lines = ["---", `name: ${skill.name}`, `description: ${skill.description}`];
  if (skill.emoji && skill.emoji !== "✦") lines.push(`emoji: ${skill.emoji}`);
  if (skill.tools?.length) lines.push(`tools: ${JSON.stringify(skill.tools)}`);
  lines.push("---", "", skill.instructions.trim(), "");
  return lines.join("\n");
}

export const slugifySkillName = (value: string) =>
  value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "skill";

/** The only skills text the model sees before it loads one. */
export function renderSkillIndex(list: SkillSummary[]): string {
  if (list.length === 0) return "";
  const lines = list.map((s) => `- ${s.emoji} ${s.name}: ${s.description}`.slice(0, 400));
  return [
    "# Skills",
    "",
    "You have these skills available. Each is a pack of detailed instructions for a specific kind of task.",
    "Only load a skill when the request clearly matches it — call the loadSkill tool with the skill name to read its full instructions, then follow them exactly.",
    "Do not summarise or guess at a skill's contents; load it. Do not load more than two skills per turn.",
    "",
    ...lines,
  ].join("\n");
}

export function selectSkillList<T extends { enabled?: boolean; name: string; id?: string }>(
  all: T[],
  allow: string[] | null | undefined,
): T[] {
  const enabled = all.filter((s) => s.enabled !== false);
  if (!allow || allow.length === 0) return enabled;
  const set = new Set(allow);
  return enabled.filter((s) => set.has(s.name) || (s.id ? set.has(s.id) : false));
}

/**
 * Cheap lexical match between a user request and a skill's own description.
 * Used for progressive auto-load: a strong single match attaches the skill
 * without waiting for the model to ask for it.
 */
export function skillMatchScore(request: string, skill: SkillSummary): number {
  const words = (text: string) =>
    new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter((w) => w.length > 3),
    );
  const a = words(request);
  const b = words(`${skill.name} ${skill.description}`);
  if (a.size === 0 || b.size === 0) return 0;
  let hits = 0;
  for (const w of a) if (b.has(w)) hits += 1;
  return Math.min(1, hits / Math.min(4, Math.max(1, b.size * 0.5)));
}

export function pickAutoLoadSkill<T extends SkillSummary>(
  skills: T[],
  request: string,
  threshold: number,
): T | null {
  const scored = skills
    .map((skill) => ({ skill, score: skillMatchScore(request, skill) }))
    .filter((entry) => entry.score >= threshold)
    .sort((x, y) => y.score - x.score);
  // Only auto-load when the winner is clearly ahead of the runner-up.
  if (scored.length === 0) return null;
  if (scored.length > 1 && scored[1].score > scored[0].score - 0.12) return null;
  return scored[0].skill;
}
