// Pure local utilities: deterministic recursive-descent arithmetic parser,
// conversation title derivation, attachment redaction/display helpers, and
// actionable setup guidance when no model provider is connected yet.

export function evaluateMath(input: string): number | null {
  const expr = input.replace(/\s+/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, "");
  if (!expr || !/^[0-9+\-*/().%^]+$/.test(expr)) return null;
  let pos = 0;
  const peek = () => expr[pos];
  const consume = (ch: string) => (peek() === ch ? ++pos > -1 : false);

  function exprP(): number | null {
    let v = term();
    if (v === null) return null;
    while (peek() === "+" || peek() === "-") {
      const op = expr[pos++];
      const r = term();
      if (r === null) return null;
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }
  function term(): number | null {
    let v = factor();
    if (v === null) return null;
    while (peek() === "*" || peek() === "/" || peek() === "%") {
      const op = expr[pos++];
      const r = factor();
      if (r === null) return null;
      if (op === "*") v *= r;
      else if (op === "/") {
        if (r === 0) return null;
        v /= r;
      } else v %= r;
    }
    return v;
  }
  function factor(): number | null {
    let b = unary();
    if (b === null) return null;
    if (peek() === "^" || (peek() === "*" && expr[pos + 1] === "*")) {
      pos += peek() === "^" ? 1 : 2;
      const e = factor();
      if (e === null) return null;
      b = Math.pow(b, e);
    }
    return b;
  }
  function unary(): number | null {
    if (peek() === "-") {
      pos++;
      const v = unary();
      return v === null ? null : -v;
    }
    if (peek() === "+") {
      pos++;
      return unary();
    }
    return atom();
  }
  function atom(): number | null {
    if (peek() === "(") {
      pos++;
      const v = exprP();
      if (v === null) return null;
      if (!consume(")")) return null;
      return v;
    }
    let num = "";
    while (pos < expr.length && /[0-9.]/.test(expr[pos])) num += expr[pos++];
    if (!num) return null;
    const n = Number(num);
    return Number.isFinite(n) ? n : null;
  }
  const result = exprP();
  return result !== null && pos === expr.length && Number.isFinite(result) ? result : null;
}

export function deriveTitle(message: string): string {
  const clean = stripAttachedBlocks(message)
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "New conversation";
  return clean.length <= 52 ? clean : clean.slice(0, 49).trimEnd() + "…";
}

const ATTACHMENT_BLOCK_RE = /\n*--- Attached file: ([^\n]+?) ---\n[\s\S]*?\n--- End of \1 ---/g;

/** Removes inline attachment payload blocks while preserving the user's message text. */
export function stripAttachedBlocks(content: string): string {
  return content.replace(ATTACHMENT_BLOCK_RE, "").trim();
}

/** Returns the raw attachment blocks so edits can carry them forward. */
export function extractAttachedBlocks(content: string): string[] {
  ATTACHMENT_BLOCK_RE.lastIndex = 0;
  const blocks: string[] = [];
  let match: RegExpExecArray | null;
  while ((match = ATTACHMENT_BLOCK_RE.exec(content)) !== null) {
    blocks.push(match[0].trim());
  }
  ATTACHMENT_BLOCK_RE.lastIndex = 0;
  return blocks;
}

/** Replaces inline attachment contents with a privacy notice for redacted shared links. */
export function redactAttachedBlocks(content: string): string {
  return content.replace(
    ATTACHMENT_BLOCK_RE,
    (_full, name: string) => `\n\n> *[Attached file redacted: ${name}]*`,
  );
}

/** Honest, actionable notice returned when no model provider is connected. */
export function noProviderNotice(detail?: string): string {
  const reason = detail?.trim()
    ? `**Provider configuration required:** ${detail.trim()}`
    : "**No model provider is connected yet.**";

  return [
    reason,
    "",
    "Nova connects directly to your own model providers and never uses mock or simulated responses. Connect a provider to start generating:",
    "",
    "1. Open **[Settings → Providers](/settings#providers)**.",
    "2. Add an API key for **OpenAI**, **Anthropic**, **Google Gemini**, **OpenRouter**, **Groq**, **DeepSeek**, or another supported provider — or point **Ollama / LM Studio / vLLM** at your local server.",
    "3. Save the connection and mark it **Active**, then regenerate this turn.",
  ].join("\n");
}
