import { z } from "zod";

const id = z.string().regex(/^[0-9a-f-]{36}$/i, "Invalid id");
const shortText = (max: number) => z.string().trim().max(max);
const bounded = (min: number, max: number) => z.number().finite().min(min).max(max);

export const providerId = z.enum([
  "offline",
  "openai",
  "anthropic",
  "google",
  "perplexity",
  "ollama",
  "lmstudio",
  "vllm",
  "openrouter",
  "deepseek",
  "groq",
  "together",
  "xai",
  "mistral",
  "fireworks",
  "cerebras",
  "siliconflow",
  "huggingface",
  "custom",
]);

export const settingsSchema = z.object({
  provider: providerId.default("offline"),
  model: shortText(120).default(""),
  apiKey: z.string().max(500).optional().default(""),
  baseURL: z.string().max(500).optional().default(""),
  systemPrompt: z.string().max(4000).default(""),
  temperature: bounded(0, 2).default(0.7),
  maxTokens: bounded(128, 65536).default(2048),
});

export const attachmentSchema = z.object({
  name: shortText(120),
  content: z.string().max(520000),
});

export const chatSchema = z
  .object({
    conversationId: id.nullish(),
    agentId: id.nullish(),
    content: shortText(8000).optional(),
    attachments: z.array(attachmentSchema).max(5).optional().default([]),
    mode: z.enum(["send", "regenerate", "edit"]).default("send"),
    editMessageId: id.optional(),
    editContent: shortText(8000).optional(),
    settings: settingsSchema,
  })
  .superRefine((value, ctx) => {
    if (value.mode === "send" && !value.content?.trim()) {
      ctx.addIssue({ code: "custom", path: ["content"], message: "Message is required" });
    }
    if (value.mode === "edit" && (!value.editMessageId || !value.editContent?.trim())) {
      ctx.addIssue({
        code: "custom",
        path: ["editContent"],
        message: "Edit requires an id and new content",
      });
    }
    if (value.mode !== "send" && !value.conversationId) {
      ctx.addIssue({
        code: "custom",
        path: ["conversationId"],
        message: "Conversation is required",
      });
    }
  });

export const conversationCreateSchema = z.object({
  title: shortText(200).optional(),
});

export const conversationPatchSchema = z
  .object({
    title: shortText(200).optional(),
    pinned: z.boolean().optional(),
  })
  .refine((v) => v.title !== undefined || v.pinned !== undefined, {
    message: "No changes supplied",
  });

export const agentSchema = z.object({
  name: shortText(80).min(1, "Name is required"),
  description: z.string().max(500).default(""),
  systemPrompt: z.string().max(8000).default(""),
  model: shortText(120).nullable().optional(),
  temperature: bounded(0, 2).default(0.7),
  maxSteps: z.number().int().min(1).max(20).default(5),
  tools: z.array(z.string().max(40)).max(20).default([]),
  icon: shortText(20).default("bot"),
  memoryMode: z.enum(["auto", "on", "off"]).default("auto"),
  skills: z.array(z.string().max(60)).max(40).nullable().optional(),
});

export const agentPatchSchema = agentSchema.partial().extend({
  isDefault: z.literal(true).optional(),
});

export const memorySchema = z.object({
  key: shortText(60).min(1),
  value: shortText(2000).min(1),
});

export const taskSchema = z.object({
  title: shortText(300).min(1),
});

export const taskPatchSchema = z
  .object({
    status: z.enum(["open", "done"]).optional(),
    title: shortText(300).optional(),
  })
  .refine((v) => v.status !== undefined || v.title !== undefined, {
    message: "No changes supplied",
  });

export const templateSchema = z.object({
  name: shortText(80).min(1),
  content: z.string().max(8000).min(1),
});

export const messagePatchSchema = z.object({
  content: shortText(8000).min(1),
});

export const authSchema = z.object({
  password: z.string().min(1).max(200),
});

export const feedbackSchema = z.object({
  rating: z.enum(["up", "down"]),
});

export const searchQuerySchema = z.object({
  q: z.string().trim().min(2).max(200),
  limit: z.coerce.number().int().min(1).max(30).default(12),
});

export const paginationSchema = z.object({
  limit: z.coerce.number().int().min(1).max(200).default(100),
  offset: z.coerce.number().int().min(0).max(10000).default(0),
});

export function slugify(value: string): string {
  return (
    value
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "note"
  );
}

/* ── Credentials & preferences ──────────────────────────────────────────── */

export const credentialInputSchema = z.object({
  provider: z.string().trim().min(1).max(40),
  kind: z.enum(["model", "search", "reader"]).optional(),
  label: z.string().trim().max(80).optional(),
  secret: z.string().max(1000).optional(),
  baseURL: z.string().trim().max(500).nullish(),
  options: z.record(z.string(), z.unknown()).optional(),
  enabled: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

export const credentialTestSchema = z.object({
  provider: z.string().trim().min(1).max(40),
  secret: z.string().max(1000).optional(),
  baseURL: z.string().trim().max(500).nullish(),
});

export const toolTestSchema = z.object({
  tool: z.enum([
    "calculator",
    "currentTime",
    "webSearch",
    "webFetch",
    "fetchUrl",
    "searchHistory",
    "recall",
    "listTasks",
    "loadSkill",
  ]),
  input: z.string().max(4000).optional().default(""),
});

/**
 * Preferences are validated by the shared `normalizePreferences` model, which
 * clamps every numeric range and drops unknown keys. The schema here only needs
 * to guarantee a JSON object of shallow values.
 */
export const preferencesSchema = z
  .record(z.string(), z.unknown())
  .refine((value) => Object.keys(value).length <= 120, "Too many preference keys at once");

export const skillCreateSchema = z.object({
  name: z.string().trim().min(1).max(80),
  description: z.string().trim().max(600).default(""),
  instructions: z.string().max(40000).default(""),
  tools: z.array(z.string().max(40)).max(20).nullable().optional(),
  emoji: z.string().trim().max(8).default("✦"),
  enabled: z.boolean().default(true),
});

export const skillPatchSchema = skillCreateSchema.partial();

export const skillImportSchema = z.object({
  markdown: z.string().min(1).max(200000),
  overwrite: z.boolean().default(false),
});

export const memoryCreateSchema = z.object({
  key: z.string().trim().max(60).optional(),
  value: z.string().trim().min(1).max(2000),
  type: z.enum(["preference", "fact", "entity", "procedure", "event"]).default("fact"),
  importance: z.number().min(0).max(1).default(0.5),
  confidence: z.number().min(0).max(1).default(1),
  tags: z.array(z.string().max(40)).max(12).optional(),
  pinned: z.boolean().optional(),
});

export const memoryPatchSchema = z.object({
  value: z.string().trim().min(1).max(2000).optional(),
  type: memoryCreateSchema.shape.type.optional(),
  importance: z.number().min(0).max(1).optional(),
  confidence: z.number().min(0).max(1).optional(),
  tags: z.array(z.string().max(40)).max(12).optional(),
  pinned: z.boolean().optional(),
  enabled: z.boolean().optional(),
});

export const contextPatchSchema = z.object({
  maxHistoryMessages: z.number().int().min(2).max(200).optional(),
  injectMemories: z.boolean().optional(),
  memoryLimit: z.number().int().min(0).max(25).optional(),
  includeSkills: z.boolean().optional(),
  autoCompact: z.boolean().optional(),
  compactThreshold: z.number().min(0.3).max(0.98).optional(),
  contextWindow: z.number().int().min(4096).max(2000000).optional(),
  outputBudget: z.number().int().min(128).max(65536).optional(),
});

export const compactSchema = z.object({
  keepRecent: z.number().int().min(2).max(40).optional(),
});
