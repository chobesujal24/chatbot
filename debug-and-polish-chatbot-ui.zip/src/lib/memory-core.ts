// Pure memory ranking and extraction. Client-safe so the UI and tests share it.
//
// Mirrors the mem0 approach (`mem0ai/mem0`): store discrete facts, then rank
// candidates by relevance, importance, confidence and recency rather than
// replaying raw transcript.

export const MEMORY_TYPES = ["preference", "fact", "entity", "procedure", "event"] as const;
export type MemoryType = (typeof MEMORY_TYPES)[number];

const STOPWORDS = new Set(`a about above after again against all am any are as at be because been before being below between both but by can cannot could did do does doing down during each few for from further had has have having he her here hers herself him himself his how i if in into is it its itself just me more most my myself no nor not now of off on once only or other our ours ourselves out over own same she should so some such than that the their theirs them themselves then there these they this those through to too under until up very was we what when where which while who whom why will with would you your yours yourself yourself`.split(/\s+/));

export const tokenize = (text: string): string[] =>
  text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));

/** Share of the smaller set present in both — catches rephrased statements. */
export const containment = (a: Set<string>, b: Set<string>): number => {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter += 1;
  return inter / Math.min(a.size, b.size);
};

export const jaccard = (a: Set<string>, b: Set<string>): number => {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter += 1;
  return inter / (a.size + b.size - inter);
};

export const HALF_LIFE_DAYS = 45;

export interface ScorableMemory {
  key: string;
  value: string;
  tags?: string[] | null;
  importance: number;
  confidence: number;
  pinned?: boolean;
  enabled?: boolean;
  useCount?: number;
  updatedAt: Date | string;
}

/** Relevance × importance × confidence × recency, plus pinned/use boosts. */
export function scoreMemory(
  memory: ScorableMemory,
  queryTokens: Set<string>,
  now = Date.now(),
  options: { halfLifeDays?: number } = {},
): number {
  const valueTokens = new Set(
    tokenize(`${memory.key} ${memory.value} ${(memory.tags ?? []).join(" ")}`),
  );
  let overlap = 0;
  for (const t of queryTokens) if (valueTokens.has(t)) overlap += 1;
  const relevance = queryTokens.size
    ? Math.min(1, overlap / Math.min(4, queryTokens.size))
    : 0.35;
  const updatedAt =
    memory.updatedAt instanceof Date ? memory.updatedAt.getTime() : Date.parse(String(memory.updatedAt));
  const ageDays = Math.max(0, (now - (Number.isFinite(updatedAt) ? updatedAt : now)) / 86_400_000);
  const recency = Math.exp(-ageDays / Math.max(1, options.halfLifeDays ?? HALF_LIFE_DAYS));
  const base =
    relevance * 0.55 + memory.importance * 0.25 + memory.confidence * 0.1 + recency * 0.1;
  const useBoost = Math.min(0.08, Math.log1p(memory.useCount ?? 0) * 0.02);
  const pinnedBoost = memory.pinned ? 0.15 : 0;
  const enabledFactor = memory.enabled === false ? 0 : 1;
  return Math.min(1, (base + useBoost + pinnedBoost) * enabledFactor);
}

export const slugifyMemoryKey = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 50) || `note-${Date.now().toString(36)}`;

export interface RenderableMemory {
  key: string;
  value: string;
  type: MemoryType;
}

export function renderMemoryBlock(items: Array<RenderableMemory & { id?: string }>): string {
  if (items.length === 0) return "";
  const lines = items.map((m) => `- [${m.type}] ${m.value}`);
  return [
    "# Long-term memory",
    "",
    "Durable facts about this workspace, retrieved because they look relevant to the current request.",
    "Use them silently. If one is contradicted by what the user says now, trust the user and save the correction with remember. Never claim to remember something not listed here.",
    "",
    ...lines,
  ].join("\n");
}

/* ── Deterministic extraction, used when no model is connected ───────────── */

const PATTERNS: Array<{
  re: RegExp;
  type: MemoryType;
  importance: number;
  build: (m: RegExpMatchArray) => string;
}> = [
  {
    re: /\bi (?:prefer|like|love|enjoy|hate|dislike|avoid|want)\b([^.!?\n]{3,160})/i,
    type: "preference",
    importance: 0.8,
    build: (m) => `Prefers: ${m[1].trim().replace(/^to\s+/, "")}`,
  },
  {
    re: /\bi (?:always|never|usually|typically)\b([^.!?\n]{3,160})/i,
    type: "procedure",
    importance: 0.7,
    build: (m) => `Habit: I ${m[0].replace(/^i\s+/i, "").trim().slice(0, 160)}`,
  },
  {
    re: /\b(?:my name is|call me)\s+([\p{L}'-]{2,40})/u,
    type: "entity",
    importance: 0.9,
    build: (m) => `Name: ${m[1].trim()}`,
  },
  {
    re: /\bi(?:'m| am)?\s+(?:a|an)\s+([^.!?\n]{3,120})/i,
    type: "entity",
    importance: 0.6,
    build: (m) => `Is a ${m[1].trim()}`,
  },
  {
    re: /\b(?:use|switch to)\s+([^.!?\n]{3,120})\b(?:instead|rather)\b/i,
    type: "preference",
    importance: 0.85,
    build: (m) => `Correction: ${m[0].trim().slice(0, 200)}`,
  },
  {
    re: /\b(?:remember|note that|keep in mind)\b[:\s]+([^.!?\n]{4,200})/i,
    type: "fact",
    importance: 0.9,
    build: (m) => m[1].trim().slice(0, 400),
  },
  {
    re: /\b(?:my|our)\s+(project|repo|stack|team|company|client)\b([^.!?\n]{2,140})/i,
    type: "fact",
    importance: 0.65,
    build: (m) => `${m[1].trim()}: ${m[2].trim().replace(/^\s*(is|are)\s+/, "")}`,
  },
];

export interface ExtractedCandidate {
  value: string;
  type: MemoryType;
  importance: number;
  confidence: number;
  origin: "extracted";
}

export function extractCandidates(text: string): ExtractedCandidate[] {
  const out: ExtractedCandidate[] = [];
  const seen = new Set<string>();
  for (const pattern of PATTERNS) {
    const flags = pattern.re.flags.includes("g") ? pattern.re.flags : `${pattern.re.flags}g`;
    for (const m of text.matchAll(new RegExp(pattern.re.source, flags))) {
      const value = pattern.build(m).replace(/\s+/g, " ").trim();
      if (value.length < 6 || seen.has(value.toLowerCase())) continue;
      seen.add(value.toLowerCase());
      out.push({
        value: value.slice(0, 400),
        type: pattern.type,
        importance: pattern.importance,
        confidence: 0.6,
        origin: "extracted",
      });
      if (out.length >= 4) return out;
    }
  }
  return out;
}

export const clamp01 = (n: number) => Math.min(1, Math.max(0, Number.isFinite(n) ? n : 0.5));
