/**
 * Sandbox helpers for the in-app code workspace.
 *
 * The preview runs inside an iframe mounted with `sandbox="allow-scripts"` and
 * no `allow-same-origin`, so it executes in an opaque origin: it cannot read the
 * app's cookies, localStorage or DOM, and it cannot reach the API except
 * through fetch calls the user wrote themselves.
 *
 * These helpers are pure so they can be unit tested without a DOM.
 */

export type SandboxLanguage =
  | "html"
  | "css"
  | "javascript"
  | "typescript"
  | "json"
  | "python"
  | "markdown"
  | "text";

export interface WorkspaceFile {
  id: string;
  name: string;
  language: SandboxLanguage;
  content: string;
}

const LANG_BY_EXT: Record<string, SandboxLanguage> = {
  html: "html",
  htm: "html",
  css: "css",
  js: "javascript",
  mjs: "javascript",
  jsx: "javascript",
  ts: "typescript",
  tsx: "typescript",
  json: "json",
  py: "python",
  md: "markdown",
  txt: "text",
};

export const SANDBOX_LANG_LABEL: Record<SandboxLanguage, string> = {
  html: "HTML",
  css: "CSS",
  javascript: "JavaScript",
  typescript: "TypeScript",
  json: "JSON",
  python: "Python",
  markdown: "Markdown",
  text: "Text",
};

export function detectSandboxLanguage(name: string): SandboxLanguage {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  return LANG_BY_EXT[ext] ?? "text";
}

/** Token placeholder replaced with a per-run nonce before the iframe renders. */
export const SANDBOX_TOKEN_PLACEHOLDER = "__NOVA_SANDBOX_TOKEN__";

/** Escapes a value for safe inclusion in a double-quoted JS string literal. */
function jsString(value: string): string {
  return JSON.stringify(value);
}

/**
 * Console bridge injected before the user program. It forwards log output to
 * the parent frame, authenticated by the per-run nonce so other frames on the
 * page cannot inject fake console lines.
 */
export function buildConsoleBridge(): string {
  return `<script>
(function () {
  var token = ${SANDBOX_TOKEN_PLACEHOLDER};
  var send = function (level, args) {
    try {
      var text = Array.prototype.map.call(args, function (a) {
        if (typeof a === "string") return a;
        try { return JSON.stringify(a); } catch (e) { return String(a); }
      }).join(" ");
      parent.postMessage({ source: "nova-sandbox", token: token, level: level, text: text }, "*");
    } catch (e) {}
  };
  ["log", "info", "warn", "error"].forEach(function (level) {
    var original = console[level];
    console[level] = function () {
      send(level, arguments);
      if (original) original.apply(console, arguments);
    };
  });
  window.addEventListener("error", function (event) { send("error", [event.message]); });
  window.addEventListener("unhandledrejection", function (event) {
    send("error", ["Unhandled promise rejection: " + String(event.reason)]);
  });
})();
<\/script>`;
}

/** Wraps the user program so its result or failure is reported to the parent. */
export function buildProgramRunner(program: string): string {
  const indented = program
    .split("\n")
    .map((line) => (line ? `    ${line}` : ""))
    .join("\n");
  return `<script>
(function () {
  var token = ${SANDBOX_TOKEN_PLACEHOLDER};
  try {
${indented}
    parent.postMessage(
      { source: "nova-sandbox", token: token, level: "info", text: "Program finished without errors." },
      "*"
    );
  } catch (error) {
    parent.postMessage(
      {
        source: "nova-sandbox",
        token: token,
        level: "error",
        text: String(error && error.message ? error.message : error),
      },
      "*"
    );
  }
})();
<\/script>`;
}

/**
 * Builds a self-contained document for the preview iframe: the stylesheet is
 * inlined, the external script tag is removed and the program is appended.
 */
export function buildPreviewDocument(files: WorkspaceFile[]): string {
  const byName = new Map(files.map((f) => [f.name, f.content]));
  const html = byName.get("index.html") ?? files.find((f) => f.language === "html")?.content ?? "";
  const css = byName.get("styles.css") ?? files.find((f) => f.language === "css")?.content ?? "";
  const js =
    byName.get("app.js") ??
    files.find((f) => f.language === "javascript" || f.language === "typescript")?.content ??
    "";

  const inlinedHtml = html
    .replace(
      /<link[^>]*href=["']styles\.css["'][^>]*>/gi,
      `<style>\n${css}\n</style>`,
    )
    .replace(/<script[^>]*src=["']app\.js["'][^>]*><\/script>/gi, "");

  const injected = `${buildConsoleBridge()}\n${buildProgramRunner(js)}`;

  return inlinedHtml.includes("</body>")
    ? inlinedHtml.replace("</body>", `${injected}\n</body>`)
    : `${inlinedHtml}\n${injected}`;
}

/** Replaces the placeholder with a per-run nonce (properly quoted for JS). */
export function withSandboxToken(document: string, token: string): string {
  return document.replaceAll(SANDBOX_TOKEN_PLACEHOLDER, jsString(token));
}
