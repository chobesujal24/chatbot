// Client-safe tool metadata (no server imports).

export type ToolGroup = "core" | "web" | "workspace" | "memory" | "skills";

export interface ToolMeta {
  name: string;
  label: string;
  description: string;
  group: ToolGroup;
}

export const TOOL_META: ToolMeta[] = [
  {
    name: "calculator",
    label: "Calculator",
    description: "Evaluate arithmetic expressions exactly.",
    group: "core",
  },
  {
    name: "currentTime",
    label: "Current time",
    description: "Get the current date and time.",
    group: "core",
  },
  {
    name: "webSearch",
    label: "Web search",
    description: "Search the web through your configured search provider.",
    group: "web",
  },
  {
    name: "webFetch",
    label: "Read page",
    description: "Read a page as clean markdown via Firecrawl or Jina.",
    group: "web",
  },
  {
    name: "fetchUrl",
    label: "Fetch URL",
    description: "Fetch a public page directly, without a third-party service.",
    group: "web",
  },
  {
    name: "searchHistory",
    label: "Search history",
    description: "Search past conversations for context.",
    group: "workspace",
  },
  {
    name: "saveMemory",
    label: "Save memory",
    description: "Persist a fact for future conversations.",
    group: "workspace",
  },
  {
    name: "recallMemories",
    label: "Recall memory",
    description: "Read saved facts and preferences.",
    group: "workspace",
  },
  {
    name: "createTask",
    label: "Create task",
    description: "Add an item to the shared task list.",
    group: "workspace",
  },
  {
    name: "listTasks",
    label: "List tasks",
    description: "Read open or completed tasks.",
    group: "workspace",
  },
  {
    name: "loadSkill",
    label: "Load skill",
    description: "Read the full instructions of an available skill.",
    group: "skills",
  },
  {
    name: "remember",
    label: "Remember",
    description: "Store a durable fact, preference or correction in long-term memory.",
    group: "memory",
  },
  {
    name: "recall",
    label: "Recall",
    description: "Search long-term memory for relevant context.",
    group: "memory",
  },
  {
    name: "forgetMemory",
    label: "Forget",
    description: "Delete a stale or wrong memory by key.",
    group: "memory",
  },
  {
    name: "completeTask",
    label: "Complete task",
    description: "Mark a task as done.",
    group: "workspace",
  },
];

export const TOOL_GROUP_LABELS: Record<ToolGroup, string> = {
  core: "Core",
  web: "Web tools",
  workspace: "Workspace",
  memory: "Memory",
  skills: "Skills",
};
