import "server-only";

import { db } from "@/db";
import { skills, type Skill } from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { selectSkillList, slugifySkillName, type ParsedSkillFile } from "./skills-format";

export {
  parseSkillMarkdown,
  serializeSkillMarkdown,
  slugifySkillName,
  renderSkillIndex,
  selectSkillList,
  type ParsedSkillFile,
  type SkillSummary,
} from "./skills-format";

/**
 * Skills follow the Agent Skills format from `anthropics/skills`: a SKILL.md
 * file with YAML frontmatter (`name`, `description`) and markdown instructions.
 * Progressive disclosure — the model only sees the index until it calls
 * `loadSkill`, so unused skills cost a few dozen tokens each.
 */

export const SEED_SKILLS: Array<Omit<ParsedSkillFile, "name"> & { name: string }> = [
  {
    name: "structured-writing",
    emoji: "✎",
    description:
      "Rewrite rough notes, emails and docs into tight structured prose with a leading takeaway.",
    instructions: `# Structured Writing

Rewrite the supplied material so a reader gets the point in the first line.

## Method
1. Identify the single decision or takeaway the reader needs. Lead with it.
2. Cut throat-clearing openers, restated questions, and anything that does not change a reader's action.
3. Group remaining content under short imperative headings a skimmer would scan ("What changed", "Why it matters", "Next step").
4. Convert prose lists into bullets or a table when items are parallel.
5. Keep the original tense, terminology and numbers exactly. Never invent facts, dates or names.

## Output
Return the rewritten text only. If key information is missing, add a short "Open questions" list at the end. Flag any claim you could not preserve verbatim.`,
    tools: null,
  },
  {
    name: "code-review",
    emoji: "⌁",
    description:
      "Review a diff or file for correctness, security and clarity, ordered by severity.",
    instructions: `# Code Review

Review the code as a senior engineer who must not waste the author's time.

## Order of attention
1. Correctness: logic errors, wrong edge cases, off-by-one, unhandled null/error paths, races.
2. Security: injection, SSRF, secrets in code or logs, unsafe deserialisation, missing authorisation checks.
3. Data integrity: transactions, idempotency, migration safety.
4. Performance only when it is provably quadratic or worse on user input.
5. Clarity and naming as a last pass.

## Format
Group findings under severity headings: Blocker, Should fix, Nit. For each: file:line, one sentence on the problem, one sentence on the fix, and a minimal code suggestion. Say explicitly what you checked and found fine, so the author knows the review was not shallow. Do not restate the diff back to them.`,
    tools: null,
  },
  {
    name: "research-brief",
    emoji: "⌕",
    description:
      "Turn a question into a sourced brief: answer first, evidence second, unknowns last.",
    instructions: `# Research Brief

Produce a brief a colleague can act on without reading the sources themselves.

## Method
1. Restate the question in one line, then answer it in two sentences at the top.
2. Use webSearch to find at least three independent sources; use webFetch to read the ones that actually carry the claim. Prefer primary sources: official docs, papers, specifications, vendor pricing pages, repository READMEs.
3. For each claim in the answer, attach the URL that supports it inline.
4. Note the date of each source. Anything older than two years must be labelled "possibly stale".
5. End with "Not verified" — the specific things you could not confirm and how they would change the answer.

## Discipline
Never present a search snippet as a fact you have not read. If sources conflict, show both and say which is stronger and why. If the question is unanswerable from public sources, say so plainly rather than padding.`,
    tools: ["webSearch", "webFetch", "fetchUrl", "currentTime"],
  },
  {
    name: "sql-assistant",
    emoji: "⌗",
    description:
      "Write and optimise SQL with an explicit read-only guarantee and a verification query.",
    instructions: `# SQL Assistant

## Rules
1. Always write read-only queries unless the user explicitly asks for a mutation, and never emit DROP, TRUNCATE or unguarded UPDATE/DELETE.
2. State the assumed schema before the query: tables, join keys, relevant indexes.
3. Use CTEs rather than nested subqueries. Qualify every column.
4. Add a LIMIT while exploring; aggregate only after confirming row counts.
5. Follow the query with a one-line verification: an expected row count or a sanity check the user can run.
6. If a full scan is likely, say so and give the index that would fix it.

## Output
Provide the SQL in a fenced sql block, then a short "Assumptions" list, then the verification query.`,
    tools: ["calculator"],
  },
];

export async function seedSkills(workspaceId: string) {
  const existing = await db
    .select({ name: skills.name })
    .from(skills)
    .where(eq(skills.workspaceId, workspaceId));
  const have = new Set(existing.map((e) => e.name));
  const missing = SEED_SKILLS.filter((s) => !have.has(s.name));
  if (missing.length === 0) return;
  await db
    .insert(skills)
    .values(
      missing.map((s) => ({
        workspaceId,
        name: s.name,
        description: s.description,
        instructions: s.instructions,
        tools: s.tools,
        emoji: s.emoji,
        source: "builtin",
        enabled: true,
      })),
    )
    .onConflictDoNothing();
}

export async function listSkills(workspaceId: string) {
  await seedSkills(workspaceId);
  return db
    .select()
    .from(skills)
    .where(eq(skills.workspaceId, workspaceId))
    .orderBy(asc(skills.name));
}

export const toSkill = (s: Skill) => ({
  id: s.id,
  name: s.name,
  description: s.description,
  instructions: s.instructions,
  tools: s.tools ?? null,
  emoji: s.emoji,
  source: s.source,
  enabled: s.enabled,
  useCount: s.useCount,
  lastUsedAt: s.lastUsedAt?.toISOString() ?? null,
  createdAt: s.createdAt.toISOString(),
  updatedAt: s.updatedAt.toISOString(),
});

/** Filter by the agent's allowlist, then render the progressive index. */
export function selectSkills(
  all: Skill[],
  allow: string[] | null | undefined,
): Skill[] {
  return selectSkillList(
    all.map((s) => ({ ...s, name: s.name, enabled: s.enabled })),
    allow,
  ) as Skill[];
}

export async function loadSkillInstructions(workspaceId: string, name: string) {
  const slug = slugifySkillName(name);
  const [row] = await db
    .select()
    .from(skills)
    .where(and(eq(skills.workspaceId, workspaceId), eq(skills.name, slug)))
    .limit(1);
  if (!row) return null;
  await db
    .update(skills)
    .set({ useCount: row.useCount + 1, lastUsedAt: new Date() })
    .where(eq(skills.id, row.id));
  return {
    name: row.name,
    description: row.description,
    instructions: row.instructions,
    tools: row.tools ?? null,
  };
}
