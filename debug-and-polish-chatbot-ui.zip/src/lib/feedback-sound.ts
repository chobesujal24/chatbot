"use client";

/**
 * Plays a gentle two-note Web Audio chime when an assistant reply completes.
 * Uses zero external audio assets and degrades silently if blocked by autoplay policy.
 */
export function playCompletionChime() {
  if (typeof window === "undefined") return;
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const notes = [523.25, 659.25]; // C5 -> E5
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);
      gain.gain.setValueAtTime(0.0001, now + idx * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.08, now + idx * 0.09 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.09 + 0.24);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.26);
    });

    setTimeout(() => {
      void ctx.close().catch(() => undefined);
    }, 650);
  } catch {
    /* ignore audio context restrictions */
  }
}

export function notifyReplyComplete(title: string, snippet: string) {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  if (document.visibilityState === "visible" && document.hasFocus()) return;
  try {
    const clean = snippet.replace(/[#*_>`~\n]+/g, " ").trim().slice(0, 140);
    new Notification(title || "Nova reply ready", {
      body: clean || "Your response has finished generating.",
      silent: true,
    });
  } catch {
    /* ignore notification errors */
  }
}
