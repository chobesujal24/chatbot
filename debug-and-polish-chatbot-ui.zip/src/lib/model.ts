import type { LanguageModel } from "ai";
import type { Settings } from "./types";
import { findProvider } from "./providers";

export interface ModelResolution {
  model: LanguageModel | null;
  error?: string;
  label: string;
  /** True when the workspace has no model provider configured at all. */
  missingCredentials: boolean;
}

/**
 * Provider SDKs read env vars when imported and throw on empty strings, so we
 * strip injected blanks before loading them.
 */
const PROVIDER_ENV = [
  "OPENAI_API_KEY",
  "OPENAI_BASE_URL",
  "OPENAI_ORGANIZATION",
  "OPENAI_PROJECT",
  "ANTHROPIC_API_KEY",
  "ANTHROPIC_BASE_URL",
  "GOOGLE_GENERATIVE_AI_API_KEY",
  "GOOGLE_API_KEY",
  "GOOGLE_BASE_URL",
];

function sanitizeEnv() {
  for (const name of PROVIDER_ENV) {
    const value = process.env[name];
    if (value !== undefined && value.trim() === "") delete process.env[name];
  }
}

function serverFallbackKey(providerId: string): string {
  switch (providerId) {
    case "openai":
      return process.env.OPENAI_API_KEY?.trim() ?? "";
    case "anthropic":
      return process.env.ANTHROPIC_API_KEY?.trim() ?? "";
    case "google":
      return (
        process.env.GOOGLE_GENERATIVE_AI_API_KEY?.trim() ||
        process.env.GOOGLE_API_KEY?.trim() ||
        ""
      );
    default:
      return "";
  }
}

export interface ResolvedCredential {
  provider: string;
  secret: string;
  baseURL: string | null;
  options?: Record<string, unknown>;
}

export interface ModelOptions {
  /** Extra headers sent with every request (OpenRouter referer/title, gateways). */
  headers?: Record<string, string>;
  /** Per-request timeout in seconds. */
  timeout?: number;
}

export async function resolveModel(
  settings: Settings,
  credential: ResolvedCredential | null,
  options: ModelOptions = {},
): Promise<ModelResolution> {
  sanitizeEnv();

  const providerId = credential?.provider || settings.provider;
  if (!providerId || providerId === "offline") {
    // Check if deployment provides a server-level key before giving up.
    const fallbackProvider = serverFallbackKey("openai")
      ? "openai"
      : serverFallbackKey("anthropic")
        ? "anthropic"
        : serverFallbackKey("google")
          ? "google"
          : null;
    if (!fallbackProvider) {
      return {
        model: null,
        label: "unconfigured",
        missingCredentials: true,
        error: "No model provider is connected yet.",
      };
    }
    return resolveModel(
      { ...settings, provider: fallbackProvider },
      { provider: fallbackProvider, secret: serverFallbackKey(fallbackProvider), baseURL: null },
      options,
    );
  }

  const preset = findProvider(providerId);
  const rawModel =
    settings.model && settings.model !== "offline-demo" ? settings.model.trim() : "";
  const label = rawModel || preset?.models[0] || "";
  const apiKey = credential?.secret?.trim() || serverFallbackKey(providerId);
  const customBase = (credential?.baseURL ?? settings.baseURL ?? "").trim();
  const baseURL = customBase || preset?.baseURL || "";
  const extraHeaders =
    options.headers && Object.keys(options.headers).length > 0 ? options.headers : undefined;

  if (!label) {
    return {
      model: null,
      label: providerId,
      missingCredentials: false,
      error: `No model ID selected for ${preset?.label ?? providerId}. Pick or enter a model in Settings → Providers.`,
    };
  }

  if (providerId === "custom" || preset?.kind === "openai-compatible") {
    if (!baseURL) {
      return {
        model: null,
        label,
        missingCredentials: true,
        error: "No base URL configured. Add one in Settings → Providers.",
      };
    }
    if (preset?.requiresKey && !apiKey) {
      return {
        model: null,
        label,
        missingCredentials: true,
        error: `No API key stored for ${preset.label}. Add one in Settings → Providers.`,
      };
    }
    const { createOpenAI } = await import("@ai-sdk/openai");
    return {
      model: createOpenAI({
        apiKey: apiKey || "not-required",
        baseURL,
        ...(extraHeaders ? { headers: extraHeaders } : {}),
      }).chat(label),
      label,
      missingCredentials: false,
    };
  }

  if (!apiKey) {
    return {
      model: null,
      label,
      missingCredentials: true,
      error: `No API key stored for ${preset?.label ?? providerId}. Add one in Settings → Providers.`,
    };
  }

  switch (providerId) {
    case "openai": {
      const { createOpenAI } = await import("@ai-sdk/openai");
      const effectiveBase = customBase || process.env.OPENAI_BASE_URL?.trim() || undefined;
      return {
        model: createOpenAI({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        }).chat(label),
        label,
        missingCredentials: false,
      };
    }
    case "anthropic": {
      const { createAnthropic } = await import("@ai-sdk/anthropic");
      const effectiveBase = customBase || process.env.ANTHROPIC_BASE_URL?.trim() || undefined;
      return {
        model: createAnthropic({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        })(label),
        label,
        missingCredentials: false,
      };
    }
    case "google": {
      const { createGoogleGenerativeAI } = await import("@ai-sdk/google");
      const effectiveBase = customBase || process.env.GOOGLE_BASE_URL?.trim() || undefined;
      return {
        model: createGoogleGenerativeAI({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        })(label),
        label,
        missingCredentials: false,
      };
    }
    default:
      return {
        model: null,
        label,
        missingCredentials: true,
        error: `Provider "${providerId}" is not supported.`,
      };
  }
}
