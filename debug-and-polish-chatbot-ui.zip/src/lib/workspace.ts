import "server-only";

import { cookies, headers } from "next/headers";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { agents, workspaces } from "@/db/schema";
import { eq } from "drizzle-orm";
import { appSecret } from "./secrets";
import { seedSkills } from "./skills";

const WORKSPACE_COOKIE = "nova_ws";
const SESSION_COOKIE = "nova_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;

function sign(value: string, secret: string): string {
  return createHmac("sha256", secret).update(value).digest("hex").slice(0, 32);
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

async function isHttps(): Promise<boolean> {
  const h = await headers();
  return (h.get("x-forwarded-proto") ?? "http").split(",")[0].trim() === "https";
}

async function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: await isHttps(),
    path: "/",
  };
}

/** Whether this deployment requires a passcode before a workspace is issued. */
export function passwordRequired(): boolean {
  return Boolean(process.env.APP_PASSWORD?.trim());
}

export async function isAuthorized(): Promise<boolean> {
  if (!passwordRequired()) return true;
  const raw = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!raw) return false;
  const [expires, signature] = raw.split(".");
  if (!expires || !signature) return false;
  if (Number(expires) < Date.now()) return false;
  const expected = await sign(`session:${expires}`, await appSecret());
  return safeEqual(signature, expected);
}

export async function verifyPassword(password: string): Promise<boolean> {
  const configured = process.env.APP_PASSWORD ?? "";
  // Constant-time-ish comparison against the configured secret.
  const a = createHmac("sha256", "nova-pw").update(password).digest();
  const b = createHmac("sha256", "nova-pw").update(configured).digest();
  return timingSafeEqual(a, b) && password.length > 0;
}

export async function createSession(): Promise<void> {
  const expires = String(Date.now() + SESSION_TTL_MS);
  const token = `${expires}.${await sign(`session:${expires}`, await appSecret())}`;
  (await cookies()).set(SESSION_COOKIE, token, {
    ...(await cookieOptions()),
    maxAge: SESSION_TTL_MS / 1000,
  });
}

/** Reads and verifies the workspace cookie. Never trusts an unverified value. */
export async function currentWorkspace(): Promise<string | null> {
  const raw = (await cookies()).get(WORKSPACE_COOKIE)?.value;
  if (!raw) return null;
  const [id, signature] = raw.split(".");
  if (!id || !signature) return null;
  const expected = await sign(id, await appSecret());
  if (!safeEqual(signature, expected)) return null;
  const [row] = await db
    .select({ id: workspaces.id })
    .from(workspaces)
    .where(eq(workspaces.id, id))
    .limit(1);
  return row?.id ?? null;
}

export const SEED_AGENTS = [
  {
    name: "General",
    description: "Everyday assistant with math, time, history and memory tools.",
    systemPrompt:
      "You are Nova's General agent. Be direct, concise and well-structured. Use your tools when they make an answer more accurate: calculator for arithmetic, currentTime for time questions, searchHistory for anything about past conversations, and saveMemory/recallMemories for durable facts. Prefer Markdown with fenced code blocks and tables where helpful.",
    tools: ["calculator", "currentTime", "searchHistory", "saveMemory", "recallMemories"],
    icon: "bot",
    isDefault: true,
  },
  {
    name: "Researcher",
    description: "Fetches web sources, searches history and tracks work in tasks.",
    systemPrompt:
      "You are Nova's Research agent. Use webSearch to find current sources and webFetch (or fetchUrl) to read pages, cross-check past conversations with searchHistory, and save durable findings with saveMemory. Track multi-step work with createTask/listTasks/completeTask. Always cite the URLs you used and state what you could not verify.",
    tools: ["webSearch", "webFetch", "fetchUrl", "searchHistory", "saveMemory", "recallMemories", "createTask", "listTasks", "completeTask", "currentTime"],
    icon: "search",
    isDefault: false,
  },
  {
    name: "Coder",
    description: "Engineering-focused agent for code, debugging and technical design.",
    systemPrompt:
      "You are Nova's Code agent, a senior engineer. Write precise, idiomatic code with fenced blocks and language tags, explain tradeoffs briefly, and use calculator for any arithmetic. Fetch documentation pages with fetchUrl when you need current API details. Track implementation work with the task tools.",
    tools: ["calculator", "webFetch", "fetchUrl", "searchHistory", "createTask", "listTasks", "completeTask"],
    icon: "code",
    isDefault: false,
  },
  {
    name: "Analyst",
    description: "Data-focused agent that computes carefully and presents tables.",
    systemPrompt:
      "You are Nova's Analyst agent. Compute with the calculator tool instead of mental math, present results in Markdown tables, and separate observed data from assumptions. Search history for prior context and save reusable findings to memory.",
    tools: ["calculator", "webSearch", "webFetch", "searchHistory", "recallMemories", "saveMemory", "createTask", "listTasks"],
    icon: "chart",
    isDefault: false,
  },
];

export async function seedAgents(workspaceId: string) {
  const existing = await db
    .select({ id: agents.id, name: agents.name, tools: agents.tools })
    .from(agents)
    .where(eq(agents.workspaceId, workspaceId));
  const byName = new Map(existing.map((a) => [a.name, a]));

  // Insert the agents that are missing.
  const missing = SEED_AGENTS.filter((s) => !byName.has(s.name)).map((s) => ({
    workspaceId,
    name: s.name,
    description: s.description,
    systemPrompt: s.systemPrompt,
    tools: s.tools,
    icon: s.icon,
    isDefault: s.isDefault,
    temperature: 0.7,
    maxSteps: 5,
  }));
  if (missing.length > 0) await db.insert(agents).values(missing);

  // Keep the tool set of seeded agents in sync with the current release.
  for (const seed of SEED_AGENTS) {
    const row = byName.get(seed.name);
    if (!row) continue;
    const merged = Array.from(new Set([...(row.tools ?? []), ...seed.tools]));
    if (merged.length !== (row.tools ?? []).length) {
      await db.update(agents).set({ tools: merged }).where(eq(agents.id, row.id));
    }
  }
}

/** The single entry point that mints a workspace. Called only by /api/bootstrap. */
export async function bootstrapWorkspace(): Promise<{ id: string; created: boolean }> {
  const existing = await currentWorkspace();
  if (existing) {
    await db
      .update(workspaces)
      .set({ lastSeenAt: new Date() })
      .where(eq(workspaces.id, existing));
    return { id: existing, created: false };
  }
  const id = randomUUID();
  await db.insert(workspaces).values({ id });
  await seedAgents(id);
  await seedSkills(id);
  const token = `${id}.${await sign(id, await appSecret())}`;
  (await cookies()).set(WORKSPACE_COOKIE, token, {
    ...(await cookieOptions()),
    maxAge: 60 * 60 * 24 * 365,
  });
  return { id, created: true };
}


