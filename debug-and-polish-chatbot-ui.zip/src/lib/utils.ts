import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** cn() — the utility used by vendored shadcn/ui components. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
