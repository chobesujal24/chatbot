// Client-safe agent icon keys (no server imports).

export const AGENT_ICONS = [
  "bot",
  "search",
  "code",
  "chart",
  "sparkles",
  "brain",
  "wrench",
  "globe",
] as const;

export type AgentIconKey = (typeof AGENT_ICONS)[number];
