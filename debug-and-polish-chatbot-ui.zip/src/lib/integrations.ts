import "server-only";

import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { isBlockedIpv4, isBlockedIpv6 } from "./ssrf";

export interface SearchResult {
  title: string;
  url: string;
  text: string;
  published?: string;
}

export interface WebDocument {
  url: string;
  title?: string;
  markdown: string;
  provider: string;
}

const TIMEOUT = 25_000;

async function request(
  url: string,
  init: RequestInit & { timeoutMs?: number } = {},
): Promise<{ status: number; json: unknown; text: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeoutMs ?? TIMEOUT);
  try {
    const res = await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: { "User-Agent": "Nova/1.0", ...(init.headers ?? {}) },
    });
    const text = await res.text();
    let json: unknown = null;
    try {
      json = JSON.parse(text);
    } catch {
      /* not JSON */
    }
    return { status: res.status, json, text };
  } finally {
    clearTimeout(timer);
  }
}

/** Blocks private/link-local destinations before any request leaves the server. */
async function assertPublicHost(hostname: string) {
  if (isIP(hostname)) {
    const blocked = hostname.includes(":")
      ? isBlockedIpv6(hostname)
      : isBlockedIpv4(hostname);
    if (blocked) throw new Error("Target resolves to a blocked address.");
    return;
  }
  const addresses = await lookup(hostname, { all: true, verbatim: true }).catch(() => {
    throw new Error("DNS resolution failed.");
  });
  for (const a of addresses) {
    const blocked = a.family === 6 ? isBlockedIpv6(a.address) : isBlockedIpv4(a.address);
    if (blocked) throw new Error("Target resolves to a blocked address.");
  }
}

/* ── Search providers ───────────────────────────────────────────────────── */

export async function searchWithFirecrawl(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://api.firecrawl.dev",
): Promise<SearchResult[]> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/v2/search`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ query, limit: Math.min(limit, 20) }),
  });
  if (res.status >= 400) throw new Error(`Firecrawl search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    data?: { web?: { title?: string; url?: string; description?: string }[] };
  };
  return (payload?.data?.web ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.description ?? "",
  }));
}

export async function searchWithTavily(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://api.tavily.com",
): Promise<SearchResult[]> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/search`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      query,
      max_results: Math.min(limit, 20),
      include_answer: true,
      search_depth: "basic",
    }),
  });
  if (res.status >= 400) throw new Error(`Tavily search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    answer?: string;
    results?: { title?: string; url?: string; content?: string }[];
  };
  const results = (payload?.results ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.content ?? "",
  }));
  if (payload?.answer) {
    results.unshift({ title: "Tavily answer", url: "", text: payload.answer });
  }
  return results;
}

export async function searchWithBrave(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://api.search.brave.com/res/v1",
): Promise<SearchResult[]> {
  const url = `${baseURL.replace(/\/$/, "")}/web/search?q=${encodeURIComponent(query)}&count=${Math.min(limit, 20)}`;
  const res = await request(url, {
    headers: { "X-Subscription-Token": key, Accept: "application/json" },
  });
  if (res.status >= 400) throw new Error(`Brave search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    web?: { results?: { title?: string; url?: string; description?: string }[] };
  };
  return (payload?.web?.results ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.description ?? "",
  }));
}

export async function searchWithExa(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://api.exa.ai",
): Promise<SearchResult[]> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/search`, {
    method: "POST",
    headers: { "x-api-key": key, "Content-Type": "application/json" },
    body: JSON.stringify({
      query,
      numResults: Math.min(limit, 20),
      type: "auto",
      contents: { text: { maxCharacters: 1500 } },
    }),
  });
  if (res.status >= 400) throw new Error(`Exa search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    results?: {
      title?: string;
      url?: string;
      text?: string;
      highlights?: string[];
      publishedDate?: string;
    }[];
  };
  return (payload?.results ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.highlights?.join(" ") || r.text || "",
    published: r.publishedDate,
  }));
}

export async function searchWithSerper(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://google.serper.dev",
): Promise<SearchResult[]> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/search`, {
    method: "POST",
    headers: { "X-API-KEY": key, "Content-Type": "application/json" },
    body: JSON.stringify({ q: query, num: Math.min(limit, 20) }),
  });
  if (res.status >= 400) throw new Error(`Serper search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    answerBox?: { answer?: string; snippet?: string; link?: string };
    organic?: { title?: string; link?: string; snippet?: string }[];
  };
  const results: SearchResult[] = [];
  if (payload?.answerBox?.answer) {
    results.push({
      title: "Answer box",
      url: payload.answerBox.link ?? "",
      text: payload.answerBox.answer,
    });
  }
  for (const r of payload?.organic ?? []) {
    results.push({ title: r.title ?? r.link ?? "Untitled", url: r.link ?? "", text: r.snippet ?? "" });
  }
  return results.slice(0, limit);
}

export async function searchWithSerpApi(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://serpapi.com",
): Promise<SearchResult[]> {
  const url = `${baseURL.replace(/\/$/, "")}/search.json?q=${encodeURIComponent(query)}&api_key=${encodeURIComponent(key)}&num=${Math.min(limit, 20)}`;
  const res = await request(url, { headers: { Accept: "application/json" } });
  if (res.status >= 400) throw new Error(`SerpApi search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    answer_box?: { answer?: string; snippet?: string; link?: string };
    organic_results?: { title?: string; link?: string; snippet?: string }[];
  };
  const results: SearchResult[] = [];
  if (payload?.answer_box?.answer) {
    results.push({
      title: "Answer box",
      url: payload.answer_box.link ?? "",
      text: payload.answer_box.answer,
    });
  }
  for (const r of payload?.organic_results ?? []) {
    results.push({ title: r.title ?? r.link ?? "Untitled", url: r.link ?? "", text: r.snippet ?? "" });
  }
  return results.slice(0, limit);
}

export async function searchWithJina(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://s.jina.ai",
): Promise<SearchResult[]> {
  const url = `${baseURL.replace(/\/$/, "")}/${encodeURIComponent(query)}`;
  const res = await request(url, {
    headers: { Authorization: `Bearer ${key}`, Accept: "application/json" },
  });
  if (res.status >= 400) throw new Error(`Jina search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    data?: { title?: string; url?: string; content?: string }[];
  };
  return (payload?.data ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.content ?? "",
  }));
}

export async function searchWithYou(
  key: string,
  query: string,
  limit: number,
  baseURL = "https://api.ydc-index.io",
): Promise<SearchResult[]> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/search`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ query, count: Math.min(limit, 20) }),
  });
  if (res.status >= 400) throw new Error(`You.com search failed (HTTP ${res.status}).`);
  const payload = res.json as {
    hits?: { hits?: { title?: string; url?: string; description?: string }[] };
  };
  return (payload?.hits?.hits ?? []).slice(0, limit).map((r) => ({
    title: r.title ?? r.url ?? "Untitled",
    url: r.url ?? "",
    text: r.description ?? "",
  }));
}

/* ── Page readers ───────────────────────────────────────────────────────── */

export async function scrapeWithFirecrawl(
  key: string,
  url: string,
  options: { onlyMainContent?: boolean; timeoutMs?: number } = {},
  baseURL = "https://api.firecrawl.dev",
): Promise<WebDocument> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/v2/scrape`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      url,
      formats: ["markdown"],
      onlyMainContent: options.onlyMainContent ?? true,
      timeout: options.timeoutMs ?? 30000,
    }),
  });
  if (res.status >= 400) throw new Error(`Firecrawl scrape failed (HTTP ${res.status}).`);
  const payload = res.json as {
    success?: boolean;
    error?: string;
    data?: { markdown?: string; metadata?: { title?: string; sourceURL?: string } };
  };
  if (payload?.success === false) throw new Error(payload.error || "Firecrawl failed.");
  return {
    url: payload?.data?.metadata?.sourceURL ?? url,
    title: payload?.data?.metadata?.title,
    markdown: payload?.data?.markdown ?? "",
    provider: "firecrawl",
  };
}

export async function readWithJina(
  key: string | null,
  url: string,
  baseURL = "https://r.jina.ai",
): Promise<WebDocument> {
  const res = await request(`${baseURL.replace(/\/$/, "")}/${url}`, {
    headers: key ? { Authorization: `Bearer ${key}`, Accept: "text/plain" } : {},
  });
  if (res.status >= 400) throw new Error(`Jina reader failed (HTTP ${res.status}).`);
  const text = res.text;
  const titleMatch = /^Title:\s*(.+)$/m.exec(text);
  return {
    url,
    title: titleMatch?.[1]?.trim(),
    markdown: text,
    provider: "jina",
  };
}

/** Validates that a user-supplied URL is safe to hand to a third-party reader. */
export async function assertSafeTarget(url: string) {
  const parsed = new URL(url);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Only http and https URLs are allowed.");
  }
  await assertPublicHost(parsed.hostname);
  return parsed;
}
