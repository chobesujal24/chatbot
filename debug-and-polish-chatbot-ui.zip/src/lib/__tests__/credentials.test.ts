import { describe, expect, it } from "vitest";
import { createHash } from "node:crypto";
import { decryptValue, encryptValue, maskSecret } from "../crypto";
import { PROVIDERS, findProvider, providersForKind } from "../providers";
import { normalizePreferences, DEFAULT_PREFERENCES } from "../preferences-client";

const key = createHash("sha256").update("test-secret").digest();

describe("credential encryption", () => {
  it("round-trips a secret", () => {
    const payload = encryptValue("sk-live-1234567890", key);
    expect(payload).not.toContain("sk-live");
    expect(decryptValue(payload, key)).toBe("sk-live-1234567890");
  });

  it("produces a different ciphertext each time (random IV)", () => {
    const a = encryptValue("same", key);
    const b = encryptValue("same", key);
    expect(a).not.toBe(b);
    expect(decryptValue(a, key)).toBe("same");
    expect(decryptValue(b, key)).toBe("same");
  });

  it("rejects a tampered payload", () => {
    const payload = encryptValue("secret", key);
    const [iv, tag, data] = payload.split(".");
    const tampered = `${iv}.${tag}.${data.slice(0, -2)}AA`;
    expect(decryptValue(tampered, key)).toBeNull();
  });

  it("cannot be decrypted with a different key", () => {
    const payload = encryptValue("secret", key);
    const other = createHash("sha256").update("different").digest();
    expect(decryptValue(payload, other)).toBeNull();
  });

  it("masks secrets for display", () => {
    expect(maskSecret("sk-abcdefghijkl")).toBe("sk-a••••ijkl");
    expect(maskSecret("short")).toBe("••••");
  });
});

describe("provider catalog", () => {
  it("covers the major model providers", () => {
    for (const id of ["openai", "anthropic", "google", "ollama", "openrouter", "custom"]) {
      expect(findProvider(id), id).toBeDefined();
    }
  });

  it("covers the requested web integrations", () => {
    for (const id of ["firecrawl", "tavily", "brave", "exa", "serper", "jina"]) {
      expect(findProvider(id), id).toBeDefined();
    }
  });

  it("splits providers by credential kind", () => {
    const model = providersForKind("model").map((p) => p.id);
    const search = providersForKind("search").map((p) => p.id);
    const reader = providersForKind("reader").map((p) => p.id);
    expect(model).toContain("openai");
    expect(search).toContain("firecrawl");
    expect(reader).toContain("jina");
    expect(model).not.toContain("firecrawl");
  });

  it("marks local runtimes as not requiring a key", () => {
    expect(findProvider("ollama")?.requiresKey).toBe(false);
    expect(findProvider("openai")?.requiresKey).toBe(true);
  });

  it("gives every provider a docs link", () => {
    for (const p of PROVIDERS) {
      expect(p.docs.startsWith("http"), p.id).toBe(true);
    }
  });
});

describe("preferences", () => {
  it("merges partial input with defaults", () => {
    const prefs = normalizePreferences({ theme: "dark", fontSize: "lg", animations: false });
    expect(prefs.animations).toBe(false);
    expect(prefs.theme).toBe("dark");
    expect(prefs.fontSize).toBe("lg");
    expect(prefs.density).toBe(DEFAULT_PREFERENCES.density);
  });

  it("rejects unknown values by falling back", () => {
    const prefs = normalizePreferences({ theme: "neon", fontSize: "xl", density: "wide" });
    expect(prefs.theme).toBe("system");
    expect(prefs.fontSize).toBe("md");
    expect(prefs.density).toBe("comfortable");
  });

  it("clamps numeric ranges and drops unknown keys", () => {
    const prefs = normalizePreferences({ temperature: 99, outputBudget: 1, contextWindow: 1, bogus: true });
    expect(prefs.temperature).toBeLessThanOrEqual(2);
    expect(prefs.outputBudget).toBeGreaterThanOrEqual(128);
    expect(prefs.contextWindow).toBeGreaterThanOrEqual(4096);
    expect("bogus" in prefs).toBe(false);
  });

  it("repairs a corrupt accent colour and boolean coercion", () => {
    expect(normalizePreferences({ accent: "neon" }).accent).toBe(DEFAULT_PREFERENCES.accent);
    expect(normalizePreferences({ animations: null }).animations).toBe(true);
    expect(normalizePreferences(undefined).memoryLimit).toBe(6);
  });
});
