import { describe, expect, it } from "vitest";
import { buildPreviewDocument, type WorkspaceFile } from "../code-sandbox";

const file = (name: string, content: string): WorkspaceFile => ({
  id: name,
  name,
  language: name.endsWith(".html") ? "html" : name.endsWith(".css") ? "css" : "javascript",
  content,
});

describe("sandbox preview document", () => {
  it("inlines the stylesheet and strips the external script tag", () => {
    const doc = buildPreviewDocument([
      file(
        "index.html",
        `<!doctype html><html><head><link rel="stylesheet" href="styles.css" /></head><body><h1>Hi</h1><script src="app.js"></script></body></html>`,
      ),
      file("styles.css", "body { color: red; }"),
      file("app.js", "console.log('hello');"),
    ]);

    expect(doc).not.toContain('<link rel="stylesheet"');
    expect(doc).not.toContain('src="app.js"');
    expect(doc).toContain("body { color: red; }");
    expect(doc).toContain("console.log('hello');");
  });

  it("injects the console bridge and the program before </body>", () => {
    const doc = buildPreviewDocument([
      file("index.html", `<html><body><p>x</p></body></html>`),
      file("app.js", "console.log('x');"),
    ]);

    expect(doc).toContain("nova-sandbox");
    expect(doc).toContain("__NOVA_SANDBOX_TOKEN__");
    expect(doc.indexOf("nova-sandbox")).toBeLessThan(doc.indexOf("</body>"));
  });

  it("works without an html file by wrapping the script in a shell", () => {
    const doc = buildPreviewDocument([file("app.js", "console.log('lonely');")]);
    expect(doc).toContain("console.log('lonely');");
    expect(doc).toContain("nova-sandbox");
  });

  it("never leaves an unresolved token after replacement", () => {
    const doc = buildPreviewDocument([file("index.html", "<html><body></body></html>")]);
    const token = "abc123token";
    const resolved = doc.replaceAll("__NOVA_SANDBOX_TOKEN__", token);
    expect(resolved).not.toContain("__NOVA_SANDBOX_TOKEN__");
    expect(resolved).toContain(token);
  });
});
