import { describe, expect, it } from "vitest";
import {
  parseSkillMarkdown,
  pickAutoLoadSkill,
  renderSkillIndex,
  selectSkillList,
  serializeSkillMarkdown,
  skillMatchScore,
  slugifySkillName,
} from "../skills-format";
import {
  containment,
  extractCandidates,
  jaccard,
  renderMemoryBlock,
  scoreMemory,
  slugifyMemoryKey,
  tokenize,
} from "../memory-core";
import {
  buildBreakdown,
  compactionTargets,
  estimateTokens,
  extractiveSummary,
  planHistory,
  resolveContextSettings,
  shouldCompact,
} from "../context";

/* ── Skills (Agent Skills / SKILL.md format) ─────────────────────────────── */

describe("skill files", () => {
  const sample = `---
name: research-brief
description: Turn a question into a sourced brief.
tools: ["webSearch", "webFetch"]
emoji: "⌕"
---

# Research Brief

1. Answer first.
2. Cite sources.
`;

  it("parses frontmatter and body", () => {
    const parsed = parseSkillMarkdown(sample);
    expect(parsed.name).toBe("research-brief");
    expect(parsed.description).toBe("Turn a question into a sourced brief.");
    expect(parsed.tools).toEqual(["webSearch", "webFetch"]);
    expect(parsed.emoji).toBe("⌕");
    expect(parsed.instructions).toContain("Answer first.");
  });

  it("falls back to headings when frontmatter is missing", () => {
    const parsed = parseSkillMarkdown("# My Skill\n\nSome guidance here.");
    expect(parsed.name).toBe("My Skill");
    expect(parsed.description).toContain("Some guidance");
    expect(parsed.tools).toBeNull();
  });

  it("accepts comma-separated tool lists", () => {
    const parsed = parseSkillMarkdown("---\nname: x\ntools: a, b\n---\nbody");
    expect(parsed.tools).toEqual(["a", "b"]);
  });

  it("round-trips through serialisation", () => {
    const parsed = parseSkillMarkdown(sample);
    const again = parseSkillMarkdown(serializeSkillMarkdown(parsed));
    expect(again.name).toBe(parsed.name);
    expect(again.tools).toEqual(parsed.tools);
    expect(again.instructions).toBe(parsed.instructions);
  });

  it("slugifies names for stable keys", () => {
    expect(slugifySkillName("Research Brief!")).toBe("research-brief");
    expect(slugifySkillName("   ")).toBe("skill");
  });

  it("renders an index that tells the model to load on demand", () => {
    const index = renderSkillIndex([
      { name: "code-review", description: "Review diffs", emoji: "⌁" },
    ]);
    expect(index).toContain("loadSkill");
    expect(index).toContain("code-review: Review diffs");
    expect(renderSkillIndex([])).toBe("");
  });

  it("respects an agent allowlist but defaults to all enabled", () => {
    const all = [
      { name: "a", enabled: true },
      { name: "b", enabled: true },
      { name: "c", enabled: false },
    ];
    expect(selectSkillList(all, null).map((s) => s.name)).toEqual(["a", "b"]);
    expect(selectSkillList(all, ["b"]).map((s) => s.name)).toEqual(["b"]);
    expect(selectSkillList(all, ["missing"])).toEqual([]);
  });

  it("scores a request against a skill description", () => {
    const review = { name: "code-review", description: "Review a diff for correctness and security", emoji: "⌁" };
    const writing = { name: "structured-writing", description: "Rewrite notes into structured prose", emoji: "✎" };
    expect(skillMatchScore("please review this diff for security issues", review)).toBeGreaterThan(
      skillMatchScore("please review this diff for security issues", writing),
    );
    expect(skillMatchScore("what is the capital of France", review)).toBeLessThan(0.6);
  });

  it("auto-loads only on a clear single winner", () => {
    const review = { name: "code-review", description: "Review a diff for correctness and security", emoji: "⌁" };
    const writing = { name: "structured-writing", description: "Rewrite notes into structured prose", emoji: "✎" };
    expect(pickAutoLoadSkill([review, writing], "review this diff for correctness", 0.55)?.name).toBe("code-review");
    expect(pickAutoLoadSkill([review, writing], "hello there", 0.55)).toBeNull();
    // Two equally plausible skills must not trigger a guess.
    const twin = { name: "diff-audit", description: "Review a diff for correctness and security", emoji: "⌁" };
    expect(pickAutoLoadSkill([review, twin], "review this diff for correctness and security", 0.5)).toBeNull();
  });
});

/* ── Memory (mem0-style ranking) ─────────────────────────────────────────── */

const baseMemory = {
  key: "preferred-package-manager",
  value: "Prefers pnpm over npm for JavaScript projects",
  importance: 0.8,
  confidence: 1,
  enabled: true,
  pinned: false,
  useCount: 0,
  updatedAt: new Date(),
};

describe("memory ranking", () => {
  it("tokenizes without stopwords or short words", () => {
    const tokens = tokenize("The pnpm is preferred by me for projects");
    expect(tokens).toContain("pnpm");
    expect(tokens).toContain("projects");
    expect(tokens).not.toContain("the");
    expect(tokens).not.toContain("is");
  });

  it("ranks a matching query above an unrelated one", () => {
    const match = scoreMemory(baseMemory, new Set(tokenize("which package manager should I use")));
    const miss = scoreMemory(baseMemory, new Set(tokenize("what does the ssrf guard block")));
    expect(match).toBeGreaterThan(miss);
    expect(match).toBeGreaterThan(0.2);
  });

  it("decays with age", () => {
    const fresh = scoreMemory(baseMemory, new Set(["pnpm"]));
    const stale = scoreMemory(
      { ...baseMemory, updatedAt: new Date(Date.now() - 365 * 86_400_000) },
      new Set(["pnpm"]),
    );
    expect(fresh).toBeGreaterThan(stale);
  });

  it("boosts pinned memories and ignores disabled ones", () => {
    const plain = scoreMemory(baseMemory, new Set(["pnpm"]));
    const pinned = scoreMemory({ ...baseMemory, pinned: true }, new Set(["pnpm"]));
    const disabled = scoreMemory({ ...baseMemory, enabled: false }, new Set(["pnpm"]));
    expect(pinned).toBeGreaterThan(plain);
    expect(disabled).toBe(0);
  });

  it("rewards frequently used memories", () => {
    const often = scoreMemory({ ...baseMemory, useCount: 12 }, new Set(["pnpm"]));
    expect(often).toBeGreaterThan(scoreMemory(baseMemory, new Set(["pnpm"])));
  });

  it("measures overlap with jaccard", () => {
    expect(jaccard(new Set(["a", "b"]), new Set(["a", "b"]))).toBe(1);
    expect(jaccard(new Set(["a"]), new Set(["b"]))).toBe(0);
    expect(jaccard(new Set<string>([]), new Set(["b"]))).toBe(0);
  });

  it("extracts durable statements and skips chatter", () => {
    const found = extractCandidates(
      "I prefer pnpm for JS projects. Also my name is Ada. What is the weather today?",
    );
    expect(found.length).toBeGreaterThanOrEqual(2);
    expect(found.some((f) => f.type === "preference" && /pnpm/.test(f.value))).toBe(true);
    expect(found.some((f) => f.type === "entity" && /Ada/.test(f.value))).toBe(true);
    expect(extractCandidates("hello there, how are things?")).toHaveLength(0);
  });

  it("caps extraction at four candidates", () => {
    const long = [
      "I prefer tabs",
      "I always run tests first",
      "my name is Grace",
      "I am a systems engineer",
      "use pnpm instead of npm",
      "remember the release is Friday",
    ].join(". ");
    expect(extractCandidates(long).length).toBeLessThanOrEqual(4);
  });

  it("containment catches a rephrased fact that Jaccard alone would miss", () => {
    const a = new Set(tokenize("Prefers pnpm for all JS repos"));
    const b = new Set(tokenize("Prefers pnpm and bun"));
    // Symmetric overlap is too weak to merge these, but one-sided overlap shows
    // b is a restatement/correction of a.
    expect(jaccard(a, b)).toBeLessThan(0.5);
    expect(containment(a, b)).toBeGreaterThanOrEqual(0.6);
    expect(containment(a, b)).toBeGreaterThan(jaccard(a, b));
  });

  it("renders an instruction block the model can trust", () => {
    const block = renderMemoryBlock([{ key: "a", value: "Prefers dark mode", type: "preference" }]);
    expect(block).toContain("# Long-term memory");
    expect(block).toContain("[preference] Prefers dark mode");
    expect(block).toContain("trust the user");
    expect(renderMemoryBlock([])).toBe("");
  });

  it("slugifies keys deterministically", () => {
    expect(slugifyMemoryKey("Preferred Package Manager!")).toBe("preferred-package-manager");
  });
});

/* ── Context control ─────────────────────────────────────────────────────── */

const settings = resolveContextSettings(undefined, null);

describe("context budgeting", () => {
  it("estimates tokens by character class", () => {
    expect(estimateTokens("")).toBe(0);
    expect(estimateTokens("four score and seven years ago")).toBeLessThan(12);
    expect(estimateTokens("日本語のテキスト")).toBeGreaterThanOrEqual(7);
  });

  it("keeps the compact ratio as a fraction", () => {
    expect(resolveContextSettings(undefined, null).compactThreshold).toBe(0.8);
    expect(resolveContextSettings({ contextSettings: { compactThreshold: 0.92 } }, null).compactThreshold).toBe(0.92);
  });

  it("reads flat workspace preference keys, with conversation overrides winning", () => {
    const prefs = { contextWindow: 200_000, autoCompact: false, memoryLimit: 9, showSkillsIndex: false };
    const fromPrefs = resolveContextSettings(prefs, null);
    expect(fromPrefs.contextWindow).toBe(200_000);
    expect(fromPrefs.autoCompact).toBe(false);
    expect(fromPrefs.memoryLimit).toBe(9);
    expect(fromPrefs.includeSkills).toBe(false);
    const overridden = resolveContextSettings(prefs, { memoryLimit: 2 });
    expect(overridden.memoryLimit).toBe(2);
    expect(overridden.contextWindow).toBe(200_000);
  });

  it("clamps and defaults workspace settings", () => {
    expect(resolveContextSettings({ contextSettings: { maxHistoryMessages: 9999 } }).maxHistoryMessages).toBe(200);
    expect(resolveContextSettings({ contextSettings: { memoryLimit: -5 } }).memoryLimit).toBe(0);
    expect(resolveContextSettings(undefined, { autoCompact: false }).autoCompact).toBe(false);
    expect(resolveContextSettings(undefined, null).contextWindow).toBe(128_000);
  });

  it("breaks the prompt into labelled segments", () => {
    const breakdown = buildBreakdown({
      system: "You are helpful.",
      skillsIndex: "# Skills\n- a: one\n- b: two",
      memoryBlock: "# Long-term memory\n- [fact] uses pnpm",
      history: [
        { role: "user", content: "first question about the thing" },
        { role: "assistant", content: "an answer with details" },
      ],
      settings,
    });
    const ids = breakdown.segments.map((s) => s.id);
    expect(ids).toEqual(expect.arrayContaining(["system", "skills", "memory", "history"]));
    expect(breakdown.promptTokens).toBe(
      breakdown.segments.reduce((sum, s) => sum + s.tokens, 0),
    );
    expect(breakdown.headroom).toBeGreaterThan(0);
  });

  it("reports overage when the budget is exceeded", () => {
    const breakdown = buildBreakdown({
      history: [{ role: "user", content: "x".repeat(4000) }],
      settings: { ...settings, contextWindow: 4096 },
    });
    expect(breakdown.ratio).toBeGreaterThan(0);
  });

  it("keeps the newest turns within history depth", () => {
    const rows = Array.from({ length: 40 }, (_, i) => ({
      content: `message ${i}`,
      createdAt: new Date(Date.now() + i),
    }));
    const plan = planHistory(rows, { ...settings, maxHistoryMessages: 10 }, 0);
    expect(plan.included).toHaveLength(10);
    expect(plan.included.at(-1)?.content).toBe("message 39");
    expect(plan.dropped[0].content).toBe("message 0");
  });

  it("skips rows already folded into the summary", () => {
    const rows = Array.from({ length: 10 }, (_, i) => ({
      content: `m${i}`,
      createdAt: new Date(Date.now() + i),
    }));
    const plan = planHistory(rows, { ...settings, maxHistoryMessages: 50 }, 6);
    expect(plan.included).toHaveLength(4);
    expect(plan.included[0].content).toBe("m6");
  });

  it("triggers compaction past the threshold only when enabled", () => {
    const breakdown = { ...buildBreakdown({ history: [], settings }), ratio: 0.9 };
    expect(shouldCompact(breakdown, { ...settings, autoCompact: true, compactThreshold: 0.8 })).toBe(true);
    expect(shouldCompact(breakdown, { ...settings, autoCompact: false, compactThreshold: 0.8 })).toBe(false);
    expect(shouldCompact({ ...breakdown, ratio: 0.5 }, { ...settings, compactThreshold: 0.8 })).toBe(false);
  });

  it("folds whole exchanges and keeps the newest turns", () => {
    const small = { ...settings, contextWindow: 4096, outputBudget: 512 };
    const included = Array.from({ length: 20 }, (_, i) => ({
      content: `turn ${i} ` + "detail ".repeat(120),
    }));
    const drop = compactionTargets(included, small, 400);
    expect(drop).toBeGreaterThan(0);
    expect(drop % 2).toBe(0);
    expect(drop).toBeLessThanOrEqual(included.length - 2);
  });

  it("does nothing when there is plenty of headroom", () => {
    const short = Array.from({ length: 6 }, (_, i) => ({ content: `m${i}` }));
    expect(compactionTargets(short, settings, 10)).toBe(0);
    expect(compactionTargets([{ content: "x" }, { content: "y" }], settings, 0)).toBe(0);
  });

  it("summarises offline transcripts extractively", () => {
    const summary = extractiveSummary([
      { role: "user", content: "We moved from npm to pnpm in the monorepo. Revenue was $1.84M in Q2." },
      { role: "assistant", content: "You should run pnpm install --frozen-lockfile in CI. npm is not used anymore." },
      { role: "user", content: "We moved from npm to pnpm in the monorepo." },
    ]);
    expect(summary.startsWith("- ")).toBe(true);
    expect(summary).toContain("pnpm");
    expect(summary).toContain("$1.84M");
    // duplicate content is collapsed
    expect(summary.split("\n")).toHaveLength(new Set(summary.split("\n")).size);
    expect(extractiveSummary([{ role: "user", content: "hi" }])).toBe("");
    expect(extractiveSummary([{ role: "user", content: "ok thanks" }])).toBe("");
  });

  it("caps the summary length", () => {
    const many = Array.from({ length: 400 }, (_, i) => ({
      role: "user",
      content: `Sentence number ${i} describing some detail about the project setup and choices.`,
    }));
    expect(extractiveSummary(many).length).toBeLessThan(4500);
  });
});
