import "server-only";

import type { ProviderId } from "./types";

/** True when the deployment provides a server-side key for the provider. */
export function hasServerKey(provider: ProviderId): boolean {
  const map: Partial<Record<ProviderId, string>> = {
    openai: "OPENAI_API_KEY",
    anthropic: "ANTHROPIC_API_KEY",
    google: "GOOGLE_GENERATIVE_AI_API_KEY",
  };
  const name = map[provider];
  const value = name ? process.env[name] : undefined;
  return Boolean(value && value.trim());
}
