import { db } from "@/db";
import { rateLimits } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterMs: number;
}

/**
 * Atomic fixed-window counter stored in PostgreSQL. Works across multiple
 * server instances without an external Redis dependency.
 */
export async function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number,
): Promise<RateLimitResult> {
  const cutoff = new Date(Date.now() - windowMs);
  try {
    await db.execute(sql`
      insert into rate_limits (key, count, window_start)
      values (${key}, 1, now())
      on conflict (key) do update set
        count = case
          when rate_limits.window_start < ${cutoff}::timestamptz then 1
          else rate_limits.count + 1
        end,
        window_start = case
          when rate_limits.window_start < ${cutoff}::timestamptz then now()
          else rate_limits.window_start
        end
    `);
    // Opportunistically prune expired windows so the table cannot grow forever.
    if (Math.random() < 0.02) {
      await db.delete(rateLimits).where(sql`${rateLimits.windowStart} < ${cutoff}`).catch(() => undefined);
    }
    const [row] = await db
      .select()
      .from(rateLimits)
      .where(eq(rateLimits.key, key))
      .limit(1);
    const count = row?.count ?? 1;
    const windowStart = row?.windowStart?.getTime() ?? Date.now();
    return {
      allowed: count <= limit,
      remaining: Math.max(0, limit - count),
      retryAfterMs: Math.max(0, windowMs - (Date.now() - windowStart)),
    };
  } catch (error) {
    // Fail open on infrastructure errors; never lock users out because a
    // counter table is temporarily unavailable.
    console.error("rate limit check failed", error);
    return { allowed: true, remaining: limit, retryAfterMs: 0 };
  }
}
