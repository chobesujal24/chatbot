# Nova — open-source AI workspace

A production-hardened, full-stack chat workspace with agents, tools, memory and tasks. Built
only from open-source projects hosted on GitHub.

## Sources on GitHub

| Project | Repository | Use |
| --- | --- | --- |
| Next.js | `vercel/next.js` | App Router + route handlers |
| Vercel AI SDK | `vercel/ai` | `streamText`, tool loops, UI message streams |
| AI SDK providers | `vercel/ai` (`packages/openai`, `packages/anthropic`, `packages/google`) | BYOK model connections |
| shadcn/ui | `shadcn-ui/ui` | UI primitives vendored into `src/components/ui/` |
| Radix UI | `radix-ui/primitives` | Accessible dialog / menu primitives |
| Tailwind CSS | `tailwindlabs/tailwindcss` | Styling + design tokens |
| Drizzle ORM | `drizzle-team/drizzle-orm` | Typed PostgreSQL access |
| PostgreSQL | `postgres/postgres` | All persistent state |
| Streamdown | `vercel/streamdown` | Streaming-safe Markdown rendering |
| Shiki | `shikijs/shiki` | Code syntax highlighting |
| AI Elements | `vercel/ai-elements` | `Conversation` + `Shimmer`, vendored into `src/components/ai-elements/` |
| use-stick-to-bottom | `stackblitz-labs/use-stick-to-bottom` | Auto-scroll while streaming |
| cmdk | `pacocoursey/cmdk` | Command palette |
| Lucide, sonner | `lucide-icons/lucide`, `emilkowalski/sonner` | Icons, toasts |
| Motion | `motiondivision/motion` | Shimmer animation |
| Geist, Instrument Serif | `vercel/geist-font`, `Instrument/instrument-serif` | Typography (OFL) |
| Zod | `colinhacks/zod` | Request validation |
| Vitest | `vitest-dev/vitest` | Unit tests |

## Features

### Bring-your-own-key (BYOK)
Nova is an **interface, not a service** — it never proxies models for you and holds no shared
pool of keys. You bring your own accounts:

- **Model providers (16):** OpenAI, Anthropic, Google Gemini, Perplexity, Ollama, LM Studio,
  vLLM, OpenRouter, DeepSeek, Groq, Together AI, xAI Grok, Mistral, Fireworks AI, Cerebras,
  SiliconFlow, Hugging Face — plus a **Custom endpoint** for any OpenAI-compatible server.
- **Web search (8):** Firecrawl, Tavily, Brave Search, Exa, Serper, SerpApi, Jina, You.com.
- **Page readers (2):** Firecrawl (clean markdown scraping) and Jina Reader.

Each provider stores its **base URL** and **API key** separately, so you can point any slot at a
proxy, a regional endpoint or a self-hosted server. Keys are **encrypted at rest with
AES-256-GCM** (key derived from `AUTH_SECRET`), never returned to the browser, never logged, and
never written to localStorage. A **Test connection** button makes the cheapest possible
authenticated call to verify a key, and **Load models** lists the models the endpoint exposes.

### Agents & tools
- **Agents** bundle a system prompt, model, temperature, max tool steps and tool set. Four ship
  by default (General, Researcher, Coder, Analyst), seeded per workspace.
- **Tools** run server-side through the AI SDK tool loop: calculator, current time, **web search**
  (via your provider), **web page reading** (Firecrawl/Jina, falling back to a direct SSRF-guarded
  fetch), direct URL fetch, history search, long-term memory, and a shared task list.
- Agents are seeded per workspace and their tool sets stay in sync with the current release.
- **Tool activity UI**: collapsible step timeline with per-tool input/output, persisted with the
  message. Token usage and duration are recorded per response.
- **Reasoning-capable streaming** via the AI SDK UI message protocol (NDJSON chunks).

### Chat
- Works without any key in an explicitly labelled offline demo responder, but the real product is
  BYOK: connect a provider and Nova streams from it.
- Conversation CRUD, pinning, renaming, forking, date grouping, global full-text-ish search,
  command palette (`⌘K`), prompt templates, text-file attachments (click or drag-and-drop).
- Edit & resend, regenerate, copy, delete, thumbs up/down feedback.
- **Share links**: revocable read-only public pages at `/share/[token]`, expiring after 30 days,
  excluded from search engines.
- **Usage dashboard** in Settings: conversations, messages, tokens, tool calls and per-model
  token bars, all computed from your own database.
- **Settings backup**: export your preferences to JSON, import them into another workspace, or
  re-run onboarding.
- **Modern shell**: a collapsible icon rail (state remembered per browser), sticky blurred header
  with live provider status, tokenised elevation scale, subtle grain texture, warm OKLCH neutrals
  and a single brand hue used for accents.
- **Settings page** (`/settings`) with nine sections: Providers, Integrations, Agents,
  Usage, Appearance, Chat & models, Data & privacy, Advanced and Shortcuts — searchable, with
  every preference persisted per workspace.
- **Onboarding**: a three-step first-run flow that walks you from “no provider” to a connected,
  tested model.
- Appearance controls: theme, accent colour, text size, message density, reduced motion.
- Chat controls: Enter-to-send, draft autosave, attachment size limit, default agent, temperature,
  token and step budgets, system prompt, timestamps and token usage.
- Advanced: request timeout, search result count, custom request headers (OpenRouter referer /
  title), sound and desktop notifications on completion.
- Export a chat as Markdown/JSON, or export/delete the whole workspace.
- Light/dark/system theme, inline theme bootstrapping, reduced-motion support, keyboard shortcuts.

## Production readiness

### Multi-tenancy and authentication
Every browser gets an isolated **workspace** identified by an HMAC-signed, httpOnly,
SameSite=Lax cookie. `/api/bootstrap` is the single entry point that mints it; every other
route re-verifies the signature and checks row-level ownership before reading or writing.
Set `APP_PASSWORD` to require a passcode (signed 7-day session) before a workspace is issued.
Set `AUTH_SECRET` to a long random value in production so cookies stay valid across instances.

### Secrets
API keys entered in Settings are encrypted with **AES-256-GCM** and stored in the database,
scoped to the workspace. The browser can only ask whether a key exists and sees a masked preview
(`sk-a••••9x`). Keys are never written to localStorage, never returned by any API route, and
never logged. Server-side keys (`OPENAI_API_KEY`, etc.) remain supported as an alternative for
self-hosted deployments. Empty provider env vars are sanitised before SDK import so injected blank
values cannot crash boot.

### Request safety
- Zod validation on every request body and query, with a consistent `{ error: { code, message } }`
  envelope and a per-request id.
- Same-origin verification on all mutating requests.
- PostgreSQL-backed atomic fixed-window rate limiting on chat, auth, credentials, exports,
  purges and bootstrap (fails open on infrastructure errors so users are never locked out).
- Payload caps (256 KB), message length caps, list pagination and query limits.
- **SSRF-safe fetch**: only http/https on ports 80/443/8080/8443; resolves the hostname and
  validates *every* address (IPv4, IPv6, IPv4-mapped, NAT64, 6to4, metadata ranges); pins the
  socket to the validated IP; follows redirects manually and revalidates each hop; enforces
  timeout and 200 KB body cap.
- Security headers: CSP, `X-Frame-Options: DENY`, `X-Content-Type-Options`, Referrer-Policy,
  Permissions-Policy, COOP, HSTS in production; `X-Powered-By` disabled.

### Reliability
- `/api/health` performs a real database round-trip and reports latency.
- Streaming responses persist partial output on disconnect and surface real provider errors.
- React error boundaries (`error.tsx`, `global-error.tsx`), 404 and loading states.
- `aria-live` announcements for streaming, a skip link, focus-visible rings and reduced-motion
  CSS.
- Indexes on all workspace/message lookup paths.

### Tests
```bash
npx vitest run
```
32 unit tests cover the arithmetic parser, SSRF address policy and URL rejection, request
validation schemas, slugification, formatting and grouping, the offline responder, credential
encryption (round-trip, random IV, tamper and wrong-key rejection) and the provider catalog.

## Running

```bash
npm install
cp .env.example .env      # set DATABASE_URL, AUTH_SECRET and optionally APP_PASSWORD
npx drizzle-kit push
npm run dev
```

Optional server-side keys: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`,
`GOOGLE_GENERATIVE_AI_API_KEY`, `OPENAI_BASE_URL`. See `.env.example` for the full list and
security notes.

## Validation

```bash
npx next typegen
npm exec tsc -- --noEmit --pretty false
npx vitest run
npm run build
```
