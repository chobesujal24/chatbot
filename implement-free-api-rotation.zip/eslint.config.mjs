import { defineConfig, globalIgnores } from "eslint/config";
import nextCoreWebVitals from "eslint-config-next/core-web-vitals";

export default defineConfig([
  // Keep the starter on the flat config export that actually runs under the pinned ESLint/Next toolchain.
  ...nextCoreWebVitals,
  {
    rules: {
      // Advisory, not a correctness rule. The remaining hits are deliberate
      // "sync from an external source" effects — hydrating UI state from
      // localStorage after mount, loading data when a dialog opens, reading
      // Notification.permission. State that could be derived during render has
      // been converted; keep the rest visible as warnings rather than errors.
      "react-hooks/set-state-in-effect": "warn",
    },
  },
  globalIgnores([".next/**", "out/**", "build/**", "next-env.d.ts"]),
]);
