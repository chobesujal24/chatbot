# Nova UI refinement

## Direction

Nova is a working tool, not a marketing page. The interface should make writing,
resuming a conversation, and working with files feel ordinary and predictable.

This pass removes decorative gradients, glowing marks, oversized shadows, repeated
connection badges, and technical marketing copy. It uses a flat warm-neutral canvas,
a small monogram, a limited type scale, consistent control sizes, and a single accent.
Existing custom colour preferences are preserved.

## Research reviewed

The sources below informed patterns, not a pixel-for-pixel copy. This is a curated
comparison of leading products, not an exhaustive survey of every website.

- [Linear — How we redesigned the Linear UI](https://linear.app/now/how-we-redesigned-the-linear-ui):
  align sidebar/header controls, reduce chrome, establish clear hierarchy, and stress-test split views.
- [OpenAI — The ChatGPT home page](https://help.openai.com/en/articles/9125172-the-chatgpt-home-page):
  put the prompt first; make new-chat and saved-history behaviour understandable.
- [Claude](https://www.anthropic.com/claude):
  describe work in plain language and keep the user in control of the next action.
- [Notion AI](https://www.notion.com/product/ai):
  connect the assistant to useful workspace context rather than filling the interface with mode badges.
- [Perplexity interface reference](https://www.shadcn.io/design/perplexity):
  a restrained canvas, readable input, and low-elevation navigation. This is a third-party analysis.
- [Nielsen Norman Group — AI chatbot design guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/):
  use relevant, clickable starter prompts and progressive disclosure rather than a wall of instructions.

## Applied decisions

- The main composer is the visual anchor. Agent and model controls are present but secondary.
- Starter categories are keyboard-accessible. Choosing a starter creates an editable draft;
  it does not make a model request or incur a charge.
- Recent conversations come from the user's workspace. No fabricated history or statistics.
- One short connection hint explains demo mode. Advanced settings stay in menus.
- Search is always reachable from navigation and the command shortcut.
- The mobile drawer is inert when closed, traps focus when open, and closes before launching a dialog.
- The sidebar temporarily folds when the editor would otherwise squeeze the chat column.
- File attachments show their real byte size; a revised file replaces its earlier version by name.
- Draft storage failures do not block sending. A stale conversation request cannot overwrite a newer selection.
- Theme changes are shared between Settings, chat, local preferences, and the workspace API.
- Respect reduced motion, support phone widths, preserve native code-editor undo, and keep all existing tools.

## Verification

TypeScript, route type generation, the production build, unit tests, and a managed production
health check are required before completion. Browser checks cover desktop, dark mode, mobile,
split-editor layouts, prompt-to-draft, sending, recent chats, search, model setup, and sandbox execution.
