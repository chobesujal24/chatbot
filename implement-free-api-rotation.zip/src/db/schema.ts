import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", ["user", "assistant"]);
export const taskStatusEnum = pgEnum("task_status", ["open", "done"]);
export const feedbackEnum = pgEnum("feedback", ["up", "down"]);
export const memoryTypeEnum = pgEnum("memory_type", [
  "preference",
  "fact",
  "entity",
  "procedure",
  "event",
]);
export const memorySourceEnum = pgEnum("memory_source", [
  "user",
  "agent",
  "extracted",
  "manual",
]);

export interface ToolCallRecord {
  id: string;
  name: string;
  input: unknown;
  output: unknown;
  status: "done" | "error";
}

export interface UsageInfo {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  durationMs: number;
}

/** What the model actually saw for a given turn. */
export interface ContextMeta {
  injectedMemoryIds: string[];
  usedSkillNames: string[];
  historyMessages: number;
  summarizedMessages: number;
  estimatedTokens: number;
  compacted: boolean;
}

/** Per-conversation overrides of the workspace context defaults. */
export interface ContextSettings {
  maxHistoryMessages?: number;
  injectMemories?: boolean;
  memoryLimit?: number;
  includeSkills?: boolean;
  autoCompact?: boolean;
  compactThreshold?: number;
  contextWindow?: number;
  outputBudget?: number;
}

export const appSecrets = pgTable("app_secrets", {
  id: text("id").primaryKey(),
  value: text("value").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey(),
  label: text("label").notNull().default("Workspace"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

// Router settings and request metadata are isolated to the signed workspace.
export const freeMaxConfig = pgTable("free_max_config", {
  workspaceId: uuid("workspace_id").primaryKey().references(() => workspaces.id, { onDelete: "cascade" }),
  settings: jsonb("settings").$type<import("@/lib/free-max/catalog").RoutingSettings>(),
  cursor: integer("cursor").notNull().default(0),
});
export const freeMaxRuns = pgTable("free_max_runs", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), model: text("model").notNull(),
  outcome: text("outcome").notNull(), durationMs: integer("duration_ms").notNull(),
  tokens: integer("tokens").notNull().default(0),
  attempts: jsonb("attempts").$type<{ provider: string; status: number; note: string }[]>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, t => [index("free_max_runs_workspace_created").on(t.workspaceId, t.createdAt)]);
export const freeMaxCooldowns = pgTable("free_max_cooldowns", {
  key: text("key").primaryKey(), until: timestamp("until", { withTimezone: true }).notNull(),
});

export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  count: integer("count").notNull().default(0),
  windowStart: timestamp("window_start", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ── Skills: SKILL.md style instruction packs (see anthropics/skills) ─────── */

export const skills = pgTable(
  "skills",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    instructions: text("instructions").notNull().default(""),
    /** Optional tool allowlist; empty means inherit the agent's tools. */
    tools: jsonb("tools").$type<string[]>(),
    emoji: text("emoji").notNull().default("✦"),
    source: text("source").notNull().default("custom"),
    enabled: boolean("enabled").notNull().default(true),
    useCount: integer("use_count").notNull().default(0),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("skills_workspace_name_idx").on(t.workspaceId, t.name),
    index("skills_workspace_idx").on(t.workspaceId, t.enabled),
  ],
);

/* ── Memory: mem0-style scoped long-term memory ──────────────────────────── */

export const memories = pgTable(
  "memories",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    /** Short slug, kept for stable references and display. */
    key: text("key").notNull(),
    value: text("value").notNull(),
    type: memoryTypeEnum("type").notNull().default("fact"),
    origin: memorySourceEnum("origin").notNull().default("manual"),
    tags: jsonb("tags").$type<string[]>(),
    confidence: real("confidence").notNull().default(0.8),
    importance: real("importance").notNull().default(0.5),
    pinned: boolean("pinned").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    useCount: integer("use_count").notNull().default(0),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
    /** Set when a newer memory replaces this one (mem0 supersede semantics). */
    supersededBy: uuid("superseded_by"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
    .notNull(),
  },
  (t) => [
    uniqueIndex("memories_workspace_key_idx").on(t.workspaceId, t.key),
    index("memories_workspace_idx").on(t.workspaceId, t.enabled),
    index("memories_type_idx").on(t.workspaceId, t.type),
  ],
);

export const memoryLog = pgTable("memory_log", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  action: text("action").notNull(),
  memoryKey: text("memory_key").notNull(),
  detail: text("detail"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const agents = pgTable(
  "agents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    systemPrompt: text("system_prompt").notNull().default(""),
    model: text("model"),
    temperature: real("temperature").notNull().default(0.7),
    maxSteps: integer("max_steps").notNull().default(5),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    /** Skills this agent may use. Null means "all enabled skills". */
    skills: jsonb("skills").$type<string[]>(),
    memoryMode: text("memory_mode").notNull().default("auto"),
    icon: text("icon").notNull().default("bot"),
    isDefault: boolean("is_default").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("agents_workspace_idx").on(t.workspaceId)],
);

export const conversations = pgTable(
  "conversations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull().default("New chat"),
    pinned: boolean("pinned").notNull().default(false),
    model: text("model"),
    agentId: uuid("agent_id").references(() => agents.id, {
      onDelete: "set null",
    }),
    /** Rolling summary produced by compaction. */
    summary: text("summary"),
    summarizedCount: integer("summarized_count").notNull().default(0),
    context: jsonb("context").$type<ContextSettings>(),
    lastSequence: integer("last_sequence").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    index("conversations_workspace_updated_idx").on(t.workspaceId, t.updatedAt),
    index("conversations_workspace_pinned_idx").on(t.workspaceId, t.pinned),
  ],
);

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    role: roleEnum("role").notNull(),
    content: text("content").notNull(),
    model: text("model"),
    attachments: jsonb("attachments").$type<{ name: string; size: number }[]>(),
    toolCalls: jsonb("tool_calls").$type<ToolCallRecord[]>(),
    usage: jsonb("usage").$type<UsageInfo>(),
    contextMeta: jsonb("context_meta").$type<ContextMeta>(),
    seq: integer("seq").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    index("messages_conversation_created_idx").on(t.conversationId, t.createdAt),
    index("messages_conversation_seq_idx").on(t.conversationId, t.seq),
    index("messages_workspace_idx").on(t.workspaceId),
  ],
);

export const messageFeedback = pgTable(
  "message_feedback",
  {
    messageId: uuid("message_id")
      .primaryKey()
      .references(() => messages.id, { onDelete: "cascade" }),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    rating: feedbackEnum("rating").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("feedback_workspace_idx").on(t.workspaceId)],
);

export const sharedLinks = pgTable(
  "shared_links",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    token: text("token").notNull().unique(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (t) => [index("shared_links_token_idx").on(t.token)],
);

export const tasks = pgTable(
  "tasks",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    status: taskStatusEnum("status").notNull().default("open"),
    agentId: uuid("agent_id").references(() => agents.id, {
      onDelete: "set null",
    }),
    conversationId: uuid("conversation_id").references(() => conversations.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("tasks_workspace_idx").on(t.workspaceId, t.createdAt)],
);

export const promptTemplates = pgTable(
  "prompt_templates",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("templates_workspace_idx").on(t.workspaceId)],
);

export const credentials = pgTable(
  "credentials",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    provider: text("provider").notNull(),
    kind: text("kind").notNull().default("model"),
    label: text("label").notNull().default(""),
    secret: text("secret").notNull(),
    baseURL: text("base_url"),
    options: jsonb("options").$type<Record<string, unknown>>(),
    enabled: boolean("enabled").notNull().default(true),
    isActive: boolean("is_active").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("credentials_workspace_provider_idx").on(t.workspaceId, t.provider),
    index("credentials_workspace_idx").on(t.workspaceId),
  ],
);

export const workspacePreferences = pgTable("workspace_preferences", {
  workspaceId: uuid("workspace_id")
    .primaryKey()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  preferences: jsonb("preferences").$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type Workspace = typeof workspaces.$inferSelect;
export type Skill = typeof skills.$inferSelect;
export type Agent = typeof agents.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Memory = typeof memories.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type PromptTemplate = typeof promptTemplates.$inferSelect;
export type SharedLink = typeof sharedLinks.$inferSelect;
