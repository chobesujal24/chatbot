/**
 * Sandbox helpers for the in-app code workspace.
 *
 * The preview runs inside an iframe mounted with a `sandbox` attribute that
 * omits `allow-same-origin`, so it executes in an opaque origin: it cannot read
 * the app's cookies, localStorage or DOM. The srcdoc document also inherits the
 * app's Content-Security-Policy, which blocks network access from the preview.
 *
 * These helpers are pure (string in, string out) so they can be unit tested
 * without a DOM. Behaviour that only a browser can prove — script execution,
 * the console bridge, error line mapping — is covered by browser tests.
 */

import { guardLoops } from "./code-highlight";

export type SandboxLanguage =
  | "html"
  | "css"
  | "javascript"
  | "typescript"
  | "json"
  | "python"
  | "markdown"
  | "text";

export interface WorkspaceFile {
  id: string;
  name: string;
  language: SandboxLanguage;
  content: string;
}

const LANG_BY_EXT: Record<string, SandboxLanguage> = {
  html: "html",
  htm: "html",
  css: "css",
  js: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  jsx: "javascript",
  ts: "typescript",
  tsx: "typescript",
  json: "json",
  py: "python",
  md: "markdown",
  markdown: "markdown",
  txt: "text",
};

export const SANDBOX_LANG_LABEL: Record<SandboxLanguage, string> = {
  html: "HTML",
  css: "CSS",
  javascript: "JavaScript",
  typescript: "TypeScript",
  json: "JSON",
  python: "Python",
  markdown: "Markdown",
  text: "Text",
};

/** Languages that are stored and shared with the model but not executed. */
export const NOT_RUNNABLE_NOTE: Partial<Record<SandboxLanguage, string>> = {
  typescript:
    "TypeScript is not executed — the preview runs plain JavaScript. The file is still attached when you send the workspace to Nova.",
  python:
    "Python needs a runtime the browser sandbox does not have. The file is still attached when you send the workspace to Nova.",
};

export function detectSandboxLanguage(name: string): SandboxLanguage {
  const ext = name.trim().toLowerCase().split(".").pop() ?? "";
  return LANG_BY_EXT[ext] ?? "text";
}

/** Token placeholder replaced with a per-run nonce before the iframe renders. */
export const SANDBOX_TOKEN_PLACEHOLDER = "__NOVA_SANDBOX_TOKEN__";
const LINE_MAP_PLACEHOLDER = "__NOVA_LINE_MAP__";

/** Formats JSON for the preview pane; returns the original text when invalid. */
export function formatJson(source: string): { text: string; error: string | null } {
  try {
    return { text: JSON.stringify(JSON.parse(source), null, 2), error: null };
  } catch (error) {
    return {
      text: source,
      error: error instanceof Error ? error.message : "Invalid JSON",
    };
  }
}

/**
 * Runtime injected at the top of every preview document.
 *
 * - Forwards console output, uncaught errors, rejected promises, failed
 *   resources and CSP violations to the parent, authenticated by a per-run nonce
 *   so no other frame can forge console lines.
 * - Maps document line numbers back to the workspace file they came from.
 * - Hosts the loop guard that `guardLoops` calls from instrumented conditions.
 *
 * Written with `String.raw` so the browser receives it byte for byte; it must
 * not contain backticks or `${`.
 */
const BRIDGE_SOURCE = String.raw`(function () {
  var token = __NOVA_SANDBOX_TOKEN__;
  var map = __NOVA_LINE_MAP__;
  var LOOP_LIMIT_MS = 2000;
  var reported = {};

  function toJson(value, indent) {
    var ancestors = [];
    return JSON.stringify(value, function (key, item) {
      if (typeof item === "bigint") return String(item) + "n";
      if (typeof item === "function") return "ƒ " + (item.name || "anonymous") + "()";
      if (typeof item === "undefined") return "undefined";
      if (typeof item === "symbol") return String(item);
      if (item instanceof Error) return (item.name || "Error") + ": " + item.message;
      if (typeof Map !== "undefined" && item instanceof Map) item = { Map: Array.from(item.entries()) };
      else if (typeof Set !== "undefined" && item instanceof Set) item = { Set: Array.from(item.values()) };
      if (item && typeof item === "object") {
        while (ancestors.length > 0 && ancestors[ancestors.length - 1] !== this) ancestors.pop();
        if (ancestors.indexOf(item) !== -1) return "[Circular]";
        ancestors.push(item);
      }
      return item;
    }, indent);
  }

  function describe(value, nested) {
    var type = typeof value;
    if (type === "string") return nested ? JSON.stringify(value) : value;
    if (type === "undefined") return "undefined";
    if (value === null) return "null";
    if (type === "function") return "ƒ " + (value.name || "anonymous") + "()";
    if (type === "bigint") return String(value) + "n";
    if (type !== "object") return String(value);
    if (value instanceof Error) return (value.name || "Error") + ": " + value.message;
    if (typeof Node !== "undefined" && value instanceof Node) {
      if (value.nodeType !== 1) return value.nodeName;
      var label = "<" + value.tagName.toLowerCase();
      if (value.id) label += "#" + value.id;
      if (typeof value.className === "string" && value.className.trim()) {
        label += "." + value.className.trim().split(/\s+/).join(".");
      }
      return label + ">";
    }
    try {
      var compact = toJson(value, 0);
      if (typeof compact !== "string") return String(value);
      return compact.length > 72 ? toJson(value, 2) : compact;
    } catch (error) {
      return String(value);
    }
  }

  function post(level, text, where) {
    try {
      parent.postMessage({
        source: "nova-sandbox",
        token: token,
        level: level,
        text: String(text).slice(0, 6000),
        file: where ? where.file : null,
        line: where ? where.line : null
      }, "*");
    } catch (error) {}
  }

  function locate(lineno) {
    if (!lineno) return null;
    for (var i = 0; i < map.length; i++) {
      var entry = map[i];
      if (lineno >= entry.s && lineno < entry.s + entry.n) {
        return { file: entry.f, line: lineno - entry.s + 1 };
      }
    }
    return null;
  }

  function fromStack(stack) {
    var lines = String(stack || "").split("\n");
    for (var i = 0; i < lines.length; i++) {
      var match = /:(\d+):\d+\)?\s*$/.exec(lines[i]);
      if (!match) continue;
      var where = locate(Number(match[1]));
      if (where) return where;
    }
    return null;
  }

  function join(args, from) {
    var parts = [];
    for (var i = from; i < args.length; i++) parts.push(describe(args[i], false));
    return parts.join(" ");
  }

  ["log", "info", "warn", "error", "debug"].forEach(function (level) {
    var original = console[level];
    console[level] = function () {
      post(level === "debug" ? "log" : level, join(arguments, 0), fromStack(new Error().stack));
      if (original) original.apply(console, arguments);
    };
  });
  console.clear = function () { post("clear", ""); };
  console.table = function (data) { post("log", describe(data, true), fromStack(new Error().stack)); };
  console.assert = function (condition) {
    if (condition) return;
    post("error", ("Assertion failed: " + join(arguments, 1)).trim(), fromStack(new Error().stack));
  };
  var timers = {};
  console.time = function (label) { timers[label || "default"] = performance.now(); };
  console.timeEnd = function (label) {
    var key = label || "default";
    if (!(key in timers)) return;
    post("log", key + ": " + (performance.now() - timers[key]).toFixed(1) + "ms");
    delete timers[key];
  };

  window.addEventListener("error", function (event) {
    if (event.error && event.error.__novaLoop) return;
    var target = event.target;
    if (target && target !== window && target.tagName) {
      var url = target.src || target.href || "";
      post("warn", "Failed to load <" + target.tagName.toLowerCase() + ">" + (url ? " " + url : ""));
      return;
    }
    var where = locate(event.lineno) || (event.error ? fromStack(event.error.stack) : null);
    post("error", String(event.message || "Script error").replace(/^Uncaught\s+/, ""), where);
  }, true);

  window.addEventListener("unhandledrejection", function (event) {
    var reason = event.reason;
    post(
      "error",
      "Unhandled promise rejection: " + describe(reason, false),
      reason && reason.stack ? fromStack(reason.stack) : null
    );
  });

  document.addEventListener("securitypolicyviolation", function (event) {
    var uri = event.blockedURI || "resource";
    var key = uri + "|" + event.violatedDirective;
    if (reported[key]) return;
    reported[key] = true;
    post("warn", "Blocked by the sandbox security policy: " + uri + " (" + event.violatedDirective + ")");
  });

  var loopArmed = false;
  var loopStart = 0;
  window.__novaLoop = function (file, line) {
    var now = Date.now();
    if (!loopArmed) {
      // The timer can only fire once the current task yields, so a loop that
      // never yields keeps accumulating elapsed time until the limit trips.
      loopArmed = true;
      loopStart = now;
      setTimeout(function () { loopArmed = false; }, 0);
      return;
    }
    if (now - loopStart <= LOOP_LIMIT_MS) return;
    loopArmed = false;
    var message = "Loop stopped after blocking the page for 2 seconds (possible infinite loop).";
    post("error", message, { file: file, line: line });
    var error = new Error(message);
    error.__novaLoop = true;
    throw error;
  };

  window.addEventListener("load", function () { post("ready", ""); });
})();`;

const SHELL = [
  "<!doctype html>",
  '<html lang="en">',
  "<head>",
  '<meta charset="utf-8" />',
  '<meta name="viewport" content="width=device-width, initial-scale=1" />',
  "<title>Preview</title>",
  "<style>body{margin:0;padding:1.25rem;font:14px/1.6 ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif}</style>",
  "</head>",
  "<body>",
  '<div id="app"></div>',
  "</body>",
  "</html>",
].join("\n");

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, (char) => `\\${char}`);
}

function escapeHtml(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** Keeps user code from terminating the inline `<script>` that carries it. */
function escapeScript(source: string): string {
  return source
    .replace(/<\/script/gi, (match) => `<\\/${match.slice(2)}`)
    .replace(/<!--/g, "<\\!--");
}

function escapeStyle(source: string): string {
  return source.replace(/<\/style/gi, (match) => `<\\/${match.slice(2)}`);
}

/** Matches a tag that references a workspace file by (optionally `./`) name. */
function referencePattern(tag: "link" | "script", name: string): RegExp {
  const attr = tag === "link" ? "href" : "src";
  const target = `\\b${attr}\\s*=\\s*["']?(?:\\./)?${escapeRegExp(name)}["']?(?=[\\s>/])`;
  return tag === "link"
    ? new RegExp(`<link\\b[^>]*${target}[^>]*>`, "gi")
    : new RegExp(`<script\\b[^>]*${target}[^>]*>\\s*</script\\s*>`, "gi");
}

/**
 * Inserts `text` relative to the first (or last) match of `pattern`. Uses slicing
 * rather than `String.replace` with a replacement string, because user code may
 * contain `$&`, `$1` or `$$`, which `replace` would silently rewrite.
 */
function inject(
  doc: string,
  pattern: RegExp,
  text: string,
  where: "before" | "after",
  pick: "first" | "last" = "first",
): string | null {
  const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
  const matches = Array.from(doc.matchAll(new RegExp(pattern.source, flags)));
  if (matches.length === 0) return null;
  const match = pick === "first" ? matches[0] : matches[matches.length - 1];
  const index = (match.index ?? 0) + (where === "after" ? match[0].length : 0);
  return doc.slice(0, index) + text + doc.slice(index);
}

export interface PreviewOptions {
  /** Execute JavaScript files. False renders markup and styles only. */
  run?: boolean;
  /** Instrument loops so a runaway loop cannot freeze the page. Default true. */
  loopGuard?: boolean;
}

/**
 * Builds a self-contained document for the preview iframe.
 *
 * - `<link href="styles.css">` and `<script src="app.js">` that point at
 *   workspace files are replaced **in place**, so load order matches a real page.
 * - Scripts run as ordinary top-level scripts, so their declarations are global
 *   and inline handlers such as `onclick="save()"` work.
 * - Files nothing references are still loaded: stylesheets at the end of
 *   `<head>`, scripts at the end of `<body>`.
 * - A workspace without an HTML file gets a minimal shell with `<div id="app">`.
 */
export function buildPreviewDocument(files: WorkspaceFile[], options: PreviewOptions = {}): string {
  const run = options.run !== false;
  const guard = options.loopGuard !== false;
  const htmlFile =
    files.find((f) => f.name.toLowerCase() === "index.html") ??
    files.find((f) => f.language === "html") ??
    null;
  const cssFiles = files.filter((f) => f.language === "css");
  const jsFiles = files.filter((f) => f.language === "javascript");

  let doc: string;
  if (htmlFile) {
    doc = htmlFile.content;
  } else if (cssFiles.length === 0 && jsFiles.length === 0 && files.length > 0) {
    const data = files[0];
    const text = data.language === "json" ? formatJson(data.content).text : data.content;
    doc = SHELL.replace(
      '<div id="app"></div>',
      () => `<pre style="margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 ui-monospace,SFMono-Regular,Menlo,monospace">${escapeHtml(text)}</pre>`,
    );
  } else {
    doc = SHELL;
  }

  const inlined: { index: number; name: string; lines: number }[] = [];
  const styleTag = (file: WorkspaceFile) =>
    `<style data-nova-file="${escapeHtml(file.name)}">\n${escapeStyle(file.content)}\n</style>`;
  const scriptTag = (file: WorkspaceFile, original = "") => {
    const index = inlined.length;
    inlined.push({ index, name: file.name, lines: file.content.split("\n").length });
    const source = guard ? guardLoops(file.content, file.name) : file.content;
    const type = /\btype\s*=\s*["']?module\b/i.test(original) ? ' type="module"' : "";
    // The user's first line must sit on the line directly after this tag: the
    // line map below relies on it.
    return `<script data-nova-script="${index}"${type}>\n${escapeScript(source)}\n</script>`;
  };

  const referenced = new Set<string>();
  for (const file of cssFiles) {
    doc = doc.replace(referencePattern("link", file.name), () => {
      referenced.add(file.id);
      return styleTag(file);
    });
  }
  for (const file of jsFiles) {
    doc = doc.replace(referencePattern("script", file.name), (original) => {
      referenced.add(file.id);
      return run ? scriptTag(file, original) : "";
    });
  }

  const looseStyles = cssFiles.filter((f) => !referenced.has(f.id) && f.content.trim()).map(styleTag).join("\n");
  if (looseStyles) {
    doc =
      inject(doc, /<\/head\s*>/i, `${looseStyles}\n`, "before") ??
      inject(doc, /<body\b[^>]*>/i, `\n${looseStyles}`, "after") ??
      `${looseStyles}\n${doc}`;
  }

  if (!run) return doc;

  const looseScripts = jsFiles
    .filter((f) => !referenced.has(f.id) && f.content.trim())
    .map((f) => scriptTag(f))
    .join("\n");
  if (looseScripts) {
    doc = inject(doc, /<\/body\s*>/i, `${looseScripts}\n`, "before", "last") ?? `${doc}\n${looseScripts}`;
  }

  // The bridge goes first so it also observes scripts in <head>.
  const bridge = `<script data-nova-bridge>\n${BRIDGE_SOURCE}\n</script>`;
  doc =
    inject(doc, /<head\b[^>]*>/i, `\n${bridge}`, "after") ??
    inject(doc, /<html\b[^>]*>/i, `\n${bridge}`, "after") ??
    inject(doc, /<!doctype[^>]*>/i, `\n${bridge}`, "after") ??
    `${bridge}\n${doc}`;

  // Error events report line numbers relative to the whole document. Record
  // where each workspace script landed so the bridge can translate them back.
  const map = inlined
    .map((entry) => {
      const position = doc.indexOf(`<script data-nova-script="${entry.index}"`);
      if (position < 0) return null;
      let line = 1;
      for (let i = 0; i < position; i += 1) if (doc.charCodeAt(i) === 10) line += 1;
      return { f: entry.name, s: line + 1, n: entry.lines };
    })
    .filter((entry): entry is { f: string; s: number; n: number } => entry !== null);

  return doc.split(LINE_MAP_PLACEHOLDER).join(JSON.stringify(map).replace(/</g, "\\u003c"));
}

/** Replaces the placeholder with a per-run nonce (properly quoted for JS). */
export function withSandboxToken(document: string, token: string): string {
  return document.split(SANDBOX_TOKEN_PLACEHOLDER).join(JSON.stringify(token));
}

/** Turns an arbitrary (uploaded) name into one the workspace accepts. */
export function sanitizeFileName(name: string): string {
  const cleaned = name
    .trim()
    .replace(/[^\w.-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return cleaned || "file.txt";
}

/** Validates workspace file names before they are committed to state. */
export function validateFileName(
  files: WorkspaceFile[],
  name: string,
  ignoreId?: string,
): string | null {
  const trimmed = name.trim();
  if (!trimmed) return "Enter a file name.";
  if (trimmed.length > 60) return "Keep the file name under 60 characters.";
  if (!/^[\w.-]+\.[a-z0-9]+$/i.test(trimmed)) {
    return "Use a name like index.html — letters, numbers, dots, dashes and underscores only.";
  }
  const clash = files.some(
    (file) => file.id !== ignoreId && file.name.toLowerCase() === trimmed.toLowerCase(),
  );
  if (clash) return `“${trimmed}” already exists in this workspace.`;
  return null;
}

/** Joins every file into a single downloadable Markdown document. */
export function exportWorkspaceMarkdown(files: WorkspaceFile[]): string {
  return files
    .map((file) => `### ${file.name}\n\n\`\`\`${file.language}\n${file.content}\n\`\`\``)
    .join("\n\n");
}
