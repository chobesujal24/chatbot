// Pure local utilities: deterministic recursive-descent arithmetic parser,
// conversation title derivation, attachment redaction/display helpers, and
// actionable setup guidance when no model provider is connected yet.

export function evaluateMath(input: string): number | null {
  const expr = input.replace(/\s+/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, "");
  if (!expr || !/^[0-9+\-*/().%^]+$/.test(expr)) return null;
  let pos = 0;
  const peek = () => expr[pos];
  const consume = (ch: string) => (peek() === ch ? ++pos > -1 : false);

  function exprP(): number | null {
    let v = term();
    if (v === null) return null;
    while (peek() === "+" || peek() === "-") {
      const op = expr[pos++];
      const r = term();
      if (r === null) return null;
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }
  function term(): number | null {
    let v = factor();
    if (v === null) return null;
    while (peek() === "*" || peek() === "/" || peek() === "%") {
      const op = expr[pos++];
      const r = factor();
      if (r === null) return null;
      if (op === "*") v *= r;
      else if (op === "/") {
        if (r === 0) return null;
        v /= r;
      } else v %= r;
    }
    return v;
  }
  function factor(): number | null {
    let b = unary();
    if (b === null) return null;
    if (peek() === "^" || (peek() === "*" && expr[pos + 1] === "*")) {
      pos += peek() === "^" ? 1 : 2;
      const e = factor();
      if (e === null) return null;
      b = Math.pow(b, e);
    }
    return b;
  }
  function unary(): number | null {
    if (peek() === "-") {
      pos++;
      const v = unary();
      return v === null ? null : -v;
    }
    if (peek() === "+") {
      pos++;
      return unary();
    }
    return atom();
  }
  function atom(): number | null {
    if (peek() === "(") {
      pos++;
      const v = exprP();
      if (v === null) return null;
      if (!consume(")")) return null;
      return v;
    }
    let num = "";
    while (pos < expr.length && /[0-9.]/.test(expr[pos])) num += expr[pos++];
    if (!num) return null;
    const n = Number(num);
    return Number.isFinite(n) ? n : null;
  }
  const result = exprP();
  return result !== null && pos === expr.length && Number.isFinite(result) ? result : null;
}

export function deriveTitle(message: string): string {
  const clean = stripAttachedBlocks(message)
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "New conversation";
  return clean.length <= 52 ? clean : clean.slice(0, 49).trimEnd() + "…";
}

const ATTACHMENT_BLOCK_RE = /\n*--- Attached file: ([^\n]+?) ---\n[\s\S]*?\n--- End of \1 ---/g;

/** Removes inline attachment payload blocks while preserving the user's message text. */
export function stripAttachedBlocks(content: string): string {
  return content.replace(ATTACHMENT_BLOCK_RE, "").trim();
}

/** Returns the raw attachment blocks so edits can carry them forward. */
export function extractAttachedBlocks(content: string): string[] {
  ATTACHMENT_BLOCK_RE.lastIndex = 0;
  const blocks: string[] = [];
  let match: RegExpExecArray | null;
  while ((match = ATTACHMENT_BLOCK_RE.exec(content)) !== null) {
    blocks.push(match[0].trim());
  }
  ATTACHMENT_BLOCK_RE.lastIndex = 0;
  return blocks;
}

/** Replaces inline attachment contents with a privacy notice for redacted shared links. */
export function redactAttachedBlocks(content: string): string {
  return content.replace(
    ATTACHMENT_BLOCK_RE,
    (_full, name: string) => `\n\n> *[Attached file redacted: ${name}]*`,
  );
}


/* ── Offline demo responder ─────────────────────────────────────────────────
 * When a workspace has no model connection the product must not be a dead end.
 * This responder is deterministic, runs entirely on the server (no network),
 * and is always labelled as a demo so it can never be mistaken for model
 * output. It can answer arithmetic, review attached code, and scaffold a
 * sandbox project — enough to evaluate the whole interface before adding a key.
 */

export interface DemoAttachment {
  name: string;
  content: string;
}

export interface DemoReplyInput {
  prompt: string;
  attachments?: DemoAttachment[];
  agentName?: string | null;
  memoryCount?: number;
  skillCount?: number;
}

const DEMO_BADGE =
  "> **Offline demo** · no model provider is connected, so this reply is generated locally by Nova's deterministic demo responder — not by an LLM.";

const CONNECT_STEPS = [
  "**Connect a model to continue**",
  "",
  "1. Open [Settings → Providers](/settings#providers).",
  "2. Paste an API key for OpenAI, Anthropic, Gemini, OpenRouter, Groq, DeepSeek and friends — or point Ollama / LM Studio / vLLM at your local server.",
  "3. Save it, mark the connection **Active**, then resend this message.",
].join("\n");

/** Collapses the blank lines introduced by block composition. */
function finalize(blocks: string[]): string {
  return blocks
    .join("\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

interface Finding {
  file: string;
  issue: string;
  fix: string;
}

function reviewAttachment(file: DemoAttachment): Finding[] {
  const findings: Finding[] = [];
  const content = file.content;
  const lines = content.split("\n").length;
  const push = (issue: string, fix: string) => findings.push({ file: file.name, issue, fix });

  if (/console\.(log|debug)\(/.test(content)) {
    push("Debug logging is left in the file.", "Remove `console.log` calls or route them through a logger.");
  }
  if (/\.innerHTML\s*=/.test(content)) {
    push("`innerHTML` assignment can inject markup.", "Use `textContent`, or sanitise with a vetted library such as DOMPurify.");
  }
  if (/\beval\s*\(|new Function\s*\(/.test(content)) {
    push("Dynamic code execution via `eval`/`Function`.", "Parse data with `JSON.parse` or an explicit allowlist instead.");
  }
  if (/(api[_-]?key|secret|password)\s*[:=]\s*["'][^"']{8,}["']/i.test(content)) {
    push("A credential-like value looks hard-coded.", "Move secrets into environment variables and rotate the exposed value.");
  }
  if (/http:\/\//.test(content)) {
    push("An insecure `http://` URL is referenced.", "Use `https://` so the sandbox stays on a secure origin.");
  }
  if (/target=["']_blank["']/.test(content) && !/rel=["'][^"']*noopener/.test(content)) {
    push("`target=\"_blank\"` without `rel=\"noopener\"`.", "Add `rel=\"noopener noreferrer\"`.");
  }
  if (/<button(?![^>]*type=)/i.test(content)) {
    push("A `<button>` has no explicit `type`.", "Add `type=\"button\"` so it cannot submit a parent form.");
  }
  if (/fetch\(/.test(content) && !/try\s*\{|\.catch\(/.test(content)) {
    push("`fetch` has no error handling.", "Wrap it in `try/catch` and check `response.ok`.");
  }
  if (/\bTODO\b|\bFIXME\b/.test(content)) {
    push("Unfinished `TODO`/`FIXME` markers.", "Resolve them or file an issue before shipping.");
  }
  if (lines > 220) {
    push(`The file is ${lines} lines long.`, "Split rendering, state and I/O into smaller modules.");
  }
  return findings;
}

function mathAnswer(prompt: string): string | null {
  const expression = prompt.replace(/[?]/g, "").trim();
  if (!/\d/.test(expression) || !/[+\-*/^%]/.test(expression)) return null;
  const value = evaluateMath(expression);
  if (value === null) return null;
  return [
    `The expression evaluates to **${value.toLocaleString(undefined, { maximumFractionDigits: 8 })}**.`,
    "",
    "| Input | Result |",
    "| --- | --- |",
    `| \`${expression}\` | **${value}** |`,
    "",
    "The calculator tool runs locally, so arithmetic keeps working even without a provider.",
  ].join("\n");
}

function codeScaffold(prompt: string): string {
  const wantsFetch = /\b(fetch|api|request|http)\b/i.test(prompt);
  const wantsStyle = /\b(css|style|design|layout|tailwind)\b/i.test(prompt);
  if (wantsFetch && !wantsStyle) {
    return [
      "Here is a runnable starting point for the **Code workspace**. Note that the preview iframe is sandboxed with an opaque origin, so it cannot call the network — this example simulates an async request so you can see loading and error states, then swap in a real `fetch` once the code runs in your app.",
      "",
      "```js",
      "const button = document.querySelector(\"#load\");",
      "const output = document.querySelector(\"#out\");",
      "",
      "function fakeRequest(shouldFail = false) {",
      "  return new Promise((resolve, reject) => {",
      "    setTimeout(() => {",
      "      if (shouldFail) reject(new Error(\"HTTP 500\"));",
      "      else resolve({ id: 1, title: \"Ship the sandbox\", done: false });",
      "    }, 600);",
      "  });",
      "}",
      "",
      "button.addEventListener(\"click\", async () => {",
      "  output.textContent = \"Loading…\";",
      "  try {",
      "    const data = await fakeRequest();",
      "    output.textContent = JSON.stringify(data, null, 2);",
      "  } catch (error) {",
      "    output.textContent = \"Request failed: \" + error.message;",
      "  }",
      "});",
      "```",
      "",
      "- Add `type=\"button\"` and `id=\"load\"` to the button, plus `<pre id=\"out\">` for the result.",
      "- When you move the code into a Next.js route or a page without the sandbox attribute, replace `fakeRequest()` with `fetch()` and check `response.ok`.",
    ].join("\n");
  }
  return [
    "A compact, dependency-free page that runs directly in the **Code workspace**:",
    "",
    "```html",
    "<main class=\"card\">",
    "  <h1>Focus timer</h1>",
    "  <p id=\"time\">25:00</p>",
    "  <button id=\"start\" type=\"button\">Start</button>",
    "</main>",
    "```",
    "",
    "```js",
    "let remaining = 25 * 60;",
    "let ticker = null;",
    "const out = document.getElementById(\"time\");",
    "",
    "document.getElementById(\"start\").addEventListener(\"click\", () => {",
    "  if (ticker) { clearInterval(ticker); ticker = null; return; }",
    "  ticker = setInterval(() => {",
    "    remaining = Math.max(0, remaining - 1);",
    "    out.textContent = String(Math.floor(remaining / 60)).padStart(2, \"0\") + \":\" + String(remaining % 60).padStart(2, \"0\");",
    "    if (remaining === 0) clearInterval(ticker);",
    "  }, 1000);",
    "});",
    "```",
    "",
    "Open the **code panel** (the `</>` button in the header), paste these into `index.html` and `app.js`, then press **Run**. Send the files back with **Send to Nova** for a line-by-line review.",
  ].join("\n");
}

/**
 * Builds the offline demonstration reply. Kept pure so the chat route can stream
 * it and tests can assert on it without a database or network.
 */
export function buildDemoReply(input: DemoReplyInput): string {
  const prompt = stripAttachedBlocks(input.prompt) || input.prompt || "";
  const attachments = (input.attachments ?? []).filter((file) => file.content.trim().length > 0);
  const parts: string[] = [DEMO_BADGE];

  if (!prompt.trim() && attachments.length === 0) {
    parts.push(
      "",
      "Welcome to Nova. Send a message to explore the workspace shell — the demo responder can review attached files, do arithmetic and scaffold a sandbox page.",
    );
    return finalize(parts);
  }

  if (attachments.length > 0) {
    const findings = attachments.flatMap(reviewAttachment);
    const totalLines = attachments.reduce((sum, file) => sum + file.content.split("\n").length, 0);
    parts.push(
      "",
      `### Review of ${attachments.length} attached file${attachments.length === 1 ? "" : "s"}`,
      "",
      attachments
        .map((file) => `- \`${file.name}\` — ${file.content.split("\n").length} lines, ${file.content.length.toLocaleString()} characters`)
        .join("\n"),
      "",
      `That is **${totalLines} lines** in total. ${findings.length === 0 ? "I found no obvious red flags in the quick static pass." : `The static pass flagged **${findings.length} item${findings.length === 1 ? "" : "s"}** worth a look:`}`,
    );
    if (findings.length > 0) {
      parts.push("", "| File | Observation | Suggested fix |", "| --- | --- | --- |");
      for (const finding of findings.slice(0, 8)) {
        parts.push(`| \`${finding.file}\` | ${finding.issue} | ${finding.fix} |`);
      }
    }
    parts.push(
      "",
      "**Next steps**",
      "1. Fix any security notes first — they are cheapest to address now.",
      "2. Keep rendering and data access in separate functions so the sandbox preview stays testable.",
      "3. Connect a model provider to get a deeper, model-written review with diffs.",
    );
    return finalize(parts);
  }

  const math = mathAnswer(prompt);
  if (math) {
    parts.push("", math);
    return finalize(parts);
  }

  if (/^(hi|hey|hello|yo|good (morning|evening|afternoon))\b/i.test(prompt.trim())) {
    parts.push(
      "",
      "Hello! You are talking to the local demo responder, so everything here is deterministic and free.",
      "",
      "**What you can try right now**",
      "- Ask `2 + 3 * (4 ^ 2)` — the calculator runs locally.",
      "- Open the code panel with the **`</>`** header button, edit the starter page, press **Run**, then **Send to Nova** — I will review the files.",
      "- Create an agent, a task list, memories, a prompt template or a share link to explore the rest of the shell.",
      "",
      CONNECT_STEPS,
    );
    return finalize(parts);
  }

  if (/\b(code|build|component|function|sandbox|html|css|javascript|react|typescript|bug|refactor)\b/i.test(prompt)) {
    parts.push(
      "",
      `### ${input.agentName ? `${input.agentName}: ` : ""}a runnable starting point`,
      "",
      codeScaffold(prompt),
      "",
      CONNECT_STEPS,
    );
    return finalize(parts);
  }

  if (/\b(capabilit|feature|what can you|help me with|tools?)\b/i.test(prompt)) {
    parts.push(
      "",
      "**What this workspace contains**",
      "",
      "| Area | What it does |",
      "| --- | --- |",
      "| Chat | Streaming replies, edit & resend, regenerate, forks, share links, feedback |",
      "| Agents | Custom prompts, models, tool sets and memory policy |",
      "| Tools | Calculator, time, web search, page reading, URL fetch, memory, task list |",
      "| Code workspace | Multi-file editor with a sandboxed live preview and console |",
      "| Memory | Scoped, searchable, deduped long-term memory with usage counts |",
      "| Settings | Providers, integrations, usage, appearance, data export |",
      "",
      "With a provider connected, the same tools run through a real model with multi-step loops. Without one, this demo responder still exercises the interface.",
      "",
      CONNECT_STEPS,
    );
    return finalize(parts);
  }

  const topic = prompt.trim().replace(/\s+/g, " ").slice(0, 140);
  parts.push(
    "",
    `### On “${topic}${prompt.trim().length > 140 ? "…" : ""}”`,
    "",
    "A real model would reason over your workspace context here. Locally, I can still give you a useful structure to work from:",
    "",
    "1. **Define the outcome** — write the one sentence that tells you this is finished.",
    "2. **List the constraints** — time, stack, data, and anything that cannot change.",
    "3. **Draft the smallest next step** — one file, one endpoint or one decision you can make now.",
    "4. **Review with evidence** — run it, capture the result, and compare against step 1.",
    "",
    input.memoryCount
      ? `_${input.memoryCount} relevant memor${input.memoryCount === 1 ? "y" : "ies"} matched this message and would be injected into the prompt for a connected model._`
      : "_Memories, skills and tools all activate automatically once a model is connected._",
    "",
    CONNECT_STEPS,
  );
  return finalize(parts);
}

/** Splits a demo reply into small deltas so the UI streams like a model reply. */
export function* demoChunks(text: string): Generator<string> {
  const size = 48;
  for (let index = 0; index < text.length; index += size) {
    yield text.slice(index, index + size);
  }
}
