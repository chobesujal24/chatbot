import type { ClientAttachment } from "./types";

export const MAX_ATTACHMENTS = 5;
export const MAX_PROMPT_LENGTH = 8000;
export const TEXT_FILE_PATTERN = /\.(txt|md|markdown|json|csv|tsv|log|js|mjs|cjs|jsx|ts|tsx|py|rs|go|java|css|html|htm|yml|yaml|sql|xml|env|toml)$/i;

export function attachmentBytes(content: string): number {
  return new TextEncoder().encode(content).byteLength;
}

/**
 * A newer file with the same name replaces the earlier version, even when its
 * character count is unchanged. A sixth file is reported, never silently lost.
 */
export function mergeAttachments(
  existing: ClientAttachment[],
  incoming: ClientAttachment[],
  maxBytes: number,
): { files: ClientAttachment[]; oversized: string[]; overflow: number } {
  const files = existing.slice(0, MAX_ATTACHMENTS);
  const oversized: string[] = [];
  let overflow = 0;
  for (const file of incoming) {
    if (attachmentBytes(file.content) > maxBytes) {
      oversized.push(file.name);
      continue;
    }
    const index = files.findIndex((item) => item.name === file.name);
    if (index >= 0) files[index] = file;
    else if (files.length < MAX_ATTACHMENTS) files.push(file);
    else overflow += 1;
  }
  return { files, oversized, overflow };
}
