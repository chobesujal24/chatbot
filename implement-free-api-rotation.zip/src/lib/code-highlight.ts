/**
 * Dependency-free tokenizers for the code workspace editor.
 *
 * They are deliberately small: the goal is readable colouring while typing, not
 * a full parser. Every tokenizer upholds one invariant — concatenating the token
 * texts yields the input exactly — so the highlighted layer can sit pixel-aligned
 * underneath the textarea. `tokenize` verifies it and falls back to plain text.
 *
 * The JavaScript tokenizer is also reused by `guardLoops`, which instruments loop
 * conditions so a runaway loop cannot freeze the page hosting the preview.
 */

import type { SandboxLanguage } from "./code-sandbox";

export type TokenKind =
  | "plain"
  | "comment"
  | "string"
  | "number"
  | "keyword"
  | "literal"
  | "function"
  | "property"
  | "tag"
  | "attr"
  | "punct"
  | "meta"
  | "regex";

export interface Token {
  kind: TokenKind;
  text: string;
}

/** Sticky match at `index`; never returns an empty match. */
function at(re: RegExp, code: string, index: number): string | null {
  re.lastIndex = index;
  const match = re.exec(code);
  return match && match[0].length > 0 ? match[0] : null;
}

const RE_WS = /\s+/y;
const RE_DQ = /"(?:\\[\s\S]|[^"\\\n])*"?/y;
const RE_SQ = /'(?:\\[\s\S]|[^'\\\n])*'?/y;
const RE_BLOCK_COMMENT = /\/\*[\s\S]*?(?:\*\/|$)/y;

/* ── JavaScript / TypeScript ─────────────────────────────────────────────── */

const RE_IDENT = /[A-Za-z_$\u00a0-\uffff][\w$\u00a0-\uffff]*/y;
const RE_NUMBER =
  /(?:0[xX][\da-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+|(?:\d[\d_]*\.?[\d_]*|\.\d[\d_]*)(?:[eE][+-]?\d+)?)n?/y;
const RE_REGEX = /\/(?![*/])(?:\\.|\[(?:\\.|[^\]\\\n])*\]|[^/\\\n[])+\/[a-z]*/y;
const RE_LINE_COMMENT = /\/\/[^\n]*/y;
const RE_OPERATOR = /[+\-*%=!&|^~?:<>.@#]+/y;

const JS_KEYWORDS = new Set(
  "break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return static switch throw try typeof var void while with yield async await of".split(
    " ",
  ),
);
const TS_KEYWORDS = new Set(
  "interface type enum implements namespace declare readonly abstract public private protected keyof infer is satisfies as".split(
    " ",
  ),
);
const JS_LITERALS = new Set(["true", "false", "null", "undefined", "NaN", "Infinity", "this", "super"]);

function scanTemplate(code: string, start: number): number {
  let j = start + 1;
  while (j < code.length) {
    const ch = code[j];
    if (ch === "\\") {
      j += 2;
      continue;
    }
    if (ch === "`") return j + 1;
    if (ch === "$" && code[j + 1] === "{") {
      j = scanInterpolation(code, j + 2);
      continue;
    }
    j += 1;
  }
  return code.length;
}

function scanInterpolation(code: string, start: number): number {
  let depth = 1;
  let j = start;
  while (j < code.length) {
    const ch = code[j];
    if (ch === "`") {
      j = scanTemplate(code, j);
      continue;
    }
    if (ch === '"' || ch === "'") {
      const text = at(ch === '"' ? RE_DQ : RE_SQ, code, j);
      j += text ? text.length : 1;
      continue;
    }
    if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) return j + 1;
    }
    j += 1;
  }
  return code.length;
}

export function tokenizeScript(code: string, typed = false): Token[] {
  const out: Token[] = [];
  const n = code.length;
  let i = 0;
  // Whether a `/` here would start a regex literal (after an operator) or be a
  // division (after a value). The classic heuristic, good enough for colouring.
  // Cast (not annotation): `prev` is reassigned inside `emit`, which control-flow
  // narrowing cannot see.
  let prev = "start" as "start" | "value" | "operator";
  let afterDot = false;

  const emit = (kind: TokenKind, text: string, sig: "value" | "operator" | null) => {
    out.push({ kind, text });
    if (sig) {
      prev = sig;
      afterDot = false;
    }
    i += text.length;
  };

  while (i < n) {
    const ch = code[i];
    let text: string | null;

    if ((text = at(RE_WS, code, i))) {
      emit("plain", text, null);
      continue;
    }

    if (ch === "/") {
      const next = code[i + 1];
      if (next === "/" && (text = at(RE_LINE_COMMENT, code, i))) {
        emit("comment", text, null);
        continue;
      }
      if (next === "*" && (text = at(RE_BLOCK_COMMENT, code, i))) {
        emit("comment", text, null);
        continue;
      }
      if (prev !== "value" && (text = at(RE_REGEX, code, i))) {
        emit("regex", text, "value");
        continue;
      }
      emit("punct", next === "=" ? "/=" : "/", "operator");
      continue;
    }

    if (ch === '"' || ch === "'") {
      text = at(ch === '"' ? RE_DQ : RE_SQ, code, i) ?? ch;
      emit("string", text, "value");
      continue;
    }

    if (ch === "`") {
      const end = Math.min(scanTemplate(code, i), n);
      emit("string", code.slice(i, end), "value");
      continue;
    }

    if ((ch >= "0" && ch <= "9") || (ch === "." && code[i + 1] >= "0" && code[i + 1] <= "9")) {
      text = at(RE_NUMBER, code, i);
      if (text) {
        emit("number", text, "value");
        continue;
      }
    }

    if ((text = at(RE_IDENT, code, i))) {
      const wasDot = afterDot;
      if (!wasDot && (JS_KEYWORDS.has(text) || (typed && TS_KEYWORDS.has(text)))) {
        emit("keyword", text, "operator");
        continue;
      }
      if (!wasDot && JS_LITERALS.has(text)) {
        emit("literal", text, "value");
        continue;
      }
      let look = i + text.length;
      while (look < n && (code[look] === " " || code[look] === "\t")) look += 1;
      emit(code[look] === "(" ? "function" : "plain", text, "value");
      continue;
    }

    if ("(){}[];,".includes(ch)) {
      emit("punct", ch, ch === ")" || ch === "]" || ch === "}" ? "value" : "operator");
      continue;
    }

    if ((text = at(RE_OPERATOR, code, i))) {
      emit("punct", text, "operator");
      afterDot = text.endsWith(".") && !text.endsWith("..");
      continue;
    }

    emit("plain", ch, "value");
  }
  return out;
}

/* ── CSS ─────────────────────────────────────────────────────────────────── */

const RE_CSS_AT = /@[\w-]+/y;
const RE_CSS_IDENT = /-{0,2}[A-Za-z_][\w-]*|--[\w-]+/y;
const RE_CSS_NUMBER = /[+-]?(?:\d+\.?\d*|\.\d+)(?:%|[a-zA-Z]+)?/y;
const RE_CSS_HEX = /#[\da-fA-F]{3,8}\b/y;
const RE_CSS_DECL = /\s*:(?!:)[^{};]*(?:;|\}|$)/y;
const RE_CSS_COLON = /\s*:/y;
const RE_CSS_SELECTOR = /[.#][\w-]+/y;
const RE_CSS_PSEUDO = /::?[\w-]+/y;
const RE_CSS_IMPORTANT = /!\s*important/y;

export function tokenizeCss(code: string): Token[] {
  const out: Token[] = [];
  const n = code.length;
  let i = 0;
  let depth = 0;
  let inValue = false;
  const emit = (kind: TokenKind, text: string) => {
    out.push({ kind, text });
    i += text.length;
  };

  while (i < n) {
    const ch = code[i];
    let text: string | null;

    if ((text = at(RE_WS, code, i))) emit("plain", text);
    else if (ch === "/" && code[i + 1] === "*" && (text = at(RE_BLOCK_COMMENT, code, i))) emit("comment", text);
    else if (ch === '"' || ch === "'") emit("string", at(ch === '"' ? RE_DQ : RE_SQ, code, i) ?? ch);
    else if (ch === "@" && (text = at(RE_CSS_AT, code, i))) emit("keyword", text);
    else if (ch === "{") {
      depth += 1;
      inValue = false;
      emit("punct", ch);
    } else if (ch === "}") {
      depth = Math.max(0, depth - 1);
      inValue = false;
      emit("punct", ch);
    } else if (ch === ";") {
      inValue = false;
      emit("punct", ch);
    } else if (inValue) {
      if (ch === "#" && (text = at(RE_CSS_HEX, code, i))) emit("number", text);
      else if ((text = at(RE_CSS_NUMBER, code, i))) emit("number", text);
      else if (ch === "!" && (text = at(RE_CSS_IMPORTANT, code, i))) emit("keyword", text);
      else if ((text = at(RE_CSS_IDENT, code, i))) {
        if (code[i + text.length] === "(") emit("function", text);
        else emit(text.startsWith("--") ? "property" : "plain", text);
      } else emit("punct", ch);
    } else if ((text = at(RE_CSS_IDENT, code, i))) {
      if (depth > 0 && at(RE_CSS_DECL, code, i + text.length)) {
        emit("property", text);
        const colon = at(RE_CSS_COLON, code, i);
        if (colon) emit("punct", colon);
        inValue = true;
      } else emit("tag", text);
    } else if ((ch === "." || ch === "#") && (text = at(RE_CSS_SELECTOR, code, i))) emit("attr", text);
    else if (ch === ":" && (text = at(RE_CSS_PSEUDO, code, i))) emit("meta", text);
    else if ((text = at(RE_CSS_NUMBER, code, i))) emit("number", text);
    else emit("punct", ch);
  }
  return out;
}

/* ── HTML ────────────────────────────────────────────────────────────────── */

const RE_HTML_COMMENT = /<!--[\s\S]*?(?:-->|$)/y;
const RE_HTML_DOCTYPE = /<![^>]*>?/y;
const RE_HTML_TAG_OPEN = /<\/?[A-Za-z][\w:-]*/y;
const RE_HTML_TAG_END = /\/?>/y;
const RE_HTML_ATTR = /[^\s"'<>/=]+/y;
const RE_HTML_ATTR_STRING = /"[^"]*"?|'[^']*'?/y;
const RE_HTML_UNQUOTED = /[^\s>]+/y;
const RE_HTML_ENTITY = /&[#\w]+;/y;
const RE_HTML_TEXT = /[^<&]+/y;

export function tokenizeHtml(code: string): Token[] {
  const out: Token[] = [];
  const n = code.length;
  let i = 0;
  const emit = (kind: TokenKind, text: string) => {
    out.push({ kind, text });
    i += text.length;
  };

  while (i < n) {
    let text: string | null;
    if (code.startsWith("<!--", i) && (text = at(RE_HTML_COMMENT, code, i))) {
      emit("comment", text);
      continue;
    }
    if (code.startsWith("<!", i) && (text = at(RE_HTML_DOCTYPE, code, i))) {
      emit("meta", text);
      continue;
    }
    if ((text = at(RE_HTML_TAG_OPEN, code, i))) {
      const closing = text.startsWith("</");
      const name = text.slice(closing ? 2 : 1).toLowerCase();
      emit("tag", text);
      let afterEquals = false;
      let selfClosed = false;
      let ended = false;
      while (i < n && !ended) {
        const ch = code[i];
        if ((text = at(RE_WS, code, i))) emit("plain", text);
        else if ((text = at(RE_HTML_TAG_END, code, i))) {
          selfClosed = text.startsWith("/");
          emit("tag", text);
          ended = true;
        } else if (ch === "=") {
          emit("punct", ch);
          afterEquals = true;
        } else if ((ch === '"' || ch === "'") && (text = at(RE_HTML_ATTR_STRING, code, i))) {
          emit("string", text);
          afterEquals = false;
        } else if (afterEquals && (text = at(RE_HTML_UNQUOTED, code, i))) {
          emit("string", text);
          afterEquals = false;
        } else if (ch === "<") {
          // A new tag started before this one closed (mid-edit); bail out.
          ended = true;
        } else if ((text = at(RE_HTML_ATTR, code, i))) emit("attr", text);
        else emit("plain", ch);
      }
      if (!closing && !selfClosed && (name === "script" || name === "style")) {
        const lower = code.toLowerCase();
        const close = lower.indexOf(`</${name}`, i);
        const end = close === -1 ? n : close;
        const inner = code.slice(i, end);
        if (inner) {
          out.push(...(name === "script" ? tokenizeScript(inner) : tokenizeCss(inner)));
          i = end;
        }
      }
      continue;
    }
    if ((text = at(RE_HTML_ENTITY, code, i))) {
      emit("literal", text);
      continue;
    }
    if ((text = at(RE_HTML_TEXT, code, i))) {
      emit("plain", text);
      continue;
    }
    emit("plain", code[i]);
  }
  return out;
}

/* ── JSON ────────────────────────────────────────────────────────────────── */

const RE_JSON_NUMBER = /-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
const RE_JSON_LITERAL = /\b(?:true|false|null)\b/y;

export function tokenizeJson(code: string): Token[] {
  const out: Token[] = [];
  const n = code.length;
  let i = 0;
  const emit = (kind: TokenKind, text: string) => {
    out.push({ kind, text });
    i += text.length;
  };
  while (i < n) {
    const ch = code[i];
    let text: string | null;
    if ((text = at(RE_WS, code, i))) emit("plain", text);
    else if (ch === '"' && (text = at(RE_DQ, code, i))) {
      emit(at(RE_CSS_COLON, code, i + text.length) ? "property" : "string", text);
    } else if ((text = at(RE_JSON_NUMBER, code, i))) emit("number", text);
    else if ((text = at(RE_JSON_LITERAL, code, i))) emit("keyword", text);
    else emit("punct", ch);
  }
  return out;
}

/* ── Python ──────────────────────────────────────────────────────────────── */

const RE_PY_COMMENT = /#[^\n]*/y;
const RE_PY_TRIPLE = /[rbfuRBFU]{0,2}(?:"""[\s\S]*?(?:"""|$)|'''[\s\S]*?(?:'''|$))/y;
const RE_PY_STRING = /[rbfuRBFU]{0,2}(?:"(?:\\[\s\S]|[^"\\\n])*"?|'(?:\\[\s\S]|[^'\\\n])*'?)/y;
const RE_PY_DECORATOR = /@[\w.]+/y;
const RE_PY_IDENT = /[A-Za-z_][\w]*/y;
const PY_KEYWORDS = new Set(
  "and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case".split(
    " ",
  ),
);
const PY_LITERALS = new Set(["True", "False", "None", "self", "cls"]);

export function tokenizePython(code: string): Token[] {
  const out: Token[] = [];
  const n = code.length;
  let i = 0;
  let defining = false;
  const emit = (kind: TokenKind, text: string) => {
    out.push({ kind, text });
    i += text.length;
  };
  while (i < n) {
    const ch = code[i];
    let text: string | null;
    if ((text = at(RE_WS, code, i))) emit("plain", text);
    else if (ch === "#" && (text = at(RE_PY_COMMENT, code, i))) emit("comment", text);
    else if ((text = at(RE_PY_TRIPLE, code, i))) emit("string", text);
    else if ((text = at(RE_PY_STRING, code, i))) emit("string", text);
    else if (ch === "@" && (text = at(RE_PY_DECORATOR, code, i))) emit("meta", text);
    else if (ch >= "0" && ch <= "9" && (text = at(RE_NUMBER, code, i))) emit("number", text);
    else if ((text = at(RE_PY_IDENT, code, i))) {
      if (PY_KEYWORDS.has(text)) {
        defining = text === "def" || text === "class";
        emit("keyword", text);
      } else if (PY_LITERALS.has(text)) emit("literal", text);
      else if (defining || code[i + text.length] === "(") {
        defining = false;
        emit("function", text);
      } else emit("plain", text);
    } else emit("punct", ch);
  }
  return out;
}

/* ── Markdown ────────────────────────────────────────────────────────────── */

const RE_MD_INLINE = /`[^`\n]+`|\*\*[^*\n]+\*\*|\[[^\]\n]*\]\([^)\n]*\)/g;

export function tokenizeMarkdown(code: string): Token[] {
  const out: Token[] = [];
  let fenced = false;
  const lines = code.split("\n");
  lines.forEach((line, index) => {
    const newline = index < lines.length - 1 ? "\n" : "";
    const fence = /^\s*(?:```|~~~)/.test(line);
    if (fence || fenced) {
      out.push({ kind: "string", text: line + newline });
      if (fence) fenced = !fenced;
      return;
    }
    if (/^#{1,6}\s/.test(line)) {
      out.push({ kind: "keyword", text: line + newline });
      return;
    }
    if (/^\s*>/.test(line)) {
      out.push({ kind: "comment", text: line + newline });
      return;
    }
    let cursor = 0;
    const marker = /^\s*(?:[-*+]|\d+\.)\s/.exec(line);
    if (marker) {
      out.push({ kind: "punct", text: marker[0] });
      cursor = marker[0].length;
    }
    RE_MD_INLINE.lastIndex = cursor;
    let match: RegExpExecArray | null;
    while ((match = RE_MD_INLINE.exec(line)) !== null) {
      if (match.index > cursor) out.push({ kind: "plain", text: line.slice(cursor, match.index) });
      const text = match[0];
      out.push({ kind: text.startsWith("`") ? "string" : text.startsWith("[") ? "property" : "literal", text });
      cursor = match.index + text.length;
    }
    const rest = line.slice(cursor) + newline;
    if (rest) out.push({ kind: "plain", text: rest });
  });
  return out;
}

/* ── Public API ──────────────────────────────────────────────────────────── */

/** Files above this size are shown without colouring to keep typing instant. */
export const HIGHLIGHT_LIMIT = 150_000;

export function tokenize(code: string, language: SandboxLanguage): Token[] {
  if (!code) return [];
  if (code.length > HIGHLIGHT_LIMIT) return [{ kind: "plain", text: code }];
  let tokens: Token[];
  try {
    switch (language) {
      case "javascript":
        tokens = tokenizeScript(code);
        break;
      case "typescript":
        tokens = tokenizeScript(code, true);
        break;
      case "css":
        tokens = tokenizeCss(code);
        break;
      case "html":
        tokens = tokenizeHtml(code);
        break;
      case "json":
        tokens = tokenizeJson(code);
        break;
      case "python":
        tokens = tokenizePython(code);
        break;
      case "markdown":
        tokens = tokenizeMarkdown(code);
        break;
      default:
        tokens = [{ kind: "plain", text: code }];
    }
  } catch {
    return [{ kind: "plain", text: code }];
  }
  let total = 0;
  for (const token of tokens) total += token.text.length;
  // The highlighted layer must mirror the textarea character for character.
  return total === code.length ? tokens : [{ kind: "plain", text: code }];
}

/** Tokens grouped per source line; always `code.split("\n").length` entries. */
export function tokenizeLines(code: string, language: SandboxLanguage): Token[][] {
  const lines: Token[][] = [[]];
  for (const token of tokenize(code, language)) {
    const parts = token.text.split("\n");
    for (let index = 0; index < parts.length; index += 1) {
      if (index > 0) lines.push([]);
      if (parts[index]) lines[lines.length - 1].push({ kind: token.kind, text: parts[index] });
    }
  }
  return lines;
}

/* ── Loop guard ──────────────────────────────────────────────────────────── */

export const LOOP_GUARD_NAME = "__novaLoop";

/**
 * Instruments `while (…)` and `for (…; …; …)` conditions with a call to the
 * sandbox's loop guard, which throws when a loop blocks the page for too long.
 *
 * The preview iframe shares a thread with the app, so without this a
 * `while (true)` typed mid-edit would freeze the whole tab on the next auto-run.
 *
 * It is conservative by design: only loop headers that open and close on a
 * single line are touched, and every insertion stays on that line, so reported
 * error line numbers never shift. Anything unusual is left exactly as written.
 */
export function guardLoops(code: string, file: string): string {
  if (!/\b(?:while|for)\b/.test(code)) return code;
  let tokens: Token[];
  try {
    tokens = tokenizeScript(code);
  } catch {
    return code;
  }
  const starts: number[] = [];
  let offset = 0;
  for (const token of tokens) {
    starts.push(offset);
    offset += token.text.length;
  }
  if (offset !== code.length) return code;

  const isTrivia = (token: Token) =>
    token.kind === "comment" || (token.kind === "plain" && token.text.trim() === "");
  const inserts: { pos: number; text: string }[] = [];
  let line = 1;

  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    const tokenLine = line;
    for (let c = 0; c < token.text.length; c += 1) if (token.text[c] === "\n") line += 1;
    if (token.kind !== "keyword" || (token.text !== "while" && token.text !== "for")) continue;

    let open = index + 1;
    while (open < tokens.length && isTrivia(tokens[open]) && !tokens[open].text.includes("\n")) open += 1;
    if (open >= tokens.length || tokens[open].kind !== "punct" || tokens[open].text !== "(") continue;

    let depth = 0;
    let close = -1;
    const semis: number[] = [];
    for (let j = open; j < tokens.length; j += 1) {
      const current = tokens[j];
      if (current.text.includes("\n")) break;
      if (current.kind !== "punct") continue;
      if (current.text === "(" || current.text === "[" || current.text === "{") depth += 1;
      else if (current.text === ")" || current.text === "]" || current.text === "}") {
        depth -= 1;
        if (depth === 0) {
          close = current.text === ")" ? j : -1;
          break;
        }
      } else if (current.text === ";" && depth === 1) semis.push(j);
    }
    if (close < 0) continue;

    const call = `${LOOP_GUARD_NAME}(${JSON.stringify(file)},${tokenLine})`;
    if (token.text === "while") {
      if (semis.length > 0) continue;
      if (!code.slice(starts[open] + 1, starts[close]).trim()) continue;
      inserts.push({ pos: starts[open] + 1, text: `${call}||(` }, { pos: starts[close], text: ")" });
    } else {
      // `for (a of b)` / `for (k in o)` are bounded by their iterable.
      if (semis.length !== 2) continue;
      const condStart = starts[semis[0]] + 1;
      const condEnd = starts[semis[1]];
      if (!code.slice(condStart, condEnd).trim()) inserts.push({ pos: condEnd, text: `!${call}` });
      else inserts.push({ pos: condStart, text: `${call}||(` }, { pos: condEnd, text: ")" });
    }
  }

  if (inserts.length === 0) return code;
  inserts.sort((a, b) => b.pos - a.pos);
  let result = code;
  for (const insert of inserts) {
    result = result.slice(0, insert.pos) + insert.text + result.slice(insert.pos);
  }
  return result;
}
