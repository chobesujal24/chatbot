"use client";

import { useSyncExternalStore } from "react";

const subscribe = () => () => {};
const getServerSnapshot = () => "Ctrl";
const getSnapshot = () => (/Mac|iPhone|iPad|iPod/.test(navigator.platform) ? "⌘" : "Ctrl");

/** Hydration-safe, platform-appropriate modifier for visible keyboard hints. */
export function useShortcutKey(): string {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
