import type { ProviderId, Settings } from "./types";

export const SETTINGS_KEY = "nova-settings-v2";

export const DEFAULT_SYSTEM_PROMPT =
  "You are Nova, a precise and helpful assistant. Be direct, concise and well-structured. Use Markdown, fenced code blocks with language tags, and tables when they help. State uncertainty honestly.";

export const DEFAULT_SETTINGS: Settings = {
  provider: "free-max",
  model: "auto",
  apiKey: "",
  baseURL: "",
  systemPrompt: DEFAULT_SYSTEM_PROMPT,
  temperature: 0.7,
  maxTokens: 2048,
};

export function providerLabel(id: ProviderId): string {
  return id;
}
