/** Curated starting points. Selecting one creates a draft; it never sends it. */
export type PromptCategory = "explore" | "write" | "learn" | "code";
export type PromptIcon = "write" | "plan" | "learn" | "code" | "notes" | "compare";

export interface StarterPrompt {
  id: string;
  title: string;
  description: string;
  icon: PromptIcon;
  prompt: string;
}

export const PROMPT_CATEGORIES: { id: PromptCategory; label: string }[] = [
  { id: "explore", label: "For you" },
  { id: "write", label: "Writing" },
  { id: "learn", label: "Learning" },
  { id: "code", label: "Coding" },
];

export const HOME_PROMPTS: Record<PromptCategory, StarterPrompt[]> = {
  explore: [
    {
      id: "first-draft",
      title: "Find the right words",
      description: "Turn a rough thought into a first draft.",
      icon: "write",
      prompt: "Help me write a clear, thoughtful first draft. Start by asking what I want to say, who it's for, and the tone I have in mind.",
    },
    {
      id: "work-through",
      title: "Make a plan",
      description: "Break a big idea into manageable steps.",
      icon: "plan",
      prompt: "Help me break a project into practical next steps. Ask me about the goal, the deadline, and any constraints before making a plan.",
    },
    {
      id: "understand",
      title: "Understand something new",
      description: "An explanation that meets you where you are.",
      icon: "learn",
      prompt: "I want to understand a new topic. Ask what I'm curious about and what I already know, then explain it with a concrete example.",
    },
    {
      id: "code-review",
      title: "Get a second pair of eyes",
      description: "Work through a tricky piece of code.",
      icon: "code",
      prompt: "Help me review a piece of code for correctness, readability, and edge cases. Ask me to share the code and what it's meant to do before suggesting changes.",
    },
  ],
  write: [
    {
      id: "email",
      title: "Write a thoughtful email",
      description: "Clear, useful, and still in your voice.",
      icon: "write",
      prompt: "Help me draft an email that sounds like me. First ask who I'm writing to, the outcome I want, and how formal it should be.",
    },
    {
      id: "edit",
      title: "Make a draft clearer",
      description: "Keep the meaning. Lose the extra words.",
      icon: "notes",
      prompt: "I'd like to make a draft clearer and more concise without losing my voice. Ask me to paste it, then suggest an edit and explain the important changes.",
    },
    {
      id: "outline",
      title: "Find a structure",
      description: "An outline for the idea in your head.",
      icon: "plan",
      prompt: "Help me turn an idea into a useful outline. Ask about the topic, audience, and main takeaway, then propose a simple structure.",
    },
    {
      id: "notes",
      title: "Put notes to work",
      description: "Pull out the decisions and next steps.",
      icon: "notes",
      prompt: "Help me turn messy notes into a concise summary, decisions, and next steps. Ask me to paste or attach my notes first. Do not invent details that aren't there.",
    },
  ],
  learn: [
    {
      id: "explain",
      title: "Explain it simply",
      description: "Start with the basics, not the jargon.",
      icon: "learn",
      prompt: "Explain a topic to me in plain language, with an analogy and a worked example. First ask what topic and how familiar I am with it.",
    },
    {
      id: "compare",
      title: "Compare two options",
      description: "See the trade-offs side by side.",
      icon: "compare",
      prompt: "Help me compare two options. Ask which options I'm considering and what matters most, then lay out the trade-offs and uncertainties.",
    },
    {
      id: "practice",
      title: "Test what you know",
      description: "A few good questions, one at a time.",
      icon: "notes",
      prompt: "Quiz me on a topic one question at a time. Ask which topic and difficulty level first. Wait for each answer and explain anything I miss.",
    },
    {
      id: "study-plan",
      title: "Build a learning habit",
      description: "A realistic plan for your available time.",
      icon: "plan",
      prompt: "Help me make a realistic learning plan. Ask what I want to learn, where I'm starting, and how much time I can set aside each week.",
    },
  ],
  code: [
    {
      id: "debug",
      title: "Track down a bug",
      description: "From the symptom to a small, testable fix.",
      icon: "code",
      prompt: "Help me debug an issue. Ask for the smallest code example, the error message, the expected behaviour, and what I've already tried. Let's identify the cause before changing things.",
    },
    {
      id: "simplify-code",
      title: "Make code easier to read",
      description: "Refactor without changing how it works.",
      icon: "notes",
      prompt: "Help me refactor code for clarity without changing its behaviour. Ask me to share the code first, then explain the changes and how to verify them.",
    },
    {
      id: "prototype",
      title: "Build a small prototype",
      description: "Start with plain HTML, CSS, and JavaScript.",
      icon: "code",
      prompt: "Help me build a small prototype with plain HTML, CSS, and JavaScript that I can run in the code workspace. Ask what I want to make first. Keep it dependency-free.",
    },
    {
      id: "test-cases",
      title: "Think through edge cases",
      description: "Find the gaps before they become bugs.",
      icon: "compare",
      prompt: "Help me identify edge cases and write focused tests for a function. Ask for the code, intended behaviour, and test framework first.",
    },
  ],
};
