/** A plain-text excerpt around the match, not just the beginning of a message. */
export function searchSnippet(content: string, query: string, limit = 220): string {
  const text = content.replace(/\s+/g, " ").trim();
  const needle = query.replace(/\s+/g, " ").trim();
  const width = Math.max(40, Math.floor(limit));
  if (text.length <= width) return text;

  const index = needle ? text.toLocaleLowerCase().indexOf(needle.toLocaleLowerCase()) : -1;
  let start = index < 0 ? 0 : Math.max(0, index - 60);
  // If the result is near the end, use the available space for preceding context.
  start = Math.min(start, Math.max(0, text.length - width));
  if (start > 0) {
    const boundary = text.indexOf(" ", start);
    if (boundary > start && boundary - start < 20 && (index < 0 || boundary < index)) start = boundary + 1;
  }
  const end = Math.min(text.length, start + width);
  return `${start > 0 ? "…" : ""}${text.slice(start, end).trim()}${end < text.length ? "…" : ""}`;
}
