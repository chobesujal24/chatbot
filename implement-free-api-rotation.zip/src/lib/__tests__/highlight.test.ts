import { describe, expect, it } from "vitest";
import { guardLoops, tokenize, tokenizeLines } from "../code-highlight";
import type { SandboxLanguage } from "../code-sandbox";

const kinds = (code: string, language: SandboxLanguage) =>
  tokenize(code, language)
    .filter((token) => token.text.trim())
    .map((token) => `${token.kind}:${token.text}`);

const SAMPLES: Record<SandboxLanguage, string> = {
  javascript:
    "const re = /(\\d+)\\)/g; // c\nlet s = `a ${b ? `x` : 'y'} $${n}`;\nfor (let i = 0; i < 3; i++) { x = a / b / c; }\n/* open",
  typescript: "interface A { x: number }\nexport const f = <T,>(a: T): T => a as T;",
  css: ":root { --ink: #1c1917; }\n@media (min-width: 600px) { .a:hover > b { color: rgb(1 2 3 / 45%) !important; margin: -1.5rem auto } }\n/* open",
  html: '<!doctype html>\n<div class="a" data-x=1 hidden>&amp; hi<br/></div>\n<style>p{color:red}</style><script>if (a < b) { x() }</script>\n<!-- open',
  json: '{ "a": [1, -2.5e3, true, null], "b": "x\\"y" ',
  python: "@dec\ndef f(x):\n    '''doc'''\n    return f\"{x}\" # c\nclass A: pass",
  markdown: "# Title\n- item with `code` and **bold** and [l](u)\n```js\nlet x\n```\n> quote",
  text: "plain\ntext",
};

describe("tokenizers", () => {
  // The highlighted layer sits under a transparent textarea, so a tokenizer
  // that drops or duplicates a single character would misalign the editor.
  for (const [language, code] of Object.entries(SAMPLES) as [SandboxLanguage, string][]) {
    it(`reproduces ${language} input exactly, even when it is unfinished`, () => {
      expect(tokenize(code, language).map((token) => token.text).join("")).toBe(code);
      expect(tokenizeLines(code, language)).toHaveLength(code.split("\n").length);
    });
  }

  it("colours every language except plain text", () => {
    for (const [language, code] of Object.entries(SAMPLES) as [SandboxLanguage, string][]) {
      const coloured = tokenize(code, language).some((token) => token.kind !== "plain");
      expect(coloured).toBe(language !== "text");
    }
  });

  it("keeps line structure for empty input and trailing newlines", () => {
    expect(tokenizeLines("", "javascript")).toEqual([[]]);
    expect(tokenizeLines("a\n", "javascript")).toHaveLength(2);
    expect(tokenizeLines("\n\n", "css")).toHaveLength(3);
  });

  it("tells regex literals from division", () => {
    expect(kinds("x = /a\\/b/g;", "javascript")).toContain("regex:/a\\/b/g");
    expect(kinds("a / b / c", "javascript").some((k) => k.startsWith("regex"))).toBe(false);
  });

  it("treats a nested template literal as one string", () => {
    expect(kinds("`a ${b ? `x` : `y`} z`", "javascript")).toEqual(["string:`a ${b ? `x` : `y`} z`"]);
  });

  it("does not highlight keywords used as property names", () => {
    expect(kinds("obj.while", "javascript")).not.toContain("keyword:while");
    expect(kinds("while (x) {}", "javascript")).toContain("keyword:while");
  });

  it("highlights embedded script and style inside HTML", () => {
    expect(kinds("<script>const a = 1</script>", "html")).toContain("keyword:const");
    expect(kinds("<style>a { color: red }</style>", "html")).toContain("property:color");
  });

  it("separates CSS selectors, properties and values", () => {
    expect(kinds("a { color: red }", "css")).toEqual([
      "tag:a",
      "punct:{",
      "property:color",
      "punct::",
      "plain:red",
      "punct:}",
    ]);
  });

  it("marks JSON keys differently from string values", () => {
    expect(kinds('{"k": "v"}', "json")).toEqual(["punct:{", 'property:"k"', "punct::", 'string:"v"', "punct:}"]);
  });
});

describe("loop guard", () => {
  const guard = (code: string) => guardLoops(code, "a.js");

  /** Runs guarded code with a guard that trips after `limit` iterations. */
  const run = (code: string, limit = 50): unknown => {
    let calls = 0;
    const trip = () => {
      calls += 1;
      if (calls > limit) throw new Error("STOPPED");
      return undefined;
    };
    return new Function(
      "__novaLoop",
      `${guard(code)}; return typeof result === "undefined" ? undefined : result;`,
    )(trip);
  };

  it("instruments while and for conditions on the same line", () => {
    expect(guard("while (true) {}")).toBe('while (__novaLoop("a.js",1)||(true)) {}');
    expect(guard("for (;;) {}")).toBe('for (;!__novaLoop("a.js",1);) {}');
    expect(guard("for (let i = 0; i < 3; i++) {}")).toBe(
      'for (let i = 0;__novaLoop("a.js",1)||( i < 3); i++) {}',
    );
  });

  it("reports the loop's own line and never changes the line count", () => {
    expect(guard("a();\n\nwhile (x) y();")).toContain('"a.js",3');
    const source = "while (a) {\n  for (;;) {}\n}\n";
    expect(guard(source).split("\n")).toHaveLength(source.split("\n").length);
  });

  it.each([
    "for (const x of xs) {}",
    "for (const k in o) {}",
    'const s = "while (true) {}";',
    "// while (true) {}",
    "/* for (;;) {} */",
    "obj.while(1); Symbol.for('x');",
    "while (\n  x\n) {}",
    "for await (const x of y) {}",
    "const o = { while: 1, for: 2 };",
    "const t = `while (true) {}`;",
  ])("leaves %j untouched", (source) => {
    expect(guard(source)).toBe(source);
  });

  it.each([
    ["let result = 0; for (let i = 0; i < 5; i++) { result += i; }", 10],
    ["let result = 0; while (result < 7) result++;", 7],
    ["let result = 0; do { result += 2; } while (result < 9);", 10],
    ["let result = 0; const s = 'a)b'; while (/\\)/.test(s) && result < 3) { for (let j = 0; j < 2; j++) result++; }", 4],
    ["let result = 0; const q = [1, 2, 3]; let v; while ((v = q.shift())) result += v;", 6],
    ["let result = 0; for (;;) { if (++result === 4) break; }", 4],
    ["const n = 5; let result = `$${n}`; for (let i = 0; i < 1; i++) result += `|${'while (true)'}`;", "$5|while (true)"],
    ["let result = 0; for (let i = 0, f = () => { return 2; }; i < f(); i++) result++;", 2],
  ])("guarded code still computes the same result: %s", (source, expected) => {
    expect(run(source)).toBe(expected);
  });

  it.each([
    "while (true) {}",
    "for (;;) {}",
    "let i = 0; do { i++; } while (i > 0);",
    "for (let i = 0; i >= 0; i++) {}",
    "while (1) continue;",
  ])("stops the runaway loop %j", (source) => {
    expect(() => run(source, 1000)).toThrow("STOPPED");
  });
});
