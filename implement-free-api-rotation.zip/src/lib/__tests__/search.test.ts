import { describe, expect, it } from "vitest";
import { searchSnippet } from "../search-snippet";

describe("search snippets", () => {
  it("keeps a short message intact", () => {
    expect(searchSnippet("A useful answer", "useful")).toBe("A useful answer");
  });
  it("shows a match beyond the opening of a long response", () => {
    const text = "Introduction. ".repeat(40) + "The important marker is here. " + "Details. ".repeat(40);
    const snippet = searchSnippet(text, "important marker");
    expect(snippet).toContain("important marker");
    expect(snippet.startsWith("…")).toBe(true);
    expect(snippet.length).toBeLessThanOrEqual(222);
  });
  it("finds matches case-insensitively", () => {
    expect(searchSnippet("Earlier context. ".repeat(30) + "MATCH ME at the end", "match me")).toContain("MATCH ME");
  });
  it("normalizes line breaks for a readable one-line preview", () => {
    expect(searchSnippet("Notes:\n\nFirst\tpoint", "First")).toBe("Notes: First point");
  });
  it("falls back to the beginning for a title-only match", () => {
    expect(searchSnippet("Long body. ".repeat(40), "title-only").startsWith("Long body.")).toBe(true);
  });
  it("handles empty text and an empty query", () => {
    expect(searchSnippet("", "anything")).toBe("");
    expect(searchSnippet("plain text", "")).toBe("plain text");
  });
});
