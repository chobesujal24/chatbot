import { describe, expect, it } from "vitest";
import {
  buildPreviewDocument,
  detectSandboxLanguage,
  sanitizeFileName,
  validateFileName,
  withSandboxToken,
  type WorkspaceFile,
} from "../code-sandbox";

const file = (name: string, content: string): WorkspaceFile => ({
  id: name,
  name,
  language: detectSandboxLanguage(name),
  content,
});

describe("sandbox preview document", () => {
  it("inlines the stylesheet and strips the external script tag", () => {
    const doc = buildPreviewDocument([
      file(
        "index.html",
        `<!doctype html><html><head><link rel="stylesheet" href="styles.css" /></head><body><h1>Hi</h1><script src="app.js"></script></body></html>`,
      ),
      file("styles.css", "body { color: red; }"),
      file("app.js", "console.log('hello');"),
    ]);

    expect(doc).not.toContain('<link rel="stylesheet"');
    expect(doc).not.toContain('src="app.js"');
    expect(doc).toContain("body { color: red; }");
    expect(doc).toContain("console.log('hello');");
  });

  it("injects the console bridge and the program before </body>", () => {
    const doc = buildPreviewDocument([
      file("index.html", `<html><body><p>x</p></body></html>`),
      file("app.js", "console.log('x');"),
    ]);

    expect(doc).toContain("nova-sandbox");
    expect(doc).toContain("__NOVA_SANDBOX_TOKEN__");
    expect(doc.indexOf("nova-sandbox")).toBeLessThan(doc.indexOf("</body>"));
  });

  it("works without an html file by wrapping the script in a shell", () => {
    const doc = buildPreviewDocument([file("app.js", "console.log('lonely');")]);
    expect(doc).toContain("console.log('lonely');");
    expect(doc).toContain("nova-sandbox");
  });

  it("never leaves an unresolved token after replacement", () => {
    const doc = buildPreviewDocument([file("index.html", "<html><body></body></html>")]);
    const token = "abc123token";
    const resolved = doc.replaceAll("__NOVA_SANDBOX_TOKEN__", token);
    expect(resolved).not.toContain("__NOVA_SANDBOX_TOKEN__");
    expect(resolved).toContain(token);
  });
});

/*
 * These assert the *structure* of the generated document. They cannot prove a
 * browser executes it — that is covered by browser tests — but each one pins a
 * failure that string-presence checks alone previously let through.
 */
describe("sandbox document assembly", () => {
  const page = [
    "<!doctype html>",
    "<html>",
    "<head>",
    '<link rel="stylesheet" href="styles.css" />',
    "</head>",
    "<body>",
    '<button onclick="go()">x</button>',
    '<script src="app.js"></script>',
    "</body>",
    "</html>",
  ].join("\n");

  it("closes every script element it opens", () => {
    // Regression: the closer was once emitted as `<\/script>`, which HTML does
    // not treat as an end tag, so the bridge swallowed the rest of the page.
    const doc = buildPreviewDocument([file("index.html", page), file("app.js", "console.log(1);")]);
    const opens = doc.match(/<script\b/g)?.length ?? 0;
    const closes = doc.match(/<\/script>/g)?.length ?? 0;
    expect(opens).toBe(2);
    expect(closes).toBe(opens);
    expect(doc).not.toContain("<\\/script>");
  });

  it("keeps user code byte for byte, including $-sequences", () => {
    // `String.replace` with a replacement *string* rewrites `$$`, `$&` and `$'`.
    const code = "const a = `$${1}`; const b = 'x'.replace(/(x)/, '$1$&'); const c = \"$'\";";
    const doc = buildPreviewDocument([file("index.html", page), file("app.js", code)]);
    expect(doc).toContain(code);
  });

  it("keeps multi-line template literals intact", () => {
    const code = "const t = `line one\n  line two\n`;";
    const doc = buildPreviewDocument([file("index.html", page), file("app.js", code)]);
    expect(doc).toContain(code);
  });

  it("escapes a closing script tag inside user code", () => {
    const doc = buildPreviewDocument([
      file("index.html", page),
      file("app.js", 'document.title = "</script>";'),
    ]);
    expect(doc).toContain('document.title = "<\\/script>";');
    expect(doc.match(/<\/script>/g)?.length).toBe(2);
  });

  it("inlines scripts in place, after the markup that precedes them", () => {
    const doc = buildPreviewDocument([file("index.html", page), file("app.js", "function go() {}")]);
    expect(doc.indexOf("<button")).toBeGreaterThan(-1);
    expect(doc.indexOf("function go() {}")).toBeGreaterThan(doc.indexOf("<button"));
    expect(doc.indexOf("function go() {}")).toBeLessThan(doc.indexOf("</body>"));
  });

  it("puts the bridge ahead of every user script", () => {
    const doc = buildPreviewDocument([file("index.html", page), file("app.js", "run();")]);
    expect(doc.indexOf("data-nova-bridge")).toBeGreaterThan(doc.indexOf("<head>"));
    expect(doc.indexOf("data-nova-bridge")).toBeLessThan(doc.indexOf('data-nova-script="0"'));
  });

  it("records where each script landed so errors map back to file lines", () => {
    const doc = buildPreviewDocument([
      file("index.html", page),
      file("app.js", "one();\ntwo();\nthree();"),
    ]);
    const raw = /var map = (\[.*?\]);/.exec(doc)?.[1];
    expect(raw).toBeTruthy();
    const map = JSON.parse(raw as string) as { f: string; s: number; n: number }[];
    expect(map).toEqual([{ f: "app.js", s: expect.any(Number), n: 3 }]);
    const lines = doc.split("\n");
    expect(lines[map[0].s - 1]).toBe("one();");
    expect(lines[map[0].s + 1]).toBe("three();");
    expect(doc).not.toContain("__NOVA_LINE_MAP__");
  });

  it("loads files nothing references: styles in head, scripts at the end of body", () => {
    const doc = buildPreviewDocument([
      file("index.html", "<html><head></head><body><p>x</p></body></html>"),
      file("extra.css", "p { margin: 0; }"),
      file("extra.js", "boot();"),
    ]);
    expect(doc.indexOf("p { margin: 0; }")).toBeLessThan(doc.indexOf("</head>"));
    expect(doc.indexOf("boot();")).toBeGreaterThan(doc.indexOf("<p>x</p>"));
    expect(doc.indexOf("boot();")).toBeLessThan(doc.indexOf("</body>"));
  });

  it("does not confuse app.js with app.jsx when matching references", () => {
    const doc = buildPreviewDocument([
      file("index.html", '<html><body><script src="app.jsx"></script></body></html>'),
      file("app.js", "ok();"),
    ]);
    expect(doc).toContain('src="app.jsx"');
  });

  it("preserves type=module on inlined scripts", () => {
    const doc = buildPreviewDocument([
      file("index.html", '<html><body><script type="module" src="./app.js"></script></body></html>'),
      file("app.js", "export {};"),
    ]);
    expect(doc).toContain('<script data-nova-script="0" type="module">');
  });

  it("guards loops by default and leaves code alone when switched off", () => {
    const files = [file("index.html", page), file("app.js", "while (true) {}")];
    expect(buildPreviewDocument(files)).toContain('while (__novaLoop("app.js",1)||(true)) {}');
    expect(buildPreviewDocument(files, { loopGuard: false })).toContain("\nwhile (true) {}\n");
  });

  it("renders markup and styles only when run is false", () => {
    const doc = buildPreviewDocument(
      [file("index.html", page), file("styles.css", "b{}"), file("app.js", "danger();")],
      { run: false },
    );
    expect(doc).toContain("b{}");
    expect(doc).not.toContain("danger();");
    expect(doc).not.toContain("<script");
  });

  it("shows a data-only workspace as escaped text", () => {
    const doc = buildPreviewDocument([file("data.json", '{"a":"<b>"}')]);
    expect(doc).toContain("&lt;b&gt;");
    expect(doc).toContain("<!doctype html>");
  });

  it("quotes the nonce as a JavaScript string everywhere", () => {
    const doc = withSandboxToken(buildPreviewDocument([file("app.js", "x();")]), 'to"ken');
    expect(doc).toContain('var token = "to\\"ken";');
    expect(doc).not.toContain("__NOVA_SANDBOX_TOKEN__");
  });
});

describe("workspace file names", () => {
  const files = [file("index.html", "")];

  it("accepts ordinary names and rejects unsafe or duplicate ones", () => {
    expect(validateFileName(files, "app.js")).toBeNull();
    expect(validateFileName(files, "")).toMatch(/Enter/);
    expect(validateFileName(files, "no-extension")).toMatch(/index\.html/);
    expect(validateFileName(files, '"><script>.js')).not.toBeNull();
    expect(validateFileName(files, "INDEX.html")).toMatch(/already exists/);
    expect(validateFileName(files, "index.html", "index.html")).toBeNull();
  });

  it("sanitises uploaded names", () => {
    expect(sanitizeFileName('my "file" (1).js')).toBe("my-file-1-.js");
    expect(sanitizeFileName("   ")).toBe("file.txt");
    expect(sanitizeFileName("ok_name-2.css")).toBe("ok_name-2.css");
  });

  it("detects languages from extensions", () => {
    expect(detectSandboxLanguage("a.TSX")).toBe("typescript");
    expect(detectSandboxLanguage("a.mjs")).toBe("javascript");
    expect(detectSandboxLanguage("README")).toBe("text");
  });
});
