import { describe, expect, it } from "vitest";
import { attachmentBytes, MAX_ATTACHMENTS, MAX_PROMPT_LENGTH, mergeAttachments, TEXT_FILE_PATTERN } from "../composer-state";
import { HOME_PROMPTS, PROMPT_CATEGORIES } from "../home-prompts";

const file = (name: string, content = "text") => ({ name, content });

describe("composer attachments", () => {
  it("replaces a revised file even when the name and length are unchanged", () => {
    const original = [file("app.js", "let a=1;")];
    const result = mergeAttachments(original, [file("app.js", "let a=2;")], 1024);
    expect(result.files).toEqual([file("app.js", "let a=2;")]);
    expect(original).toEqual([file("app.js", "let a=1;")]);
  });

  it("enforces the count limit and reports omitted files", () => {
    const incoming = Array.from({ length: 7 }, (_, index) => file(`${index}.txt`));
    const result = mergeAttachments([], incoming, 1024);
    expect(result.files).toHaveLength(MAX_ATTACHMENTS);
    expect(result.overflow).toBe(2);
  });

  it("can update an attached file when all five slots are occupied", () => {
    const original = Array.from({ length: 5 }, (_, index) => file(`${index}.txt`));
    const result = mergeAttachments(original, [file("2.txt", "updated")], 1024);
    expect(result.files).toHaveLength(5);
    expect(result.files[2].content).toBe("updated");
    expect(result.overflow).toBe(0);
  });

  it("counts bytes, not JavaScript characters, for non-ASCII files", () => {
    expect(attachmentBytes("é🙂")).toBe(6);
    const result = mergeAttachments([], [file("unicode.txt", "é🙂")], 5);
    expect(result.files).toHaveLength(0);
    expect(result.oversized).toEqual(["unicode.txt"]);
  });

  it("leaves a previous attachment intact if its replacement is oversized", () => {
    const result = mergeAttachments([file("data.txt", "ok")], [file("data.txt", "too long")], 2);
    expect(result.files).toEqual([file("data.txt", "ok")]);
    expect(result.oversized).toEqual(["data.txt"]);
  });

  it.each(["main.mjs", "config.yaml", "NOTES.MD", "sample.tsv", "view.tsx", "page.htm"])("accepts %s", (name) => {
    expect(TEXT_FILE_PATTERN.test(name)).toBe(true);
  });

  it.each(["photo.png", "archive.zip", "font.woff2"])("rejects unsupported %s", (name) => {
    expect(TEXT_FILE_PATTERN.test(name)).toBe(false);
  });
});

describe("home starting points", () => {
  it("provides a complete, editable prompt for every category", () => {
    for (const category of PROMPT_CATEGORIES) {
      expect(HOME_PROMPTS[category.id]).toHaveLength(4);
      for (const starter of HOME_PROMPTS[category.id]) {
        expect(starter.title.trim().length).toBeGreaterThan(5);
        expect(starter.prompt.length).toBeGreaterThan(40);
        expect(starter.prompt.length).toBeLessThan(MAX_PROMPT_LENGTH);
      }
    }
  });

  it("uses unique identifiers for stable keyboard and selection state", () => {
    const identifiers = Object.values(HOME_PROMPTS).flat().map((prompt) => prompt.id);
    expect(new Set(identifiers).size).toBe(identifiers.length);
    expect(new Set(PROMPT_CATEGORIES.map((category) => category.id)).size).toBe(PROMPT_CATEGORIES.length);
  });
});
