import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { createElement } from "react";
import { Logo } from "@/components/logo";
import { LanguageLogo, ProviderLogo, StackLogo } from "@/components/provider-logo";
import { PROVIDERS } from "@/lib/providers";
import { SANDBOX_LANG_LABEL, type SandboxLanguage } from "@/lib/code-sandbox";

describe("brand, provider, language, and stack logos", () => {
  it("renders the Nova emblem, wordmark, and brand lockup cleanly", async () => {
    const { NovaWordmark, BrandLockup } = await import("@/components/logo");
    const badge = renderToStaticMarkup(createElement(Logo, { size: 28, glow: true }));
    const glyph = renderToStaticMarkup(createElement(Logo, { size: 16, variant: "glyph" }));
    const wordmark = renderToStaticMarkup(createElement(NovaWordmark, { size: "md" }));
    const lockup = renderToStaticMarkup(createElement(BrandLockup, { size: "md" }));
    expect(badge).toContain("<svg");
    expect(badge).toContain("circle");
    expect(glyph).toContain("<svg");
    expect(wordmark).toContain("Nova");
    expect(wordmark).toContain("font-serif");
    expect(lockup).toContain("<svg");
    expect(lockup).toContain("Nova");
  });

  it("renders a dedicated vector logo for every configured provider and integration", () => {
    expect(PROVIDERS.length).toBeGreaterThanOrEqual(24);
    for (const preset of PROVIDERS) {
      const badge = renderToStaticMarkup(createElement(ProviderLogo, { provider: preset.id, size: 28 }));
      const glyph = renderToStaticMarkup(
        createElement(ProviderLogo, { provider: preset.id, size: 14, variant: "glyph" }),
      );
      expect(badge, `badge for ${preset.id}`).toContain("<svg");
      expect(badge, `background for ${preset.id}`).toContain("background-color:");
      expect(glyph, `glyph for ${preset.id}`).toContain("<svg");
    }
  });

  it("renders a distinct language mark for every sandbox language", () => {
    const languages = Object.keys(SANDBOX_LANG_LABEL) as SandboxLanguage[];
    expect(languages).toHaveLength(8);
    const markups = new Set<string>();
    for (const language of languages) {
      const html = renderToStaticMarkup(createElement(LanguageLogo, { language, size: 13 }));
      expect(html).toContain("<svg");
      markups.add(html);
    }
    expect(markups.size).toBe(languages.length);
  });

  it("renders open-source stack marks cleanly", () => {
    for (const repo of [
      "vercel/next.js",
      "vercel/ai",
      "shadcn-ui/ui",
      "radix-ui/primitives",
      "tailwindlabs/tailwindcss",
      "drizzle-team/drizzle-orm",
      "postgres/postgres",
      "pacocoursey/cmdk",
    ]) {
      const html = renderToStaticMarkup(createElement(StackLogo, { repo }));
      expect(html).toContain("<svg");
    }
  });
});
