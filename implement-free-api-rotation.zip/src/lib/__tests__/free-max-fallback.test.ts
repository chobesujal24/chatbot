import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { freeMaxConfig, freeMaxCooldowns, freeMaxRuns } from "@/db/schema";
import { DEFAULT_ROUTING } from "../free-max/catalog";
const state=vi.hoisted(()=>({runs:[] as Record<string,unknown>[], pauses:[] as {key:string;until:Date}[],cursor:0,rotation:true}));
vi.mock("server-only",()=>({}));
vi.mock("@/lib/credentials",()=>({listCredentials:async()=>[]}));
vi.mock("@/lib/rate-limit",()=>({checkRateLimit:async()=>({allowed:true})}));
vi.mock("@/db",()=>({db:{
  insert:(table:unknown)=>({values:(value:Record<string,unknown>)=>{
    if(table===freeMaxConfig)return {onConflictDoUpdate:()=>({returning:async()=>[{cursor:++state.cursor,settings:{...DEFAULT_ROUTING,rotation:state.rotation}}]})};
    if(table===freeMaxCooldowns)return {onConflictDoUpdate:async()=>{state.pauses.push(value as {key:string;until:Date});}};
    if(table===freeMaxRuns){state.runs.push(value);return Promise.resolve();}
    throw new Error("Unexpected database write");
  }}),select:()=>({from:()=>({where:async()=>[]})}),
}}));
import { runFreeMax } from "../free-max/router";
const messages=[{role:"user" as const,content:"Hello"}];
const good=()=>Response.json({model:"gpt-oss-20b",choices:[{message:{content:"A real response shape."},finish_reason:"stop"}],usage:{total_tokens:20,prompt_tokens:12,completion_tokens:8}});
beforeEach(()=>{state.runs.length=0;state.pauses.length=0;state.cursor=0;state.rotation=true;vi.stubEnv("FREE_MAX_ENABLED_PROVIDERS","");});
afterEach(()=>{vi.unstubAllGlobals();vi.unstubAllEnvs();});
describe("one logical hit with controlled upstream responses",()=>{
  it("tries the next provider after 429, honors Retry-After, and records one logical completion",async()=>{
    const before=Date.now();const upstream=vi.fn().mockResolvedValueOnce(new Response("limited",{status:429,headers:{"Retry-After":"120"}})).mockResolvedValueOnce(good());vi.stubGlobal("fetch",upstream);
    const result=await runFreeMax("workspace",messages);expect(result.provider).toBe("ovh");expect(result.model).toBe("gpt-oss-20b");expect(result.attempts.map(a=>a.status)).toEqual([429,200]);expect(upstream).toHaveBeenCalledTimes(2);expect(state.runs).toHaveLength(1);expect(state.pauses[0].until.getTime()).toBeGreaterThanOrEqual(before+120000);expect(JSON.stringify(state.runs)).not.toContain("Hello");
    for(const [,init] of upstream.mock.calls)expect(init.headers.Authorization).toBeUndefined();
  });
  it("stops on the first success and rotates the first choice on the next hit",async()=>{
    const upstream=vi.fn().mockImplementation(async()=>good());vi.stubGlobal("fetch",upstream);
    expect((await runFreeMax("workspace",messages)).provider).toBe("kilo");expect((await runFreeMax("workspace",messages)).provider).toBe("ovh");expect(upstream).toHaveBeenCalledTimes(2);expect(state.runs).toHaveLength(2);
  });
  it("does not switch a pinned provider on failure",async()=>{
    const upstream=vi.fn().mockResolvedValue(new Response("busy",{status:503}));vi.stubGlobal("fetch",upstream);
    await expect(runFreeMax("workspace",messages,"kilo::kilo-auto/free")).rejects.toMatchObject({status:503});expect(upstream).toHaveBeenCalledTimes(1);
  });
  it("does not route around authorization or moderation refusals",async()=>{
    const upstream=vi.fn().mockResolvedValueOnce(new Response("forbidden",{status:403})).mockResolvedValueOnce(Response.json({choices:[{finish_reason:"content_filter",message:{content:""}}]}));vi.stubGlobal("fetch",upstream);
    await expect(runFreeMax("workspace",messages)).rejects.toMatchObject({status:422});await expect(runFreeMax("workspace",messages)).rejects.toMatchObject({status:422});expect(upstream).toHaveBeenCalledTimes(2);
  });
  it("never performs fallback with automatic rotation turned off",async()=>{
    state.rotation=false;const upstream=vi.fn().mockResolvedValue(new Response("limited",{status:429}));vi.stubGlobal("fetch",upstream);
    await expect(runFreeMax("workspace",messages)).rejects.toMatchObject({status:429});expect(upstream).toHaveBeenCalledTimes(1);
  });
});
