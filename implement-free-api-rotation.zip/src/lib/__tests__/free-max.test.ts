import { describe, expect, it } from "vitest";
import { CATALOG, DEFAULT_ROUTING, KEYLESS_COUNT, MODEL_COUNT } from "../free-max/catalog";
import { parsePin, planRoutes, retryDelay } from "../free-max/policy";

describe("Free Max catalog and routing contract", () => {
  it("has 24 distinct services and selectable, source-linked model routes", () => {
    expect(new Set(CATALOG.map(p=>p.id)).size).toBe(24);
    expect(KEYLESS_COUNT).toBe(2);expect(MODEL_COUNT).toBeGreaterThan(50);
    for(const p of CATALOG){expect(p.baseURL.startsWith("https://")).toBe(true);expect(p.docs.startsWith("https://")).toBe(true);expect(p.models.length).toBeGreaterThan(0);for(const m of p.models){expect(parsePin(`${p.id}::${m.id}`)).toEqual({provider:p.id,model:m.id});}}
  });
  it("never rotates into a finite trial",()=>{for(const strategy of ["keyless-first","round-robin","high-allowance"] as const){expect(planRoutes(CATALOG,{...DEFAULT_ROUTING,strategy},2).some(p=>p.access==="trial")).toBe(false);}});
  it("prefers anonymous providers and rotates the first choice",()=>{const first=planRoutes(CATALOG,DEFAULT_ROUTING,0),second=planRoutes(CATALOG,DEFAULT_ROUTING,1);expect(first[0].id).toBe("kilo");expect(second[0].id).toBe("ovh");expect(first.slice(0,2).every(p=>p.access==="keyless")).toBe(true);});
  it("round robin visits every eligible provider once",()=>{const pool=CATALOG.filter(p=>p.access!=="trial");expect(new Set(pool.map((_,i)=>planRoutes(pool,{...DEFAULT_ROUTING,strategy:"round-robin"},i)[0].id)).size).toBe(pool.length);});
  it("never changes a manual model pin",()=>{const only=planRoutes(CATALOG,DEFAULT_ROUTING,100,"cerebras");expect(only.map(p=>p.id)).toEqual(["cerebras"]);expect(parsePin("auto")).toBeNull();expect(parsePin("free-max")).toBeNull();expect(()=>parsePin("openrouter::a-paid-model")).toThrow();expect(()=>parsePin("https://not-a-catalog-endpoint.test")).toThrow();});
  it("honors disabled routes and stable order when rotation is off",()=>{expect(planRoutes(CATALOG,{...DEFAULT_ROUTING,disabled:["kilo"]},0)[0].id).toBe("ovh");expect(planRoutes(CATALOG,{...DEFAULT_ROUTING,rotation:false},7)[0].id).toBe("kilo");expect(planRoutes([],{...DEFAULT_ROUTING},0)).toEqual([]);});
  it("respects both forms of Retry-After, including long limits",()=>{const now=Date.UTC(2026,10,18);expect(retryDelay("120",now)).toBe(120000);expect(retryDelay(new Date(now+3600000).toUTCString(),now)).toBe(3600000);expect(retryDelay("172800",now)).toBe(172800000);expect(retryDelay("invalid",now)).toBe(60000);expect(retryDelay(null,now)).toBe(60000);});
});
