import { CATALOG, type FreeProvider, type RoutingSettings } from "./catalog";

export function planRoutes(providers: FreeProvider[], settings: RoutingSettings, cursor: number, pinned?: string) {
  const eligible = providers.filter(p => !settings.disabled.includes(p.id) && (pinned ? p.id === pinned : p.access !== "trial"));
  if (pinned || !eligible.length) return eligible;
  const rotate = (items: FreeProvider[]) => {
    if (!items.length) return [];
    const index = settings.rotation ? Math.max(0, cursor) % items.length : 0;
    return [...items.slice(index), ...items.slice(0, index)];
  };
  if (settings.strategy === "high-allowance") return [...eligible].sort((a,b) => a.rank - b.rank);
  if (settings.strategy === "keyless-first") return [...rotate(eligible.filter(p => p.access === "keyless")), ...rotate(eligible.filter(p => p.access !== "keyless"))];
  return rotate(eligible);
}
export function retryDelay(header: string | null, now = Date.now()) {
  if (!header) return 60_000;
  const seconds = Number(header);
  const delay = Number.isFinite(seconds) ? seconds * 1000 : Date.parse(header) - now;
  return Number.isFinite(delay) ? Math.max(1000, delay) : 60_000;
}
export function parsePin(value: string) {
  if (!value || value === "auto" || value === "free-max") return null;
  const [provider, model] = value.split("::");
  const match = CATALOG.find(p => p.id === provider);
  if (!match || !match.models.some(m => m.id === model)) throw new Error("Select a model from the Free Max catalog.");
  return { provider, model };
}
