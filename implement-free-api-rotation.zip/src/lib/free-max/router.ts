import "server-only";
import { createHash } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { freeMaxConfig, freeMaxCooldowns, freeMaxRuns } from "@/db/schema";
import { listCredentials, type StoredCredential } from "@/lib/credentials";
import { checkRateLimit } from "@/lib/rate-limit";
import { ApiError } from "@/lib/http";
import { CATALOG, DEFAULT_ROUTING, type FreeProvider } from "./catalog";
import { parsePin, planRoutes, retryDelay } from "./policy";

export interface ChatTurn { role: "system" | "user" | "assistant"; content: string }
type Attempt = { provider: string; status: number; note: string };
export function connectionFor(p: FreeProvider, credentials: StoredCredential[]) {
  // Never silently use a production key. Workspace users or the deployment owner
  // must explicitly attest that this is a free-plan account without paid overages.
  const stored = credentials.find(c => c.provider === p.id && c.enabled && c.options.freeMax === true);
  const enabled = (process.env.FREE_MAX_ENABLED_PROVIDERS ?? "").split(",").map(s => s.trim()).includes(p.id);
  const key = p.access === "keyless" ? "" : stored?.secret || (enabled && p.env ? process.env[p.env]?.trim() : "") || "";
  const account = String(stored?.options.accountId || process.env.CLOUDFLARE_ACCOUNT_ID || "");
  const ready = (p.access === "keyless" || Boolean(key)) && (p.id !== "cloudflare" || /^[a-f0-9]{32}$/i.test(account));
  return { key, account, ready, id: stored?.id ?? null, fromEnv: !stored && Boolean(key) };
}
export async function readRouting(ws: string) {
  const [row] = await db.select().from(freeMaxConfig).where(eq(freeMaxConfig.workspaceId, ws));
  return { ...DEFAULT_ROUTING, ...row?.settings };
}
export async function runFreeMax(ws: string, turns: ChatTurn[], pin = "auto", maxTokens = 2048, signal?: AbortSignal) {
  let selected: ReturnType<typeof parsePin>;
  try { selected = parsePin(pin); } catch { throw new ApiError(400, "unknown_model", "Choose a model from the model library."); }
  const [credentials, [config]] = await Promise.all([
    listCredentials(ws), db.insert(freeMaxConfig).values({ workspaceId: ws, cursor: 1 }).onConflictDoUpdate({ target: freeMaxConfig.workspaceId, set: { cursor: sql`${freeMaxConfig.cursor} + 1` } }).returning(),
  ]);
  const settings = { ...DEFAULT_ROUTING, ...config.settings };
  const candidates = planRoutes(CATALOG.filter(p => connectionFor(p, credentials).ready), settings, config.cursor - 1, selected?.provider);
  if (!candidates.length) throw new ApiError(409, "setup_required", selected ? "This provider is disabled or needs a free API key. Open its provider details to connect it." : "No eligible routes. Enable a no-sign-up provider or connect a free API key in the directory.");
  const started = Date.now();
  const deadline = AbortSignal.timeout(65000);
  const attempts: Attempt[] = [];
  let count = 0;
  const budget = selected || !settings.rotation ? 1 : Math.min(5, Math.max(1, settings.maxAttempts));
  let failure = "The eligible providers are temporarily unavailable. Try again or connect another free provider.";
  let status = 503;
  for (const p of candidates) {
    if (count >= budget || deadline.aborted || signal?.aborted) break;
    const conn = connectionFor(p, credentials);
    const scope = createHash("sha256").update(`${p.id}:${conn.key || "shared-anonymous"}`).digest("hex");
    const [cool] = await db.select().from(freeMaxCooldowns).where(eq(freeMaxCooldowns.key, scope));
    if (cool && cool.until.getTime() > Date.now()) {
      attempts.push({provider:p.id, status:429, note:"Cooldown; no request sent"}); status = 429;
      failure = `${p.name} is cooling down. Try again after ${cool.until.toISOString().slice(11,19)} UTC, or connect another free provider.`; continue;
    }
    const model = selected?.model || p.models[0].id;
    if (p.access === "keyless") {
      const rate = await checkRateLimit(`free-max:${p.id}:${p.id === "ovh" ? model : "pool"}`, p.id === "ovh" ? 2 : 200, p.id === "ovh" ? 60000 : 3600000);
      if (!rate.allowed) { attempts.push({provider:p.id,status:429,note:"Shared anonymous allowance reached"}); status=429; failure="The shared anonymous allowance is in use. Wait for its reset or connect a free key."; continue; }
    }
    count++;
    const baseURL = p.baseURL.replace("{account}", conn.account);
    try {
      const response = await fetch(`${baseURL}/chat/completions`, {
        method:"POST", cache:"no-store", redirect:"error",
        headers:{"Content-Type":"application/json", ...(conn.key ? { Authorization:`Bearer ${conn.key}` } : {})},
        body:JSON.stringify({model, messages:turns, max_tokens: Math.min(4096,Math.max(128,maxTokens)), stream:false}),
        signal:AbortSignal.any([AbortSignal.timeout(28000), deadline, ...(signal ? [signal] : [])]),
      });
      if (!response.ok) {
        const code = response.status;
        const retryable = code === 429 || code === 402 || code === 408 || code >= 500;
        const note = code === 429 ? "Provider rate limit" : code === 401 || code === 403 ? "Access not authorized" : code === 402 ? "Free allowance exhausted" : `Provider HTTP ${code}`;
        attempts.push({ provider:p.id,status:code,note });
        await response.body?.cancel();
        if (retryable) {
          const until = new Date(Date.now() + (code === 429 ? retryDelay(response.headers.get("retry-after")) : code === 402 ? 86400000 : 15000));
          await db.insert(freeMaxCooldowns).values({key:scope,until}).onConflictDoUpdate({target:freeMaxCooldowns.key,set:{until:sql`greatest(${freeMaxCooldowns.until}, ${until.toISOString()}::timestamptz)`}});
          status = code === 429 ? 429 : 503; failure = `${p.name}: ${note.toLowerCase()}. Retry later or add another eligible free route.`; continue;
        }
        // Never route around safety refusals or authentication/policy errors.
        failure = `${p.name}: ${note}. Check this provider’s model availability, account tier, and key in the directory.`; status = 422; break;
      }
      const json = await response.json();
      const choice = json.choices?.[0];
      if (choice?.finish_reason === "content_filter" || choice?.message?.refusal) {
        failure = `${p.name} declined this request. No fallback was attempted.`; status = 422; attempts.push({provider:p.id,status:422,note:"Provider declined request"}); break;
      }
      const text = choice?.message?.content;
      if (typeof text !== "string" || !text.trim()) { attempts.push({provider:p.id,status:502,note:"Empty completion"}); failure=`${p.name} returned no text. Choose another model or shorten your request.`; continue; }
      const actual = typeof json.model === "string" ? json.model.slice(0,180) : model;
      const number = (x:unknown) => Math.min(2147483647, Math.max(0, Math.floor(Number(x) || 0)));
      const usage = {inputTokens:number(json.usage?.prompt_tokens),outputTokens:number(json.usage?.completion_tokens),totalTokens:number(json.usage?.total_tokens)};
      attempts.push({provider:p.id,status:200,note:"Completed"});
      const durationMs = Date.now()-started;
      await db.insert(freeMaxRuns).values({workspaceId:ws,provider:p.id,model:actual,outcome:"success",durationMs,tokens:usage.totalTokens,attempts}).catch(() => { console.warn("Free Max: completion delivered, but request metadata could not be saved."); });
      return {text, provider:p.id, model:actual, usage, durationMs, attempts};
    } catch {
      if (signal?.aborted) {failure="Generation was stopped.";status=499;break;}
      attempts.push({provider:p.id,status:503,note:"Connection timed out or unavailable"});
      failure=`${p.name} could not be reached. Try again or select another provider.`;
    }
  }
  await db.insert(freeMaxRuns).values({workspaceId:ws,provider:attempts.at(-1)?.provider ?? "free-max",model:pin,outcome:"failed",durationMs:Date.now()-started,attempts});
  throw new ApiError(status, "route_unavailable", failure);
}
