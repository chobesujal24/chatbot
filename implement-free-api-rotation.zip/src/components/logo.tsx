import { cn } from "@/lib/utils";

/**
 * Nova geometric emblem — a precision 4-point nova star with an orbital spark
 * and subtle inner core, rendered inside a subtly lit brand squircle.
 */
export function Logo({
  size = 28,
  className,
  glow = false,
  variant = "badge",
}: {
  size?: number;
  className?: string;
  /** Subtle ambient ring for loading or focal states. */
  glow?: boolean;
  variant?: "badge" | "glyph";
}) {
  if (variant === "glyph") {
    return (
      <svg
        aria-hidden="true"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        className={cn("shrink-0 select-none text-brand", className)}
      >
        <path
          d="M12 2.2C12.78 7.42 16.58 11.22 21.8 12C16.58 12.78 12.78 16.58 12 21.8C11.22 16.58 7.42 12.78 2.2 12C7.42 11.22 11.22 7.42 12 2.2Z"
          fill="currentColor"
        />
        <circle cx="12" cy="12" r="1.45" fill="var(--background)" />
        <circle cx="18.6" cy="5.4" r="1.55" fill="currentColor" fillOpacity="0.9" />
      </svg>
    );
  }

  const iconSize = Math.max(11, Math.round(size * 0.62));
  return (
    <span
      aria-hidden="true"
      className={cn(
        "nova-emblem relative inline-flex shrink-0 select-none items-center justify-center rounded-[28%] text-white",
        "bg-[linear-gradient(155deg,color-mix(in_oklab,var(--brand)_86%,white)_0%,var(--brand)_58%,color-mix(in_oklab,var(--brand)_82%,black)_100%)]",
        "ring-1 ring-inset ring-white/22 dark:ring-white/16 shadow-[0_1px_2px_rgb(30_25_20/0.14)]",
        glow && "ring-4 ring-brand/15",
        className,
      )}
      style={{ width: size, height: size }}
    >
      <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="none" className="relative z-10">
        <path
          d="M12 2.2C12.78 7.42 16.58 11.22 21.8 12C16.58 12.78 12.78 16.58 12 21.8C11.22 16.58 7.42 12.78 2.2 12C7.42 11.22 11.22 7.42 12 2.2Z"
          fill="currentColor"
        />
        <circle cx="12" cy="12" r="1.4" fill="var(--brand)" />
        <circle cx="18.6" cy="5.4" r="1.55" fill="currentColor" fillOpacity="0.92" />
      </svg>
    </span>
  );
}

/**
 * Editorial wordmark for Nova. Uses Instrument Serif for a crisp, high-craft
 * brand voice that contrasts cleanly against Geist UI copy.
 */
export function NovaWordmark({
  size = "md",
  className,
}: {
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const sizes = {
    sm: "text-[20px] tracking-[-0.015em]",
    md: "text-[24px] tracking-[-0.018em]",
    lg: "text-[38px] tracking-[-0.02em]",
  } as const;

  return (
    <span
      className={cn(
        "inline-flex items-baseline font-serif font-normal leading-none text-foreground select-none",
        sizes[size],
        className,
      )}
    >
      Nova
    </span>
  );
}

/** Unified Nova emblem + wordmark lockup for navigation, headers, and gates. */
export function BrandLockup({
  size = "md",
  className,
}: {
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const iconSizes = { sm: 24, md: 27, lg: 38 } as const;
  const gaps = { sm: "gap-2", md: "gap-2.5", lg: "gap-3" } as const;

  return (
    <span className={cn("inline-flex items-center", gaps[size], className)}>
      <Logo size={iconSizes[size]} />
      <NovaWordmark size={size} />
    </span>
  );
}
