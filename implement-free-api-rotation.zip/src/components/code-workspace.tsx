"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import {
  Braces,
  Check,
  ChevronDown,
  Code2,
  Copy,
  Download,
  Ellipsis,
  Eye,
  FilePlus2,
  Loader2,
  Maximize2,
  Minimize2,
  Monitor,
  PanelRightClose,
  Pencil,
  Play,
  RefreshCw,
  RotateCcw,
  Rows2,
  Send,
  ShieldCheck,
  Smartphone,
  Terminal,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Markdown } from "@/components/markdown";
import { LanguageLogo } from "@/components/provider-logo";
import {
  buildPreviewDocument,
  detectSandboxLanguage,
  exportWorkspaceMarkdown,
  formatJson,
  NOT_RUNNABLE_NOTE,
  SANDBOX_LANG_LABEL,
  sanitizeFileName,
  validateFileName,
  withSandboxToken,
  type SandboxLanguage,
  type WorkspaceFile,
} from "@/lib/code-sandbox";
import { tokenizeLines } from "@/lib/code-highlight";
import { useMediaQuery, useMounted } from "@/lib/use-media-query";
import { cn } from "@/lib/utils";

export type { WorkspaceFile } from "@/lib/code-sandbox";

type ViewMode = "code" | "split" | "preview";
type Device = "desktop" | "mobile";

interface ConsoleLine {
  id: number;
  token: string;
  level: string;
  text: string;
  file: string | null;
  line: number | null;
  count: number;
}

interface WorkspacePrefs {
  autoRun: boolean;
  loopGuard: boolean;
  wrap: boolean;
  view: ViewMode;
  device: Device;
  consoleOpen: boolean;
  width: number;
  editorRatio: number;
}

interface RunSession {
  id: number;
  token: string;
  doc: string;
  /** The exact inputs this run was built from, so auto-run can skip no-ops. */
  files: WorkspaceFile[];
  loopGuard: boolean;
  startedAt: number;
}

const DEFAULT_PREFS: WorkspacePrefs = {
  autoRun: true,
  loopGuard: true,
  wrap: false,
  view: "split",
  device: "desktop",
  consoleOpen: true,
  width: 640,
  editorRatio: 0.55,
};

const STORAGE_PREFIX = "nova-code-workspace:v2:";
const SETTINGS_PREFIX = "nova-code-settings:v2:";
const LINE_HEIGHT = 20;
const MIN_WIDTH = 380;
const PANEL_EASE = [0.22, 1, 0.36, 1] as const;
const IMPORT_ACCEPT =
  ".txt,.md,.json,.csv,.log,.js,.mjs,.cjs,.jsx,.ts,.tsx,.py,.css,.html,.htm,.yml,.yaml,.sql,.toml";

const VIEWS: { id: ViewMode; label: string; icon: typeof Code2 }[] = [
  { id: "code", label: "Code", icon: Code2 },
  { id: "split", label: "Split", icon: Rows2 },
  { id: "preview", label: "Preview", icon: Eye },
];

const PAIRS: Record<string, string> = { "(": ")", "[": "]", "{": "}", '"': '"', "'": "'", "`": "`" };
const CLOSERS = [")", "]", "}", '"', "'", "`"];
const LINE_COMMENT: Partial<Record<SandboxLanguage, string>> = {
  javascript: "//",
  typescript: "//",
  python: "#",
};

const STARTER_FILES: WorkspaceFile[] = [
  {
    id: "starter-index",
    name: "index.html",
    language: "html",
    content: `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Nova Sandbox</title>
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
    <main class="card">
      <p class="eyebrow">Live sandbox</p>
      <h1>Hello from Nova</h1>
      <p>Edit the files above, then ask Nova to improve them.</p>
      <button id="cta" type="button">Count clicks</button>
      <output id="log">Ready when you are.</output>
    </main>
    <script src="app.js"></script>
  </body>
</html>
`,
  },
  {
    id: "starter-styles",
    name: "styles.css",
    language: "css",
    content: `:root {
  --ink: #1c1917;
  --accent: #b35f43;
  --line: color-mix(in oklab, var(--ink) 14%, transparent);
  font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  display: flex;
  padding: 1.25rem;
  box-sizing: border-box;
  background: #faf9f7;
  color: var(--ink);
}

/* margin: auto centres the card, and unlike place-items it never clips the
   top of the page when the preview is shorter than the content. */
.card {
  width: min(30rem, 100%);
  margin: auto;
  display: grid;
  gap: 0.6rem;
  padding: 1.5rem;
  box-sizing: border-box;
  border: 1px solid var(--line);
  border-radius: 18px;
  background: #fff;
  box-shadow: 0 18px 40px -24px rgb(28 25 23 / 45%);
}

.eyebrow {
  margin: 0;
  font: 600 11px/1.4 ui-monospace, SFMono-Regular, Menlo, monospace;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--accent);
}

h1 {
  margin: 0;
  font-size: 1.6rem;
  letter-spacing: -0.02em;
}

p {
  margin: 0;
  line-height: 1.6;
  color: color-mix(in oklab, var(--ink) 72%, transparent);
}

button {
  justify-self: start;
  margin-top: 0.25rem;
  padding: 0.55rem 1rem;
  border: 0;
  border-radius: 999px;
  background: var(--ink);
  color: #fff;
  font: inherit;
  font-weight: 500;
  cursor: pointer;
  transition: transform 140ms ease, background-color 140ms ease;
}

button:hover {
  transform: translateY(-1px);
  background: var(--accent);
}

output {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.85rem;
  opacity: 0.7;
}
`,
  },
  {
    id: "starter-app",
    name: "app.js",
    language: "javascript",
    content: `const cta = document.getElementById("cta");
const log = document.getElementById("log");

let count = 0;

cta.addEventListener("click", () => {
  count += 1;
  log.textContent = "Clicked " + count + (count === 1 ? " time" : " times");
  console.log("Clicked", count);
});

console.log("Sandbox ready — click the button.");
`,
  },
];

/* ── Pure helpers ──────────────────────────────────────────────────────────── */

function cloneStarter(): WorkspaceFile[] {
  return STARTER_FILES.map((file) => ({ ...file }));
}

function newFileId(): string {
  return `file-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function loadFiles(storageId: string): WorkspaceFile[] {
  if (typeof window === "undefined") return cloneStarter();
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(storageId) ?? "null");
    if (Array.isArray(parsed)) {
      const safe = parsed
        .filter(
          (f): f is { id?: unknown; name: string; content: string } =>
            Boolean(f) && typeof f.name === "string" && typeof f.content === "string",
        )
        .map((f, index) => ({
          id: typeof f.id === "string" && f.id ? f.id : `file-restored-${index}`,
          name: f.name,
          content: f.content,
          language: detectSandboxLanguage(f.name),
        }));
      if (safe.length > 0) return safe;
    }
  } catch {
    /* malformed workspace — fall back to the starter */
  }
  return cloneStarter();
}

function loadPrefs(settingsId: string): WorkspacePrefs {
  if (typeof window === "undefined") return DEFAULT_PREFS;
  try {
    const raw = JSON.parse(window.localStorage.getItem(settingsId) ?? "null") as Partial<WorkspacePrefs> | null;
    if (!raw || typeof raw !== "object") return DEFAULT_PREFS;
    return {
      autoRun: typeof raw.autoRun === "boolean" ? raw.autoRun : DEFAULT_PREFS.autoRun,
      loopGuard: typeof raw.loopGuard === "boolean" ? raw.loopGuard : DEFAULT_PREFS.loopGuard,
      wrap: typeof raw.wrap === "boolean" ? raw.wrap : DEFAULT_PREFS.wrap,
      view: raw.view === "code" || raw.view === "preview" || raw.view === "split" ? raw.view : DEFAULT_PREFS.view,
      device: raw.device === "mobile" ? "mobile" : "desktop",
      consoleOpen: typeof raw.consoleOpen === "boolean" ? raw.consoleOpen : DEFAULT_PREFS.consoleOpen,
      width: typeof raw.width === "number" && raw.width >= MIN_WIDTH ? raw.width : DEFAULT_PREFS.width,
      editorRatio:
        typeof raw.editorRatio === "number" && raw.editorRatio >= 0.22 && raw.editorRatio <= 0.78
          ? raw.editorRatio
          : DEFAULT_PREFS.editorRatio,
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

let runCounter = 0;

function createRun(files: WorkspaceFile[], loopGuard: boolean): RunSession {
  const token =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
  runCounter += 1;
  return {
    id: runCounter,
    token,
    doc: files.length > 0 ? withSandboxToken(buildPreviewDocument(files, { loopGuard }), token) : "",
    files,
    loopGuard,
    startedAt: typeof performance !== "undefined" ? performance.now() : 0,
  };
}

function download(name: string, content: string, type = "text/plain;charset=utf-8") {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Edits go through `execCommand` so they join the textarea's native undo stack;
 * assigning `value` from React would wipe it. Falls back to `setRangeText`.
 */
function replaceRange(el: HTMLTextAreaElement, from: number, to: number, text: string) {
  el.focus();
  el.setSelectionRange(from, to);
  let done = false;
  try {
    done = text ? document.execCommand("insertText", false, text) : document.execCommand("delete");
  } catch {
    done = false;
  }
  if (!done) {
    el.setRangeText(text, from, to, "end");
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
}

function motionDisabled(): boolean {
  if (typeof document === "undefined") return false;
  return (
    document.documentElement.dataset.animations === "off" ||
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

/* ── Component ─────────────────────────────────────────────────────────────── */

interface Props {
  onClose: () => void;
  /** Files are handed to the composer as attachments for the next message. */
  onSendToNova: (files: WorkspaceFile[]) => void;
  /**
   * Scopes persistence. The parent should also pass it as `key`, so switching
   * workspace remounts the panel with that workspace's files.
   */
  storageKey?: string;
}

export default function CodeWorkspace({ onClose, onSendToNova, storageKey = "default" }: Props) {
  const storageId = `${STORAGE_PREFIX}${storageKey}`;
  const settingsId = `${SETTINGS_PREFIX}${storageKey}`;

  const mounted = useMounted();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const desktopLayout = !mounted || isDesktop;

  // The panel only ever mounts on the client (after a click), so reading
  // localStorage in the initialisers is safe and avoids a flash of starter files.
  const [files, setFiles] = useState<WorkspaceFile[]>(() => loadFiles(storageId));
  const [activeId, setActiveId] = useState<string>(() => files[0]?.id ?? "");
  const [prefs, setPrefs] = useState<WorkspacePrefs>(() => loadPrefs(settingsId));
  const [maximized, setMaximized] = useState(false);
  const [session, setSession] = useState<RunSession>(() => createRun(files, prefs.loopGuard));
  const [loadedRun, setLoadedRun] = useState(0);
  const [lastRunMs, setLastRunMs] = useState<number | null>(null);
  const [consoleLines, setConsoleLines] = useState<ConsoleLine[]>([]);
  const [caret, setCaret] = useState({ line: 1, col: 1 });
  const [adding, setAdding] = useState(false);
  const [newFileName, setNewFileName] = useState("");
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [armedDeleteId, setArmedDeleteId] = useState<string | null>(null);
  const [resetArmed, setResetArmed] = useState(false);
  const [copiedConsole, setCopiedConsole] = useState(false);
  const [copiedFile, setCopiedFile] = useState(false);
  const [sent, setSent] = useState(false);
  const [resizing, setResizing] = useState<"col" | "row" | null>(null);

  const frameRef = useRef<HTMLIFrameElement>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const splitBodyRef = useRef<HTMLDivElement>(null);
  const consoleRef = useRef<HTMLDivElement>(null);
  const uploadRef = useRef<HTMLInputElement>(null);
  const tabRefs = useRef<Map<string, HTMLButtonElement>>(new Map());
  const cancelRenameRef = useRef(false);
  const cancelAddRef = useRef(false);
  const consoleIdRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const active = useMemo(
    () => files.find((f) => f.id === activeId) ?? files[0] ?? null,
    [files, activeId],
  );
  const highlighted = useMemo(
    () => (active ? tokenizeLines(active.content, active.language) : [[]]),
    [active],
  );
  const jsonCheck = useMemo(
    () => (active?.language === "json" && active.content.trim() ? formatJson(active.content) : null),
    [active],
  );
  const visibleLines = useMemo(
    () => consoleLines.filter((line) => line.token === session.token),
    [consoleLines, session.token],
  );

  const patchPrefs = useCallback((patch: Partial<WorkspacePrefs>) => {
    setPrefs((prev) => ({ ...prev, ...patch }));
  }, []);

  const later = useCallback((fn: () => void, ms: number) => {
    timersRef.current.push(setTimeout(fn, ms));
  }, []);

  useEffect(() => {
    const timers = timersRef.current;
    return () => timers.forEach(clearTimeout);
  }, []);

  // Keep the active tab scrolled into view when switching or adding files.
  useEffect(() => {
    if (!active) return;
    const node = tabRefs.current.get(active.id);
    node?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [active]);

  // Mobile Escape-to-close when focus is not inside an editable control or open menu.
  useEffect(() => {
    if (desktopLayout) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || event.defaultPrevented) return;
      const target = event.target as HTMLElement | null;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
      if (document.querySelector('[data-slot="dropdown-menu-content"][data-state="open"]')) return;
      event.preventDefault();
      onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [desktopLayout, onClose]);

  /* ── Persistence ─────────────────────────────────────────────────────── */
  useEffect(() => {
    try {
      window.localStorage.setItem(storageId, JSON.stringify(files));
    } catch {
      /* storage may be unavailable or full */
    }
  }, [files, storageId]);

  useEffect(() => {
    try {
      window.localStorage.setItem(settingsId, JSON.stringify(prefs));
    } catch {
      /* ignore */
    }
  }, [prefs, settingsId]);

  /* ── Console bridge ──────────────────────────────────────────────────────
     Subscribed once, before the first paint, so no early message is missed.
     Every line keeps the nonce of the run that produced it; rendering filters
     on the current run, so lines from a superseded document never show. */
  useLayoutEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.source !== frameRef.current?.contentWindow) return;
      const data = event.data as {
        source?: string;
        token?: string;
        level?: string;
        text?: string;
        file?: string | null;
        line?: number | null;
      } | null;
      if (!data || data.source !== "nova-sandbox" || typeof data.token !== "string") return;
      const token = data.token;
      if (data.level === "ready") return;
      if (data.level === "clear") {
        setConsoleLines((prev) => prev.filter((line) => line.token !== token));
        return;
      }
      const level = data.level ?? "log";
      const text = data.text ?? "";
      const file = typeof data.file === "string" ? data.file : null;
      const line = typeof data.line === "number" ? data.line : null;
      setConsoleLines((prev) => {
        const last = prev[prev.length - 1];
        if (
          last &&
          last.token === token &&
          last.level === level &&
          last.text === text &&
          last.file === file &&
          last.line === line
        ) {
          return [...prev.slice(0, -1), { ...last, count: last.count + 1 }];
        }
        consoleIdRef.current += 1;
        return [...prev, { id: consoleIdRef.current, token, level, text, file, line, count: 1 }].slice(-300);
      });
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    const el = consoleRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [visibleLines.length, prefs.consoleOpen]);

  /* ── Running ─────────────────────────────────────────────────────────── */
  const startRun = useCallback((nextFiles: WorkspaceFile[], loopGuard: boolean) => {
    setConsoleLines([]);
    setSession(createRun(nextFiles, loopGuard));
  }, []);

  const run = useCallback(() => {
    if (files.length === 0) {
      toast.message("Add a file before running the workspace.");
      return;
    }
    startRun(files, prefs.loopGuard);
  }, [files, prefs.loopGuard, startRun]);

  // Auto-run: debounced so the preview is rebuilt when typing pauses, and
  // skipped entirely when nothing changed since the last run.
  useEffect(() => {
    if (!prefs.autoRun) return;
    if (session.files === files && session.loopGuard === prefs.loopGuard) return;
    const timer = setTimeout(() => startRun(files, prefs.loopGuard), 700);
    return () => clearTimeout(timer);
  }, [files, prefs.autoRun, prefs.loopGuard, session.files, session.loopGuard, startRun]);

  const running = Boolean(session.doc) && loadedRun !== session.id;
  const stale = !prefs.autoRun && (session.files !== files || session.loopGuard !== prefs.loopGuard);
  const errorCount = visibleLines.reduce((sum, line) => sum + (line.level === "error" ? line.count : 0), 0);

  /* ── File operations ─────────────────────────────────────────────────── */
  const updateActive = useCallback(
    (content: string) => {
      if (!active) return;
      const id = active.id;
      setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, content } : f)));
    },
    [active],
  );

  const syncCaret = useCallback((el: HTMLTextAreaElement) => {
    const before = el.value.slice(0, el.selectionStart);
    const line = before.split("\n").length;
    const col = before.length - before.lastIndexOf("\n");
    setCaret((prev) => (prev.line === line && prev.col === col ? prev : { line, col }));
  }, []);

  const selectFile = (id: string) => {
    setActiveId(id);
    setCaret({ line: 1, col: 1 });
  };

  const beginAdd = () => {
    cancelAddRef.current = false;
    setNewFileName("");
    setAdding(true);
  };

  const commitAdd = (fromBlur = false) => {
    if (cancelAddRef.current) {
      cancelAddRef.current = false;
      setAdding(false);
      setNewFileName("");
      return;
    }
    const trimmed = newFileName.trim();
    if (!trimmed) {
      if (fromBlur) setAdding(false);
      else toast.error("Enter a file name.");
      return;
    }
    const error = validateFileName(files, trimmed);
    if (error) {
      toast.error(error);
      if (fromBlur) {
        setAdding(false);
        setNewFileName("");
      }
      return;
    }
    const file: WorkspaceFile = { id: newFileId(), name: trimmed, language: detectSandboxLanguage(trimmed), content: "" };
    setFiles((prev) => [...prev, file]);
    selectFile(file.id);
    setAdding(false);
    setNewFileName("");
    if (prefs.view === "preview") patchPrefs({ view: "split" });
    later(() => editorRef.current?.focus(), 60);
  };

  const beginRename = (file: WorkspaceFile) => {
    cancelRenameRef.current = false;
    setRenamingId(file.id);
    setRenameValue(file.name);
  };

  const commitRename = (file: WorkspaceFile) => {
    if (cancelRenameRef.current) {
      cancelRenameRef.current = false;
      setRenamingId(null);
      return;
    }
    const next = renameValue.trim();
    if (!next || next === file.name) {
      setRenamingId(null);
      return;
    }
    const error = validateFileName(files, next, file.id);
    if (error) {
      toast.error(error);
      setRenamingId(null);
      return;
    }
    setFiles((prev) =>
      prev.map((f) => (f.id === file.id ? { ...f, name: next, language: detectSandboxLanguage(next) } : f)),
    );
    setRenamingId(null);
  };

  const onTabKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>, index: number) => {
    if (files.length < 2) return;
    let targetIndex = -1;
    if (event.key === "ArrowRight") targetIndex = (index + 1) % files.length;
    else if (event.key === "ArrowLeft") targetIndex = (index - 1 + files.length) % files.length;
    else if (event.key === "Home") targetIndex = 0;
    else if (event.key === "End") targetIndex = files.length - 1;
    else if (event.key === "F2") {
      event.preventDefault();
      beginRename(files[index]);
      return;
    }
    if (targetIndex < 0) return;
    event.preventDefault();
    const nextFile = files[targetIndex];
    selectFile(nextFile.id);
    tabRefs.current.get(nextFile.id)?.focus();
  };

  const requestDelete = (file: WorkspaceFile) => {
    if (armedDeleteId !== file.id) {
      setArmedDeleteId(file.id);
      later(() => setArmedDeleteId((current) => (current === file.id ? null : current)), 3500);
      toast.message(`Click again to delete ${file.name}`);
      return;
    }
    setArmedDeleteId(null);
    const index = files.findIndex((f) => f.id === file.id);
    const next = files.filter((f) => f.id !== file.id);
    setFiles(next);
    if (file.id === active?.id) selectFile(next[Math.min(index, next.length - 1)]?.id ?? "");
  };

  const resetWorkspace = () => {
    const starter = cloneStarter();
    setFiles(starter);
    selectFile(starter[0].id);
    setResetArmed(false);
    startRun(starter, prefs.loopGuard);
    toast.success("Starter files restored");
  };

  const onUpload = async (list: FileList | null) => {
    if (!list || list.length === 0) return;
    const taken = new Set(files.map((f) => f.name.toLowerCase()));
    const incoming: WorkspaceFile[] = [];
    for (const file of Array.from(list).slice(0, 8)) {
      if (file.size > 220_000) {
        toast.error(`${file.name} is larger than 220 KB.`);
        continue;
      }
      const content = (await file.text()).replace(/\r\n?/g, "\n");
      let name = sanitizeFileName(file.name);
      for (let n = 2; taken.has(name.toLowerCase()); n += 1) {
        const dot = name.lastIndexOf(".");
        const base = (dot > 0 ? name.slice(0, dot) : name).replace(/-\d+$/, "");
        name = `${base}-${n}${dot > 0 ? name.slice(dot) : ""}`;
      }
      taken.add(name.toLowerCase());
      incoming.push({ id: newFileId(), name, language: detectSandboxLanguage(name), content });
    }
    if (incoming.length === 0) return;
    setFiles((prev) => [...prev, ...incoming]);
    selectFile(incoming[0].id);
    toast.success(`Imported ${incoming.length} file${incoming.length === 1 ? "" : "s"}`);
  };

  const sendToNova = () => {
    const usable = files.filter((file) => file.content.trim().length > 0);
    if (usable.length === 0) {
      toast.message("The workspace is empty — write some code first.");
      return;
    }
    onSendToNova(usable);
    setSent(true);
    later(() => setSent(false), 1600);
  };

  const copyActiveFile = async () => {
    if (!active) return;
    try {
      await navigator.clipboard.writeText(active.content);
      setCopiedFile(true);
      later(() => setCopiedFile(false), 1400);
    } catch {
      toast.error("Clipboard access is blocked in this browser.");
    }
  };

  const prettifyJson = () => {
    if (!active || active.language !== "json") return;
    const result = formatJson(active.content);
    if (result.error) {
      toast.error(`Cannot format JSON: ${result.error}`);
      return;
    }
    const formatted = `${result.text}\n`;
    if (formatted === active.content) return;
    if (editorRef.current) {
      replaceRange(editorRef.current, 0, editorRef.current.value.length, formatted);
      syncCaret(editorRef.current);
    } else {
      updateActive(formatted);
    }
  };

  const copyConsole = async () => {
    if (visibleLines.length === 0) return;
    try {
      await navigator.clipboard.writeText(
        visibleLines
          .map((line) => `${line.text}${line.file && line.line ? `  (${line.file}:${line.line})` : ""}`)
          .join("\n"),
      );
      setCopiedConsole(true);
      later(() => setCopiedConsole(false), 1400);
    } catch {
      toast.error("Clipboard access is blocked in this browser.");
    }
  };

  /** Jumps to a console location: opens the file and selects the line. */
  const reveal = (fileName: string, line: number) => {
    const target = files.find((f) => f.name === fileName);
    if (!target) {
      toast.message(`${fileName} is no longer in the workspace.`);
      return;
    }
    setActiveId(target.id);
    if (prefs.view === "preview") patchPrefs({ view: "split" });
    const lines = target.content.split("\n");
    const safe = Math.min(Math.max(line, 1), lines.length);
    let start = 0;
    for (let i = 0; i < safe - 1; i += 1) start += lines[i].length + 1;
    setCaret({ line: safe, col: 1 });
    later(() => {
      const el = editorRef.current;
      if (!el) return;
      el.focus({ preventScroll: true });
      el.setSelectionRange(start, start + lines[safe - 1].length);
      if (scrollerRef.current) scrollerRef.current.scrollTop = Math.max(0, (safe - 4) * LINE_HEIGHT);
    }, 40);
  };

  /* ── Editor keyboard behaviour ───────────────────────────────────────── */
  const onEditorKeyDown = (event: ReactKeyboardEvent<HTMLTextAreaElement>) => {
    if (event.nativeEvent.isComposing || !active) return;
    const el = event.currentTarget;
    const value = el.value;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const mod = event.metaKey || event.ctrlKey;
    const key = event.key;

    if (mod && (key === "Enter" || key.toLowerCase() === "s")) {
      event.preventDefault();
      run();
      return;
    }

    const comment = LINE_COMMENT[active.language];
    if (mod && key === "/" && comment) {
      event.preventDefault();
      const from = value.lastIndexOf("\n", start - 1) + 1;
      const lineEnd = value.indexOf("\n", end);
      const to = lineEnd === -1 ? value.length : lineEnd;
      const lines = value.slice(from, to).split("\n");
      const filled = lines.filter((l) => l.trim());
      const allCommented = filled.length > 0 && filled.every((l) => l.trimStart().startsWith(comment));
      const next = lines
        .map((l) => {
          if (!l.trim()) return l;
          const indent = /^[ \t]*/.exec(l)?.[0] ?? "";
          const body = l.slice(indent.length);
          if (!allCommented) return `${indent}${comment} ${body}`;
          return indent + body.slice(comment.length).replace(/^ /, "");
        })
        .join("\n");
      if (next !== lines.join("\n")) {
        replaceRange(el, from, to, next);
        el.setSelectionRange(from, from + next.length);
        syncCaret(el);
      }
      return;
    }

    if (mod || event.altKey) return;

    if (key === "Escape") {
      el.blur();
      return;
    }

    if (key === "Tab") {
      event.preventDefault();
      const multi = value.slice(start, end).includes("\n");
      if (!multi && !event.shiftKey) {
        replaceRange(el, start, end, "  ");
        syncCaret(el);
        return;
      }
      const from = value.lastIndexOf("\n", start - 1) + 1;
      const lineEnd = value.indexOf("\n", end);
      // A selection that ends at column 0 does not include that last line.
      const to = multi && value[end - 1] === "\n" ? end - 1 : lineEnd === -1 ? value.length : lineEnd;
      const block = value.slice(from, to);
      const next = block
        .split("\n")
        .map((l) => (event.shiftKey ? l.replace(/^(?: {1,2}|\t)/, "") : l ? `  ${l}` : l))
        .join("\n");
      if (next === block) return;
      replaceRange(el, from, to, next);
      if (multi) el.setSelectionRange(from, from + next.length);
      else {
        const position = Math.max(from, start + (next.length - block.length));
        el.setSelectionRange(position, position);
      }
      syncCaret(el);
      return;
    }

    if (key === "Enter") {
      const lineStart = value.lastIndexOf("\n", start - 1) + 1;
      const indent = /^[ \t]*/.exec(value.slice(lineStart, start))?.[0] ?? "";
      const before = value[start - 1] ?? "";
      const after = value[end] ?? "";
      const opens =
        before === "{" || before === "[" || before === "(" || (active.language === "python" && before === ":");
      const between =
        (PAIRS[before] !== undefined && PAIRS[before] === after && before !== after) ||
        (before === ">" && value.startsWith("</", end));
      event.preventDefault();
      if (between) {
        replaceRange(el, start, end, `\n${indent}  \n${indent}`);
        const position = start + 1 + indent.length + 2;
        el.setSelectionRange(position, position);
      } else {
        replaceRange(el, start, end, `\n${indent}${opens ? "  " : ""}`);
      }
      syncCaret(el);
      return;
    }

    const prose = active.language === "markdown" || active.language === "text";
    if (start !== end) {
      if (PAIRS[key] && !prose) {
        event.preventDefault();
        replaceRange(el, start, end, `${key}${value.slice(start, end)}${PAIRS[key]}`);
        el.setSelectionRange(start + 1, end + 1);
        syncCaret(el);
      }
      return;
    }

    const nextChar = value[start] ?? "";
    const prevChar = value[start - 1] ?? "";
    if (CLOSERS.includes(key) && nextChar === key) {
      event.preventDefault();
      el.setSelectionRange(start + 1, start + 1);
      syncCaret(el);
      return;
    }
    if (PAIRS[key] && !prose) {
      const quote = key === PAIRS[key];
      const roomAfter = nextChar === "" || /[\s)\]}>,;:]/.test(nextChar);
      const fineBefore = !quote || !/[\w$]/.test(prevChar);
      if (roomAfter && fineBefore) {
        event.preventDefault();
        replaceRange(el, start, end, `${key}${PAIRS[key]}`);
        el.setSelectionRange(start + 1, start + 1);
        syncCaret(el);
      }
      return;
    }
    if (key === "Backspace" && start > 0 && nextChar && PAIRS[prevChar] === nextChar) {
      event.preventDefault();
      replaceRange(el, start - 1, start + 1, "");
      syncCaret(el);
    }
  };

  /* ── Panel & split resizing ──────────────────────────────────────────── */
  const clampWidth = (width: number) =>
    Math.round(Math.min(Math.max(width, MIN_WIDTH), Math.max(MIN_WIDTH, window.innerWidth - 420)));

  const startResize = (event: ReactPointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (maximized) setMaximized(false);
    setResizing("col");
    const move = (e: PointerEvent) => patchPrefs({ width: clampWidth(window.innerWidth - e.clientX) });
    const stop = () => {
      setResizing(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
  };

  const startSplitResize = (event: ReactPointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    const container = splitBodyRef.current;
    if (!container) return;
    setResizing("row");
    const move = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const consoleEl = container.querySelector<HTMLElement>('[aria-label="Console"]');
      const available = Math.max(200, rect.height - (consoleEl?.offsetHeight ?? 0));
      const ratio = Math.min(0.78, Math.max(0.22, (e.clientY - rect.top) / available));
      patchPrefs({ editorRatio: Math.round(ratio * 1000) / 1000 });
    };
    const stop = () => {
      setResizing(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
  };

  /* ── Render ──────────────────────────────────────────────────────────── */
  const lineCount = highlighted.length;
  const languageNote = active ? NOT_RUNNABLE_NOTE[active.language] : undefined;
  const dataPreview = active && (active.language === "json" || active.language === "markdown") ? active : null;
  const view = prefs.view;
  const noMotion = motionDisabled();
  const targetWidth = maximized
    ? typeof window !== "undefined"
      ? Math.min(980, Math.max(prefs.width, window.innerWidth - 360))
      : 920
    : prefs.width;
  const iconButton =
    "flex size-7 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40";

  return (
    <motion.aside
      aria-label="Code workspace"
      initial={noMotion ? false : desktopLayout ? { width: 0, opacity: 0 } : { opacity: 0, y: 16 }}
      animate={
        desktopLayout
          ? { width: targetWidth, opacity: 1, y: 0 }
          : { opacity: 1, y: 0 }
      }
      exit={
        noMotion
          ? { opacity: 0, transition: { duration: 0 } }
          : desktopLayout
            ? { width: 0, opacity: 0 }
            : { opacity: 0, y: 14 }
      }
      transition={
        resizing === "col" || noMotion
          ? { duration: 0 }
          : { duration: 0.22, ease: PANEL_EASE }
      }
      style={{ "--ws-width": `${targetWidth}px` } as CSSProperties}
      className="code-workspace fixed inset-0 z-50 flex min-w-0 flex-col overflow-hidden bg-card lg:relative lg:inset-auto lg:z-auto lg:w-[var(--ws-width)] lg:max-w-[calc(100vw-22rem)] lg:shrink-0 lg:border-l lg:border-border/70"
    >
      {/* Inner frame keeps toolbar & editor from squishing while the outer panel animates width */}
      <div
        className="relative flex min-h-0 flex-1 flex-col"
        style={desktopLayout ? ({ minWidth: Math.min(targetWidth, MIN_WIDTH) } as CSSProperties) : undefined}
      >
        {/* Resize handle (desktop) */}
        <div
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize code workspace"
          aria-valuenow={targetWidth}
          tabIndex={0}
          onPointerDown={startResize}
          onDoubleClick={() => {
            setMaximized(false);
            patchPrefs({ width: DEFAULT_PREFS.width });
          }}
          onKeyDown={(event) => {
            if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
            event.preventDefault();
            setMaximized(false);
            patchPrefs({ width: clampWidth(prefs.width + (event.key === "ArrowLeft" ? 32 : -32)) });
          }}
          title="Drag to resize · double-click to reset"
          className={cn(
            "absolute inset-y-0 left-0 z-30 hidden w-2 -translate-x-1/2 cursor-col-resize outline-none transition-colors lg:block",
            "after:absolute after:inset-y-0 after:left-1/2 after:w-0.5 after:-translate-x-1/2 after:transition-colors hover:after:bg-brand/60 focus-visible:after:bg-brand",
            resizing === "col" && "after:bg-brand",
          )}
        />
        {resizing && (
          <div
            className={cn(
              "fixed inset-0 z-[70] select-none",
              resizing === "col" ? "cursor-col-resize" : "cursor-row-resize",
            )}
          />
        )}

        {/* Header */}
        <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border/70 bg-surface-1 pl-3 pr-1.5">
          <span className="flex size-6 shrink-0 items-center justify-center rounded-md bg-brand/10 text-brand">
            <Code2 size={13} strokeWidth={1.9} />
          </span>
          <p className="truncate text-[13px] font-semibold">Code workspace</p>
          <span
            title="The preview runs in a sandboxed iframe with an opaque origin: no cookies, no storage, no access to this app, and no network."
            className="hidden shrink-0 items-center gap-1 rounded-full border border-border/70 px-1.5 py-px font-mono text-[10px] text-muted-foreground sm:inline-flex"
          >
            <ShieldCheck size={10} /> sandboxed
          </span>
          <div className="ml-auto flex items-center gap-0.5">
            <Button
              size="xs"
              variant={sent ? "default" : "outline"}
              onClick={sendToNova}
              disabled={files.length === 0}
              title="Attach these files to your next message"
              className="mr-1 h-7 gap-1.5 px-2.5"
            >
              {sent ? <Check size={12} /> : <Send size={12} />}
              {sent ? "Attached" : "Send to Nova"}
            </Button>

            <button
              type="button"
              onClick={() => setMaximized((prev) => !prev)}
              aria-label={maximized ? "Restore workspace width" : "Expand workspace width"}
              aria-pressed={maximized}
              title={maximized ? "Restore width" : "Expand width"}
              className={cn(iconButton, "hidden xl:flex")}
            >
              {maximized ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
            </button>

            <DropdownMenu onOpenChange={(open) => !open && setResetArmed(false)}>
              <DropdownMenuTrigger asChild>
                <button type="button" aria-label="Workspace menu" className={iconButton}>
                  <Ellipsis size={15} />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-60 p-1">
                <DropdownMenuItem onSelect={beginAdd} className="rounded-md text-[12.5px]">
                  <FilePlus2 size={14} /> New file
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => uploadRef.current?.click()} className="rounded-md text-[12.5px]">
                  <Upload size={14} /> Import files…
                </DropdownMenuItem>
                {active && (
                  <>
                    <DropdownMenuItem onSelect={() => beginRename(active)} className="rounded-md text-[12.5px]">
                      <Pencil size={14} /> Rename {active.name}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onSelect={() => download(active.name, active.content)}
                      className="rounded-md text-[12.5px]"
                    >
                      <Download size={14} /> Download {active.name}
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuItem
                  disabled={files.length === 0}
                  onSelect={() =>
                    download("workspace.md", exportWorkspaceMarkdown(files), "text/markdown;charset=utf-8")
                  }
                  className="rounded-md text-[12.5px]"
                >
                  <Download size={14} /> Export all as Markdown
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuCheckboxItem
                  checked={prefs.wrap}
                  onCheckedChange={(checked) => patchPrefs({ wrap: Boolean(checked) })}
                  className="rounded-md text-[12.5px]"
                >
                  Word wrap
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={prefs.loopGuard}
                  onCheckedChange={(checked) => patchPrefs({ loopGuard: Boolean(checked) })}
                  className="rounded-md text-[12.5px]"
                  title="Stops loops that block the page for more than 2 seconds"
                >
                  Stop runaway loops
                </DropdownMenuCheckboxItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onSelect={(event) => {
                    if (resetArmed) {
                      resetWorkspace();
                      return;
                    }
                    event.preventDefault();
                    setResetArmed(true);
                  }}
                  className={cn("rounded-md text-[12.5px]", resetArmed && "bg-destructive/10 text-destructive")}
                >
                  <RotateCcw size={14} /> {resetArmed ? "Click again to discard all files" : "Reset to starter files"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <button type="button" onClick={onClose} aria-label="Close code workspace" title="Close" className={iconButton}>
              <PanelRightClose size={15} className="hidden lg:block" />
              <X size={16} className="lg:hidden" />
            </button>
          </div>
          <input
            ref={uploadRef}
            type="file"
            multiple
            accept={IMPORT_ACCEPT}
            className="hidden"
            onChange={(event) => {
              void onUpload(event.target.files);
              event.target.value = "";
            }}
          />
        </div>

        {/* File tabs */}
        <div className="flex h-9 shrink-0 items-stretch border-b border-border/70 bg-surface-2/70">
          <div role="tablist" aria-label="Workspace files" className="scroll-none flex min-w-0 flex-1 items-stretch overflow-x-auto">
            {files.map((file, index) => {
              const isActive = file.id === active?.id;
              const armed = armedDeleteId === file.id;
              if (renamingId === file.id) {
                return (
                  <input
                    key={file.id}
                    autoFocus
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    onFocus={(e) => {
                      const dot = e.target.value.lastIndexOf(".");
                      e.target.setSelectionRange(0, dot > 0 ? dot : e.target.value.length);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        commitRename(file);
                      } else if (e.key === "Escape") {
                        e.preventDefault();
                        cancelRenameRef.current = true;
                        setRenamingId(null);
                      }
                    }}
                    onBlur={() => commitRename(file)}
                    aria-label={`Rename ${file.name}`}
                    spellCheck={false}
                    className="h-full w-36 shrink-0 border-r border-border/60 bg-background px-3 font-mono text-[11.5px] outline-none ring-1 ring-inset ring-brand/60"
                  />
                );
              }
              return (
                <div
                  key={file.id}
                  className={cn(
                    "group/tab relative flex shrink-0 items-center border-r border-border/60 transition-colors",
                    isActive
                      ? "bg-background text-foreground"
                      : "text-muted-foreground hover:bg-background/60 hover:text-foreground",
                  )}
                >
                  {isActive && (
                    <motion.span
                      layoutId="code-ws-active-tab"
                      aria-hidden="true"
                      className="absolute inset-x-0 top-0 h-0.5 bg-brand"
                      transition={noMotion ? { duration: 0 } : { type: "spring", stiffness: 520, damping: 40 }}
                    />
                  )}
                  <button
                    ref={(node) => {
                      if (node) tabRefs.current.set(file.id, node);
                      else tabRefs.current.delete(file.id);
                    }}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    tabIndex={isActive ? 0 : -1}
                    onClick={() => selectFile(file.id)}
                    onKeyDown={(event) => onTabKeyDown(event, index)}
                    onDoubleClick={() => beginRename(file)}
                    title={`${file.name} — double-click or press F2 to rename`}
                    className="flex h-full items-center gap-1.5 pl-3 pr-1 font-mono text-[11.5px] outline-none focus-visible:bg-accent"
                  >
                    <LanguageLogo language={file.language} size={12} />
                    <span className="whitespace-nowrap">{file.name}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => requestDelete(file)}
                    aria-label={armed ? `Confirm deleting ${file.name}` : `Delete ${file.name}`}
                    title={armed ? "Click again to delete" : `Delete ${file.name}`}
                    className={cn(
                      "mr-1.5 flex size-[18px] shrink-0 items-center justify-center rounded outline-none transition focus-visible:opacity-100 focus-visible:ring-2 focus-visible:ring-ring",
                      armed
                        ? "bg-destructive/15 text-destructive"
                        : "text-muted-foreground/70 hover:bg-accent hover:text-foreground",
                      !isActive && !armed && "opacity-0 group-hover/tab:opacity-100",
                    )}
                  >
                    {armed ? <Trash2 size={11} /> : <X size={11} />}
                  </button>
                </div>
              );
            })}
            {adding && (
              <input
                autoFocus
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    commitAdd(false);
                  } else if (e.key === "Escape") {
                    e.preventDefault();
                    cancelAddRef.current = true;
                    setAdding(false);
                    setNewFileName("");
                  }
                }}
                onBlur={() => commitAdd(true)}
                placeholder="script.js"
                aria-label="New file name"
                spellCheck={false}
                className="h-full w-36 shrink-0 bg-background px-3 font-mono text-[11.5px] outline-none ring-1 ring-inset ring-brand/60 placeholder:text-muted-foreground/50"
              />
            )}
          </div>
          <button
            type="button"
            onClick={beginAdd}
            aria-label="New file"
            title="New file"
            className="flex w-9 shrink-0 items-center justify-center border-l border-border/60 text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground focus-visible:bg-accent"
          >
            <FilePlus2 size={13} />
          </button>
        </div>

        {/* Toolbar */}
        <div className="flex h-10 shrink-0 items-center gap-2 border-b border-border/70 bg-surface-1 px-2">
          <div role="group" aria-label="Layout" className="relative flex items-center rounded-lg border border-border/70 bg-muted/50 p-0.5">
            {VIEWS.map((item) => {
              const selected = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={selected}
                  aria-label={`${item.label} view`}
                  title={`${item.label} view`}
                  onClick={() => patchPrefs({ view: item.id })}
                  className={cn(
                    "relative isolate inline-flex h-6 items-center gap-1.5 rounded-md px-2 text-[11.5px] font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring",
                    selected ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {selected && (
                    <motion.span
                      layoutId="code-ws-view-pill"
                      aria-hidden="true"
                      className="absolute inset-0 -z-10 rounded-md bg-background shadow-xs"
                      transition={noMotion ? { duration: 0 } : { type: "spring", stiffness: 520, damping: 38 }}
                    />
                  )}
                  <item.icon size={12} />
                  <span className="workspace-view-label">{item.label}</span>
                </button>
              );
            })}
          </div>
          <div className="ml-auto flex items-center gap-1">
            {active?.language === "json" && active.content.trim().length > 0 && (
              <button
                type="button"
                onClick={prettifyJson}
                title="Format JSON"
                aria-label="Format JSON"
                className="workspace-view-label inline-flex h-7 items-center gap-1 rounded-md border border-border/70 px-2 text-[11px] font-medium text-muted-foreground outline-none transition hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Braces size={11} /> Format
              </button>
            )}
            {active && view !== "preview" && (
              <button
                type="button"
                onClick={() => void copyActiveFile()}
                aria-label={`Copy ${active.name}`}
                title={`Copy ${active.name}`}
                className={iconButton}
              >
                {copiedFile ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
              </button>
            )}
            <button
              type="button"
              onClick={() => patchPrefs({ autoRun: !prefs.autoRun })}
              aria-pressed={prefs.autoRun}
              title={prefs.autoRun ? "Auto-run is on: the preview refreshes when you pause typing" : "Auto-run is off: press Run to refresh"}
              className={cn(
                "inline-flex h-7 items-center gap-1.5 rounded-md border px-2 text-[11.5px] font-medium outline-none transition focus-visible:ring-2 focus-visible:ring-ring",
                prefs.autoRun
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                  : "border-border/70 text-muted-foreground hover:text-foreground",
              )}
            >
              <span className={cn("size-1.5 rounded-full", prefs.autoRun ? "bg-emerald-500" : "bg-muted-foreground/50")} />
              Auto
            </button>
            <button
              type="button"
              onClick={run}
              disabled={files.length === 0}
              title="Run (⌘/Ctrl + Enter)"
              className={cn(
                "inline-flex h-7 items-center gap-1.5 rounded-md bg-foreground px-3 text-[11.5px] font-semibold text-background outline-none transition hover:opacity-90 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40",
                stale && "ring-2 ring-brand/60",
              )}
            >
              {running ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
              Run
            </button>
          </div>
        </div>

        <div ref={splitBodyRef} className="flex min-h-0 flex-1 flex-col">
          {/* Editor */}
          {view !== "preview" && (
            <section
              aria-label="Editor"
              style={
                view === "split"
                  ? ({ flexGrow: Math.round(prefs.editorRatio * 1000), flexBasis: 0 } as CSSProperties)
                  : undefined
              }
              className={cn("flex min-h-0 flex-col", view !== "split" && "flex-1")}
            >
              {active ? (
                <div
                  key={active.id}
                  ref={scrollerRef}
                  className="code-scroller scroll-slim relative min-h-0 flex-1 overflow-auto"
                >
                  <div className="code-stack" data-wrap={prefs.wrap}>
                    <pre aria-hidden className="code-layer code-highlight">
                      {highlighted.map((tokens, index) => (
                        <div key={index} className="cl" data-active={index + 1 === caret.line ? "" : undefined}>
                          {tokens.map((token, j) =>
                            token.kind === "plain" ? (
                              token.text
                            ) : (
                              <span key={j} className={`tok-${token.kind}`}>
                                {token.text}
                              </span>
                            ),
                          )}
                        </div>
                      ))}
                    </pre>
                    <textarea
                      ref={editorRef}
                      value={active.content}
                      onChange={(e) => {
                        updateActive(e.target.value);
                        syncCaret(e.currentTarget);
                      }}
                      onKeyDown={onEditorKeyDown}
                      onSelect={(e) => syncCaret(e.currentTarget)}
                      wrap={prefs.wrap ? "soft" : "off"}
                      spellCheck={false}
                      autoCapitalize="off"
                      autoCorrect="off"
                      autoComplete="off"
                      aria-label={`Code editor — ${active.name}`}
                      placeholder={`Start typing in ${active.name}…`}
                      className="code-layer code-input"
                    />
                  </div>
                </div>
              ) : (
                <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
                  <p className="text-[12.5px] text-muted-foreground">This workspace has no files.</p>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={beginAdd}>
                      <FilePlus2 size={13} /> New file
                    </Button>
                    <Button size="sm" onClick={resetWorkspace}>
                      Add starter files
                    </Button>
                  </div>
                </div>
              )}
              {languageNote && (
                <p className="shrink-0 border-t border-amber-500/25 bg-amber-500/[0.07] px-3 py-1.5 text-[11px] leading-snug text-amber-800 dark:text-amber-300">
                  {languageNote}
                </p>
              )}
              {active && (
                <div className="flex h-6 shrink-0 items-center gap-2.5 whitespace-nowrap border-t border-border/70 bg-surface-2/70 px-2.5 font-mono text-[10px] text-muted-foreground">
                  <span>
                    Ln {caret.line}, Col {caret.col}
                  </span>
                  <span className="hidden items-center gap-1 sm:inline-flex">
                    <LanguageLogo language={active.language} size={10} />
                    {SANDBOX_LANG_LABEL[active.language]}
                  </span>
                  <span className="hidden sm:inline">
                    {lineCount} line{lineCount === 1 ? "" : "s"}
                  </span>
                  {jsonCheck &&
                    (jsonCheck.error ? (
                      <span className="min-w-0 truncate text-destructive" title={jsonCheck.error}>
                        {jsonCheck.error}
                      </span>
                    ) : (
                      <span className="text-emerald-600 dark:text-emerald-400">Valid JSON</span>
                    ))}
                  <span className="ml-auto inline-flex items-center gap-1.5" title="Files are stored in this browser only">
                    <span className="size-1.5 rounded-full bg-emerald-500" /> Saved locally
                  </span>
                </div>
              )}
            </section>
          )}

          {/* Split-pane divider (Split view only) */}
          {view === "split" && (
            <div
              role="separator"
              aria-orientation="horizontal"
              aria-label="Resize editor and preview"
              aria-valuenow={Math.round(prefs.editorRatio * 100)}
              tabIndex={0}
              onPointerDown={startSplitResize}
              onDoubleClick={() => patchPrefs({ editorRatio: DEFAULT_PREFS.editorRatio })}
              onKeyDown={(event) => {
                if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
                event.preventDefault();
                const delta = event.key === "ArrowUp" ? -0.05 : 0.05;
                patchPrefs({ editorRatio: Math.min(0.78, Math.max(0.22, Number((prefs.editorRatio + delta).toFixed(2)))) });
              }}
              title="Drag to adjust split · double-click to reset"
              className={cn(
                "group relative z-20 flex h-1.5 shrink-0 cursor-row-resize items-center justify-center border-t border-border/70 bg-surface-2/60 outline-none transition-colors hover:bg-brand/15 focus-visible:bg-brand/20",
                resizing === "row" && "bg-brand/25",
              )}
            >
              <span className="h-0.5 w-7 rounded-full bg-border transition-colors group-hover:bg-brand/70" />
            </div>
          )}

          {/* Preview — kept mounted in Code view so the page keeps running. */}
          <section
            aria-label="Preview"
            style={
              view === "split"
                ? ({ flexGrow: Math.round((1 - prefs.editorRatio) * 1000), flexBasis: 0 } as CSSProperties)
                : undefined
            }
            className={cn(
              "min-h-0 flex-col border-border/70",
              view === "code" ? "hidden" : "flex",
              view !== "split" && "flex-1",
            )}
          >
            <div className="flex h-8 shrink-0 items-center gap-2 whitespace-nowrap border-b border-border/70 bg-surface-1 px-2.5 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1.5 font-medium text-foreground/80">
                <span
                  className={cn(
                    "size-1.5 rounded-full transition-colors",
                    running ? "animate-pulse bg-amber-500" : errorCount > 0 ? "bg-destructive" : "bg-emerald-500",
                  )}
                />
                {dataPreview ? `${dataPreview.name} preview` : "Preview"}
              </span>
              {stale ? (
                <span className="text-brand">Edited — press Run</span>
              ) : (
                lastRunMs !== null && !running && !dataPreview && (
                  <span className="hidden font-mono text-[10px] opacity-70 sm:inline">{lastRunMs} ms</span>
                )
              )}
              <div className="ml-auto flex items-center gap-1">
                <div role="group" aria-label="Preview width" className="flex items-center rounded-md border border-border/70 p-0.5">
                  {(["desktop", "mobile"] as const).map((device) => {
                    const DeviceIcon = device === "desktop" ? Monitor : Smartphone;
                    return (
                      <button
                        key={device}
                        type="button"
                        onClick={() => patchPrefs({ device })}
                        aria-label={device === "desktop" ? "Full-width preview" : "Phone-width preview"}
                        aria-pressed={prefs.device === device}
                        className={cn(
                          "flex size-5 items-center justify-center rounded outline-none transition focus-visible:ring-2 focus-visible:ring-ring",
                          prefs.device === device ? "bg-accent text-foreground" : "hover:text-foreground",
                        )}
                      >
                        <DeviceIcon size={11} />
                      </button>
                    );
                  })}
                </div>
                <button type="button" onClick={run} aria-label="Reload preview" title="Reload preview" className={cn(iconButton, "size-6")}>
                  <RefreshCw size={12} className={running ? "animate-spin" : undefined} />
                </button>
              </div>
            </div>

            <div className="relative min-h-0 flex-1 bg-surface-3/40 p-2">
              {dataPreview && (
                <div className="scroll-slim absolute inset-2 z-10 overflow-auto rounded-lg border border-border/60 bg-background p-4">
                  {dataPreview.language === "markdown" ? (
                    dataPreview.content.trim() ? (
                      <Markdown content={dataPreview.content} />
                    ) : (
                      <p className="text-[12px] text-muted-foreground">Nothing to preview yet.</p>
                    )
                  ) : (
                    <pre className="whitespace-pre-wrap break-words font-mono text-[11.5px] leading-relaxed text-foreground/90">
                      {formatJson(dataPreview.content).text}
                    </pre>
                  )}
                </div>
              )}
              <div
                className={cn(
                  "mx-auto h-full overflow-hidden rounded-lg border border-border/60 bg-white shadow-xs transition-[max-width] duration-200 ease-out",
                  prefs.device === "mobile" ? "max-w-[390px]" : "max-w-full",
                )}
              >
                {session.doc ? (
                  <iframe
                    ref={frameRef}
                    title="Sandbox preview"
                    sandbox="allow-scripts allow-modals allow-forms"
                    referrerPolicy="no-referrer"
                    srcDoc={session.doc}
                    onLoad={() => {
                      setLoadedRun(session.id);
                      setLastRunMs(Math.max(1, Math.round(performance.now() - session.startedAt)));
                    }}
                    className="size-full border-0 bg-white"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center px-5 text-center text-[12px] text-neutral-500">
                    Add a file to see a preview.
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Console */}
          <section aria-label="Console" className="flex shrink-0 flex-col border-t border-border/70 bg-background">
            <div className="flex h-7 shrink-0 items-center gap-2 px-2">
              <button
                type="button"
                onClick={() => patchPrefs({ consoleOpen: !prefs.consoleOpen })}
                aria-expanded={prefs.consoleOpen}
                className="inline-flex items-center gap-1.5 rounded px-1 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground outline-none transition hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
              >
                <ChevronDown size={12} className={cn("transition-transform duration-150", !prefs.consoleOpen && "-rotate-90")} />
                <Terminal size={11} />
                Console
                {visibleLines.length > 0 && (
                  <span
                    className={cn(
                      "rounded-full px-1.5 py-px font-mono text-[9.5px] normal-case tracking-normal",
                      errorCount > 0 ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground",
                    )}
                  >
                    {errorCount > 0 ? `${errorCount} error${errorCount === 1 ? "" : "s"}` : visibleLines.length}
                  </span>
                )}
              </button>
              <div className="ml-auto flex items-center gap-0.5">
                <button
                  type="button"
                  onClick={() => void copyConsole()}
                  disabled={visibleLines.length === 0}
                  aria-label="Copy console output"
                  title="Copy console output"
                  className={cn(iconButton, "size-6")}
                >
                  {copiedConsole ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                </button>
                <button
                  type="button"
                  onClick={() => setConsoleLines([])}
                  disabled={visibleLines.length === 0}
                  aria-label="Clear console"
                  title="Clear console"
                  className={cn(iconButton, "size-6")}
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
            <AnimatePresence initial={false}>
              {prefs.consoleOpen && (
                <motion.div
                  key="console-body"
                  initial={noMotion ? false : { height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={noMotion ? { opacity: 0, transition: { duration: 0 } } : { height: 0, opacity: 0 }}
                  transition={noMotion ? { duration: 0 } : { duration: 0.18, ease: PANEL_EASE }}
                  className="overflow-hidden"
                >
                  <div
                    ref={consoleRef}
                    role="log"
                    aria-label="Console output"
                    className="scroll-slim h-[92px] overflow-y-auto border-t border-border/60 px-1 py-1 sm:h-[116px]"
                  >
                    {visibleLines.length === 0 ? (
                      <p className="px-1.5 py-1 font-mono text-[11px] text-muted-foreground/60">
                        {running ? "Running…" : "console.log output and errors appear here."}
                      </p>
                    ) : (
                      visibleLines.map((line) => (
                        <div
                          key={line.id}
                          className={cn(
                            "flex items-start gap-1.5 rounded px-1.5 py-0.5 font-mono text-[11px] leading-[1.55]",
                            line.level === "error"
                              ? "bg-destructive/[0.07] text-destructive"
                              : line.level === "warn"
                                ? "bg-amber-500/[0.08] text-amber-800 dark:text-amber-300"
                                : "text-foreground/80",
                          )}
                        >
                          <span aria-hidden className="w-3 shrink-0 text-center opacity-60">
                            {line.level === "error" ? "✕" : line.level === "warn" ? "!" : line.level === "info" ? "i" : "›"}
                          </span>
                          <span className="min-w-0 flex-1 whitespace-pre-wrap break-words">{line.text}</span>
                          {line.count > 1 && (
                            <span className="shrink-0 rounded-full bg-foreground/10 px-1.5 text-[9.5px] leading-[1.7]" title="Repeated">
                              {line.count}
                            </span>
                          )}
                          {line.file && line.line !== null && (
                            <button
                              type="button"
                              onClick={() => reveal(line.file as string, line.line as number)}
                              title="Jump to this line"
                              className="shrink-0 rounded px-1 text-[10px] text-muted-foreground underline-offset-2 outline-none transition hover:bg-accent hover:text-foreground hover:underline focus-visible:ring-2 focus-visible:ring-ring"
                            >
                              {line.file}:{line.line}
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        </div>
      </div>
    </motion.aside>
  );
}
