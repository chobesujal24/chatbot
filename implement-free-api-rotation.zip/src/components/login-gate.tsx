"use client";

import { useState } from "react";
import { BrandLockup } from "./logo";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export default function LoginGate({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
        setError(data?.error?.message ?? "Incorrect passcode.");
        return;
      }
      onSuccess();
    } catch {
      setError("Could not reach the server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center bg-background px-5">
      <div className="w-full max-w-sm">
        <h1>
          <BrandLockup size="lg" />
        </h1>
        <p className="mt-2 text-[14px] text-muted-foreground">
          This workspace is protected. Enter the passcode to continue.
        </p>
        <div className="mt-7 space-y-3">
          <Input
            type="password"
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void submit();
            }}
            placeholder="Passcode"
            className="h-11 text-[14px]"
          />
          {error && <p className="text-[13px] text-destructive">{error}</p>}
          <Button className="w-full" disabled={!password || loading} onClick={() => void submit()}>
            {loading ? "Checking…" : "Continue"}
          </Button>
        </div>
      </div>
    </div>
  );
}
