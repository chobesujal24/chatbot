"use client";

import Link from "next/link";
import {
  ArrowDownToLine, ChevronRight, Code2, Copy, Ellipsis, FileText, HelpCircle,
  Keyboard, Link2, PanelLeft, Pencil, Pin, PinOff, Search, Settings2, Trash2,
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { AgentIcon } from "./agent-icon";
import ContextMeter from "./context-meter";
import { useShortcutKey } from "@/lib/use-shortcut-key";
import { cn } from "@/lib/utils";
import type { Agent, ConversationContext } from "@/lib/types";

interface HeaderProps {
  title: string | null;
  activeId: string | null;
  isHome?: boolean;
  pinned: boolean;
  sidebarOpen: boolean;
  sidebarCollapsed?: boolean;
  selectedAgent: Agent | null;
  model: string;
  providerLabel: string;
  hasProvider: boolean;
  onToggleSidebar: () => void;
  onOpenPalette: () => void;
  onOpenShortcuts: () => void;
  onOpenAbout?: () => void;
  onShare: () => void;
  onExport: (format: "md" | "json") => void;
  onFork: () => void;
  onRename: () => void;
  onTogglePin: () => void;
  onDelete: () => void;
  onOpenSettings: () => void;
  context: ConversationContext | null;
  compacting: boolean;
  onCompact: () => void;
  onContextOverride: (patch: Record<string, unknown>) => void;
  onContextReset: () => void;
  showMeter?: boolean;
  codePanelOpen?: boolean;
  onToggleCodePanel?: () => void;
}

export default function Header(props: HeaderProps) {
  const isHome = Boolean(props.isHome);
  const shortcut = useShortcutKey();
  return (
    <TooltipProvider delayDuration={250}>
      <header className={cn("workspace-header @container/header relative z-20", isHome && "is-home")}>
        <div className="flex min-w-0 items-center gap-2.5">
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" onClick={props.onToggleSidebar} aria-label="Open sidebar" className="header-icon lg:hidden">
                <PanelLeft size={17} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Toggle sidebar <kbd className="ml-2 opacity-60">{shortcut} B</kbd></TooltipContent>
          </Tooltip>
          {isHome ? (
            <div className="flex min-w-0 items-center gap-2 text-[12px]">
              <span className="hidden text-muted-foreground @lg/header:inline">Workspace</span>
              <ChevronRight size={12} className="hidden text-muted-foreground/50 @lg/header:inline" aria-hidden />
              <span className="truncate font-medium text-foreground/85">New chat</span>
            </div>
          ) : (
            <div className="flex min-w-0 items-center gap-2.5">
              <h1 className="min-w-0 truncate text-[13px] font-medium" title={props.title ?? undefined}>{props.title ?? "New conversation"}</h1>
              {props.pinned && <Pin size={12} className="shrink-0 text-brand" aria-label="Pinned conversation" />}
              {props.selectedAgent && <span className="hidden shrink-0 items-center gap-1.5 border-l border-border pl-2.5 text-[11.5px] text-muted-foreground @xl/header:inline-flex"><AgentIcon icon={props.selectedAgent.icon} size={12} />{props.selectedAgent.name}</span>}
            </div>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-1.5">
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" onClick={props.onOpenPalette} aria-label="Search conversations" className={cn("header-icon", isHome && "lg:hidden")}>
                <Search size={15} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Search <kbd className="ml-2 opacity-60">{shortcut} K</kbd></TooltipContent>
          </Tooltip>
          {props.onToggleCodePanel && (
            <button type="button" onClick={props.onToggleCodePanel} aria-label={props.codePanelOpen ? "Close code workspace" : "Open code workspace"} aria-pressed={Boolean(props.codePanelOpen)} className="header-editor">
              <Code2 size={14} strokeWidth={1.6} />
              <span className="hidden @sm/header:inline">{props.codePanelOpen ? "Close editor" : "Open editor"}</span>
            </button>
          )}

          {!isHome && props.showMeter !== false && (
            <div className="hidden @sm/header:block">
              <ContextMeter data={props.context} busy={false} compacting={props.compacting} onCompact={props.onCompact} onOverride={props.onContextOverride} onReset={props.onContextReset} />
            </div>
          )}
          {!isHome && props.activeId && (
            <Tooltip>
              <TooltipTrigger asChild><button type="button" onClick={props.onShare} aria-label="Share conversation" className="header-icon hidden @lg/header:inline-flex"><Link2 size={15} /></button></TooltipTrigger>
              <TooltipContent side="bottom">Share conversation</TooltipContent>
            </Tooltip>
          )}

          {isHome ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild><button type="button" aria-label="Help and settings" className="header-icon"><HelpCircle size={16} strokeWidth={1.6} /></button></DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 p-1.5">
                <DropdownMenuItem onSelect={props.onOpenShortcuts}><Keyboard size={15} /> Keyboard shortcuts</DropdownMenuItem>
                {props.onOpenAbout && <DropdownMenuItem onSelect={props.onOpenAbout}><HelpCircle size={15} /> About Nova</DropdownMenuItem>}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link href="/settings"><Settings2 size={15} /> Workspace settings</Link></DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild><button type="button" aria-label="Conversation options" className="header-icon"><Ellipsis size={17} /></button></DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 p-1.5">
                <DropdownMenuItem onSelect={props.onRename} disabled={!props.activeId}><Pencil size={14} /> Rename conversation</DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onTogglePin} disabled={!props.activeId}>{props.pinned ? <PinOff size={14} /> : <Pin size={14} />}{props.pinned ? "Unpin conversation" : "Pin conversation"}</DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onFork} disabled={!props.activeId}><Copy size={14} /> Duplicate conversation</DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onShare} disabled={!props.activeId}><Link2 size={14} /> Share conversation</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => props.onExport("md")} disabled={!props.activeId}><FileText size={14} /> Export Markdown</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => props.onExport("json")} disabled={!props.activeId}><ArrowDownToLine size={14} /> Export JSON</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={props.onOpenSettings}><Settings2 size={14} /> Model settings</DropdownMenuItem>
                <DropdownMenuItem onSelect={props.onOpenShortcuts}><Keyboard size={14} /> Keyboard shortcuts</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem variant="destructive" disabled={!props.activeId} onSelect={props.onDelete}><Trash2 size={14} /> Delete conversation</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </header>
    </TooltipProvider>
  );
}
