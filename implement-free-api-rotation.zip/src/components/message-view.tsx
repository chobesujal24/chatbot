"use client";

import { useState, type ReactNode } from "react";
import {
  IconCheck,
  IconClose,
  IconCopy,
  IconMemory,
  IconPencil,
  IconRefresh,
  IconSpark,
  IconThumbDown,
  IconThumbUp,
  IconTrash,
} from "./icons";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "./ai-elements/conversation";
import { Shimmer } from "./ai-elements/shimmer";
import { Markdown } from "./markdown";
import { Logo } from "./logo";
import ToolCalls, { type ToolCallView } from "./tool-calls";
import { Button } from "./ui/button";
import { formatDuration, formatTokens, shortTime } from "@/lib/format";
import { stripAttachedBlocks } from "@/lib/offline";
import type { ChatMessage } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-client";
import { cn } from "@/lib/utils";

interface MessageViewProps {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamingText: string;
  streamingTools: ToolCallView[];
  pendingUser: string | null;
  feedback: Record<string, "up" | "down">;
  prefs: Preferences;
  onFeedback: (id: string, rating: "up" | "down" | null) => void;
  onCopy: (text: string) => void;
  onEditSubmit: (id: string, content: string) => void;
  onRegenerate: () => void;
  onDelete: (id: string) => void;
}

function ContextChips({ meta }: { meta?: ChatMessage["contextMeta"] }) {
  if (!meta) return null;
  const memories = meta.injectedMemoryIds?.length ?? 0;
  const usedSkills = meta.usedSkillNames?.length ?? 0;
  if (!memories && !usedSkills && !meta.summarizedMessages && !meta.compacted) return null;
  return (
    <div className="mb-2.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
      {usedSkills > 0 && (
        <span className="inline-flex items-center gap-1 rounded-full border border-purple-500/25 bg-purple-500/10 px-2.5 py-0.5 text-purple-700 dark:text-purple-300">
          <IconSpark size={10} className="text-purple-500" />
          <span>{meta.usedSkillNames.slice(0, 2).join(", ")}</span>
          {usedSkills > 2 ? <span>+{usedSkills - 2}</span> : null}
        </span>
      )}
      {memories > 0 && (
        <span
          className="inline-flex items-center gap-1 rounded-full border border-teal-500/25 bg-teal-500/10 px-2.5 py-0.5 text-teal-700 dark:text-teal-300"
          title="Memories injected into this turn"
        >
          <IconMemory size={10} className="text-teal-500" />
          <span>{memories} memor{memories === 1 ? "y" : "ies"} recalled</span>
        </span>
      )}
      {meta.compacted && (
        <span
          className="inline-flex items-center gap-1 rounded-full border border-brand/25 bg-brand/10 px-2.5 py-0.5 text-brand"
          title="Older messages were folded into a summary for this reply"
        >
          <span>compacted {meta.summarizedMessages} turn(s)</span>
        </span>
      )}
    </div>
  );
}

function ActionButton({
  label,
  onClick,
  active,
  activeClassName,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  activeClassName?: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "flex size-7 items-center justify-center rounded-lg border border-transparent outline-none transition-colors",
        active
          ? activeClassName ?? "bg-accent text-foreground"
          : "text-muted-foreground hover:border-border/60 hover:bg-accent/80 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

export default function MessageView(props: MessageViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const lastAssistantId = [...props.messages].reverse().find((m) => m.role === "assistant")?.id;
  const { feedback, prefs } = props;

  const copy = (id: string, text: string) => {
    props.onCopy(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1400);
  };

  const submitEdit = (id: string) => {
    props.onEditSubmit(id, draft);
    setEditingId(null);
  };

  return (
    <Conversation className="min-h-0 flex-1">
      <ConversationContent
        className={cn(
          // Size container: narrow threads (phones, or a docked code panel) drop
          // the avatar gutter so replies get the full width.
          "nova-thread @container mx-auto w-full px-4 pb-8 pt-8 sm:px-6",
          prefs.density === "compact" ? "gap-6" : "gap-9",
        )}
      >
        {props.messages.map((message) => {
          const isEditing = editingId === message.id;

          if (message.role === "user") {
            const visibleUserText = stripAttachedBlocks(message.content) || message.content;
            return (
              <div key={message.id} className="animate-message-in group flex flex-col items-end">
                {isEditing ? (
                  <div className="w-full max-w-[88%] rounded-2xl border border-brand/30 bg-card p-3.5 shadow-sm ring-2 ring-brand/10">
                    <textarea
                      autoFocus
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          submitEdit(message.id);
                        }
                        if (e.key === "Escape") setEditingId(null);
                      }}
                      rows={Math.min(8, Math.max(2, draft.split("\n").length))}
                      className="scroll-slim w-full resize-none bg-transparent px-2 py-1 text-[15px] leading-relaxed outline-none"
                    />
                    <div className="mt-2.5 flex justify-end gap-2 border-t pt-2.5">
                      <Button size="xs" variant="ghost" onClick={() => setEditingId(null)}>
                        <IconClose size={13} /> Cancel
                      </Button>
                      <Button size="xs" onClick={() => submitEdit(message.id)}>
                        Save & resend
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-br-md border border-border/70 bg-surface-2 px-4 py-2.5 text-[15px] leading-relaxed shadow-2xs [overflow-wrap:anywhere]">
                    {visibleUserText}
                  </div>
                )}

                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-2 flex flex-wrap justify-end gap-1.5">
                    {message.attachments.map((a) => (
                      <span
                        key={a.name}
                        className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-2 py-1 font-mono text-[11px] text-muted-foreground shadow-2xs"
                      >
                        <span>{a.name}</span>
                        <span className="text-[10px] opacity-70">
                          ({Math.round(a.size / 1024 * 10) / 10} KB)
                        </span>
                      </span>
                    ))}
                  </div>
                )}

                {!isEditing && (
                  <div className="mt-1.5 flex items-center gap-0.5 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
                    <ActionButton label="Copy text" onClick={() => copy(message.id, visibleUserText)}>
                      {copiedId === message.id ? <IconCheck size={13} className="text-emerald-500" /> : <IconCopy size={13} />}
                    </ActionButton>
                    <ActionButton
                      label="Edit and resend"
                      onClick={() => {
                        setEditingId(message.id);
                        setDraft(visibleUserText);
                      }}
                    >
                      <IconPencil size={13} />
                    </ActionButton>
                    <ActionButton label="Delete turn" onClick={() => props.onDelete(message.id)}>
                      <IconTrash size={13} />
                    </ActionButton>
                  </div>
                )}
              </div>
            );
          }

          const calls: ToolCallView[] = (message.toolCalls ?? []).map((c) => ({
            id: c.id,
            name: c.name,
            input: c.input,
            output: c.output,
            status: c.status === "error" ? "error" : "done",
          }));
          const isLast = message.id === lastAssistantId;
          const usage = message.usage && message.usage.totalTokens > 0 ? message.usage : null;

          return (
            <div key={message.id} className="animate-message-in group flex gap-3.5">
              <Logo size={28} className="mt-1 hidden shrink-0 @md:inline-flex" />
              <div className="min-w-0 flex-1">
                {/* Assistant Header */}
                <div className="mb-1.5 flex items-baseline gap-2">
                  <Logo size={16} className="self-center @md:hidden" />
                  <span className="text-[13px] font-semibold tracking-tight text-foreground">
                    Nova
                  </span>
                  {message.model && (
                    <span className="rounded bg-muted/60 px-1.5 py-px font-mono text-[10.5px] text-muted-foreground">
                      {message.model}
                    </span>
                  )}
                  {prefs.showTimestamps && (
                    <span className="font-mono text-[10.5px] text-muted-foreground">
                      {shortTime(message.createdAt)}
                    </span>
                  )}
                </div>

                {/* Collapsible tool activity */}
                {prefs.showThinking && <ToolCalls calls={calls} />}

                {/* Context chips */}
                <ContextChips meta={message.contextMeta} />

                {/* Markdown Prose */}
                <Markdown content={message.content} />

                {/* Action buttons & usage footer */}
                <div
                  className={cn(
                    "mt-2.5 flex flex-wrap items-center gap-1 transition-opacity focus-within:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100",
                    isLast && !props.isStreaming ? "opacity-100" : "opacity-0",
                  )}
                >
                  <ActionButton label="Copy response" onClick={() => copy(message.id, message.content)}>
                    {copiedId === message.id ? <IconCheck size={13} className="text-emerald-500" /> : <IconCopy size={13} />}
                  </ActionButton>
                  <ActionButton
                    label="Good response"
                    active={feedback[message.id] === "up"}
                    activeClassName="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20"
                    onClick={() => props.onFeedback(message.id, feedback[message.id] === "up" ? null : "up")}
                  >
                    <IconThumbUp size={13} />
                  </ActionButton>
                  <ActionButton
                    label="Bad response"
                    active={feedback[message.id] === "down"}
                    activeClassName="bg-destructive/10 text-destructive border-destructive/20"
                    onClick={() =>
                      props.onFeedback(message.id, feedback[message.id] === "down" ? null : "down")
                    }
                  >
                    <IconThumbDown size={13} />
                  </ActionButton>
                  {isLast && (
                    <ActionButton label="Regenerate" onClick={props.onRegenerate}>
                      <IconRefresh size={13} />
                    </ActionButton>
                  )}
                  <ActionButton label="Delete turn" onClick={() => props.onDelete(message.id)}>
                    <IconTrash size={13} />
                  </ActionButton>

                  {/* Token & duration metrics */}
                  {prefs.showTokenUsage && usage && (
                    <span className="ml-2 font-mono text-[10.5px] text-muted-foreground">
                      {formatTokens(usage.totalTokens)} tok · {formatDuration(usage.durationMs)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {props.pendingUser && (
          <div className="animate-message-in flex justify-end">
            <div className="max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-br-md border border-border/70 bg-surface-2 px-4 py-2.5 text-[15px] leading-relaxed shadow-2xs [overflow-wrap:anywhere]">
              {props.pendingUser}
            </div>
          </div>
        )}

        {props.isStreaming && (
          <div className="animate-message-in flex gap-3.5">
            <Logo size={28} className="mt-1 shrink-0 hidden @md:inline-flex" glow />
            <div className="min-w-0 flex-1">
              <div className="mb-1.5 flex items-center gap-2">
                <span className="text-[13px] font-semibold text-foreground">Nova</span>
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-75" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-brand" />
                </span>
                <span className="font-mono text-[10.5px] text-muted-foreground">Streaming…</span>
              </div>

              {prefs.showThinking && <ToolCalls calls={props.streamingTools} />}
              {props.streamingText ? (
                <Markdown content={props.streamingText} streaming />
              ) : (
                props.streamingTools.every((t) => t.status !== "running") && (
                  <Shimmer className="text-[14.5px]" duration={1.6}>
                    Reasoning & preparing reply…
                  </Shimmer>
                )
              )}
            </div>
          </div>
        )}
      </ConversationContent>
      <ConversationScrollButton className="bottom-5 border shadow-md" />
    </Conversation>
  );
}
