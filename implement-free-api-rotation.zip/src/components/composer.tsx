"use client";

import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ChangeEvent,
  type KeyboardEvent,
} from "react";
import { toast } from "sonner";
import { ArrowUp, Check, ChevronDown, Code2, FileText, Loader2, Paperclip, Plus, Square, Upload, X } from "lucide-react";
import { AgentIcon } from "./agent-icon";
import { ProviderLogo } from "./provider-logo";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import type { Agent, ClientAttachment } from "@/lib/types";
import type { Preferences } from "@/lib/preferences-client";
import { attachmentBytes, MAX_ATTACHMENTS, MAX_PROMPT_LENGTH, mergeAttachments, TEXT_FILE_PATTERN } from "@/lib/composer-state";
import { useShortcutKey } from "@/lib/use-shortcut-key";
import { cn } from "@/lib/utils";

export interface ComposerProps {
  variant: "hero" | "dock";
  onSend: (text: string, attachments: ClientAttachment[]) => void;
  isStreaming: boolean;
  onStop: () => void;
  agents: Agent[];
  selectedAgent: Agent | null;
  onSelectAgent: (id: string) => void;
  onOpenAgents: () => void;
  model: string;
  providerId?: string;
  providerLabel: string;
  hasProvider: boolean;
  onOpenSettings: () => void;
  onOpenConnection?: () => void;
  onOpenTemplates?: () => void;
  onOpenCodeWorkspace?: () => void;
  prefs: Preferences;
  prefill?: { text: string; nonce: number } | null;
  onPrefillConsumed?: () => void;
  draftKey?: string | null;
  incomingAttachments?: ClientAttachment[] | null;
  onIncomingAttachmentsConsumed?: () => void;
}

const DRAFT_KEY = "nova-draft";
const ACCEPT = ".txt,.md,.markdown,.json,.csv,.tsv,.log,.js,.mjs,.cjs,.jsx,.ts,.tsx,.py,.rs,.go,.java,.css,.html,.htm,.yml,.yaml,.sql,.xml,.env,.toml";

function readDraft(key: string): string {
  try {
    return window.localStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}

function removeDraft(key: string) {
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* A blocked or full storage area must not prevent sending a message. */
  }
}

export default function Composer(props: ComposerProps) {
  const [draft, setDraft] = useState({ key: "", text: "" });
  const [attachments, setAttachments] = useState<ClientAttachment[]>([]);
  const [dragging, setDragging] = useState(false);
  const [reading, setReading] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const scopeRef = useRef("");
  const dragDepth = useRef(0);
  const shortcut = useShortcutKey();
  const hintId = useId();
  const hero = props.variant === "hero";
  const draftStorageKey = `${DRAFT_KEY}:${props.draftKey ?? "new"}`;
  const text = draft.key === draftStorageKey ? draft.text : "";
  const limitKb = props.prefs.attachmentLimitKb || 60;

  const setText = useCallback((value: string) => setDraft({ key: draftStorageKey, text: value }), [draftStorageKey]);

  // Only load when the conversation changes. Toggling autosave must not erase
  // a draft the user is currently writing. Saving is gated by the loaded key.
  useEffect(() => {
    if (scopeRef.current === draftStorageKey) return;
    scopeRef.current = draftStorageKey;
    setDraft({ key: draftStorageKey, text: props.prefs.autosaveDrafts ? readDraft(draftStorageKey) : "" });
    setAttachments([]);
  }, [draftStorageKey, props.prefs.autosaveDrafts]);

  useEffect(() => {
    if (!props.prefs.autosaveDrafts || draft.key !== draftStorageKey) return;
    const timer = setTimeout(() => {
      try {
        if (draft.text.trim()) window.localStorage.setItem(draftStorageKey, draft.text);
        else window.localStorage.removeItem(draftStorageKey);
      } catch {
        /* Drafts still work in-memory when local storage is unavailable. */
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [draft, draftStorageKey, props.prefs.autosaveDrafts]);

  useLayoutEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 240)}px`;
  }, [text, attachments.length]);

  // Don't open a phone's keyboard merely by visiting the page.
  useEffect(() => {
    if (!hero || !window.matchMedia("(pointer: fine)").matches) return;
    const frame = requestAnimationFrame(() => textareaRef.current?.focus({ preventScroll: true }));
    return () => cancelAnimationFrame(frame);
  }, [hero]);

  const { prefill, onPrefillConsumed } = props;
  useEffect(() => {
    if (!prefill) return;
    setText(prefill.text);
    const frame = requestAnimationFrame(() => {
      textareaRef.current?.focus({ preventScroll: true });
      textareaRef.current?.setSelectionRange(prefill.text.length, prefill.text.length);
      onPrefillConsumed?.();
    });
    return () => cancelAnimationFrame(frame);
  }, [prefill, onPrefillConsumed, setText]);

  const addAttachments = useCallback((incoming: ClientAttachment[]) => {
    const result = mergeAttachments(attachments, incoming, limitKb * 1024);
    setAttachments(result.files);
    for (const name of result.oversized) toast.error(`${name} exceeds the ${limitKb} KB file limit.`);
    if (result.overflow) toast.message(`You can attach up to ${MAX_ATTACHMENTS} files. Remove one to add another.`);
  }, [attachments, limitKb]);

  const { incomingAttachments, onIncomingAttachmentsConsumed } = props;
  useEffect(() => {
    if (!incomingAttachments?.length) return;
    addAttachments(incomingAttachments);
    onIncomingAttachmentsConsumed?.();
  }, [incomingAttachments, onIncomingAttachmentsConsumed, addAttachments]);

  const overLimit = text.length > MAX_PROMPT_LENGTH;
  const canSend = (Boolean(text.trim()) || attachments.length > 0) && !props.isStreaming && !reading && !overLimit;

  const submit = () => {
    if (!canSend) return;
    const oversized = attachments.find((file) => attachmentBytes(file.content) > limitKb * 1024);
    if (oversized) {
      toast.error(`${oversized.name} exceeds your current ${limitKb} KB attachment limit.`);
      return;
    }
    const value = text.trim() || "Please review the attached file(s).";
    props.onSend(value, attachments);
    setText("");
    setAttachments([]);
    removeDraft(draftStorageKey);
    textareaRef.current?.focus({ preventScroll: true });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key !== "Enter" || event.shiftKey || event.nativeEvent.isComposing) return;
    if (props.prefs.sendOnEnter || event.metaKey || event.ctrlKey) {
      event.preventDefault();
      submit();
    }
  };

  const ingestFiles = async (files: File[]) => {
    if (!files.length) return;
    const targetKey = draftStorageKey;
    setReading(true);
    try {
      const next: ClientAttachment[] = [];
      for (const file of files.slice(0, 20)) {
        if (!TEXT_FILE_PATTERN.test(file.name)) {
          toast.error(`${file.name}: please choose a text or code file.`);
          continue;
        }
        if (file.size > limitKb * 1024) {
          toast.error(`${file.name} exceeds the ${limitKb} KB file limit.`);
          continue;
        }
        next.push({ name: file.name, content: await file.text() });
      }
      // A slow file read must not attach to a different conversation.
      if (scopeRef.current === targetKey && next.length) addAttachments(next);
    } catch {
      toast.error("That file couldn't be read. Please try again.");
    } finally {
      setReading(false);
    }
  };

  const onFiles = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const files = Array.from(input.files ?? []);
    input.value = "";
    await ingestFiles(files);
  };

  const card = (
    <div
      className={cn("prompt-composer", hero && "is-hero", dragging && "is-dragging", overLimit && "is-invalid")}
      onDragEnter={(event) => {
        if (!Array.from(event.dataTransfer.types).includes("Files")) return;
        event.preventDefault();
        dragDepth.current += 1;
        setDragging(true);
      }}
      onDragOver={(event) => {
        if (Array.from(event.dataTransfer.types).includes("Files")) event.preventDefault();
      }}
      onDragLeave={(event) => {
        event.preventDefault();
        dragDepth.current = Math.max(0, dragDepth.current - 1);
        if (dragDepth.current === 0) setDragging(false);
      }}
      onDrop={(event) => {
        if (!event.dataTransfer.files.length) return;
        event.preventDefault();
        dragDepth.current = 0;
        setDragging(false);
        void ingestFiles(Array.from(event.dataTransfer.files));
      }}
    >
      {dragging && (
        <div className="composer-dropzone">
          <Upload size={23} strokeWidth={1.5} />
          <p className="font-medium">Drop your files here</p>
          <p className="text-[12px] text-muted-foreground">Up to 5 text or code files · {limitKb} KB each</p>
        </div>
      )}

      {attachments.length > 0 && (
        <div className="composer-files" aria-label="Attached files">
          {attachments.map((file) => (
            <div key={file.name} className="composer-file">
              <FileText size={15} strokeWidth={1.6} className="shrink-0 text-muted-foreground" aria-hidden />
              <div className="min-w-0">
                <span className="block max-w-[164px] truncate text-[12px] font-medium" title={file.name}>{file.name}</span>
                <span className="block text-[10.5px] text-muted-foreground">{Math.max(0.1, attachmentBytes(file.content) / 1024).toFixed(1)} KB</span>
              </div>
              <button type="button" aria-label={`Remove ${file.name}`} onClick={() => setAttachments((prev) => prev.filter((item) => item.name !== file.name))} className="composer-remove-file">
                <X size={12} aria-hidden />
              </button>
            </div>
          ))}
        </div>
      )}

      <textarea
        ref={textareaRef}
        rows={1}
        value={text}
        onChange={(event) => setText(event.target.value)}
        onKeyDown={onKeyDown}
        aria-label="Message prompt"
        aria-invalid={overLimit || undefined}
        aria-describedby={hintId}
        placeholder={hero ? "Ask anything, or describe what you’d like to do…" : "Reply to Nova…"}
        className="composer-input scroll-slim"
      />

      <div className="composer-toolbar">
        <div className="flex min-w-0 items-center gap-1">
          <input ref={fileRef} type="file" multiple accept={ACCEPT} onChange={(event) => void onFiles(event)} className="hidden" aria-label="Choose text or code files" tabIndex={-1} />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" aria-label="Add to message" title="Add files or use a prompt" className="composer-add" disabled={reading}>
                {reading ? <Loader2 size={18} className="animate-spin" /> : <Plus size={19} strokeWidth={1.6} />}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side={hero ? "bottom" : "top"} align="start" sideOffset={9} className="w-64 p-1.5">
              <DropdownMenuItem onSelect={() => fileRef.current?.click()} className="items-start rounded-md py-2">
                <Paperclip size={16} className="mt-0.5" />
                <span><span className="block text-[13px]">Attach files</span><span className="mt-0.5 block text-[11.5px] text-muted-foreground">Text or code · up to {limitKb} KB each</span></span>
              </DropdownMenuItem>
              {props.onOpenTemplates && <DropdownMenuItem onSelect={props.onOpenTemplates} className="rounded-md py-2 text-[13px]"><FileText size={15} /> Use a saved prompt</DropdownMenuItem>}
              {props.onOpenCodeWorkspace && <DropdownMenuItem onSelect={props.onOpenCodeWorkspace} className="rounded-md py-2 text-[13px]"><Code2 size={15} /> Open code workspace</DropdownMenuItem>}
            </DropdownMenuContent>
          </DropdownMenu>
          <span aria-hidden className="mx-1 h-4 w-px bg-border/75" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className="composer-agent" aria-label="Choose agent">
                {props.selectedAgent && <AgentIcon icon={props.selectedAgent.icon} size={14} />}
                <span className="max-w-[96px] truncate">{props.selectedAgent?.name ?? "General"}</span>
                <ChevronDown size={12} aria-hidden className="opacity-55" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side={hero ? "bottom" : "top"} align="start" sideOffset={9} className="w-72 p-1.5">
              <DropdownMenuLabel className="text-[11.5px] font-normal text-muted-foreground">Choose how Nova helps</DropdownMenuLabel>
              {props.agents.map((agent) => (
                <DropdownMenuItem key={agent.id} onSelect={() => props.onSelectAgent(agent.id)} className="items-start gap-2.5 rounded-md p-2.5">
                  <AgentIcon icon={agent.icon} size={15} className="mt-0.5" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between text-[13px] font-medium">{agent.name}{agent.id === props.selectedAgent?.id && <Check size={13} />}</span>
                    <span className="mt-0.5 line-clamp-2 block text-[11.5px] leading-relaxed text-muted-foreground">{agent.description || "A general-purpose assistant"}</span>
                  </span>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={props.onOpenAgents} className="rounded-md py-2 text-[12.5px]">Manage agents <ArrowUp size={12} className="ml-auto rotate-45" /></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex min-w-0 items-center gap-2">
          <button
            type="button"
            onClick={props.hasProvider ? props.onOpenSettings : (props.onOpenConnection ?? props.onOpenSettings)}
            className="composer-model"
            aria-label={props.hasProvider ? "Model and generation settings" : "Connect a model"}
            title={props.hasProvider ? `${props.providerLabel} · ${props.model}` : "Demo mode — no AI model is connected"}
          >
            {props.hasProvider && props.providerId && props.providerId !== "offline" ? (
              <ProviderLogo provider={props.providerId} size={13} variant="glyph" className="text-foreground/80" />
            ) : (
              <span aria-hidden className={cn("size-[5px] shrink-0 rounded-full", props.hasProvider ? "bg-emerald-600 dark:bg-emerald-400" : "bg-muted-foreground/65")} />
            )}
            <span className="truncate">{props.hasProvider ? props.model : "Demo mode"}</span>
            <ChevronDown size={12} className="shrink-0 opacity-55" aria-hidden />
          </button>
          {props.isStreaming ? (
            <button type="button" onClick={props.onStop} aria-label="Stop generation" title="Stop generation (Esc)" className="composer-send is-enabled">
              <Square size={13} fill="currentColor" />
            </button>
          ) : (
            <button type="button" onClick={submit} disabled={!canSend} aria-label="Send message" title={props.prefs.sendOnEnter ? "Send (Enter)" : `Send (${shortcut} + Enter)`} className={cn("composer-send", canSend && "is-enabled")}>
              <ArrowUp size={18} strokeWidth={1.8} />
            </button>
          )}
        </div>
      </div>
      <div id={hintId} className={cn("composer-input-hint", text.length <= 6500 && "sr-only")} aria-live="polite">
        {text.length > 6500 ? (
          <span className={overLimit ? "text-destructive" : "text-muted-foreground"}>
            {text.length.toLocaleString()} / {MAX_PROMPT_LENGTH.toLocaleString()} characters{overLimit ? " — shorten your message to send." : ""}
          </span>
        ) : (
          `${props.prefs.sendOnEnter ? "Enter" : `${shortcut} + Enter`} to send. Shift + Enter for a new line. You can attach up to 5 text or code files.`
        )}
      </div>
    </div>
  );

  if (hero) return card;
  return (
    <div className="composer-dock">
      <div className="nova-thread mx-auto w-full">
        {card}
        <p className="composer-disclaimer">
          {props.hasProvider ? "Check important details. AI can make mistakes." : "Demo replies are generated locally, not by an AI model."}
        </p>
      </div>
    </div>
  );
}
