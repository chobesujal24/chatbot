import type { RoutingSettings } from "@/lib/free-max/catalog";
export type View = "providers" | "chat" | "models" | "activity" | "keys" | "history";
export const TITLES: Record<View,string> = {providers:"Model providers",chat:"Chat playground",models:"Model library",activity:"Activity",keys:"API keys",history:"Chat history"};
export interface Connection {provider:string;ready:boolean;hasKey:boolean;fromEnv:boolean}
export interface ChatSummary {id:string;title:string;model:string|null;updatedAt:string;pinned:boolean}
export interface Run {id:string;provider:string;model:string;outcome:string;durationMs:number;tokens:number;attempts:{provider:string;status:number;note:string}[];createdAt:string}
export interface HubData {workspace:string;routing:RoutingSettings;history:ChatSummary[];runs:Run[];connections:Connection[]}
export interface ChatMessage {id:string;role:"user"|"assistant";content:string;model?:string|null}
export async function api<T>(url:string, options?:RequestInit):Promise<T> {
  const res=await fetch(url,{cache:"no-store",...options});
  const body=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(body.error?.message || `Request failed (${res.status}).`);
  return body as T;
}
export const post = <T,>(url:string,body:unknown) => api<T>(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
export const readableTime=(iso:string)=>new Date(iso).toLocaleString(undefined,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
