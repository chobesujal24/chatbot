import { KeyRound, KeySquare, Ticket, Boxes, Code2, Cpu, Hexagon, Layers3, Network, Orbit, Waves, Zap, type LucideIcon } from "lucide-react";
import type { CSSProperties } from "react";
import type { Access, FreeProvider } from "@/lib/free-max/catalog";
export function NovaMark({size=34}:{size?:number}) {
  return <svg width={size} height={size} viewBox="0 0 42 42" fill="currentColor" aria-hidden="true">{Array.from({length:12},(_,i)=><path key={i} d="M19.3 1.5h4.2L22.2 16h-3.1z" transform={`rotate(${i*30} 21 21)`}/>)}<circle cx="21" cy="21" r="6.4"/></svg>;
}
export function ProviderMark({p,size=43}:{p:FreeProvider;size?:number}) {
  const icons:Record<string,LucideIcon>={kilo:Code2,llm7:Zap,aion:Orbit,sambanova:Waves,modelscope:Boxes,siliconflow:Layers3,aihubmix:Network,requesty:Hexagon,aimlapi:Cpu,longcat:Waves,opencode:Code2};
  const paths:Record<string,string>={openrouter:"openrouter",mistral:"mistralai",google:"googlegemini",cloudflare:"cloudflare",nvidia:"nvidia",vercel:"vercel",ovh:"ovh",alibaba:"alibabacloud","ollama-cloud":"ollama",cohere:"cohere",cerebras:"cerebras"};
  const I=icons[p.id] || Hexagon;
  return <span aria-hidden="true" className={`provider-mark mark-${p.id}`} style={{"--mark":p.color,width:size,height:size} as CSSProperties}>{p.id==="groq"?<span className="groq-symbol">g</span>:p.id==="google"?<svg viewBox="0 0 32 32" width="75%" height="75%"><defs><linearGradient id="gemini-spectrum" x1="0" x2="1" y1="1" y2="0"><stop stopColor="#b4a0f9"/><stop offset=".46" stopColor="#a7b4ff"/><stop offset="1" stopColor="#63a7ff"/></linearGradient></defs><path fill="url(#gemini-spectrum)" d="M16 0C15 9 9 15 0 16c9 1 15 7 16 16 1-9 7-15 16-16C23 15 17 9 16 0Z"/></svg>:p.id==="mistral"?<svg viewBox="0 0 35 30" width="75%" height="70%">{["#ffcf5b","#ffb844","#ff9836","#f47732","#ed5939"].map((c,i)=><g key={i} fill={c}><rect x="1" y={i*6} width="6" height="6"/><rect x="25" y={i*6} width="6" height="6"/>{i===1||i===2?<><rect x="7" y={i*6} width="6" height="6"/><rect x="19" y={i*6} width="6" height="6"/></>:null}{i===2||i===3?<rect x="13" y={i*6} width="6" height="6"/>:null}</g>)}</svg>:paths[p.id]?<span className="mask-logo" style={{maskImage:`url(/marks/${paths[p.id]}.svg)`,WebkitMaskImage:`url(/marks/${paths[p.id]}.svg)`}}/>:p.id==="zai"?<b>Z</b>:<I size={size*.56} strokeWidth={1.7}/>}</span>;
}
export function AccessBadge({access,short=false}:{access:Access;short?:boolean}) {
 const Icon=access==="keyless"?KeySquare:access==="trial"?Ticket:KeyRound;
 return <span className={`access-badge access-${access}`}><Icon size={11}/>{access==="keyless"?"No sign-up":access==="trial"?"Trial credits":short?"Free key":"Free API key"}</span>;
}
