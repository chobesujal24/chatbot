"use client";

import { Markdown } from "./markdown";
import { Logo, NovaWordmark } from "./logo";
import type { Role } from "@/lib/types";

export interface SharedMessage {
  id: string;
  role: Role;
  content: string;
  createdAt: string;
}

export default function SharedConversation({
  title,
  messages,
}: {
  title: string;
  messages: SharedMessage[];
}) {
  return (
    <div className="min-h-dvh bg-background">
      <header className="flex h-14 items-center justify-between gap-3 border-b px-5">
        <div className="flex min-w-0 items-center gap-3">
          <Logo size={28} />
          <div className="min-w-0">
            <p className="truncate text-[14px] font-medium">{title}</p>
            <p className="text-[12px] text-muted-foreground">Shared read-only conversation</p>
          </div>
        </div>
        <NovaWordmark size="sm" className="hidden shrink-0 text-muted-foreground sm:inline-flex" />
      </header>
      <main className="mx-auto max-w-[768px] space-y-8 px-5 py-10">
        {messages.map((m) =>
          m.role === "user" ? (
            <div key={m.id} className="flex justify-end">
              <div className="max-w-[85%] whitespace-pre-wrap rounded-3xl rounded-br-lg bg-secondary px-5 py-3 text-[15px] leading-relaxed">
                {m.content}
              </div>
            </div>
          ) : (
            <div key={m.id} className="flex gap-4">
              <Logo size={28} className="mt-1" />
              <div className="min-w-0 flex-1">
                <Markdown content={m.content} />
              </div>
            </div>
          ),
        )}
        {messages.length === 0 && (
          <p className="text-center text-[14px] text-muted-foreground">
            This conversation is empty.
          </p>
        )}
      </main>
    </div>
  );
}
