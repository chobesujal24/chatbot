"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  CircleAlert,
  ExternalLink,
  Eye,
  EyeOff,
  Loader2,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Star,
  Trash2,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ActivePill, Field, Note, Panel } from "./ui";
import { ProviderLogo } from "@/components/provider-logo";
import { findProvider, providersForKind, type CredentialKind, type ProviderPreset } from "@/lib/providers";
import { cn } from "@/lib/utils";

export interface CredentialRow {
  id: string;
  provider: string;
  kind: CredentialKind;
  label: string;
  hasKey: boolean;
  keyPreview: string;
  baseURL: string | null;
  options: Record<string, unknown>;
  enabled: boolean;
  isActive: boolean;
  updatedAt: string;
}

interface Props {
  kind: CredentialKind;
  credentials: CredentialRow[];
  onChanged: () => void | Promise<void>;
  onUseModel?: (model: string, providerId: string) => void;
  defaultModel?: string;
  focusProvider?: string | null;
}

const GROUPS: Array<{ id: ProviderPreset["group"]; label: string }> = [
  { id: "hosted", label: "Hosted APIs" },
  { id: "local", label: "Local runtimes" },
  { id: "search", label: "Web search" },
  { id: "reader", label: "Page readers" },
];

interface TestState {
  ok: boolean;
  message: string;
  latencyMs?: number;
}

export default function SettingsProviders({
  kind,
  credentials,
  onChanged,
  onUseModel,
  defaultModel,
  focusProvider,
}: Props) {
  const presets = useMemo(() => providersForKind(kind), [kind]);
  const stored = useMemo(() => credentials.filter((c) => c.kind === kind), [credentials, kind]);
  const activeRow = useMemo(() => stored.find((c) => c.isActive && c.enabled) ?? null, [stored]);

  const initial =
    focusProvider && presets.some((p) => p.id === focusProvider)
      ? focusProvider
      : activeRow?.provider && presets.some((p) => p.id === activeRow.provider)
        ? activeRow.provider
        : (presets[0]?.id ?? "");

  const [selected, setSelected] = useState(initial);
  const [query, setQuery] = useState("");
  const [secret, setSecret] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [baseURL, setBaseURL] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [makeActive, setMakeActive] = useState(false);
  const [saving, setSaving] = useState(false);
  const [justSaved, setJustSaved] = useState(false);
  const [testing, setTesting] = useState(false);
  const [test, setTest] = useState<TestState | null>(null);
  const [models, setModels] = useState<string[]>([]);
  const [modelFilter, setModelFilter] = useState("");
  const [customModel, setCustomModel] = useState("");
  const [modelSource, setModelSource] = useState<"preset" | "provider">("preset");
  const [loadingModels, setLoadingModels] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [armedRemove, setArmedRemove] = useState(false);
  const [error, setError] = useState("");
  const panelRef = useRef<HTMLDivElement>(null);
  const savedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const syncedActive = useRef(false);

  useEffect(
    () => () => {
      if (savedTimer.current) clearTimeout(savedTimer.current);
    },
    [],
  );

  const preset = findProvider(selected);
  const row = stored.find((c) => c.provider === selected);
  const presetBase = preset?.baseURL ?? "";
  const savedBase = row?.baseURL ?? presetBase;

  useEffect(() => {
    if (focusProvider && presets.some((p) => p.id === focusProvider)) setSelected(focusProvider);
  }, [focusProvider, presets]);

  // Credentials arrive after first paint; jump to the active provider once so the
  // editor opens on the connection that actually serves traffic — not preset[0].
  useEffect(() => {
    if (syncedActive.current || focusProvider) return;
    if (activeRow && presets.some((p) => p.id === activeRow.provider)) {
      syncedActive.current = true;
      setSelected(activeRow.provider);
    }
  }, [activeRow, focusProvider, presets]);

  // Fresh form per provider: no stale keys, no stale test result.
  useEffect(() => {
    const current = stored.find((c) => c.provider === selected);
    const p = findProvider(selected);
    setSecret("");
    setShowKey(false);
    setBaseURL(current?.baseURL ?? (p?.baseURL ?? ""));
    setEnabled(current?.enabled ?? true);
    setMakeActive(current?.isActive ?? stored.length === 0);
    setTest(null);
    setError("");
    setArmedRemove(false);
    setModelFilter("");
    setModels(p?.models ?? []);
    setModelSource("preset");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected, row?.updatedAt]);

  const dirty =
    !row ||
    secret.trim() !== "" ||
    baseURL.trim() !== savedBase ||
    enabled !== (row?.enabled ?? true) ||
    makeActive !== (row?.isActive ?? false);

  const canSave = preset
    ? preset.requiresKey
      ? Boolean(secret.trim() || row?.hasKey) && dirty
      : Boolean(baseURL.trim() || presetBase) && dirty
    : false;

  const canTest = preset
    ? preset.requiresKey
      ? Boolean(secret.trim() || row?.hasKey)
      : Boolean(baseURL.trim() || presetBase)
    : false;

  const keyPrefixHint =
    secret.trim().length > 4 &&
    preset?.keyPrefix &&
    !secret.trim().startsWith(preset.keyPrefix)
      ? `${preset.label} keys typically start with "${preset.keyPrefix}". Double-check before saving.`
      : null;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return presets;
    return presets.filter(
      (p) => p.label.toLowerCase().includes(q) || p.notes.toLowerCase().includes(q) || p.id.includes(q),
    );
  }, [presets, query]);

  const groups = GROUPS.map((g) => ({ ...g, items: filtered.filter((p) => p.group === g.id) })).filter(
    (g) => g.items.length > 0,
  );

  const visibleModels = useMemo(() => {
    const q = modelFilter.trim().toLowerCase();
    const list = q ? models.filter((m) => m.toLowerCase().includes(q)) : models;
    return list.slice(0, 120);
  }, [models, modelFilter]);

  const save = async () => {
    if (!preset) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: preset.id,
          kind,
          label: preset.label,
          secret: secret.trim() || undefined,
          baseURL: baseURL.trim() || null,
          enabled,
          isActive: makeActive,
        }),
      });
      const data = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
      if (!res.ok) throw new Error(data?.error?.message ?? "Could not save.");
      setSecret("");
      setJustSaved(true);
      if (savedTimer.current) clearTimeout(savedTimer.current);
      savedTimer.current = setTimeout(() => setJustSaved(false), 1600);
      if (kind === "model" && makeActive && onUseModel && !defaultModel && preset.models[0]) {
        onUseModel(preset.models[0], preset.id);
      }
      toast.success(`${preset.label} saved`);
      await onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save.");
    } finally {
      setSaving(false);
    }
  };

  const runTest = async () => {
    if (!preset) return;
    setTesting(true);
    setTest(null);
    try {
      const res = await fetch("/api/credentials/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: preset.id,
          secret: secret.trim() || undefined,
          baseURL: baseURL.trim() || undefined,
        }),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; message?: string; latencyMs?: number } | null;
      setTest({
        ok: Boolean(data?.ok),
        message: data?.message ?? (data?.ok ? "Connected." : "Connection failed."),
        latencyMs: data?.latencyMs,
      });
    } catch (e) {
      setTest({ ok: false, message: e instanceof Error ? e.message : "Connection failed." });
    } finally {
      setTesting(false);
    }
  };

  const loadModels = async () => {
    if (!preset) return;
    setLoadingModels(true);
    try {
      const res = await fetch(`/api/credentials/test?provider=${encodeURIComponent(preset.id)}`, { cache: "no-store" });
      const data = (await res.json().catch(() => null)) as { models?: string[]; source?: "preset" | "provider" } | null;
      if (data?.models?.length) {
        setModels(data.models);
        setModelSource(data.source ?? "preset");
        if (data.source === "provider") {
          toast.success(`Loaded ${data.models.length} models from ${preset.label}`);
        }
      } else {
        toast.message("No live model list returned; save your key first or enter a model ID manually.");
      }
    } catch {
      toast.error("Could not load models.");
    } finally {
      setLoadingModels(false);
    }
  };

  const remove = async () => {
    if (!row) return;
    if (!armedRemove) {
      setArmedRemove(true);
      setTimeout(() => setArmedRemove(false), 4000);
      return;
    }
    setArmedRemove(false);
    setRemoving(true);
    try {
      const res = await fetch(`/api/credentials?id=${encodeURIComponent(row.id)}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Could not remove.");
      toast.success(`${row.label} removed`);
      await onChanged();
    } catch {
      setError("Could not remove this provider.");
    } finally {
      setRemoving(false);
    }
  };

  if (!preset) return null;

  const status = row?.hasKey
    ? { tone: "ok" as const, text: `Stored ${row.keyPreview}` }
    : row && !preset.requiresKey
      ? { tone: "ok" as const, text: "Configured (keyless)" }
      : preset.requiresKey
        ? { tone: "warn" as const, text: "No key stored" }
        : { tone: "neutral" as const, text: "No key required" };

  const kindTitle =
    kind === "model" ? "Model providers" : kind === "search" ? "Web search providers" : "Page readers";

  return (
    <div className="space-y-4">
      {/* Status banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-muted/30 px-4 py-2.5 text-[12.5px]">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "size-2 rounded-full",
              activeRow ? "bg-emerald-500" : "bg-amber-500",
            )}
          />
          <span className="font-medium text-foreground">{kindTitle}:</span>
          {activeRow ? (
            <span className="text-muted-foreground">
              <strong className="font-medium text-foreground">{activeRow.label}</strong> is active
              {kind === "model" && defaultModel ? (
                <>
                  {" "}
                  · default model <code className="rounded bg-card px-1.5 py-0.5 font-mono text-[11.5px]">{defaultModel}</code>
                </>
              ) : null}
            </span>
          ) : (
            <span className="text-muted-foreground">
              None active yet — select a provider below, add your key or endpoint, and mark it active.
            </span>
          )}
        </div>
        {activeRow && selected !== activeRow.provider && (
          <button
            type="button"
            onClick={() => setSelected(activeRow.provider)}
            className="text-[12px] font-medium text-brand hover:underline"
          >
            Jump to active →
          </button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,236px)_minmax(0,1fr)]">
        {/* Provider list */}
        <div className="min-w-0">
          <div className="relative mb-2.5">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`Filter ${presets.length} providers`}
              aria-label="Filter providers"
              className="h-9 pl-8 text-[12.5px]"
            />
          </div>
          <div className="scroll-slim flex gap-1 overflow-x-auto pb-1 lg:grid lg:max-h-[62vh] lg:auto-cols-fr lg:grid-cols-1 lg:gap-y-3 lg:overflow-y-auto lg:overflow-x-visible lg:pr-1">
            {groups.map((group) => (
              <div key={group.id} className="flex shrink-0 gap-1 lg:block lg:space-y-0.5">
                <p className="hidden px-2 pb-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground/70 lg:block">
                  {group.label}
                </p>
                {group.items.map((p) => {
                  const r = stored.find((c) => c.provider === p.id);
                  const active = selected === p.id;
                  const configured = Boolean(r && (r.hasKey || !p.requiresKey));
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        setSelected(p.id);
                        // The editor is not a scroll container; on narrow screens the
                        // list and editor stack, so bring the editor into view.
                        if (window.innerWidth < 1024) {
                          requestAnimationFrame(() =>
                            panelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
                          );
                        }
                      }}
                      aria-current={active ? "true" : undefined}
                      className={cn(
                        "relative isolate flex w-[178px] shrink-0 items-center gap-2.5 whitespace-nowrap rounded-xl px-2.5 py-2 text-left text-[12.5px] outline-none transition-colors lg:w-full",
                        active ? "font-medium text-foreground" : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {active && <ActivePill id={`prov-${kind}`} />}
                      <ProviderLogo provider={p.id} size={20} className="relative z-10" />
                      <span className="relative z-10 min-w-0 flex-1 truncate">{p.label}</span>
                      {r?.isActive && r.enabled && (
                        <span className="relative z-10 shrink-0" title="Active">
                          <Star size={11} className="fill-brand text-brand" />
                        </span>
                      )}
                      {configured && !(r?.isActive && r.enabled) && (
                        <span
                          className="relative z-10 size-1.5 shrink-0 rounded-full bg-emerald-500"
                          title="Configured"
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
            {groups.length === 0 && (
              <p className="px-2 py-6 text-[12.5px] text-muted-foreground">Nothing matches “{query}”.</p>
            )}
          </div>
        </div>

        {/* Provider editor */}
        <div ref={panelRef} className="min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={preset.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.3, 1] }}
              className="space-y-4"
            >
              <header className="flex flex-wrap items-center gap-3 rounded-2xl border bg-card px-4 py-3.5 shadow-xs">
                <ProviderLogo provider={preset.id} size={40} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-[16px] font-semibold tracking-tight">{preset.label}</h3>
                    <span
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium",
                        status.tone === "ok" && "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
                        status.tone === "warn" && "border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-400",
                        status.tone === "neutral" && "text-muted-foreground",
                      )}
                    >
                      <span
                        className={cn(
                          "size-1.5 rounded-full",
                          status.tone === "ok"
                            ? "bg-emerald-500"
                            : status.tone === "warn"
                              ? "bg-amber-500"
                              : "bg-muted-foreground",
                        )}
                      />
                      {status.text}
                    </span>
                    {preset.freeTier && (
                      <span className="rounded-full border bg-muted/40 px-2 py-0.5 text-[11px] text-muted-foreground">
                        {preset.freeTier}
                      </span>
                    )}
                  </div>
                  <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-muted-foreground">{preset.notes}</p>
                </div>
                <a
                  href={preset.docs}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[12px] font-medium text-muted-foreground transition hover:border-foreground/25 hover:text-foreground"
                >
                  {preset.requiresKey ? "Get API key" : "Docs"} <ExternalLink size={11} />
                </a>
              </header>

              <Panel title="Connection" hint="Credentials are encrypted with AES-256-GCM at rest and never exposed to client scripts.">
                <Field
                  label={preset.requiresKey ? "API key" : "API key (optional)"}
                  hint={
                    row?.hasKey
                      ? `Key on file (${row.keyPreview}). Paste a new key only if you want to replace it.`
                      : preset.requiresKey
                        ? "Required to authenticate requests to this provider."
                        : "Leave blank unless your local server or proxy requires bearer authentication."
                  }
                >
                  <div className="w-[min(340px,65vw)] space-y-1">
                    <div className="relative">
                      <Input
                        type={showKey ? "text" : "password"}
                        value={secret}
                        onChange={(e) => {
                          setSecret(e.target.value.slice(0, 500));
                          if (error) setError("");
                        }}
                        placeholder={row?.hasKey ? `Stored ${row.keyPreview} — paste to replace` : preset.keyPlaceholder}
                        className="h-9 pr-16 font-mono text-[12.5px]"
                        autoComplete="off"
                        spellCheck={false}
                        aria-label={`${preset.label} API key`}
                      />
                      <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-0.5">
                        {secret.length > 0 && (
                          <span className="font-mono text-[10.5px] text-muted-foreground">{secret.length}</span>
                        )}
                        <button
                          type="button"
                          onClick={() => setShowKey((v) => !v)}
                          aria-label={showKey ? "Hide key" : "Show key"}
                          className="rounded p-1 text-muted-foreground hover:text-foreground"
                        >
                          {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </div>
                    {keyPrefixHint && (
                      <p className="text-[11px] text-amber-700 dark:text-amber-400">{keyPrefixHint}</p>
                    )}
                  </div>
                </Field>

                <Field
                  label="Base URL"
                  hint="Override to route through a regional endpoint, gateway, proxy or self-hosted server."
                >
                  <div className="flex w-[min(340px,65vw)] items-center gap-1.5">
                    <Input
                      value={baseURL}
                      onChange={(e) => {
                        setBaseURL(e.target.value);
                        if (error) setError("");
                      }}
                      placeholder={presetBase || "https://api.example.com/v1"}
                      className="h-9 font-mono text-[12.5px]"
                      spellCheck={false}
                      aria-label={`${preset.label} base URL`}
                    />
                    {baseURL.trim() !== presetBase && presetBase && (
                      <button
                        type="button"
                        onClick={() => setBaseURL(presetBase)}
                        title="Reset to default base URL"
                        aria-label="Reset base URL to default"
                        className="shrink-0 rounded-md p-1.5 text-muted-foreground transition hover:bg-accent hover:text-foreground"
                      >
                        <RotateCcw size={13} />
                      </button>
                    )}
                  </div>
                </Field>

                <Field label="Enable connection" hint="Disabled providers remain saved but are skipped at runtime.">
                  <Switch checked={enabled} onCheckedChange={setEnabled} aria-label="Enable provider" />
                </Field>

                <Field
                  label="Set as active provider"
                  hint={
                    kind === "model"
                      ? "Active model provider serves chat, compaction and memory extraction."
                      : kind === "search"
                        ? "Active search provider serves the webSearch agent tool."
                        : "Active reader converts web pages into clean Markdown."
                  }
                >
                  <Switch checked={makeActive} onCheckedChange={setMakeActive} aria-label="Make active provider" />
                </Field>

                <div className="flex flex-wrap items-center gap-2 px-3 py-3">
                  <Button size="sm" onClick={() => void save()} disabled={!canSave || saving}>
                    {saving ? <Loader2 size={13} className="animate-spin" /> : justSaved ? <Check size={13} /> : null}
                    {justSaved ? "Saved" : !row ? "Connect & save" : dirty ? "Save connection" : "Up to date"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => void runTest()}
                    disabled={testing || !canTest}
                    title={!canTest ? "Enter an API key or base URL to test" : "Verify connectivity right now"}
                  >
                    {testing ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
                    Test connection
                  </Button>
                  {kind === "model" && preset.modelsPath && (
                    <Button size="sm" variant="ghost" onClick={() => void loadModels()} disabled={loadingModels}>
                      <RefreshCw size={13} className={cn(loadingModels && "animate-spin")} />
                      Load models
                    </Button>
                  )}
                  {row && (
                    <Button
                      size="sm"
                      variant={armedRemove ? "destructive" : "ghost"}
                      className={cn("ml-auto", !armedRemove && "text-muted-foreground hover:text-destructive")}
                      onClick={() => void remove()}
                      disabled={removing}
                    >
                      {removing ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                      {armedRemove ? "Confirm remove" : "Remove"}
                    </Button>
                  )}
                </div>

                {error && (
                  <div className="mx-3 mb-3 flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-[12.5px] text-destructive">
                    <CircleAlert size={13} /> {error}
                  </div>
                )}
              </Panel>

              <AnimatePresence>
                {test && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.22, ease: [0.22, 1, 0.3, 1] }}
                    className="overflow-hidden"
                  >
                    <Note tone={test.ok ? "ok" : "warn"}>
                      {test.message}
                      {test.latencyMs !== undefined && (
                        <span className="ml-1.5 font-mono text-[11.5px] opacity-80">({test.latencyMs} ms)</span>
                      )}
                    </Note>
                  </motion.div>
                )}
              </AnimatePresence>

              {kind === "model" && (
                <Panel
                  title="Models"
                  hint="Click a model to set it as your workspace default, or enter any model ID exposed by this endpoint."
                  actions={
                    <span className="font-mono text-[11px] text-muted-foreground">
                      {modelSource === "provider" ? "live" : "preset"} · {models.length}
                    </span>
                  }
                >
                  <div className="space-y-3 p-3">
                    {models.length > 10 && (
                      <div className="relative">
                        <Search size={13} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          value={modelFilter}
                          onChange={(e) => setModelFilter(e.target.value)}
                          placeholder={`Filter ${models.length} models…`}
                          className="h-8 pl-8 text-[12px]"
                        />
                      </div>
                    )}

                    {visibleModels.length > 0 ? (
                      <div className="scroll-slim flex max-h-[220px] flex-wrap gap-1.5 overflow-y-auto">
                        {visibleModels.map((m) => {
                          const isDefault = defaultModel === m;
                          return (
                            <button
                              key={m}
                              type="button"
                              disabled={!onUseModel}
                              onClick={() => {
                                onUseModel?.(m, preset.id);
                                toast.success(`${m} selected — press Save changes to apply`);
                              }}
                              aria-pressed={isDefault}
                              className={cn(
                                "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 font-mono text-[11.5px] transition active:scale-[0.97]",
                                isDefault
                                  ? "border-transparent bg-foreground text-background shadow-2xs"
                                  : "bg-card text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                                !onUseModel && "cursor-default",
                              )}
                            >
                              {isDefault && <Check size={11} />}
                              {m}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-[12px] text-muted-foreground">
                        {models.length === 0
                          ? "Save your connection and click Load models to fetch available IDs, or enter a custom model ID below."
                          : `No models match “${modelFilter}”.`}
                      </p>
                    )}

                    {onUseModel && (
                      <div className="flex flex-wrap items-center gap-2 border-t pt-3">
                        <Input
                          value={customModel}
                          onChange={(e) => setCustomModel(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && customModel.trim()) {
                              const id = customModel.trim();
                              if (!models.includes(id)) setModels((prev) => [id, ...prev]);
                              onUseModel(id, preset.id);
                              setCustomModel("");
                              toast.success(`${id} selected — press Save changes to apply`);
                            }
                          }}
                          placeholder="Custom model ID (e.g. llama3.2, gpt-4.1, deepseek-chat)"
                          className="h-8 min-w-[220px] flex-1 font-mono text-[12px]"
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!customModel.trim()}
                          onClick={() => {
                            const id = customModel.trim();
                            if (!id) return;
                            if (!models.includes(id)) setModels((prev) => [id, ...prev]);
                            onUseModel(id, preset.id);
                            setCustomModel("");
                            toast.success(`${id} selected — press Save changes to apply`);
                          }}
                        >
                          <Plus size={13} /> Use model
                        </Button>
                      </div>
                    )}
                  </div>
                </Panel>
              )}

              {kind !== "model" && (
                <Note>
                  {kind === "search"
                    ? "The active search provider powers the webSearch agent tool. Firecrawl can also power page reading when a key is stored."
                    : "Page readers convert any public URL into clean Markdown for agents. Jina Reader also works without a key at standard rate limits."}
                </Note>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
