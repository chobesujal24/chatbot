"use client";

import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUpRight, BarChart3, BookOpen, Brain, CheckCheck, ChevronDown, ChevronRight,
  Code2, Copy, Download, Ellipsis, FileText, FolderOpen, HelpCircle, Keyboard,
  Layers3, MessageSquare, Moon, PanelLeftClose, Pencil, Pin, PinOff,
  Plus, Search, Settings2, Sun, Trash2, Users, X,
} from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { BrandLockup, Logo } from "./logo";
import { ProviderLogo } from "./provider-logo";
import { groupConversations } from "@/lib/format";
import { useMediaQuery, useMounted } from "@/lib/use-media-query";
import { useShortcutKey } from "@/lib/use-shortcut-key";
import { cn } from "@/lib/utils";
import type { ConversationSummary } from "@/lib/types";
import type { ThemePreference } from "./providers";

export interface SidebarNavItem {
  id: string;
  label: string;
  icon: ReactNode;
  onClick: () => void;
  badge?: number;
  active?: boolean;
}

interface SidebarProps {
  conversations: ConversationSummary[];
  activeId: string | null;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDelete: (id: string) => void | Promise<void | boolean>;
  onFork: (id: string) => void;
  onExport: (id: string, format: "md" | "json") => void;
  onOpenSettings: () => void;
  onOpenQuickSetup?: () => void;
  onOpenAgents: () => void;
  onOpenTasks: () => void;
  onOpenMemories: () => void;
  onOpenTemplates: () => void;
  onOpenStats: () => void;
  onOpenSkills: () => void;
  onOpenContext: () => void;
  onOpenAbout: () => void;
  onOpenPalette: () => void;
  onOpenShortcuts?: () => void;
  onOpenCodeWorkspace?: () => void;
  codePanelOpen?: boolean;
  offline: boolean;
  openTasks: number;
  theme: ThemePreference;
  resolvedTheme: "light" | "dark";
  onToggleTheme: () => void;
  providerId?: string | null;
  providerLabel: string | null;
  providerKeyPreview: string | null;
  collapsed?: boolean;
  onToggleCollapsed: () => void;
}

const GROUPS_KEY = "nova-sidebar-groups";

function RailHint({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent side="right" sideOffset={10}>{label}</TooltipContent>
    </Tooltip>
  );
}

export default function Sidebar(props: SidebarProps) {
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [collapsedGroups, setCollapsedGroups] = useState<string[]>([]);
  const [deleting, setDeleting] = useState<ConversationSummary | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const shellRef = useRef<HTMLElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const cancelRenameRef = useRef(false);
  const shortcut = useShortcutKey();
  const mounted = useMounted();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const mobile = mounted && !isDesktop;
  const collapsed = Boolean(props.collapsed) && !mobile;
  const groups = useMemo(() => groupConversations(props.conversations), [props.conversations]);

  useEffect(() => {
    try {
      const raw: unknown = JSON.parse(window.localStorage.getItem(GROUPS_KEY) ?? "[]");
      if (Array.isArray(raw)) setCollapsedGroups(raw.filter((item): item is string => typeof item === "string"));
    } catch {
      /* A malformed preference should not break navigation. */
    }
  }, []);

  // Off-canvas navigation is inert when closed. When open, keyboard focus stays
  // in the drawer and Escape closes it. A desktop rail remains non-modal.
  const { onClose } = props;
  useEffect(() => {
    if (!mobile || !props.open) return;
    const previous = document.activeElement as HTMLElement | null;
    const shell = shellRef.current;
    if (!shell) return;
    const focusable = () => Array.from(shell.querySelectorAll<HTMLElement>("button:not([disabled]), a[href], input:not([disabled])")).filter((el) => el.getClientRects().length > 0);
    const frame = requestAnimationFrame(() => focusable()[0]?.focus());
    const onKey = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      } else if (event.key === "Tab") {
        const nodes = focusable();
        const first = nodes[0];
        const last = nodes[nodes.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    shell.addEventListener("keydown", onKey);
    return () => {
      cancelAnimationFrame(frame);
      shell.removeEventListener("keydown", onKey);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [mobile, props.open, onClose]);

  const act = (action: () => void) => {
    if (mobile) props.onClose();
    action();
  };

  const toggleGroup = (label: string) => {
    const next = collapsedGroups.includes(label) ? collapsedGroups.filter((item) => item !== label) : [...collapsedGroups, label];
    setCollapsedGroups(next);
    try { window.localStorage.setItem(GROUPS_KEY, JSON.stringify(next)); } catch { /* optional */ }
  };

  const commitRename = () => {
    if (!cancelRenameRef.current && renamingId && draft.trim()) props.onRename(renamingId, draft.trim());
    cancelRenameRef.current = false;
    setRenamingId(null);
  };

  const onListKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if ((event.target as HTMLElement).tagName === "INPUT") return;
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const rows = Array.from(listRef.current?.querySelectorAll<HTMLButtonElement>("[data-conv-row]") ?? []);
    if (!rows.length) return;
    event.preventDefault();
    const index = rows.findIndex((row) => row === document.activeElement);
    const next = event.key === "ArrowDown" ? (index + 1) % rows.length : (index <= 0 ? rows.length - 1 : index - 1);
    rows[next]?.focus();
  };

  const confirmDelete = async () => {
    if (!deleting || deleteBusy) return;
    setDeleteBusy(true);
    try {
      const deleted = await props.onDelete(deleting.id);
      if (deleted !== false) setDeleting(null);
    } catch {
      toast.error("That conversation couldn't be deleted. Please try again.");
    } finally {
      setDeleteBusy(false);
    }
  };

  const workspaceItems: SidebarNavItem[] = [
    { id: "agents", label: "Agents", icon: <Users size={16} />, onClick: props.onOpenAgents },
    { id: "skills", label: "Skills", icon: <BookOpen size={16} />, onClick: props.onOpenSkills },
    { id: "memory", label: "Memory", icon: <Brain size={16} />, onClick: props.onOpenMemories },
    { id: "tasks", label: "Tasks", icon: <CheckCheck size={16} />, onClick: props.onOpenTasks, badge: props.openTasks },
    { id: "templates", label: "Prompt library", icon: <FileText size={16} />, onClick: props.onOpenTemplates },
    ...(props.onOpenCodeWorkspace ? [{ id: "code", label: "Code workspace", icon: <Code2 size={16} />, onClick: props.onOpenCodeWorkspace, active: props.codePanelOpen }] : []),
  ];

  return (
    <TooltipProvider delayDuration={250}>
      {mobile && props.open && <button type="button" aria-label="Close navigation overlay" onClick={props.onClose} className="nav-backdrop" />}
      <aside
        ref={shellRef}
        aria-label="Workspace navigation"
        role={mobile ? "dialog" : undefined}
        aria-modal={mobile && props.open ? true : undefined}
        inert={mobile && !props.open ? true : undefined}
        className={cn("workspace-nav", collapsed && "is-collapsed", props.open && "is-open")}
      >
        <div className="nav-brand-row">
          {collapsed ? (
            <RailHint label={`Expand sidebar · ${shortcut} B`}>
              <button type="button" onClick={props.onToggleCollapsed} aria-label="Expand sidebar" className="nav-brand-button group">
                <Logo size={28} className="transition-transform duration-150 group-hover:scale-[1.04]" />
              </button>
            </RailHint>
          ) : (
            <>
              <button type="button" onClick={() => act(props.onNew)} className="nav-brand" aria-label="Nova home">
                <BrandLockup size="md" />
              </button>
              <button type="button" onClick={mobile ? props.onClose : props.onToggleCollapsed} aria-label={mobile ? "Close sidebar" : "Collapse sidebar"} title={mobile ? "Close sidebar" : `Collapse sidebar (${shortcut} B)`} className="nav-icon-button">
                {mobile ? <X size={17} /> : <PanelLeftClose size={16} />}
              </button>
            </>
          )}
        </div>

        <div className="nav-primary">
          <RailHint label={`New chat · ${shortcut} N`}>
            <button type="button" onClick={() => act(props.onNew)} aria-label="New chat" className={cn("nav-action nav-new", !props.activeId && "is-current")}>
              <Plus size={17} strokeWidth={1.7} />
              {!collapsed && <><span>New chat</span><kbd>{shortcut} N</kbd></>}
            </button>
          </RailHint>
          <RailHint label={`Search · ${shortcut} K`}>
            <button type="button" onClick={() => act(props.onOpenPalette)} aria-label="Search conversations" className="nav-action">
              <Search size={16} strokeWidth={1.7} />
              {!collapsed && <><span>Search</span><kbd>{shortcut} K</kbd></>}
            </button>
          </RailHint>
        </div>

        <nav aria-label="Workspace tools" className="nav-tools">
          {!collapsed && <p className="nav-section-label">Workspace</p>}
          {workspaceItems.map((item) => (
            <RailHint key={item.id} label={item.label}>
              <button type="button" onClick={() => act(item.onClick)} aria-label={item.label} aria-pressed={item.id === "code" ? Boolean(item.active) : undefined} className={cn("nav-action", item.active && "is-current")}>
                {item.icon}
                {!collapsed && <span>{item.label}</span>}
                {Boolean(item.badge) && <span className={collapsed ? "nav-badge-dot" : "nav-badge"}>{!collapsed && item.badge}</span>}
              </button>
            </RailHint>
          ))}
        </nav>

        <div ref={listRef} onKeyDown={onListKeyDown} className="nav-history scroll-slim">
          {!collapsed && <p className="nav-section-label">Your conversations</p>}
          {props.conversations.length === 0 ? (
            !collapsed && <div className="nav-empty"><MessageSquare size={17} strokeWidth={1.5} aria-hidden /><p>No conversations yet.</p><span>Start a chat and it’ll be saved here.</span></div>
          ) : collapsed ? (
            <div className="space-y-1">
              {props.conversations.slice(0, 12).map((conversation) => (
                <RailHint key={conversation.id} label={conversation.title}>
                  <button type="button" data-conv-row onClick={() => act(() => props.onSelect(conversation.id))} aria-label={conversation.title} aria-current={conversation.id === props.activeId ? "page" : undefined} className={cn("nav-action", conversation.id === props.activeId && "is-current")}>
                    {conversation.pinned ? <Pin size={15} /> : <MessageSquare size={15} />}
                  </button>
                </RailHint>
              ))}
            </div>
          ) : (
            groups.map((group) => {
              const groupClosed = collapsedGroups.includes(group.label);
              return (
                <section key={group.label} className="nav-history-group">
                  <button type="button" onClick={() => toggleGroup(group.label)} aria-expanded={!groupClosed} className="nav-group-heading">
                    {groupClosed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
                    <span>{group.label}</span>
                    <span className="ml-auto">{group.items.length}</span>
                  </button>
                  <AnimatePresence initial={false}>
                    {!groupClosed && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.17, ease: [0.22, 1, 0.36, 1] }}
                        className="overflow-hidden"
                      >
                        {group.items.map((conversation) => (
                    <div key={conversation.id} className={cn("nav-conversation group/row", conversation.id === props.activeId && "is-current")}>
                      {renamingId === conversation.id ? (
                        <input
                          autoFocus maxLength={120} value={draft} onChange={(event) => setDraft(event.target.value)} onBlur={commitRename}
                          onKeyDown={(event) => {
                            if (event.key === "Enter") { event.preventDefault(); commitRename(); }
                            if (event.key === "Escape") { event.stopPropagation(); cancelRenameRef.current = true; setRenamingId(null); }
                          }}
                          aria-label="Rename conversation" className="nav-rename-input"
                        />
                      ) : (
                        <button type="button" data-conv-row onClick={() => act(() => props.onSelect(conversation.id))} aria-current={conversation.id === props.activeId ? "page" : undefined} className="nav-conversation-title" title={conversation.title}>
                          {conversation.pinned && <Pin size={11} className="shrink-0 text-brand" />}
                          <span className="truncate">{conversation.title}</span>
                        </button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button type="button" aria-label={`Options for ${conversation.title}`} className="nav-conversation-menu"><Ellipsis size={15} /></button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" side={mobile ? "bottom" : "right"} className="w-52 p-1.5">
                          <DropdownMenuItem onSelect={() => { cancelRenameRef.current = false; setDraft(conversation.title); setRenamingId(conversation.id); }}><Pencil size={14} /> Rename</DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => props.onTogglePin(conversation.id, !conversation.pinned)}>{conversation.pinned ? <PinOff size={14} /> : <Pin size={14} />}{conversation.pinned ? "Unpin" : "Pin conversation"}</DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => props.onFork(conversation.id)}><Copy size={14} /> Duplicate</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onSelect={() => props.onExport(conversation.id, "md")}><FileText size={14} /> Export Markdown</DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => props.onExport(conversation.id, "json")}><Download size={14} /> Export JSON</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem variant="destructive" onSelect={() => setDeleting(conversation)}><Trash2 size={14} /> Delete conversation</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </section>
              );
            })
          )}
        </div>

        <div className="nav-footer">
          <div className="nav-footer-links">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button type="button" aria-label="Help and shortcuts" className={collapsed ? "nav-icon-button" : "nav-help-button"}>
                  <HelpCircle size={16} strokeWidth={1.6} />{!collapsed && <span>Help & shortcuts</span>}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent side={collapsed ? "right" : "top"} align="start" className="w-56 p-1.5">
                {props.onOpenShortcuts && <DropdownMenuItem onSelect={() => act(props.onOpenShortcuts!)}><Keyboard size={15} /> Keyboard shortcuts</DropdownMenuItem>}
                <DropdownMenuItem onSelect={() => act(props.onOpenAbout)}><HelpCircle size={15} /> About Nova & open source</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => act(props.onOpenStats)}><BarChart3 size={15} /> Workspace usage</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <button type="button" onClick={props.onToggleTheme} aria-label={`Switch to ${props.resolvedTheme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${props.resolvedTheme === "dark" ? "light" : "dark"} mode`} className="nav-icon-button">
              {props.resolvedTheme === "dark" ? <Sun size={16} strokeWidth={1.6} /> : <Moon size={15} strokeWidth={1.6} />}
            </button>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" aria-label="Personal workspace settings" className="nav-workspace-button">
                {props.providerId && props.providerId !== "offline" ? (
                  <ProviderLogo provider={props.providerId} size={31} className="rounded-[7px]" />
                ) : (
                  <span className="nav-workspace-avatar"><FolderOpen size={16} strokeWidth={1.6} /></span>
                )}
                {!collapsed && <><span className="min-w-0 flex-1 text-left"><span className="block text-[12.5px] font-medium">Personal workspace</span><span className="mt-0.5 block truncate text-[11px] text-muted-foreground">{props.providerLabel ? `${props.providerLabel} connected` : "Demo mode"}</span></span><ChevronDown size={13} className="shrink-0 text-muted-foreground" /></>}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side={collapsed ? "right" : "top"} align="start" className="w-60 p-1.5">
              <DropdownMenuItem onSelect={() => act(props.onOpenSettings)}><Settings2 size={15} /> Settings <kbd className="ml-auto text-[10px] text-muted-foreground">{shortcut} ,</kbd></DropdownMenuItem>
              <DropdownMenuItem onSelect={() => act(props.onOpenQuickSetup ?? props.onOpenSettings)}><ArrowUpRight size={15} /> Connect a model</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => act(props.onOpenStats)}><BarChart3 size={15} /> Usage</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => act(props.onOpenContext)}><Layers3 size={15} /> Context preferences</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      <Dialog open={Boolean(deleting)} onOpenChange={(open) => { if (!open && !deleteBusy) setDeleting(null); }}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Delete this conversation?</DialogTitle>
            <DialogDescription>“{deleting?.title}” and its messages will be permanently removed. This can’t be undone.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleting(null)} disabled={deleteBusy}>Keep conversation</Button>
            <Button variant="destructive" onClick={() => void confirmDelete()} disabled={deleteBusy}>{deleteBusy ? "Deleting…" : "Delete conversation"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
}
