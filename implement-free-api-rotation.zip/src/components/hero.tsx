"use client";

import { useId, useMemo, useRef, useState, type ComponentProps, type KeyboardEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CheckCheck,
  Code2,
  FileText,
  GitCompareArrows,
  Keyboard,
  MessageSquare,
  PencilLine,
} from "lucide-react";
import Composer from "./composer";
import { Logo, NovaWordmark } from "./logo";
import { ProviderLogo } from "./provider-logo";
import { cn } from "@/lib/utils";
import { HOME_PROMPTS, PROMPT_CATEGORIES, type PromptCategory, type PromptIcon } from "@/lib/home-prompts";
import type { ConversationSummary } from "@/lib/types";

interface HeroProps extends Omit<ComponentProps<typeof Composer>, "variant"> {
  onSuggestion: (text: string) => void;
  onOpenQuickSetup?: () => void;
  onOpenTemplates: () => void;
  onOpenShortcuts: () => void;
  onOpenAbout: () => void;
  onOpenPalette: () => void;
  conversations: ConversationSummary[];
  onSelectConversation: (id: string) => void;
  compact?: boolean;
}

const ICONS: Record<PromptIcon, typeof PencilLine> = {
  write: PencilLine,
  plan: CheckCheck,
  learn: BookOpen,
  code: Code2,
  notes: FileText,
  compare: GitCompareArrows,
};

function recentLabel(date: string): string {
  const value = new Date(date);
  if (Number.isNaN(value.getTime())) return "";
  const today = new Date();
  if (value.toDateString() === today.toDateString()) return "Today";
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (value.toDateString() === yesterday.toDateString()) return "Yesterday";
  return value.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function Hero({
  onSuggestion,
  onOpenQuickSetup,
  onOpenTemplates,
  onOpenShortcuts,
  onOpenAbout,
  onOpenPalette,
  conversations,
  onSelectConversation,
  compact = false,
  ...composer
}: HeroProps) {
  const [category, setCategory] = useState<PromptCategory>("explore");
  const id = useId();
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const recent = useMemo(
    () => [...conversations].sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)).slice(0, 3),
    [conversations],
  );

  const onTabKey = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % PROMPT_CATEGORIES.length;
    else if (event.key === "ArrowLeft") next = (index + PROMPT_CATEGORIES.length - 1) % PROMPT_CATEGORIES.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = PROMPT_CATEGORIES.length - 1;
    else return;
    event.preventDefault();
    setCategory(PROMPT_CATEGORIES[next].id);
    tabRefs.current[next]?.focus();
  };

  return (
    <div className="home-screen scroll-slim @container/home" data-compact={compact}>
      <div className="home-content">
        <header className="home-heading">
          <p className="home-eyebrow inline-flex items-center gap-1.5">
            <Logo size={14} variant="glyph" />
            <span>{recent.length > 0 ? "Welcome back" : "A new conversation"}</span>
          </p>
          <h1>What are we working on?</h1>
          <p className="home-description">A question, a rough idea, a piece of code. Start anywhere.</p>
        </header>

        <div className="home-composer">
          <Composer {...composer} variant="hero" onOpenTemplates={onOpenTemplates} />
        </div>
        <div className="home-composer-note">
          {composer.hasProvider ? (
            <span className="inline-flex items-center gap-1.5">
              {composer.providerId && <ProviderLogo provider={composer.providerId} size={14} />}
              <span>Connected to <strong className="font-medium text-foreground">{composer.providerLabel}</strong>. You choose the model, Nova keeps the context.</span>
            </span>
          ) : (
            <>
              <span className="inline-flex items-center gap-1.5">
                <span aria-hidden className="size-[5px] rounded-full bg-muted-foreground/65" />
                You’re in demo mode.
              </span>
              <button type="button" onClick={onOpenQuickSetup ?? composer.onOpenSettings}>
                Connect a model <ArrowUpRight size={12} aria-hidden />
              </button>
              <span className="hidden @lg/home:inline">for AI responses.</span>
            </>
          )}
        </div>

        <section className="home-starters" aria-label="Conversation starters">
          <div className="home-starter-header">
            <div role="tablist" aria-label="Prompt categories" className="home-tabs">
              {PROMPT_CATEGORIES.map((tab, index) => (
                <button
                  key={tab.id}
                  ref={(element) => { tabRefs.current[index] = element; }}
                  type="button"
                  role="tab"
                  id={`${id}-tab-${tab.id}`}
                  aria-controls={`${id}-prompts`}
                  aria-selected={category === tab.id}
                  tabIndex={category === tab.id ? 0 : -1}
                  onClick={() => setCategory(tab.id)}
                  onKeyDown={(event) => onTabKey(event, index)}
                  className={cn("home-tab", category === tab.id && "is-active")}
                >
                  {tab.label}
                  {category === tab.id && (
                    <motion.span
                      layoutId="home-prompt-tab-line"
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-0 -bottom-px h-0.5 bg-brand"
                      transition={{ type: "spring", stiffness: 520, damping: 40 }}
                    />
                  )}
                </button>
              ))}
            </div>
            <button type="button" onClick={onOpenTemplates} className="home-library-link" title="Your saved prompt templates">
              <span className="hidden @lg/home:inline">Prompt library</span>
              <FileText size={14} className="@lg/home:hidden" />
              <ArrowUpRight size={13} aria-hidden />
              <span className="sr-only @lg/home:hidden">Prompt library</span>
            </button>
          </div>
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={category}
              role="tabpanel"
              id={`${id}-prompts`}
              aria-labelledby={`${id}-tab-${category}`}
              tabIndex={0}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -3 }}
              transition={{ duration: 0.15, ease: [0.22, 1, 0.36, 1] }}
              className="home-prompt-grid"
            >
            {HOME_PROMPTS[category].map((starter) => {
              const Icon = ICONS[starter.icon];
              return (
                <button
                  key={starter.id}
                  type="button"
                  onClick={() => onSuggestion(starter.prompt)}
                  className="home-prompt group"
                  title="Add this prompt to your draft"
                >
                  <span className="home-prompt-icon"><Icon size={17} strokeWidth={1.6} aria-hidden /></span>
                  <span className="min-w-0 flex-1">
                    <span className="home-prompt-title">{starter.title}</span>
                    <span className="home-prompt-description">{starter.description}</span>
                  </span>
                  <ArrowUpRight size={14} aria-hidden className="home-prompt-arrow" />
                </button>
              );
            })}
            </motion.div>
          </AnimatePresence>
        </section>

        {recent.length > 0 && !compact && (
          <section className="home-recents" aria-labelledby={`${id}-recent`}>
            <div className="flex items-center justify-between gap-3 pb-3">
              <h2 id={`${id}-recent`} className="text-[13px] font-medium text-muted-foreground">Pick up where you left off</h2>
              <button type="button" onClick={onOpenPalette} className="home-library-link">
                All chats <ArrowRight size={13} aria-hidden />
              </button>
            </div>
            {recent.map((conversation) => (
              <button
                key={conversation.id}
                type="button"
                onClick={() => onSelectConversation(conversation.id)}
                className="home-recent-row"
              >
                <MessageSquare size={14} className="shrink-0 text-muted-foreground" aria-hidden />
                <span className="min-w-0 flex-1 truncate text-left">{conversation.title}</span>
                <time dateTime={conversation.updatedAt} className="shrink-0 text-[11.5px] text-muted-foreground">
                  {recentLabel(conversation.updatedAt)}
                </time>
              </button>
            ))}
          </section>
        )}
      </div>

      <footer className="home-footer">
        <button type="button" onClick={onOpenAbout} className="inline-flex items-baseline transition-colors hover:text-foreground">
          <NovaWordmark size="sm" className="text-[14px] text-foreground/80" /> <span className="mx-1.5 opacity-40">/</span> Your open-source workspace
        </button>
        <button type="button" onClick={onOpenShortcuts} className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground">
          <Keyboard size={13} aria-hidden />
          <span className="hidden sm:inline">Keyboard shortcuts</span>
          <span className="sr-only sm:hidden">Keyboard shortcuts</span>
        </button>
      </footer>
    </div>
  );
}
