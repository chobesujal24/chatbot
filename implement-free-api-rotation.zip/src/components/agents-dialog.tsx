"use client";

import { useEffect, useState } from "react";
import { ArrowLeft, Check, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { AgentIcon } from "./agent-icon";
import { AGENT_ICONS } from "@/lib/agent-icons";
import { TOOL_GROUP_LABELS, TOOL_META } from "@/lib/tool-meta";
import { cn } from "@/lib/utils";
import type { Agent, Skill } from "@/lib/types";

interface AgentsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  agents: Agent[];
  skills: Skill[];
  selectedId: string | null;
  onChanged: () => void;
  onSelect: (id: string) => void;
}

type MemoryMode = "auto" | "on" | "off";

interface Draft {
  name: string;
  description: string;
  systemPrompt: string;
  model: string;
  temperature: number;
  maxSteps: number;
  tools: string[];
  icon: string;
  memoryMode: MemoryMode;
  skills: string[] | null;
}

const EMPTY: Draft = {
  name: "",
  description: "",
  systemPrompt: "",
  model: "",
  temperature: 0.7,
  maxSteps: 5,
  tools: [],
  icon: "bot",
  memoryMode: "auto",
  skills: null,
};

const fieldLabel = "mb-1.5 block text-[13px] font-medium";

export default function AgentsDialog(props: AgentsDialogProps) {
  const [editing, setEditing] = useState<Agent | "new" | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [armedDeleteId, setArmedDeleteId] = useState<string | null>(null);

  // Reset to the list whenever the dialog is reopened.
  const [wasOpen, setWasOpen] = useState(props.open);
  if (wasOpen !== props.open) {
    setWasOpen(props.open);
    if (props.open) setEditing(null);
  }

  const startEdit = (agent: Agent | "new") => {
    setEditing(agent);
    setDraft(
      agent === "new"
        ? EMPTY
        : {
            name: agent.name,
            description: agent.description,
            systemPrompt: agent.systemPrompt,
            model: agent.model ?? "",
            temperature: agent.temperature,
            maxSteps: agent.maxSteps,
            tools: agent.tools,
            icon: agent.icon,
            memoryMode: (agent.memoryMode ?? "auto") as MemoryMode,
            skills: agent.skills ?? null,
          },
    );
  };

  const patch = (values: Partial<Draft>) => setDraft((prev) => ({ ...prev, ...values }));

  const toggleTool = (name: string) =>
    patch({
      tools: draft.tools.includes(name)
        ? draft.tools.filter((t) => t !== name)
        : [...draft.tools, name],
    });

  const save = async () => {
    if (!draft.name.trim()) {
      toast.error("Give the agent a name");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: draft.name.trim(),
        description: draft.description,
        systemPrompt: draft.systemPrompt,
        model: draft.model.trim() || null,
        temperature: draft.temperature,
        maxSteps: draft.maxSteps,
        tools: draft.tools,
        icon: draft.icon,
        memoryMode: draft.memoryMode,
        skills: draft.skills,
      };
      const res =
        editing === "new"
          ? await fetch("/api/agents", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            })
          : await fetch(`/api/agents/${(editing as Agent).id}`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            });
      if (!res.ok) throw new Error("Save failed");
      toast.success(editing === "new" ? "Agent created" : "Agent updated");
      setEditing(null);
      props.onChanged();
    } catch {
      toast.error("Could not save agent");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (agent: Agent) => {
    // Two-step confirm instead of a native browser dialog.
    if (armedDeleteId !== agent.id) {
      setArmedDeleteId(agent.id);
      setTimeout(() => setArmedDeleteId((id) => (id === agent.id ? null : id)), 4000);
      return;
    }
    setArmedDeleteId(null);
    const res = await fetch(`/api/agents/${agent.id}`, { method: "DELETE" });
    if (!res.ok) {
      toast.error("Could not delete agent");
      return;
    }
    toast.success("Agent deleted");
    props.onChanged();
  };

  const setDefault = async (agent: Agent) => {
    const res = await fetch(`/api/agents/${agent.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isDefault: true }),
    });
    if (!res.ok) {
      toast.error("Could not set default");
      return;
    }
    toast.success(`${agent.name} is now the default agent`);
    props.onChanged();
  };

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[88vh] sm:max-w-[600px] overflow-y-auto">
        {editing === null ? (
          <>
            <DialogHeader>
              <DialogTitle>Agents</DialogTitle>
              <DialogDescription>
                Agents bundle a system prompt, a model and a set of tools. The default agent is
                used for new chats unless you pick another.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              {props.agents.map((agent) => (
                <div
                  key={agent.id}
                  className={cn(
                    "flex items-start gap-3 rounded-lg border p-3",
                    agent.id === props.selectedId
                      ? "border-primary/40 bg-accent/50"
                      : "border-border",
                  )}
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground">
                    <AgentIcon icon={agent.icon} size={17} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2 text-[14px] font-medium">
                      {agent.name}
                      {agent.isDefault && (
                        <span className="flex items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
                          <Star size={9} /> Default
                        </span>
                      )}
                      {agent.id === props.selectedId && (
                        <span className="flex items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
                          <Check size={9} /> Selected
                        </span>
                      )}
                    </p>
                    <p className="mt-0.5 line-clamp-2 text-[12px] text-muted-foreground">
                      {agent.description || "No description"}
                    </p>
                    <p className="mt-1.5 text-[12px] text-muted-foreground">
                      {agent.model ?? "settings model"} · {agent.tools.length} tools · max{" "}
                      {agent.maxSteps} steps
                    </p>
                  </div>
                  <div className="flex w-[92px] shrink-0 flex-col gap-2">
                    <Button size="sm" onClick={() => props.onSelect(agent.id)}>
                      Use
                    </Button>
                    <div className="flex items-center justify-between">
                      <Button size="icon-sm" variant="ghost" onClick={() => startEdit(agent)} aria-label="Edit agent" title="Edit">
                        <Pencil size={14} />
                      </Button>
                      {agent.isDefault ? (
                        <span
                          className="flex size-8 items-center justify-center text-foreground"
                          title="Default agent"
                          aria-label="Default agent"
                        >
                          <Star size={14} fill="currentColor" />
                        </span>
                      ) : (
                        <Button size="icon-sm" variant="ghost" onClick={() => void setDefault(agent)} aria-label="Set as default" title="Make default">
                          <Star size={14} />
                        </Button>
                      )}
                      <Button
                        size="icon-sm"
                        variant={armedDeleteId === agent.id ? "destructive" : "ghost"}
                        onClick={() => void remove(agent)}
                        aria-label={armedDeleteId === agent.id ? `Confirm delete ${agent.name}` : "Delete agent"}
                        title={armedDeleteId === agent.id ? "Click again to confirm" : "Delete"}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              {props.agents.length === 0 && (
                <p className="py-6 text-center text-[13px] text-muted-foreground">
                  No agents yet.
                </p>
              )}
            </div>
            <DialogFooter>
              <Button size="sm" onClick={() => startEdit("new")}>
                <Plus size={14} /> New agent
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditing(null)}
                  aria-label="Back to agents"
                  className="rounded p-1 transition hover:bg-accent"
                >
                  <ArrowLeft size={15} />
                </button>
                {editing === "new" ? "New agent" : `Edit ${editing.name}`}
              </DialogTitle>
              <DialogDescription>
                The agent runs a tool loop: the model may call its tools for up to max steps
                before answering.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className={fieldLabel} htmlFor="agent-name">Name</label>
                  <Input
                    id="agent-name"
                    value={draft.name}
                    onChange={(e) => patch({ name: e.target.value })}
                    placeholder="Researcher"
                    className="text-[14px]"
                  />
                </div>
                <div>
                  <label className={fieldLabel} htmlFor="agent-model">
                    Model (optional)
                  </label>
                  <Input
                    id="agent-model"
                    value={draft.model}
                    onChange={(e) => patch({ model: e.target.value })}
                    placeholder="Uses Settings model"
                    className="font-mono text-[13px]"
                  />
                </div>
              </div>
              <div>
                <label className={fieldLabel} htmlFor="agent-desc">Description</label>
                <Input
                  id="agent-desc"
                  value={draft.description}
                  onChange={(e) => patch({ description: e.target.value })}
                  placeholder="What this agent is good for"
                  className="text-[14px]"
                />
              </div>
              <div>
                <label className={fieldLabel}>Icon</label>
                <div className="flex flex-wrap gap-1.5">
                  {AGENT_ICONS.map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => patch({ icon: key })}
                      aria-label={key}
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-md border transition",
                        draft.icon === key
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:bg-accent",
                      )}
                    >
                      <AgentIcon icon={key} size={14} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className={fieldLabel} htmlFor="agent-prompt">System prompt</label>
                <Textarea
                  id="agent-prompt"
                  value={draft.systemPrompt}
                  onChange={(e) => patch({ systemPrompt: e.target.value })}
                  rows={5}
                  placeholder="You are a … agent. Use your tools when …"
                  className="resize-y text-[13px]"
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className={fieldLabel} htmlFor="agent-temp">
                    Temperature: {draft.temperature.toFixed(1)}
                  </label>
                  <input
                    id="agent-temp"
                    type="range"
                    min={0}
                    max={2}
                    step={0.1}
                    value={draft.temperature}
                    onChange={(e) => patch({ temperature: Number(e.target.value) })}
                    className="h-1.5 w-full cursor-pointer accent-foreground"
                  />
                </div>
                <div>
                  <label className={fieldLabel} htmlFor="agent-steps">Max tool steps</label>
                  <Input
                    id="agent-steps"
                    type="number"
                    min={1}
                    max={20}
                    value={draft.maxSteps}
                    onChange={(e) => patch({ maxSteps: Number(e.target.value) })}
                    className="text-[14px]"
                  />
                </div>
              </div>
              <div>
                <p className={fieldLabel}>Long-term memory</p>
                <div className="grid gap-1.5 sm:grid-cols-3">
                  {([
                    { id: "auto", title: "Auto", desc: "Recall, save and forget on its own" },
                    { id: "on", title: "Assist", desc: "Recall and save, never forget" },
                    { id: "off", title: "Off", desc: "No memory access at all" },
                  ] as const).map((option) => (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => setDraft((d) => ({ ...d, memoryMode: option.id }))}
                      aria-pressed={draft.memoryMode === option.id}
                      className={cn(
                        "rounded-lg border p-2.5 text-left transition",
                        draft.memoryMode === option.id
                          ? "border-primary/40 bg-accent/50"
                          : "border-border hover:bg-accent/40",
                      )}
                    >
                      <span className="block text-[12px] font-medium">{option.title}</span>
                      <span className="mt-0.5 block text-[10.5px] leading-snug text-muted-foreground">
                        {option.desc}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {props.skills.length > 0 && (
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <p className={cn(fieldLabel, "mb-0")}>Skills</p>
                    <button
                      type="button"
                      onClick={() => patch({ skills: draft.skills?.length ? null : [] })}
                      className="text-[11.5px] text-muted-foreground underline underline-offset-2 hover:text-foreground"
                    >
                      {draft.skills?.length ? "Use all enabled" : "Pick specific skills"}
                    </button>
                  </div>
                  {draft.skills === null ? (
                    <p className="rounded-md border bg-muted/40 px-2.5 py-2 text-[11.5px] text-muted-foreground">
                      This agent sees every enabled skill.
                    </p>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {props.skills.map((skill) => {
                        const on = draft.skills?.includes(skill.name) ?? false;
                        return (
                          <button
                            key={skill.id}
                            type="button"
                            onClick={() =>
                              patch({
                                skills: on
                                  ? (draft.skills ?? []).filter((n) => n !== skill.name)
                                  : [...(draft.skills ?? []), skill.name],
                              })
                            }
                            aria-pressed={on}
                            className={cn(
                              "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[11.5px] transition",
                              on
                                ? "border-foreground bg-foreground text-background"
                                : "text-muted-foreground hover:border-foreground/25 hover:text-foreground",
                            )}
                          >
                            {on && <Check size={11} />}
                            <span aria-hidden>{skill.emoji}</span>
                            {skill.name}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className={fieldLabel}>Tools</label>
                <div className="grid gap-1.5 sm:grid-cols-2">
                  {TOOL_META.map((tool) => (
                    <label
                      key={tool.name}
                      className={cn(
                        "flex cursor-pointer items-start gap-2 rounded-md border p-2.5 transition",
                        draft.tools.includes(tool.name)
                          ? "border-primary/40 bg-accent/50"
                          : "border-border hover:bg-accent/40",
                      )}
                    >
                      <input
                        type="checkbox"
                        checked={draft.tools.includes(tool.name)}
                        onChange={() => toggleTool(tool.name)}
                        className="mt-0.5 accent-foreground"
                      />
                      <span>
                        <span className="block text-[13px] font-medium">{tool.label}</span>
                        <span className="block text-[11px] leading-snug text-muted-foreground">
                          {tool.description}
                        </span>
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" size="sm" onClick={() => setEditing(null)}>
                Cancel
              </Button>
              <Button size="sm" onClick={() => void save()} disabled={saving}>
                {saving ? "Saving…" : editing === "new" ? "Create agent" : "Save changes"}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
