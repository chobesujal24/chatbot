"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Toaster } from "sonner";

export type ThemePreference = "light" | "dark" | "system";
interface ThemeContextValue {
  theme: ThemePreference;
  resolved: "light" | "dark";
  setTheme: (theme: ThemePreference) => void;
}
const ThemeContext = createContext<ThemeContextValue | null>(null);
const validTheme = (value: unknown): value is ThemePreference => value === "light" || value === "dark" || value === "system";

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used inside Providers");
  return context;
}

export function Providers({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemePreference>("system");
  const [resolved, setResolved] = useState<"light" | "dark">("light");
  const themeRef = useRef<ThemePreference>("system");

  const applyTheme = useCallback((next: ThemePreference) => {
    themeRef.current = next;
    const isDark = next === "dark" || (next === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.classList.toggle("dark", isDark);
    document.documentElement.style.colorScheme = isDark ? "dark" : "light";
    setThemeState(next);
    setResolved(isDark ? "dark" : "light");
  }, []);

  useEffect(() => {
    let stored: ThemePreference = "system";
    try {
      const value = window.localStorage.getItem("nova-theme");
      if (validTheme(value)) stored = value;
    } catch { /* Storage may be blocked in embedded/private contexts. */ }
    applyTheme(stored);
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onMedia = () => applyTheme(themeRef.current);
    const onPreference = (event: Event) => {
      const value = (event as CustomEvent<unknown>).detail;
      if (validTheme(value)) applyTheme(value);
    };
    const onStorage = (event: StorageEvent) => {
      if (event.key === "nova-theme") applyTheme(validTheme(event.newValue) ? event.newValue : "system");
    };
    media.addEventListener("change", onMedia);
    window.addEventListener("nova-theme-change", onPreference);
    window.addEventListener("storage", onStorage);
    return () => {
      media.removeEventListener("change", onMedia);
      window.removeEventListener("nova-theme-change", onPreference);
      window.removeEventListener("storage", onStorage);
    };
  }, [applyTheme]);

  const setTheme = useCallback((next: ThemePreference) => {
    applyTheme(next);
    try { window.localStorage.setItem("nova-theme", next); } catch { /* optional */ }
  }, [applyTheme]);

  const value = useMemo(() => ({ theme, resolved, setTheme }), [theme, resolved, setTheme]);
  return (
    <ThemeContext.Provider value={value}>
      {children}
      <Toaster
        position="bottom-right"
        theme={resolved}
        toastOptions={{ classNames: { toast: "!rounded-lg !border-border !bg-popover !text-popover-foreground !shadow-md" } }}
      />
    </ThemeContext.Provider>
  );
}
