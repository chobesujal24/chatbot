import HubApp from "@/components/hub/hub-app";
import "./hub.css";
export default function HomePage() { return <HubApp />; }
