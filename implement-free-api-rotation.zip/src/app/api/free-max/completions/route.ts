import { z } from "zod";
import { guard, parseBody, route, noStore } from "@/lib/http";
import { runFreeMax } from "@/lib/free-max/router";
export const dynamic="force-dynamic";
export const maxDuration=90;
const input=z.object({model:z.string().max(180).default("free-max"),messages:z.array(z.object({role:z.enum(["user","system","assistant"]),content:z.string().min(1).max(32000)})).min(1).max(64),max_tokens:z.number().int().min(128).max(4096).default(2048)});
export const POST=route(async request=>{
  const {workspaceId:ws}=await guard(request,{rateLimit:{bucket:"chat",limit:40,windowMs:60000}});
  const body=await parseBody(request,input);
  const result=await runFreeMax(ws,body.messages,body.model,body.max_tokens,request.signal);
  return Response.json({id:`chatcmpl-${crypto.randomUUID()}`,object:"chat.completion",created:Math.floor(Date.now()/1000),model:result.model,provider:result.provider,choices:[{index:0,message:{role:"assistant",content:result.text},finish_reason:"stop"}],usage:{prompt_tokens:result.usage.inputTokens,completion_tokens:result.usage.outputTokens,total_tokens:result.usage.totalTokens},routing:{attempts:result.attempts,duration_ms:result.durationMs}},{headers:noStore});
});
