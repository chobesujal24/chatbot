import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, freeMaxConfig, freeMaxRuns } from "@/db/schema";
import { guard, route, noStore, ApiError, parseBody } from "@/lib/http";
import { bootstrapWorkspace, isAuthorized } from "@/lib/workspace";
import { listCredentials, saveCredential, deleteCredential } from "@/lib/credentials";
import { CATALOG, findFreeProvider } from "@/lib/free-max/catalog";
import { connectionFor, readRouting } from "@/lib/free-max/router";
export const dynamic = "force-dynamic";
export const GET = route(async request => {
  await guard(request, { public:true, rateLimit:{ bucket:"router-state",limit:120,windowMs:60000 } });
  if (!(await isAuthorized())) throw new ApiError(401,"authentication_required","Unlock this workspace to continue.");
  const {id:ws} = await bootstrapWorkspace();
  const [creds,routing,history,runs] = await Promise.all([listCredentials(ws),readRouting(ws),db.select({id:conversations.id,title:conversations.title,model:conversations.model,updatedAt:conversations.updatedAt,pinned:conversations.pinned}).from(conversations).where(eq(conversations.workspaceId,ws)).orderBy(desc(conversations.pinned),desc(conversations.updatedAt)).limit(200),db.select({id:freeMaxRuns.id,provider:freeMaxRuns.provider,model:freeMaxRuns.model,outcome:freeMaxRuns.outcome,durationMs:freeMaxRuns.durationMs,tokens:freeMaxRuns.tokens,attempts:freeMaxRuns.attempts,createdAt:freeMaxRuns.createdAt}).from(freeMaxRuns).where(eq(freeMaxRuns.workspaceId,ws)).orderBy(desc(freeMaxRuns.createdAt)).limit(100)]);
  return Response.json({workspace:ws,routing,history,runs,connections:CATALOG.map(p=>{const c=connectionFor(p,creds);return {provider:p.id,ready:c.ready,hasKey:Boolean(c.key),fromEnv:c.fromEnv};})},{headers:noStore});
});
const actions = z.discriminatedUnion("action",[
  z.object({action:z.literal("settings"),strategy:z.enum(["keyless-first","round-robin","high-allowance"]),rotation:z.boolean(),maxAttempts:z.number().int().min(1).max(5),disabled:z.array(z.string().max(48)).max(24)}),
  z.object({action:z.literal("connect"),provider:z.string().max(40),secret:z.string().trim().min(4).max(4096),freePlanConfirmed:z.literal(true),accountId:z.string().trim().max(32).optional()}),
  z.object({action:z.literal("disconnect"),provider:z.string().max(40)}),
]);
export const POST = route(async request => {
  const {workspaceId:ws}=await guard(request,{rateLimit:{bucket:"router-config",limit:50,windowMs:60000}});
  const body=await parseBody(request,actions);
  if(body.action === "settings") {
    const {action,...settings}=body; void action;
    if(settings.disabled.some(id=>!findFreeProvider(id))) throw new ApiError(400,"unknown_provider","Unknown pool member.");
    await db.insert(freeMaxConfig).values({workspaceId:ws,settings}).onConflictDoUpdate({target:freeMaxConfig.workspaceId,set:{settings}});
    return Response.json({ok:true,routing:settings},{headers:noStore});
  }
  const p=findFreeProvider(body.provider);
  if(!p || p.access === "keyless") throw new ApiError(400,"invalid_provider","Choose a provider that accepts a free key.");
  if(body.action === "disconnect") {
    const cred=(await listCredentials(ws)).find(c=>c.provider===p.id && c.options.freeMax===true);
    if(!cred) throw new ApiError(404,"not_found","No saved workspace key.");
    await deleteCredential(ws,cred.id);
  } else {
    if(p.id === "cloudflare" && !/^[a-f0-9]{32}$/i.test(body.accountId ?? "")) throw new ApiError(400,"invalid_account","Enter your 32-character Cloudflare account ID.");
    await saveCredential(ws,{provider:p.id,kind:"model",label:p.name,secret:body.secret,baseURL:null,options:{freeMax:true,accountId:body.accountId || ""},enabled:true});
  }
  return Response.json({ok:true},{headers:noStore});
});
