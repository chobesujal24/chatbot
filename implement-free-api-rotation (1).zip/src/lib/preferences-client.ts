"use client";

import {
  DEFAULT_PREFERENCES,
  normalizePreferences,
  type Preferences,
} from "./preferences-model";
import { installWorkspaceSession } from "./session-client";

// Runs before any component effect, so the first fetch already carries the
// workspace token and can recover from a missing session.
installWorkspaceSession();

export * from "./preferences-model";
export { DEFAULT_PREFERENCES, normalizePreferences };

/**
 * Pushes appearance preferences onto the document so CSS and the markdown
 * renderer react immediately, before the save round-trip completes.
 */
export function applyPreferences(prefs: Partial<Preferences>) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (prefs.theme !== undefined) {
    const theme = prefs.theme;
    const dark = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    root.classList.toggle("dark", dark);
    root.style.colorScheme = dark ? "dark" : "light";
    try { window.localStorage.setItem("nova-theme", theme); } catch { /* optional */ }
    // Keep the shared provider (icons, toast theme, system-theme listener) in
    // sync when a settings control or server bootstrap changes appearance.
    window.dispatchEvent(new CustomEvent("nova-theme-change", { detail: theme }));
  }
  if (prefs.accent === DEFAULT_PREFERENCES.accent) root.style.removeProperty("--brand");
  else if (prefs.accent) root.style.setProperty("--brand", prefs.accent);
  root.dataset.fontSize = prefs.fontSize ?? "md";
  root.dataset.density = prefs.density ?? "comfortable";
  root.dataset.animations = prefs.animations === false ? "off" : "on";
  root.dataset.lineNumbers = prefs.lineNumbers === false ? "off" : "on";
  root.style.setProperty("--app-message-width", `${prefs.messageWidth ?? 768}px`);
  // Markdown reads this attribute through a MutationObserver, so code blocks
  // already on screen restyle immediately when the setting changes.
  root.dataset.codeTheme = prefs.codeTheme ?? "github";
}

export const loadLocalPreferences = (): Partial<Preferences> => {
  try {
    const raw = window.localStorage.getItem("nova-appearance");
    return raw ? (JSON.parse(raw) as Partial<Preferences>) : {};
  } catch {
    return {};
  }
};

export const saveLocalPreferences = (prefs: Partial<Preferences>) => {
  try {
    window.localStorage.setItem("nova-appearance", JSON.stringify(prefs));
  } catch {
    /* storage may be unavailable in private mode */
  }
};

export const emptyPreferences = (): Preferences => ({ ...DEFAULT_PREFERENCES });
export { normalizePreferences as sanitize };
