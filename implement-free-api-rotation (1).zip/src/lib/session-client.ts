"use client";

/**
 * Workspace session on the browser side.
 *
 * The server issues a signed workspace token as an HttpOnly cookie. Embedded
 * previews and some privacy modes drop third-party cookies, which used to make
 * every write fail with "Call /api/bootstrap first." We mirror the same token
 * into localStorage and send it as `x-nova-workspace`; the server accepts
 * either proof. A missing session is minted automatically and the request is
 * retried once, so saves never fail because of ordering.
 */

const STORAGE_KEY = "nova-workspace-token";
const HEADER = "x-nova-workspace";
const SESSION_ENDPOINTS = ["/api/bootstrap", "/api/free-max"];

let installed = false;

export function getWorkspaceToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setWorkspaceToken(token: string | null | undefined): void {
  if (typeof window === "undefined" || !token) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, token);
  } catch {
    /* storage may be blocked; the cookie still works when available */
  }
}

function apiUrl(input: RequestInfo | URL): URL | null {
  try {
    const url = typeof input === "string" ? new URL(input, window.location.origin) : input instanceof URL ? input : new URL(input.url, window.location.origin);
    return url.origin === window.location.origin && url.pathname.startsWith("/api/") ? url : null;
  } catch {
    return null;
  }
}

function withSessionHeaders(input: RequestInfo | URL, init?: RequestInit): RequestInit | undefined {
  const token = getWorkspaceToken();
  if (!token) return init;
  const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
  if (!headers.has(HEADER)) headers.set(HEADER, token);
  return { ...init, headers };
}

/** Captures the signed token returned by bootstrap-style endpoints. */
async function captureToken(url: URL, response: Response): Promise<void> {
  if (!SESSION_ENDPOINTS.some((path) => url.pathname === path)) return;
  if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) return;
  try {
    const body = (await response.clone().json()) as { token?: unknown };
    if (typeof body.token === "string" && body.token) setWorkspaceToken(body.token);
  } catch {
    /* not JSON; nothing to capture */
  }
}

/** Mints a workspace and stores its token. Safe to call repeatedly. */
export async function ensureWorkspaceSession(): Promise<string | null> {
  const native = window.__novaNativeFetch ?? window.fetch.bind(window);
  try {
    const res = await native("/api/bootstrap", { cache: "no-store", credentials: "same-origin" });
    if (!res.ok) return null;
    const body = (await res.json()) as { token?: unknown };
    if (typeof body.token === "string") setWorkspaceToken(body.token);
    return typeof body.token === "string" ? body.token : null;
  } catch {
    return null;
  }
}

declare global {
  interface Window {
    __novaNativeFetch?: typeof fetch;
    __novaSessionFetch?: boolean;
  }
}

/**
 * Patches window.fetch once so every same-origin API call carries the token and
 * recovers from a missing session. Call at module scope of any client entry.
 */
export function installWorkspaceSession(): void {
  if (installed || typeof window === "undefined") return;
  installed = true;
  if (window.__novaSessionFetch) return;
  window.__novaSessionFetch = true;

  const native = window.fetch.bind(window);
  window.__novaNativeFetch = native;

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = apiUrl(input);
    if (!url) return native(input, init);

    const first = await native(input, withSessionHeaders(input, init));
    await captureToken(url, first);
    if (first.status !== 401) return first;

    // Only a missing workspace is retried; never retry auth failures or bad input.
    const body = (await first.clone().json().catch(() => null)) as
      | { error?: { code?: string } }
      | null;
    if (body?.error?.code !== "workspace_required") return first;

    const token = await ensureWorkspaceSession();
    if (!token) return first;
    const retryInit = withSessionHeaders(input, init);
    return native(input, retryInit);
  };
}
