# Nova Studio — Free Max provider workspace

The provider hub at `/` brings **24 providers and 63 named model routes** together under the **Free Max** model provider. Two anonymous routes work without an account. Choose a model in the directory or launch the playground for automatic rotation. Free-key services and finite trials are clearly distinguished.

**[Provider research, quotas, model selection, and configuration →](docs/free-max.md)**

The complete imported Nova workspace is available at `/workspace`, including the original agents, tools, skills, settings, conversation sharing, and sandboxed code editor.

## Original Nova workspace

A full-stack chat workspace with agents, tools, long-term memory, tasks, skills and a
sandboxed multi-file code workspace. Built with Next.js (App Router), the Vercel AI SDK,
Tailwind CSS, Drizzle ORM and PostgreSQL.

## Quick start

```bash
npm install
cp .env.example .env            # or edit the existing .env
npx drizzle-kit push            # create the schema
npm run dev                     # http://localhost:3000
```

Required environment:

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
AUTH_SECRET=<long random string>   # signs workspace + session cookies
APP_PASSWORD=                      # optional passcode gate
OPENAI_API_KEY=                    # optional server-side fallback key
```

Sessions are issued lazily and can be proven two ways. Opening `/` (the provider hub),
`/workspace`, or calling any API route directly mints a signed workspace without a prior
bootstrap call. The signed token is set as a cookie (`SameSite=None; Secure; Partitioned` over
HTTPS, `Lax` locally) **and** mirrored by the browser, which sends it back as
`x-nova-workspace`. Every route resolves the workspace from either proof, and every API
response echoes the workspace it was served for in `x-nova-workspace-token`. The client
verifies its token once per page load with `GET /api/session` before any other request is
sent, so a blocked cookie or a stale token can never fan out into several workspaces.

### The "Conversation not found." fix

`/api/bootstrap` and `/api/free-max` used to look at the cookie alone. A browser without a
usable cookie (embedded previews, privacy modes) was therefore handed a new, empty workspace on
every refresh — and the hub refreshes after each reply — so the next message referenced a
conversation the new workspace did not own. Now:

- both proofs are honoured everywhere, and the server tells the client which workspace it used;
- a new message is never rejected for a stale thread: it starts a fresh conversation and the
  response carries `x-nova-conversation-recovered: 1`;
- edit/regenerate on a missing thread return a typed `conversation_not_found`, which both
  clients handle by resetting to a new chat instead of showing a dead end;
- a turn that never reaches a model is rolled back, so retrying cannot duplicate the message.

Model keys can also be added per workspace in **Settings → Providers**. They are sent to the
server when you save a connection and stored encrypted with AES-256-GCM in PostgreSQL.
Subsequent responses expose only a masked preview, never the stored plaintext key. Model
keys are not written to `localStorage` or included in ordinary chat payloads.

## Offline demo (no key required)

When no provider is connected the workspace stays fully usable: the chat route streams a
clearly labelled, deterministic **offline demo** reply (`x-nova-mode: offline-demo`) that can

- answer arithmetic through the local calculator parser,
- review attached files with a static security/style pass,
- scaffold runnable HTML/CSS/JS for the code workspace,
- list the workspace's capabilities.

Demo replies are persisted with the model label `offline-demo` so usage reporting stays
honest. Connecting a real provider switches the same conversation to model streaming with
tools, memory and skills.

## Thinking effort

Models that can tune how hard they reason get a **Thinking** picker in both composers. It lists
only the levels the selected model supports (Auto, Off, Minimal, Low, Medium, High, Extra
high), is hidden for models without a dial, and reads "Thinking built in" for reasoners that
cannot be tuned. Support is detected per provider and model in `src/lib/reasoning.ts`:

| Family | Levels | Sent as |
| --- | --- | --- |
| GPT-OSS, OpenAI o-series, GPT-5 | low / medium / high (plus minimal, off or extra high by version) | `reasoning_effort`, or the AI SDK `reasoning` option for native OpenAI |
| Claude 3.7 and newer | off / low / medium / high | AI SDK `reasoning` (thinking budget) |
| Gemini 2.5 and 3 | depends on the model | `thinkingConfig` budget or level; `reasoning_effort` on the OpenAI-compatible endpoint |
| Qwen 3, GLM 4.5+ | on / off | `enable_thinking`, `thinking.type`, or Groq's `reasoning_effort: none \| default` |
| Anything via OpenRouter | as above | OpenRouter's unified `reasoning` object |

A requested level is clamped to the nearest one the model supports. With Free Max automatic
routing it is applied per routed model. If a strict host rejects the parameter, the request is
retried once without it instead of failing the turn.

Reasoning streams live into a collapsible **Thinking…** block with a running timer, is stored
apart from the answer (`messages.reasoning`, with `reasoningMs` and the applied effort in
`usage`), and is never included in share links. Reasoning that arrives inline as
`<think>…</think>` or in a side channel (`reasoning_content`, `reasoning`) is separated
automatically, so it cannot leak into the visible answer.

## Code workspace

Open it from the header **Code** button or by selecting the **Coder** agent. On desktop it
docks beside the chat (drag its left edge to resize); on phones it is full-screen.

**Editor**
- File tabs with new / rename (double-click) / delete (two-step) / import / export.
- Syntax highlighting for HTML, CSS, JavaScript, TypeScript, JSON, Python and Markdown from a
  small built-in tokenizer (`src/lib/code-highlight.ts`) — no editor dependency.
- Line numbers that stay correct with word wrap, active-line highlight, cursor position.
- Tab / Shift+Tab indentation, auto-indent, bracket and quote pairing, `⌘/Ctrl + /` comments.
  Edits go through the browser's native undo stack, so `⌘/Ctrl + Z` behaves normally.
- `⌘/Ctrl + Enter` (or `⌘/Ctrl + S`) runs the workspace.

**Preview**
- Runs in an iframe with `sandbox="allow-scripts allow-modals allow-forms"` — no
  `allow-same-origin`, so the page has an opaque origin: no cookies, no storage, no access to
  the app. The document also inherits the app's Content-Security-Policy, which blocks all
  network access; blocked requests are reported in the console instead of failing silently.
- `<link href="styles.css">` and `<script src="app.js">` that point at workspace files are
  inlined in place. Scripts run at global scope, so inline handlers (`onclick="save()"`) work.
- Code / Split / Preview layouts, phone-width preview, auto-run on pause (toggleable).
- JSON files get validation and a formatted preview; Markdown files render as Markdown.
- TypeScript and Python files are stored and sent to the model but are not executed.

**Console**
- `console.log/info/warn/error/table/assert/time`, uncaught errors, rejected promises, failed
  resources and CSP violations, authenticated by a per-run nonce.
- Every line carries its source location (`app.js:12`); click it to jump to that line.
- Repeated lines collapse with a counter.

**Loop guard**
The preview shares a thread with the app, so an accidental `while (true)` would freeze the
whole tab. Loop conditions are instrumented (`guardLoops`) and a loop that blocks for more
than two seconds is stopped with an error pointing at its line. It only rewrites loop headers
that fit on one line and can be switched off from the workspace menu.

**Send to Nova** attaches the files to the composer (respecting the attachment size limit and
the 5-file cap). Files persist per workspace in `localStorage`.

## Feature map

| Area | Highlights |
| --- | --- |
| Chat | Streaming (including Free Max), thinking effort with live reasoning, edit & resend, regenerate, stop, forks, pinning, share links, export, feedback |
| Agents | Prompt, model, temperature, steps, tools, skills, memory policy, icons |
| Tools | Calculator, time, web search, page reader, URL fetch, history search, memory, tasks |
| Memory | Ranked recall with decay, dedupe, supersede, pinning, usage counters and a change log |
| Skills | `SKILL.md`-style instruction packs, import, auto-load, per-agent allowlists |
| Context | Token meter, windowing, extractive/model compaction, per-conversation overrides |
| Settings | Providers, integrations, agents, usage, appearance, behaviour, data, shortcuts |
| Sharing | Read-only `/share/[token]` pages, revocable, expiring, attachment redaction |

## Verification

```bash
npx next typegen
npm exec tsc -- --noEmit
npm run lint          # 0 errors
npx vitest run        # unit tests in src/lib/__tests__
npm run build
```

`/api/health` reports database reachability so a platform can verify a production boot.

The sandbox cannot be meaningfully tested without a browser: string assertions on the
generated document do not prove that scripts execute. It was verified in headless Chromium —
script execution, console bridge, `file:line` mapping, inline handlers, loop guard, network
blocking, editor keystrokes and undo, and pixel alignment of the highlight layer.

## Interface design

The main page uses a flat neutral palette, an editable prompt composer, keyboard-accessible
starter categories, and real recent conversations. Search, agents, memory, tasks, templates,
and the code workspace remain available from the sidebar. Main-page suggestions never send
an API request until the user presses Send.

See [the UI design notes](docs/ui-design-notes.md) for the research references, decisions,
and validation scope. Custom accent preferences are preserved; the new default is Clay.
