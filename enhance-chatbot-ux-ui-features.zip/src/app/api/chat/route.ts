import { db } from "@/db";
import {
  agents,
  conversations,
  messages,
  skills as skillsTable,
  type ContextMeta,
  type ToolCallRecord,
} from "@/db/schema";
import { and, asc, eq, inArray } from "drizzle-orm";
import { generateText, isStepCount, streamText, type ModelMessage } from "ai";
import {
  buildDemoReply,
  demoChunks,
  deriveTitle,
  extractAttachedBlocks,
  stripAttachedBlocks,
} from "@/lib/offline";
import { runFreeMax, type ChatTurn } from "@/lib/free-max/router";
import { parsePin } from "@/lib/free-max/policy";
import { resolveModel, type ModelResolution } from "@/lib/model";
import { buildTools } from "@/lib/tools";
import { listCredentials } from "@/lib/credentials";
import { getPreferences } from "@/lib/preferences";
import { ApiError, guard, parseBody, route } from "@/lib/http";
import { findOwnedConversation, ownedConversation } from "@/lib/data";
import { splitThink, type ReasoningChoice, type ReasoningEffort } from "@/lib/reasoning";
import { chatSchema } from "@/lib/validation";
import { renderSkillIndex, seedSkills, selectSkills } from "@/lib/skills";
import { loadSkillInstructions, pickAutoLoadSkill } from "@/lib/skills-server";
import { extractCandidates, recall, remember, renderMemoryBlock } from "@/lib/memory";
import {
  buildBreakdown,
  compactionTargets,
  estimateTokens,
  extractiveSummary,
  planHistory,
  renderSummaryBlock,
  resolveContextSettings,
  shouldCompact,
  type ContextBreakdown,
} from "@/lib/context";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

function withAttachments(content: string, files: { name: string; content: string }[]): string {
  if (files.length === 0) return content;
  return (
    content +
    "\n\n" +
    files
      .map((f) => `--- Attached file: ${f.name} ---\n${f.content}\n--- End of ${f.name} ---`)
      .join("\n\n")
  );
}

function expandSystemVariables(
  template: string,
  vars: { model: string; agent: string; date: string; memories: string; skills: string },
): { expanded: string; inlineMemories: boolean; inlineSkills: boolean } {
  let inlineMemories = false;
  let inlineSkills = false;
  // Replacer functions: a literal replacement string would interpret `$` sequences.
  const safe = (value: string) => () => value;
  const expanded = template
    .replace(/\{\{\s*model\s*\}\}/gi, safe(vars.model))
    .replace(/\{\{\s*agent\s*\}\}/gi, safe(vars.agent))
    .replace(/\{\{\s*date\s*\}\}/gi, safe(vars.date))
    .replace(/\{\{\s*memories\s*\}\}/gi, () => {
      inlineMemories = true;
      return vars.memories;
    })
    .replace(/\{\{\s*skills\s*\}\}/gi, () => {
      inlineSkills = true;
      return vars.skills;
    });
  return { expanded, inlineMemories, inlineSkills };
}

const EXTRACTION_PROMPT = `You maintain a long-term memory store. From the user's latest message, extract only durable, reusable facts: preferences, corrections, stable identity or project facts, recurring workflows. Ignore one-off questions and anything already implied.
Return a JSON array (max 3 items) of objects: {"value": string <=300 chars, "type": "preference"|"fact"|"entity"|"procedure"|"event", "importance": number 0-1}. Return [] when nothing is worth storing. Output JSON only.`;

export const POST = route(async (request) => {
  const { workspaceId: ws } = await guard(request, {
    rateLimit: { bucket: "chat", limit: 40, windowMs: 60_000 },
  });
  // Chat carries attachments (5 files × up to 500KB each), so it needs a
  // larger envelope than the 256KB default used by every other route.
  const body = await parseBody(request, chatSchema, { maxBodyBytes: 2_900_000 });
  const settings = body.settings;
  const mode = body.mode;
  const startedAt = Date.now();

  const [credentials, preferences] = await Promise.all([
    listCredentials(ws),
    getPreferences(ws),
  ]);
  const modelCredential =
    credentials.find((c) => c.kind === "model" && c.isActive && c.enabled) ?? null;
  await seedSkills(ws);

  /* ── Agent ─────────────────────────────────────────────────────────────── */
  let agent: typeof agents.$inferSelect | null = null;
  if (body.agentId) {
    const [found] = await db
      .select()
      .from(agents)
      .where(and(eq(agents.id, body.agentId), eq(agents.workspaceId, ws)))
      .limit(1);
    agent = found ?? null;
  }
  if (!agent && preferences.defaultAgentId) {
    const [found] = await db
      .select()
      .from(agents)
      .where(and(eq(agents.id, preferences.defaultAgentId), eq(agents.workspaceId, ws)))
      .limit(1);
    agent = found ?? null;
  }
  if (!agent) {
    const rows = await db.select().from(agents).where(eq(agents.workspaceId, ws)).limit(20);
    agent = rows.find((a) => a.isDefault) ?? rows[0] ?? null;
  }

  const rawSystemPrompt =
    agent?.systemPrompt?.trim() ||
    preferences.systemPrompt?.trim() ||
    settings.systemPrompt?.trim() ||
    "";
  const effectiveModel = agent?.model || preferences.defaultModel || settings.model;
  const effectiveTemperature = agent?.temperature ?? preferences.temperature ?? settings.temperature;
  const maxSteps = agent?.maxSteps ?? 5;
  const memoryMode = agent?.memoryMode ?? "auto";
  const agentToolNames = agent?.tools ?? [];
  const effectiveTools = Array.from(new Set([...agentToolNames]));

  const requestedEffort: ReasoningChoice = settings.reasoningEffort ?? "default";
  const modelOptions = {
    headers: preferences.customHeaders,
    timeout: preferences.requestTimeout,
    reasoningEffort: requestedEffort,
  };

  let conversationId = body.conversationId ?? null;
  // Set when the client referenced a conversation this workspace no longer has
  // (deleted elsewhere, or a link from an earlier session). A new message is
  // never rejected for that: it simply starts a fresh conversation.
  let recovered = false;
  let createdConversation = false;
  let insertedUserMessageId: string | null = null;
  let droppedAttachments = 0;

  /* ── Persist the turn ──────────────────────────────────────────────────── */
  if (mode === "send") {
    const content = body.content!.trim();
    const limitBytes = Math.max(5, preferences.attachmentLimitKb) * 1024;
    const validAttachments = body.attachments.filter((a) => a.content.length <= limitBytes);
    droppedAttachments = body.attachments.length - validAttachments.length;

    let nextSeq = 1;
    const existing = conversationId ? await findOwnedConversation(ws, conversationId) : null;
    if (conversationId && !existing) {
      recovered = true;
      conversationId = null;
    }
    if (existing) {
      nextSeq = (existing.lastSequence ?? 0) + 1;
      // Reserve the sequence number now so the reply can never collide with it.
      await db
        .update(conversations)
        .set({ lastSequence: nextSeq, ...(agent ? { agentId: agent.id } : {}) })
        .where(eq(conversations.id, existing.id));
    } else {
      const [created] = await db
        .insert(conversations)
        .values({
          workspaceId: ws,
          title: deriveTitle(content),
          model: effectiveModel || null,
          agentId: agent?.id ?? null,
          lastSequence: 1,
        })
        .returning();
      conversationId = created.id;
      createdConversation = true;
    }
    const [userRow] = await db
      .insert(messages)
      .values({
        workspaceId: ws,
        conversationId: conversationId!,
        role: "user",
        content: withAttachments(content, validAttachments),
        attachments: validAttachments.map((a) => ({ name: a.name, size: a.content.length })),
        seq: nextSeq,
      })
      .returning({ id: messages.id });
    insertedUserMessageId = userRow?.id ?? null;
  } else {
    const target = await ownedConversation(ws, conversationId!);
    const historyRows = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId!))
      .orderBy(asc(messages.createdAt));
    let toDelete: string[] = [];
    if (mode === "regenerate") {
      const lastUserIndex = historyRows.map((m) => m.role).lastIndexOf("user");
      if (lastUserIndex >= 0) {
        toDelete = historyRows.slice(lastUserIndex + 1).map((m) => m.id);
      }
    } else {
      const index = historyRows.findIndex((m) => m.id === body.editMessageId);
      if (index < 0 || historyRows[index].role !== "user") {
        throw new ApiError(404, "message_not_found", "Only your own messages in this conversation can be edited.");
      }
      // The edit draft carries text only; re-attach the original file blocks so
      // editing never silently drops attachments from the stored message.
      const blocks = extractAttachedBlocks(historyRows[index].content).join("\n\n");
      const merged = blocks ? `${body.editContent!.trim()}\n\n${blocks}` : body.editContent!;
      await db
        .update(messages)
        .set({ content: merged })
        .where(eq(messages.id, body.editMessageId!));
      toDelete = historyRows.slice(index + 1).map((m) => m.id);
      // Editing inside the summarized prefix invalidates the rolling summary.
      if (index < (target.summarizedCount ?? 0)) {
        await db
          .update(conversations)
          .set({ summary: null, summarizedCount: 0 })
          .where(eq(conversations.id, conversationId!));
      }
    }
    if (toDelete.length > 0) await db.delete(messages).where(inArray(messages.id, toDelete));
  }

  const stopSequences = (preferences.stopSequences ?? "")
    .split(",")
    .map((s) => s.replace(/\\n/g, "\n").trim())
    .filter(Boolean)
    .slice(0, 4);

  const cid = conversationId!;
  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, cid))
    .limit(1);

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, cid))
    .orderBy(asc(messages.createdAt))
    .limit(400);
  const lastUserMessage = [...history].reverse().find((m) => m.role === "user");
  const prompt = lastUserMessage?.content ?? "";
  // Memory recall, skill matching and extraction run on the user's words — never
  // on megabytes of attached file contents, which would skew ranking and waste work.
  const promptText = stripAttachedBlocks(prompt) || prompt;

  /* ── Model resolution ──────────────────────────────────────────────────── */
  const useFreeMax = settings.provider === "free-max" || modelCredential?.provider === "free-max";
  const resolution: ModelResolution = useFreeMax
    ? { model: null, label: "Free Max", error: undefined, missingCredentials: false }
    : await resolveModel({ ...settings, model: effectiveModel }, modelCredential, modelOptions);
  const isUnconfigured = !useFreeMax && (resolution.error != null || !resolution.model);
  // The demo responder is a first-class, clearly-labelled mode. Tracking it as
  // `offline-demo` keeps usage dashboards honest and excludes it from model stats.
  let modelLabel = isUnconfigured ? "offline-demo" : resolution.label;

  /* ── Context settings, skills, memory ──────────────────────────────────── */
  const contextSettings = resolveContextSettings(
    preferences as unknown as Record<string, unknown>,
    conversation?.context,
  );
  const allSkills = await db.select().from(skillsTable).where(eq(skillsTable.workspaceId, ws));
  const skills = contextSettings.includeSkills ? selectSkills(allSkills, agent?.skills) : [];
  const skillsIndex = renderSkillIndex(skills).replace(
    "Do not load more than two skills per turn.",
    `Do not load more than ${preferences.maxSkillsPerTurn} skill${preferences.maxSkillsPerTurn === 1 ? "" : "s"} per turn.`,
  );

  // Respect disabledTools from Settings → Tools across every agent and implicit tool.
  const disabledSet = new Set(preferences.disabledTools);
  const toolNames = new Set(effectiveTools);
  if (skills.length > 0) toolNames.add("loadSkill");
  if (memoryMode !== "off") {
    toolNames.add("remember");
    toolNames.add("recall");
  }
  if (memoryMode === "auto") toolNames.add("forgetMemory");
  for (const off of disabledSet) {
    toolNames.delete(off);
  }

  const memoryEnabled = contextSettings.injectMemories && memoryMode !== "off";
  const recalled = memoryEnabled
    ? await recall(ws, promptText, contextSettings.memoryLimit, {
        minScore: preferences.memoryMinScore,
        halfLifeDays: preferences.memoryHalfLifeDays,
        reinforce: preferences.memoryReinforce,
      })
    : [];
  const memoryBlock = renderMemoryBlock(recalled);

  /* ── History windowing + optional compaction ───────────────────────────── */
  const plan = planHistory(history, contextSettings, conversation?.summarizedCount ?? 0);
  let autoSkillBlock = "";
  const autoSkillName: string[] = [];
  if (preferences.autoLoadSkill && skills.length > 0 && promptText.trim()) {
    const candidate = pickAutoLoadSkill(skills, promptText, preferences.skillMatchThreshold);
    if (candidate) {
      const loaded = await loadSkillInstructions(ws, candidate.name);
      if (loaded) {
        autoSkillBlock = `# Active skill: ${loaded.name}\nFollow these instructions for this turn.\n\n${loaded.instructions.slice(0, 9000)}`;
        autoSkillName.push(loaded.name);
      }
    }
  }

  const { expanded: expandedSystem, inlineMemories, inlineSkills } = expandSystemVariables(
    rawSystemPrompt,
    {
      model: modelLabel ?? effectiveModel ?? "unconfigured",
      agent: agent?.name ?? "Assistant",
      date: new Date().toISOString().slice(0, 10),
      memories: memoryBlock,
      skills: skillsIndex,
    },
  );

  const systemBase = [
    expandedSystem,
    inlineSkills ? "" : skillsIndex,
    inlineMemories ? "" : memoryBlock,
    autoSkillBlock,
  ]
    .filter(Boolean)
    .join("\n\n");

  const summaryBlock = conversation?.summary
    ? renderSummaryBlock(conversation.summary, conversation.summarizedCount)
    : null;

  let breakdown: ContextBreakdown = buildBreakdown({
    system: [expandedSystem, autoSkillBlock].filter(Boolean).join("\n\n"),
    skillsIndex: inlineSkills ? undefined : skillsIndex,
    memoryBlock: inlineMemories ? undefined : memoryBlock,
    history: plan.included.map((m) => ({ role: m.role, content: m.content })),
    summary: summaryBlock ?? undefined,
    settings: contextSettings,
  });

  let effectiveIncluded = plan.included;
  let summarizedCount = conversation?.summarizedCount ?? 0;
  let compactedThisTurn = false;

  const mustFoldDropped = plan.dropped.length >= 2 && contextSettings.autoCompact;
  if ((mustFoldDropped || shouldCompact(breakdown, contextSettings)) && (mustFoldDropped || effectiveIncluded.length > 6)) {
    const fixed =
      estimateTokens(systemBase) + (summaryBlock ? estimateTokens(summaryBlock) : 0);
    const drop = mustFoldDropped
      ? plan.dropped.length
      : compactionTargets(
          effectiveIncluded.map((m) => ({ content: m.content })),
          contextSettings,
          fixed,
          preferences.compactTargetRatio,
        );
    if (drop > 0) {
      const toFold = (mustFoldDropped ? plan.dropped : effectiveIncluded.slice(0, drop)).slice(-40);
      const combined = [
        ...(conversation?.summary ? [{ role: "system", content: conversation.summary }] : []),
        ...toFold.map((m) => ({ role: m.role, content: m.content })),
      ];
      let summaryText = extractiveSummary(combined);
      if (resolution.model) {
        try {
          const { text } = await generateText({
            model: resolution.model,
            system:
              "Compress the conversation notes below into durable bullet points. Keep every name, number, file path, decision and correction. Drop pleasantries. Max 220 words, bullets only.",
            prompt: combined
              .map((m) => `${m.role}: ${m.content.slice(0, 1500)}`)
              .join("\n")
              .slice(0, 24000),
            maxOutputTokens: 512,
          });
          const cleaned = splitThink(text).text.trim();
          if (cleaned.length > 40) summaryText = cleaned;
        } catch {
          /* keep the extractive summary */
        }
      }
      if (summaryText) {
        summarizedCount += drop;
        await db
          .update(conversations)
          .set({ summary: summaryText.slice(0, 8000), summarizedCount })
          .where(eq(conversations.id, cid));
        if (!mustFoldDropped) {
          effectiveIncluded = effectiveIncluded.slice(drop);
        }
        breakdown = buildBreakdown({
          system: [expandedSystem, autoSkillBlock].filter(Boolean).join("\n\n"),
          skillsIndex: inlineSkills ? undefined : skillsIndex,
          memoryBlock: inlineMemories ? undefined : memoryBlock,
          history: effectiveIncluded.map((m) => ({ role: m.role, content: m.content })),
          summary: renderSummaryBlock(summaryText, summarizedCount),
          settings: contextSettings,
        });
        compactedThisTurn = true;
      }
    }
  }

  const contextMeta: ContextMeta = {
    injectedMemoryIds: recalled.map((r) => r.id),
    usedSkillNames: autoSkillName,
    historyMessages: effectiveIncluded.length,
    summarizedMessages: summarizedCount,
    estimatedTokens: breakdown.promptTokens,
    compacted: compactedThisTurn,
  };

  const encoder = new TextEncoder();
  let full = "";
  let saved = false;
  let streamError = "";
  let providerError = "";
  // The model's thinking is tracked apart from the answer on every provider path.
  let reasoningText = "";
  let reasoningStartedAt = 0;
  let reasoningMs = 0;
  let reasoningTokens = 0;
  let appliedEffort: ReasoningEffort | null = resolution.reasoningEffort ?? null;

  /** Undo a turn that never reached a model, so retrying cannot duplicate it. */
  const rollbackTurn = async () => {
    try {
      if (createdConversation) {
        await db.delete(conversations).where(eq(conversations.id, cid));
      } else if (insertedUserMessageId) {
        await db.delete(messages).where(eq(messages.id, insertedUserMessageId));
      }
    } catch (error) {
      console.warn("Could not roll back the failed turn", error);
    }
  };

  const persist = async (
    text: string,
    toolCalls: ToolCallRecord[],
    usage: { inputTokens: number; outputTokens: number; totalTokens: number } | null,
    stopped: boolean,
  ) => {
    if (saved) return;
    saved = true;
    // Some hosts inline the model's reasoning as <think>…</think>. Keep it out
    // of the visible answer and store it alongside instead.
    const split = splitThink(text);
    if (split.reasoning && !reasoningText.trim()) reasoningText = split.reasoning;
    const answer = split.text.trim();
    const base =
      answer ||
      (stopped
        ? "*Generation stopped.*"
        : reasoningText.trim()
          ? "*The model used its whole output budget on reasoning and returned no answer. Lower the thinking effort or raise the output limit, then try again.*"
          : "*No response generated.*");
    const content = stopped && answer ? `${base}\n\n*Generation stopped.*` : base;
    const usedSkills = Array.from(
      new Set([
        ...autoSkillName,
        ...toolCalls
          .filter((c) => c.name === "loadSkill" && c.status === "done")
          .map((c) => String((c.input as { name?: string } | null)?.name ?? ""))
          .filter(Boolean),
      ]),
    );
    // Monotonic per conversation: message rows can be deleted (edit/regenerate),
    // so history length would collide with older sequence numbers.
    const nextSeq = Math.max(conversation?.lastSequence ?? 0, history.length) + 1;
    try {
      const [row] = await db
        .insert(messages)
        .values({
          workspaceId: ws,
          conversationId: cid,
          role: "assistant",
          content,
          model: modelLabel,
          toolCalls: toolCalls.length > 0 ? toolCalls : null,
          reasoning: reasoningText.trim() ? reasoningText.trim().slice(0, 60_000) : null,
          usage: {
            ...(usage ?? { inputTokens: 0, outputTokens: 0, totalTokens: 0 }),
            durationMs: Date.now() - startedAt,
            ...(reasoningMs > 0 ? { reasoningMs } : {}),
            ...(reasoningTokens > 0 ? { reasoningTokens } : {}),
            ...(appliedEffort ? { reasoningEffort: appliedEffort } : {}),
          },
          contextMeta: {
            ...contextMeta,
            estimatedTokens: breakdown.promptTokens,
            usedSkillNames: usedSkills,
          },
          seq: nextSeq,
        })
        .returning({ id: messages.id });

      await db
        .update(conversations)
        .set({
          updatedAt: new Date(),
          ...(modelLabel ? { model: modelLabel } : {}),
          lastSequence: nextSeq,
          ...(mode === "edit" && prompt ? { title: deriveTitle(prompt) } : {}),
        })
        .where(eq(conversations.id, cid));

      // Memory write-back: only when autoExtractMemories is enabled and agent allows memory.
      if (preferences.autoExtractMemories && memoryMode !== "off") {
        const candidates = extractCandidates(promptText);
        if (!isUnconfigured && row && resolution.model) {
          try {
            const { text: extraction } = await generateText({
              model: resolution.model,
              system: EXTRACTION_PROMPT,
              prompt: `Latest user message:\n"""\n${promptText.slice(0, 4000)}\n"""`,
              maxOutputTokens: 300,
            });
            const json = /\[[\s\S]*\]/.exec(extraction)?.[0];
            if (json) {
              const parsed = JSON.parse(json) as Array<{
                value?: string;
                type?: string;
                importance?: number;
              }>;
              for (const item of parsed.slice(0, 3)) {
                if (!item?.value) continue;
                candidates.push({
                  value: String(item.value).slice(0, 400),
                  type: (["preference", "fact", "entity", "procedure", "event"].includes(String(item.type))
                    ? item.type
                    : "fact") as "fact",
                  importance: typeof item.importance === "number" ? item.importance : 0.6,
                  confidence: 0.7,
                  origin: "extracted",
                });
              }
            }
          } catch {
            /* heuristic candidates are still stored */
          }
        }
        for (const candidate of candidates) {
          await remember(ws, candidate, {
            dedupe: preferences.memoryDedupe,
            maxItems: preferences.memoryMaxItems,
          });
        }
      }
    } catch (error) {
      console.error("Failed to persist assistant message", error);
    }
  };

  let stream: ReadableStream<Uint8Array>;

  if (useFreeMax) {
    // One user turn makes one logical model request. No model-based memory
    // extraction or extra tool loop consumes the free quota in this mode.
    const turns: ChatTurn[] = [
      {
        role: "system",
        content: [
          "You are Nova, a helpful assistant. Answer the user directly. This text-only session has no external tools.",
          expandedSystem,
          inlineMemories ? "" : memoryBlock,
          summaryBlock,
        ]
          .filter(Boolean)
          .join("\n\n"),
      },
      ...effectiveIncluded
        .filter((m) => m.id !== lastUserMessage?.id)
        .map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
      { role: "user", content: prompt },
    ];

    // A pin left over from another provider's model list falls back to auto routing.
    let pin = settings.model || "auto";
    try {
      parsePin(pin);
    } catch {
      pin = "auto";
    }

    // Events produced before the response stream exists are queued, then flushed.
    const queued: Uint8Array[] = [];
    let sink: ReadableStreamDefaultController<Uint8Array> | null = null;
    const emit = (event: Record<string, unknown>) => {
      const bytes = encoder.encode(`${JSON.stringify(event)}\n`);
      if (!sink) {
        queued.push(bytes);
        return;
      }
      try {
        sink.enqueue(bytes);
      } catch {
        /* client disconnected */
      }
    };
    let textOpen = false;
    let thinkingOpen = false;
    let announce!: () => void;
    const firstOutput = new Promise<void>((resolve) => {
      announce = resolve;
    });

    const run = runFreeMax(ws, turns, pin, settings.maxTokens, request.signal, {
      effort: requestedEffort,
      onEvent: (event) => {
        if (event.type === "route") {
          modelLabel = `${event.provider} / ${event.model}`;
          appliedEffort = event.effort;
          emit({
            type: "data-route",
            data: {
              provider: event.provider,
              providerName: event.providerName,
              model: event.model,
              effort: event.effort,
            },
          });
          return;
        }
        if (event.type === "reasoning") {
          if (!thinkingOpen) {
            emit({ type: "reasoning-start", id: "r1" });
            thinkingOpen = true;
            reasoningStartedAt = Date.now();
          }
          reasoningText += event.delta;
          emit({ type: "reasoning-delta", id: "r1", delta: event.delta });
        } else {
          if (thinkingOpen) {
            emit({ type: "reasoning-end", id: "r1" });
            thinkingOpen = false;
            reasoningMs = Date.now() - reasoningStartedAt;
          }
          if (!textOpen) {
            emit({ type: "text-start", id: "t1" });
            textOpen = true;
          }
          full += event.delta;
          emit({ type: "text-delta", id: "t1", delta: event.delta });
        }
        announce();
      },
    });

    // Hold the response until the router has produced output or failed, so
    // setup and quota problems still surface as real HTTP errors — and the
    // rejected turn is rolled back instead of lingering in the history, where
    // a retry would have duplicated the user's message.
    try {
      await Promise.race([firstOutput, run]);
    } catch (error) {
      if (mode === "send") await rollbackTurn();
      throw error;
    }

    stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        controller.enqueue(encoder.encode(`${JSON.stringify({ type: "start", messageId: cid })}\n`));
        for (const bytes of queued) controller.enqueue(bytes);
        queued.length = 0;
        sink = controller;
        let usage: { inputTokens: number; outputTokens: number; totalTokens: number } | null = null;
        let stopped = false;
        try {
          const result = await run;
          modelLabel = `${result.provider} / ${result.model}`;
          appliedEffort = result.effort;
          usage = result.usage;
          stopped = result.stopped;
          if (thinkingOpen) {
            emit({ type: "reasoning-end", id: "r1" });
            thinkingOpen = false;
            if (!reasoningMs) reasoningMs = Date.now() - reasoningStartedAt;
          }
          if (result.notice) {
            const note = `${full.trim() ? "\n\n" : ""}> ${result.notice}`;
            if (!textOpen) {
              emit({ type: "text-start", id: "t1" });
              textOpen = true;
            }
            full += note;
            emit({ type: "text-delta", id: "t1", delta: note });
          }
          if (textOpen) emit({ type: "text-end", id: "t1" });
          emit({ type: "finish", finishReason: stopped ? "abort" : "stop" });
        } catch (error) {
          const message = error instanceof Error ? error.message : "The provider stream failed.";
          full += `${full.trim() ? "\n\n" : ""}> **Provider error:** ${message}`;
          emit({ type: "error", errorText: message });
        } finally {
          await persist(full, [], usage, stopped);
          try {
            controller.close();
          } catch {
            /* closed */
          }
        }
      },
    });
  } else if (isUnconfigured) {
    // No key? Answer locally instead of dead-ending the product. The reply is
    // explicit about being a demo and never pretends to be model output.
    const text = buildDemoReply({
      prompt: promptText,
      attachments: (body.attachments ?? []).map((file) => ({
        name: file.name,
        content: file.content,
      })),
      agentName: agent?.name ?? null,
      memoryCount: recalled.length,
      skillCount: skills.length,
    });
    stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        try {
          controller.enqueue(encoder.encode(`${JSON.stringify({ type: "start", messageId: "demo" })}\n`));
          controller.enqueue(encoder.encode(`${JSON.stringify({ type: "text-start", id: "t1" })}\n`));
          for (const delta of demoChunks(text)) {
            full += delta;
            controller.enqueue(
              encoder.encode(`${JSON.stringify({ type: "text-delta", id: "t1", delta })}\n`),
            );
            // A touch of pacing so the reveal animation behaves like a stream.
            await new Promise((resolve) => setTimeout(resolve, 8));
          }
          controller.enqueue(encoder.encode(`${JSON.stringify({ type: "text-end", id: "t1" })}\n`));
          controller.enqueue(
            encoder.encode(`${JSON.stringify({ type: "finish", finishReason: "stop" })}\n`),
          );
        } catch {
          /* client disconnected */
        } finally {
          await persist(full, [], null, false);
          try {
            controller.close();
          } catch {
            /* closed */
          }
        }
      },
      cancel() {
        void persist(full, [], null, true);
      },
    });
  } else {
    const modelMessages: ModelMessage[] = [
      ...(summaryBlock
        ? ([{ role: "system", content: summaryBlock } as ModelMessage])
        : []),
      ...effectiveIncluded
        .filter((m) => m.id !== lastUserMessage?.id)
        .map((m) =>
          m.role === "user"
            ? ({ role: "user", content: m.content } as ModelMessage)
            : ({ role: "assistant", content: m.content } as ModelMessage),
        ),
      ...(lastUserMessage
        ? ([{ role: "user", content: lastUserMessage.content } as ModelMessage])
        : []),
    ];

    const timeoutMs = Math.min(300, Math.max(5, preferences.requestTimeout ?? 60)) * 1000;
    const abortSignal = AbortSignal.any([request.signal, AbortSignal.timeout(timeoutMs)]);

    const result = streamText({
      model: resolution.model!,
      system: systemBase || undefined,
      messages: modelMessages,
      tools: buildTools(Array.from(toolNames), ws, {
        searchResults: preferences.searchResults,
        fetchMaxKb: preferences.fetchMaxKb,
        fetchTimeoutSec: preferences.fetchTimeoutSec,
        readerMode: preferences.readerMode,
        maxSkillsPerTurn: preferences.maxSkillsPerTurn,
        memoryDedupe: preferences.memoryDedupe,
        memoryMaxItems: preferences.memoryMaxItems,
      }),
      stopWhen: isStepCount(maxSteps),
      temperature: effectiveTemperature,
      topP: preferences.topP,
      presencePenalty: preferences.presencePenalty,
      frequencyPenalty: preferences.frequencyPenalty,
      maxOutputTokens: Math.min(settings.maxTokens || contextSettings.outputBudget, contextSettings.outputBudget),
      maxRetries: preferences.maxRetries,
      ...(stopSequences.length ? { stopSequences } : {}),
      abortSignal,
      // Thinking effort, expressed the way this provider expects it.
      ...(resolution.callOptions ?? {}),
      onError: ({ error }) =>
        console.warn("streamText:", error instanceof Error ? error.message : String(error)),
    });

    const uiStream = result.toUIMessageStream({
      onError: (error) => {
        const raw = error instanceof Error ? error.message : String(error);
        return raw.replace(/\s+/g, " ").slice(0, 300) || "The model request failed.";
      },
    });

    stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const reader = uiStream.getReader();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = value as { type?: string; delta?: string; errorText?: string };
            if (chunk.type === "reasoning-delta" && chunk.delta) {
              if (!reasoningStartedAt) reasoningStartedAt = Date.now();
              reasoningText += chunk.delta;
            }
            if (chunk.type === "text-delta" && chunk.delta) {
              if (reasoningStartedAt && !reasoningMs) reasoningMs = Date.now() - reasoningStartedAt;
              full += chunk.delta;
            }
            if (chunk.type === "error" && chunk.errorText) providerError = chunk.errorText;
            controller.enqueue(encoder.encode(`${JSON.stringify(value)}\n`));
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : "The model request failed.";
          streamError = message;
          const note = `\n\n> **Provider error:** ${message}`;
          full += note;
          try {
            controller.enqueue(
              encoder.encode(`${JSON.stringify({ type: "text-delta", id: "err", delta: note })}\n`),
            );
          } catch {
            /* closed */
          }
        } finally {
          let toolCalls: ToolCallRecord[] = [];
          let usage: { inputTokens: number; outputTokens: number; totalTokens: number } | null = null;
          try {
            // A failed provider rejects these promises; degrade to empty results
            // so the error chunk (and the persisted note below) is all the user
            // and the logs ever see.
            const [text, steps, totalUsage] = await Promise.all([
              Promise.resolve(result.text).then(
                (value) => value,
                () => "",
              ),
              Promise.resolve(result.steps).then(
                (value) => value,
                () => [],
              ),
              Promise.resolve(result.totalUsage).then(
                (value) => value,
                () => ({ inputTokens: 0, outputTokens: 0, totalTokens: 0 }),
              ),
            ]);
            if (text) full = text;
            toolCalls = steps.flatMap((step) =>
              step.toolCalls.map((call) => {
                const res = step.toolResults.find((r) => r.toolCallId === call.toolCallId);
                const failed = res && "error" in (res as object);
                return {
                  id: call.toolCallId,
                  name: call.toolName,
                  input: call.input,
                  output: res?.output ?? null,
                  status: failed ? ("error" as const) : ("done" as const),
                };
              }),
            );
            usage = {
              inputTokens: totalUsage.inputTokens ?? 0,
              outputTokens: totalUsage.outputTokens ?? 0,
              totalTokens: totalUsage.totalTokens ?? 0,
            };
            reasoningTokens =
              (totalUsage as unknown as { outputTokenDetails?: { reasoningTokens?: number } })
                .outputTokenDetails?.reasoningTokens ?? 0;
            if (preferences.trustProviderTokens !== false && (totalUsage.inputTokens ?? 0) > 0) {
              breakdown = {
                ...breakdown,
                promptTokens: totalUsage.inputTokens ?? breakdown.promptTokens,
              };
            }
          } catch (error) {
            console.warn(
              "stream result unavailable:",
              error instanceof Error ? error.message : String(error),
            );
          }
          if (providerError && !full.trim()) {
            streamError = providerError;
            full = `> **Provider error:** ${providerError}\n\nCheck the model ID, API key and base URL in [Settings → Providers](/settings#providers).`;
          }
          if (reasoningStartedAt && !reasoningMs) reasoningMs = Date.now() - reasoningStartedAt;
          await persist(full, toolCalls, usage, false);
          try {
            controller.close();
          } catch {
            /* closed */
          }
        }
      },
      cancel() {
        void persist(full, [], null, true);
      },
    });
  }

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
      "x-nova-conversation-id": cid,
      "x-nova-mode": isUnconfigured ? "offline-demo" : "model",
      "x-nova-model": modelLabel ?? "",
      "x-nova-agent": agent?.name ?? "",
      "x-nova-skills": String(skills.length),
      "x-nova-memories": String(recalled.length),
      "x-nova-context-tokens": String(breakdown.promptTokens),
      "x-nova-context-ratio": String(breakdown.ratio),
      "x-nova-compacted": compactedThisTurn ? "1" : "0",
      "x-nova-conversation-recovered": recovered ? "1" : "0",
      "x-nova-attachments-dropped": String(droppedAttachments),
      "x-nova-reasoning-effort": appliedEffort ?? "",
      ...(streamError ? { "x-nova-error": encodeURIComponent(streamError) } : {}),
    },
  });
});
