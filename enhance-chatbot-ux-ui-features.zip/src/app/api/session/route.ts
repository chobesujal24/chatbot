import { NextResponse } from "next/server";
import { ApiError, guard, noStore, route } from "@/lib/http";
import { bootstrapWorkspace, isAuthorized, passwordRequired, workspaceToken } from "@/lib/workspace";

export const dynamic = "force-dynamic";

/**
 * Lightweight session check. The browser calls this once per page load, before
 * any other API request, to confirm the workspace token it holds — or to be
 * issued one. Doing that in a single round trip is what keeps a browser on one
 * workspace even when its cookie is blocked or its stored token has gone stale.
 */
export const GET = route(async (request) => {
  await guard(request, {
    public: true,
    rateLimit: { bucket: "session", limit: 120, windowMs: 60_000 },
  });
  if (!(await isAuthorized())) {
    throw new ApiError(401, "authentication_required", "A passcode is required.");
  }
  const { id, created } = await bootstrapWorkspace(request);
  return NextResponse.json(
    { workspace: id, created, token: await workspaceToken(id), passwordRequired: passwordRequired() },
    { headers: noStore },
  );
});
