import { NextResponse } from "next/server";
import { ApiError, guard, parseBody, route } from "@/lib/http";
import {
  createSession,
  passwordRequired,
  SESSION_TOKEN_HEADER,
  verifyPassword,
} from "@/lib/workspace";
import { authSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const POST = route(async (request) => {
  await guard(request, {
    public: true,
    rateLimit: { bucket: "auth", limit: 10, windowMs: 60_000 },
  });
  if (!passwordRequired()) {
    return NextResponse.json({ ok: true, required: false });
  }
  const { password } = await parseBody(request, authSchema);
  if (!(await verifyPassword(password))) {
    throw new ApiError(401, "invalid_password", "Incorrect passcode.");
  }
  // The token is also returned in a header so browsers that drop the session
  // cookie (embedded previews) can keep the sign-in by mirroring it.
  const token = await createSession();
  return NextResponse.json(
    { ok: true, required: true },
    { headers: { [SESSION_TOKEN_HEADER]: token } },
  );
});
