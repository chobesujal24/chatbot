"use client";

import { useEffect, useRef, useState } from "react";
import { Brain, ChevronDown } from "lucide-react";
import { formatElapsed, formatThinkingDuration } from "@/lib/reasoning";
import { cn } from "@/lib/utils";

interface ReasoningBlockProps {
  /** The model's thinking so far. */
  text: string;
  /** True while the thinking phase is still streaming. */
  live?: boolean;
  /** When thinking started (epoch ms); drives the live counter. */
  startedAt?: number;
  /** How long a finished thinking phase took. */
  durationMs?: number;
  /** The effort level that was applied, shown as a small tag. */
  effort?: string;
}

/**
 * Collapsible view of a model's reasoning. It opens by itself while the model
 * is thinking and folds away once the answer starts, unless the reader has
 * chosen a state — an explicit toggle always wins.
 */
export function ReasoningBlock({ text, live = false, startedAt, durationMs, effort }: ReasoningBlockProps) {
  const [userOpen, setUserOpen] = useState<boolean | null>(null);
  const [now, setNow] = useState(0);
  const bodyRef = useRef<HTMLDivElement>(null);
  const open = userOpen ?? live;

  useEffect(() => {
    if (!live) return;
    const tick = () => setNow(Date.now());
    const first = setTimeout(tick, 0);
    const timer = setInterval(tick, 1000);
    return () => {
      clearTimeout(first);
      clearInterval(timer);
    };
  }, [live]);

  // Follow the newest thoughts while they stream in.
  useEffect(() => {
    if (!live || !open) return;
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [live, open, text]);

  if (!live && !text.trim()) return null;

  const elapsed = live && startedAt && now ? formatElapsed(now - startedAt) : null;
  const label = live
    ? "Thinking"
    : durationMs
      ? `Thought for ${formatThinkingDuration(durationMs)}`
      : "Thought process";

  return (
    <div
      className={cn(
        "mb-3 overflow-hidden rounded-xl border bg-muted/30 transition-colors",
        live && "border-brand/35",
      )}
    >
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setUserOpen(!open)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left text-[12.5px] text-muted-foreground outline-none transition-colors hover:bg-muted/50 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring/50"
      >
        <Brain size={14} aria-hidden className={cn("shrink-0", live && "animate-pulse text-brand")} />
        <span className="font-medium">
          {label}
          {live ? "…" : ""}
        </span>
        {elapsed && <span className="font-mono text-[11px] opacity-70">{elapsed}</span>}
        {effort && (
          <span className="rounded bg-muted px-1.5 py-px font-mono text-[10px] uppercase tracking-wide">
            {effort}
          </span>
        )}
        <ChevronDown
          size={13}
          aria-hidden
          className={cn("ml-auto shrink-0 transition-transform", open && "rotate-180")}
        />
      </button>
      {open && text && (
        <div
          ref={bodyRef}
          className="scroll-slim max-h-72 overflow-y-auto whitespace-pre-wrap border-t px-3.5 py-2.5 text-[12.5px] leading-relaxed text-muted-foreground [overflow-wrap:anywhere]"
        >
          {text}
        </div>
      )}
    </div>
  );
}
