"use client";
import type { RoutingSettings } from "@/lib/free-max/catalog";
import { installWorkspaceSession } from "@/lib/session-client";

installWorkspaceSession();

export type View = "providers" | "chat" | "models" | "activity" | "keys" | "history";
export const TITLES: Record<View, string> = {
  providers: "Model providers",
  chat: "Chat playground",
  models: "Model library",
  activity: "Activity",
  keys: "API keys",
  history: "Chat history",
};

export interface Connection {
  provider: string;
  ready: boolean;
  hasKey: boolean;
  fromEnv: boolean;
}
export interface ChatSummary {
  id: string;
  title: string;
  model: string | null;
  updatedAt: string;
  pinned: boolean;
}
export interface Run {
  id: string;
  provider: string;
  model: string;
  outcome: string;
  durationMs: number;
  tokens: number;
  attempts: { provider: string; status: number; note: string }[];
  createdAt: string;
}
export interface HubData {
  workspace: string;
  token?: string;
  routing: RoutingSettings;
  history: ChatSummary[];
  runs: Run[];
  connections: Connection[];
}

export interface ChatUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  durationMs: number;
  reasoningMs?: number;
  reasoningTokens?: number;
  reasoningEffort?: string;
}
export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  model?: string | null;
  /** The model's thinking, stored apart from the visible answer. */
  reasoning?: string | null;
  usage?: ChatUsage | null;
  attachments?: { name: string; size: number }[] | null;
  createdAt?: string;
}

/** An API failure that keeps the server's status and machine-readable code. */
export class ApiRequestError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string,
  ) {
    super(message);
    this.name = "ApiRequestError";
  }
}

export async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, { cache: "no-store", ...options });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiRequestError(
      body.error?.message || `Request failed (${res.status}).`,
      res.status,
      body.error?.code,
    );
  }
  return body as T;
}

export const post = <T,>(url: string, body: unknown) =>
  api<T>(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

export const readableTime = (iso: string) =>
  new Date(iso).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
