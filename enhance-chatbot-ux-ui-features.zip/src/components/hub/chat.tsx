"use client";

import {
  isValidElement,
  memo,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  Brain,
  Check,
  ChevronDown,
  CircleAlert,
  Code2,
  Copy,
  FileText,
  GitBranch,
  Layers3,
  Lightbulb,
  LoaderCircle,
  Paperclip,
  Plus,
  RefreshCw,
  ShieldCheck,
  SlidersHorizontal,
  Square,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { CATALOG, findFreeProvider, type FreeProvider } from "@/lib/free-max/catalog";
import { copyToClipboard } from "@/lib/clipboard";
import { stripAttachedBlocks } from "@/lib/offline";
import {
  effortHint,
  effortLabel,
  formatElapsed,
  formatThinkingDuration,
  isReasoningChoice,
  normalizeEffort,
  reasoningSupport,
  type ReasoningChoice,
} from "@/lib/reasoning";
import { NovaMark } from "./marks";
import { PageTitle } from "./directory";
import { api, ApiRequestError, type ChatMessage, type HubData } from "./types";

interface ChatProps {
  pin: string;
  setPin: (pin: string) => void;
  conversationId: string | null;
  setConversationId: (id: string) => void;
  onRefresh: () => Promise<void>;
  data: HubData | null;
  onDetails: (provider: FreeProvider, model?: string) => void;
  onSettings: () => void;
  notify: (message: string) => void;
  onNew: () => void;
  /** The open conversation no longer exists; drop it and start fresh. */
  onGone: () => void;
}

interface Attachment {
  name: string;
  content: string;
}
type Job = { mode: "send"; text: string; file: Attachment | null } | { mode: "regenerate" };

interface Failure {
  title: string;
  message: string;
  code?: string;
  /** Re-runs the turn that failed. */
  retry?: Job;
  /** Re-fetches the conversation that failed to load. */
  reload?: boolean;
}

/** The reply that is currently streaming in. */
interface LiveTurn {
  text: string;
  reasoning: string;
  route: string | null;
  effort: string | null;
  thinkingStartedAt: number | null;
  thinkingMs: number | null;
}

interface StreamEvent {
  type?: string;
  delta?: string;
  errorText?: string;
  data?: { provider?: string; providerName?: string; model?: string; effort?: string | null };
}

const EFFORT_KEY = "nova-thinking-effort";
const MAX_FILE_BYTES = 20_000;
const FILE_TYPES = ".txt,.md,.csv,.json,.js,.jsx,.ts,.tsx,.py,.html,.css,.yml,.yaml,.sql,.log";
const GONE_NOTICE = "That conversation is no longer available. Starting a new chat.";

const localId = () =>
  globalThis.crypto?.randomUUID?.() ?? `local-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

function failureTitle(error: ApiRequestError | null): string {
  switch (error?.code) {
    case "setup_required":
      return "No route is ready yet";
    case "rate_limited":
      return "Slow down a little";
    case "route_unavailable":
      return error.status === 429 ? "The free allowance is in use" : "No provider could answer";
    case "unknown_model":
      return "That model is not available";
    case "validation_error":
      return "That message could not be sent";
    default:
      return "The request did not go through";
  }
}

const SUGGESTIONS = [
  { icon: Lightbulb, title: "Explore an idea", text: "Help me brainstorm three useful projects I can build with free AI models." },
  { icon: Code2, title: "Write some code", text: "Write a small JavaScript function that groups an array of objects by a property, and explain how it works." },
  { icon: FileText, title: "Draft something", text: "Help me write a concise introduction for my new open-source project. Ask me about the project first." },
];

/** Fenced code with a language label and a copy button. */
function CodeBlock({ children }: { children?: ReactNode }) {
  const ref = useRef<HTMLPreElement>(null);
  const [copied, setCopied] = useState(false);
  const child = Array.isArray(children) ? children[0] : children;
  const className = isValidElement<{ className?: string }>(child) ? (child.props.className ?? "") : "";
  const language = /language-([\w+#-]+)/.exec(className)?.[1] ?? "text";
  const copy = async () => {
    if (!(await copyToClipboard(ref.current?.innerText ?? ""))) return;
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };
  return (
    <div className="code-block">
      <div className="code-head">
        <span>{language}</span>
        <button type="button" onClick={() => void copy()} aria-label="Copy code">
          {copied ? <Check size={11} /> : <Copy size={11} />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre ref={ref}>{children}</pre>
    </div>
  );
}

/** Memoised so finished messages do not re-render on every streamed frame. */
const Prose = memo(function Prose({ content }: { content: string }) {
  return (
    <div className="hub-markdown">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          pre: ({ children }) => <CodeBlock>{children}</CodeBlock>,
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noreferrer noopener">
              {children}
            </a>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
});

/**
 * The model's reasoning. Opens by itself while the model is thinking and folds
 * away when the answer starts — unless the reader toggled it, which always wins.
 */
function Thinking({
  text,
  live,
  startedAt,
  ms,
  effort,
}: {
  text: string;
  live: boolean;
  startedAt?: number | null;
  ms?: number | null;
  effort?: string | null;
}) {
  const [userOpen, setUserOpen] = useState<boolean | null>(null);
  const [now, setNow] = useState(0);
  const body = useRef<HTMLDivElement>(null);
  const open = userOpen ?? live;

  useEffect(() => {
    if (!live) return;
    const tick = () => setNow(Date.now());
    const first = setTimeout(tick, 0);
    const timer = setInterval(tick, 1000);
    return () => {
      clearTimeout(first);
      clearInterval(timer);
    };
  }, [live]);

  useEffect(() => {
    if (live && open && body.current) body.current.scrollTop = body.current.scrollHeight;
  }, [live, open, text]);

  if (!live && !text.trim()) return null;
  const label = live ? "Thinking…" : ms ? `Thought for ${formatThinkingDuration(ms)}` : "Thought process";

  return (
    <div className={`reasoning${live ? " is-live" : ""}${open ? " is-open" : ""}`}>
      <button type="button" className="reasoning-toggle" aria-expanded={open} onClick={() => setUserOpen(!open)}>
        <Brain size={13} aria-hidden />
        <span>{label}</span>
        {live && startedAt && now ? <small>{formatElapsed(now - startedAt)}</small> : null}
        {effort ? <em>{effort}</em> : null}
        <ChevronDown size={12} aria-hidden />
      </button>
      {open && text ? (
        <div className="reasoning-body" ref={body}>
          {text}
        </div>
      ) : null}
    </div>
  );
}

export function Chat({
  pin,
  setPin,
  conversationId,
  setConversationId,
  onRefresh,
  data,
  onDetails,
  onSettings,
  notify,
  onNew,
  onGone,
}: ChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(Boolean(conversationId));
  const [failure, setFailure] = useState<Failure | null>(null);
  const [attached, setAttached] = useState<Attachment | null>(null);
  const [live, setLive] = useState<LiveTurn | null>(null);
  const [pendingUser, setPendingUser] = useState<ChatMessage | null>(null);
  const [hidden, setHidden] = useState<string[]>([]);
  const [effort, setEffort] = useState<ReasoningChoice>("default");
  const [atBottom, setAtBottom] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const area = useRef<HTMLTextAreaElement>(null);
  const inputFile = useRef<HTMLInputElement>(null);
  const end = useRef<HTMLDivElement>(null);
  const ctrl = useRef<AbortController | null>(null);
  const loaded = useRef<string | null>(null);
  const liveRef = useRef<LiveTurn | null>(null);
  const frame = useRef(0);
  const stick = useRef(true);
  const alive = useRef(true);

  const provider = pin === "auto" ? null : findFreeProvider(pin.split("::")[0]);
  const routeReady = (id: string) =>
    Boolean(data?.connections.find((c) => c.provider === id)?.ready) && !data?.routing.disabled.includes(id);

  // Thinking effort: only offered where the selected route can actually use it.
  const support = useMemo(() => reasoningSupport("free-max", pin), [pin]);
  const effortOptions: ReasoningChoice[] =
    support && support.efforts.length > 0 ? ["default", ...support.efforts] : [];
  const shownEffort: ReasoningChoice =
    effort === "default" ? "default" : (normalizeEffort(effort, support) ?? "default");

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      ctrl.current?.abort();
      if (frame.current) cancelAnimationFrame(frame.current);
    };
  }, []);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(EFFORT_KEY);
      if (isReasoningChoice(stored)) setEffort(stored);
    } catch {
      /* storage is optional */
    }
  }, []);

  // Keep an unsent draft across view switches and reloads, per conversation.
  const draftKey = `nova-hub-draft:${conversationId ?? "new"}`;
  useEffect(() => {
    try {
      const saved = window.sessionStorage.getItem(draftKey);
      if (saved) setDraft((current) => current || saved);
    } catch {
      /* storage is optional */
    }
  }, [draftKey]);
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        if (draft.trim()) window.sessionStorage.setItem(draftKey, draft);
        else window.sessionStorage.removeItem(draftKey);
      } catch {
        /* storage is optional */
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [draft, draftKey]);

  const chooseEffort = (value: ReasoningChoice) => {
    setEffort(value);
    try {
      window.localStorage.setItem(EFFORT_KEY, value);
    } catch {
      /* storage is optional */
    }
  };

  // Load the open conversation. A thread that no longer exists (deleted
  // elsewhere, or a link from an earlier session) is dropped quietly instead of
  // leaving the playground stuck on an error.
  useEffect(() => {
    let cancelled = false;
    if (!conversationId) {
      setMessages([]);
      setLoading(false);
      loaded.current = null;
      return;
    }
    if (loaded.current === conversationId) return;
    setLoading(true);
    setFailure(null);
    api<{ messages: ChatMessage[] }>(`/api/conversations/${conversationId}/messages?limit=200`)
      .then((result) => {
        if (cancelled) return;
        setMessages(result.messages);
        loaded.current = conversationId;
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        if (error instanceof ApiRequestError && error.status === 404) {
          notify(GONE_NOTICE);
          onGone();
          return;
        }
        setFailure({
          title: "This conversation could not be loaded",
          message: error instanceof Error ? error.message : "Check your connection and try again.",
          reload: true,
        });
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [conversationId, notify, onGone, reloadKey]);

  // Follow new output only while the reader is already at the bottom.
  useEffect(() => {
    const node = end.current;
    if (!node || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(([entry]) => {
      stick.current = entry.isIntersecting;
      setAtBottom(entry.isIntersecting);
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useLayoutEffect(() => {
    // Instant, not smooth: the scroller animates by default, which would lag
    // behind a reply that grows on every frame.
    // Only once there is a thread: the empty welcome screen must stay put.
    if (!stick.current || (messages.length === 0 && !live && !pendingUser)) return;
    end.current?.scrollIntoView({ block: "end", behavior: "instant" });
  }, [messages, live, pendingUser, loading]);

  useLayoutEffect(() => {
    const el = area.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [draft]);

  const stop = () => ctrl.current?.abort();

  useEffect(() => {
    if (!sending) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") ctrl.current?.abort();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sending]);

  /** Coalesces streamed deltas into one render per animation frame. */
  const schedule = () => {
    if (frame.current) return;
    frame.current = requestAnimationFrame(() => {
      frame.current = 0;
      if (liveRef.current && alive.current) setLive({ ...liveRef.current });
    });
  };

  /** Reads the newline-delimited event stream. Returns an error reported mid-stream, if any. */
  const consume = async (response: Response): Promise<string> => {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("The reply arrived without a body.");
    const decoder = new TextDecoder();
    let buffer = "";
    let streamError = "";
    const handle = (line: string) => {
      const trimmed = line.trim();
      const turn = liveRef.current;
      if (!trimmed || !turn) return;
      let event: StreamEvent;
      try {
        event = JSON.parse(trimmed) as StreamEvent;
      } catch {
        return;
      }
      const closeThinking = () => {
        if (turn.thinkingStartedAt && turn.thinkingMs === null) {
          turn.thinkingMs = Date.now() - turn.thinkingStartedAt;
        }
      };
      switch (event.type) {
        case "data-route":
          turn.route = [event.data?.providerName ?? event.data?.provider, event.data?.model]
            .filter(Boolean)
            .join(" · ");
          turn.effort = event.data?.effort ?? null;
          break;
        case "reasoning-delta":
          if (event.delta) {
            turn.thinkingStartedAt ??= Date.now();
            turn.reasoning += event.delta;
          }
          break;
        case "reasoning-end":
          closeThinking();
          break;
        case "text-delta":
          if (event.delta) {
            closeThinking();
            turn.text += event.delta;
          }
          break;
        case "error":
          streamError = event.errorText || "The model returned an error.";
          break;
        default:
          return;
      }
      schedule();
    };
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) handle(line);
    }
    handle(buffer);
    return streamError;
  };

  /** Sends a message or regenerates the last reply, streaming the result. */
  const run = async (job: Job) => {
    if (ctrl.current || !data) return;
    const abort = new AbortController();
    ctrl.current = abort;
    stick.current = true;
    setFailure(null);
    setSending(true);
    const turn: LiveTurn = {
      text: "",
      reasoning: "",
      route: null,
      effort: null,
      thinkingStartedAt: null,
      thinkingMs: null,
    };
    liveRef.current = turn;
    setLive({ ...turn });

    let replaced: string[] = [];
    if (job.mode === "send") {
      setPendingUser({
        id: "pending-user",
        role: "user",
        content: job.text,
        attachments: job.file ? [{ name: job.file.name, size: job.file.content.length }] : null,
      });
      setDraft("");
      setAttached(null);
      try {
        // Cleared now rather than by the debounced save, which a conversation
        // id change would cancel and leave the sent text behind as a "draft".
        window.sessionStorage.removeItem(draftKey);
      } catch {
        /* storage is optional */
      }
    } else {
      const lastUser = messages.map((m) => m.role).lastIndexOf("user");
      replaced = messages.slice(lastUser + 1).map((m) => m.id);
      setHidden(replaced);
    }

    let threadId = conversationId;
    let accepted = false; // the server took the turn and started streaming
    let gone = false;
    let problem: Failure | null = null;

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: abort.signal,
        body: JSON.stringify({
          mode: job.mode,
          conversationId: threadId,
          ...(job.mode === "send"
            ? { content: job.text, attachments: job.file ? [job.file] : [] }
            : {}),
          settings: {
            provider: "free-max",
            model: pin,
            temperature: 0.7,
            maxTokens: 2048,
            reasoningEffort: shownEffort,
          },
        }),
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new ApiRequestError(
          body?.error?.message || `Request failed (${response.status}).`,
          response.status,
          body?.error?.code,
        );
      }
      accepted = true;
      const id = response.headers.get("x-nova-conversation-id");
      if (id && alive.current) {
        threadId = id;
        loaded.current = id;
        setConversationId(id);
      }
      if (response.headers.get("x-nova-conversation-recovered") === "1") {
        notify("That conversation was no longer available, so your message started a new one.");
      }
      if (Number(response.headers.get("x-nova-attachments-dropped") ?? 0) > 0) {
        notify("The attachment was over the size limit and was not sent.");
      }
      const streamError = await consume(response);
      if (streamError) {
        problem = { title: "The reply was interrupted", message: streamError, retry: { mode: "regenerate" } };
      }
    } catch (cause) {
      const error = cause instanceof ApiRequestError ? cause : null;
      if (abort.signal.aborted) {
        if (!accepted) {
          problem = {
            title: "Stopped",
            message:
              job.mode === "send"
                ? "Stopped before a reply started. Your message is back in the composer."
                : "Stopped before a new reply started.",
          };
        }
      } else if (error?.code === "conversation_not_found") {
        gone = true;
      } else {
        problem = {
          title: failureTitle(error),
          message:
            cause instanceof Error && cause.message
              ? cause.message
              : "Something went wrong. Please try again.",
          code: error?.code,
          retry: job,
        };
      }
    }

    if (frame.current) {
      cancelAnimationFrame(frame.current);
      frame.current = 0;
    }
    if (!alive.current) return;
    const final = liveRef.current;

    if (accepted && threadId) {
      // The server is the source of truth for ids, usage and stored reasoning.
      if (abort.signal.aborted) await wait(450); // let it save the partial reply
      try {
        const fresh = await api<{ messages: ChatMessage[] }>(
          `/api/conversations/${threadId}/messages?limit=200`,
        );
        if (alive.current) setMessages(fresh.messages);
      } catch {
        if (alive.current && final && (final.text || final.reasoning)) {
          setMessages((old) => [
            ...old.filter((m) => !replaced.includes(m.id)),
            ...(job.mode === "send"
              ? [{ id: localId(), role: "user" as const, content: job.text }]
              : []),
            {
              id: localId(),
              role: "assistant" as const,
              content: final.text,
              reasoning: final.reasoning || null,
              model: final.route,
            },
          ]);
        }
      }
    } else if (job.mode === "send") {
      // Nothing was saved, so hand the message back: no input is ever lost.
      setDraft((current) => current || job.text);
      setAttached((current) => current ?? job.file);
    }
    if (!alive.current) return;

    liveRef.current = null;
    ctrl.current = null;
    setLive(null);
    setPendingUser(null);
    setHidden([]);
    setSending(false);
    if (gone) {
      notify(GONE_NOTICE);
      onGone();
    } else {
      setFailure(problem);
    }
    void onRefresh().catch(() => undefined);
    window.setTimeout(() => area.current?.focus(), 20);
  };

  const send = () => {
    const text = draft.trim();
    if (!text || sending || !data) return;
    void run({ mode: "send", text, file: attached });
  };

  const selectProvider = (id: string) => {
    if (id === "free-max") {
      setPin("auto");
      return;
    }
    const next = findFreeProvider(id);
    if (!next) return;
    if (routeReady(id)) setPin(`${next.id}::${next.models[0].id}`);
    else onDetails(next);
  };

  const selectModel = (value: string) => {
    const [id, model] = value.split("::");
    if (id === "auto") {
      setPin("auto");
      return;
    }
    const next = findFreeProvider(id);
    if (!next) return;
    if (routeReady(id)) setPin(value);
    else onDetails(next, model);
  };

  const copyMessage = async (message: ChatMessage) => {
    if (await copyToClipboard(message.content)) {
      setCopiedId(message.id);
      setTimeout(() => setCopiedId((current) => (current === message.id ? null : current)), 1400);
    } else {
      notify("Select the reply to copy it");
    }
  };

  const visible = messages.filter((m) => !hidden.includes(m.id));
  const lastMessage = visible[visible.length - 1];
  const canRegenerate = Boolean(conversationId) && lastMessage?.role === "assistant" && !sending;
  const hasThread = visible.length > 0 || Boolean(pendingUser) || Boolean(live);
  const routeName = provider?.name || "Free Max";

  const userBubble = (message: ChatMessage) => (
    <div className="message message-user" key={message.id}>
      <div className="message-avatar">
        <UserRound size={15} />
      </div>
      <div className="message-body">
        <div className="message-label">You</div>
        <div className="hub-markdown user-text">{stripAttachedBlocks(message.content) || message.content}</div>
        {message.attachments && message.attachments.length > 0 && (
          <div className="message-files">
            {message.attachments.map((file) => (
              <span key={file.name}>
                <FileText size={11} />
                {file.name}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="chat-page">
      <PageTitle
        eyebrow="INFERENCE WORKSPACE"
        title="Chat playground"
        description="A focused space to think, write, and build with your models."
        action={
          <button className="hub-button outline" disabled={sending} onClick={onNew}>
            <Plus size={15} />
            New session
          </button>
        }
      />

      <div className="chat-config">
        <div className="chat-config-field">
          <span>MODEL PROVIDER</span>
          <div>
            <Layers3 size={16} />
            <select
              aria-label="Model provider"
              disabled={sending}
              value={provider?.id || "free-max"}
              onChange={(event) => selectProvider(event.target.value)}
            >
              <option value="free-max">Free Max</option>
              {CATALOG.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                  {p.access === "keyless" ? " · No sign-up" : ""}
                </option>
              ))}
            </select>
            <ChevronDown size={13} />
          </div>
        </div>
        <div className="config-separator" />
        <div className="chat-config-field model-field">
          <span>MODEL SELECTION</span>
          <div>
            <select
              aria-label="Model selection"
              disabled={sending}
              value={pin}
              onChange={(event) => selectModel(event.target.value)}
            >
              <option value="auto">Auto-select model</option>
              {(provider ? [provider] : CATALOG).map((p) => (
                <optgroup key={p.id} label={p.name}>
                  {p.models.map((m) => (
                    <option key={m.id} value={`${p.id}::${m.id}`}>
                      {m.name}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <ChevronDown size={13} />
          </div>
        </div>
        <button
          className="icon-button config-button"
          onClick={onSettings}
          title="Routing settings"
          aria-label="Routing settings"
        >
          <SlidersHorizontal size={16} />
        </button>
      </div>

      <div className="chat-window">
        {loading ? (
          <div className="empty-state">
            <LoaderCircle className="spin" />
            <p>Loading conversation…</p>
          </div>
        ) : !hasThread ? (
          <div className="chat-welcome">
            <div className="welcome-orbit">
              <NovaMark size={42} />
            </div>
            <div className="section-eyebrow">NOVA PLAYGROUND</div>
            <h2>A new conversation.</h2>
            <p>
              {provider
                ? `${provider.name} is selected for this session.`
                : "One prompt, intelligently routed to a free model."}
              <br />
              What would you like to work on?
            </p>
            <div className="suggestion-cards">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s.title}
                  onClick={() => {
                    setDraft(s.text);
                    area.current?.focus();
                  }}
                >
                  <s.icon size={18} />
                  <span>{s.title}</span>
                  <ArrowUpRight size={13} />
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="chat-messages" aria-live="polite" aria-busy={sending}>
            {visible.map((message) =>
              message.role === "user" ? (
                userBubble(message)
              ) : (
                <div className="message message-assistant" key={message.id}>
                  <div className="message-avatar">
                    <NovaMark size={20} />
                  </div>
                  <div className="message-body">
                    <div className="message-label">
                      Nova<span>Free Max</span>
                    </div>
                    {message.reasoning ? (
                      <Thinking
                        text={message.reasoning}
                        live={false}
                        ms={message.usage?.reasoningMs}
                        effort={message.usage?.reasoningEffort}
                      />
                    ) : null}
                    <Prose content={message.content} />
                    <div className="message-foot">
                      <GitBranch size={12} />
                      <code>{message.model || "Model reply"}</code>
                      {message.usage && message.usage.totalTokens > 0 ? (
                        <span className="meta-chip">
                          {message.usage.totalTokens.toLocaleString()} tok ·{" "}
                          {(message.usage.durationMs / 1000).toFixed(1)}s
                        </span>
                      ) : null}
                      <div className="message-actions">
                        <button type="button" onClick={() => void copyMessage(message)}>
                          {copiedId === message.id ? <Check size={11} /> : <Copy size={11} />}
                          {copiedId === message.id ? "Copied" : "Copy"}
                        </button>
                        {canRegenerate && message.id === lastMessage?.id && (
                          <button type="button" onClick={() => void run({ mode: "regenerate" })}>
                            <RefreshCw size={11} />
                            Regenerate
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ),
            )}

            {pendingUser && userBubble(pendingUser)}

            {live && (
              <div className="message message-assistant is-streaming">
                <div className="message-avatar">
                  <NovaMark size={20} />
                </div>
                <div className="message-body">
                  <div className="message-label">
                    Nova<span>{live.text ? "Answering" : live.reasoning ? "Thinking" : "Routing"}</span>
                  </div>
                  {live.reasoning ? (
                    <Thinking
                      text={live.reasoning}
                      live={!live.text}
                      startedAt={live.thinkingStartedAt}
                      ms={live.thinkingMs}
                      effort={live.effort}
                    />
                  ) : null}
                  {live.text ? (
                    <Prose content={live.text} />
                  ) : !live.reasoning ? (
                    <div className="route-pending">
                      <span className="typing-dots" aria-hidden>
                        <i />
                        <i />
                        <i />
                      </span>
                      {live.route ? `Connected to ${live.route}…` : "Finding an available free route…"}
                    </div>
                  ) : null}
                  {live.route && (
                    <div className="message-foot">
                      <GitBranch size={12} />
                      <code>{live.route}</code>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {failure && (
          <div className="chat-alert" role="alert">
            <CircleAlert size={15} aria-hidden />
            <div className="chat-alert-body">
              <strong>{failure.title}</strong>
              <p>{failure.message}</p>
              <div className="chat-alert-actions">
                {failure.retry && (
                  <button
                    type="button"
                    disabled={sending}
                    onClick={() => failure.retry && void run(failure.retry)}
                  >
                    <RefreshCw size={11} />
                    Try again
                  </button>
                )}
                {failure.reload && (
                  <button type="button" onClick={() => setReloadKey((key) => key + 1)}>
                    <RefreshCw size={11} />
                    Reload
                  </button>
                )}
                {failure.code === "setup_required" && (
                  <button type="button" onClick={onSettings}>
                    <SlidersHorizontal size={11} />
                    Routing settings
                  </button>
                )}
                {provider && (failure.code === "route_unavailable" || failure.code === "setup_required") && (
                  <button type="button" onClick={() => setPin("auto")}>
                    <Zap size={11} />
                    Use automatic routing
                  </button>
                )}
              </div>
            </div>
            <button type="button" className="dismiss" onClick={() => setFailure(null)} aria-label="Dismiss message">
              <X size={13} />
            </button>
          </div>
        )}

        <div className="composer-wrap">
          {!atBottom && hasThread && (
            <button
              type="button"
              className="scroll-latest"
              onClick={() => {
                stick.current = true;
                end.current?.scrollIntoView({ block: "end", behavior: "smooth" });
              }}
            >
              <ArrowDown size={12} />
              Latest
            </button>
          )}
          <div className="hub-composer">
            {attached && (
              <div className="attachment-chip">
                <FileText size={12} />
                {attached.name}
                <button onClick={() => setAttached(null)} aria-label="Remove attachment">
                  <X size={11} />
                </button>
              </div>
            )}
            <textarea
              ref={area}
              rows={1}
              aria-label="Message"
              placeholder={`Message ${routeName}…`}
              value={draft}
              maxLength={8000}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  send();
                }
              }}
            />
            <div className="composer-toolbar">
              <div>
                <button
                  className="icon-button"
                  title="Attach a text file"
                  aria-label="Attach a text file"
                  onClick={() => inputFile.current?.click()}
                  disabled={sending}
                >
                  <Paperclip size={17} />
                </button>
                <input
                  ref={inputFile}
                  type="file"
                  accept={FILE_TYPES}
                  hidden
                  onChange={async (event) => {
                    const input = event.currentTarget;
                    const file = input.files?.[0];
                    input.value = "";
                    if (!file) return;
                    if (file.size > MAX_FILE_BYTES) {
                      notify("Choose a text file under 20 KB");
                      return;
                    }
                    try {
                      setAttached({ name: file.name, content: await file.text() });
                    } catch {
                      notify("That file could not be read");
                    }
                  }}
                />
                <span className="composer-model">
                  <Zap size={12} />
                  {routeName}
                </span>
                {effortOptions.length > 0 ? (
                  <label
                    className={`effort-select${shownEffort !== "default" ? " is-active" : ""}`}
                    title={
                      support?.generic
                        ? `${effortHint(shownEffort, support)} Applied when the routed model supports it.`
                        : effortHint(shownEffort, support)
                    }
                  >
                    <Brain size={12} aria-hidden />
                    <span>Thinking</span>
                    <select
                      aria-label="Thinking effort"
                      disabled={sending}
                      value={shownEffort}
                      onChange={(event) => {
                        if (isReasoningChoice(event.target.value)) chooseEffort(event.target.value);
                      }}
                    >
                      {effortOptions.map((option) => (
                        <option key={option} value={option}>
                          {effortLabel(option, support)}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={11} aria-hidden />
                  </label>
                ) : support?.always ? (
                  <span className="effort-static" title="This model always reasons before it answers.">
                    <Brain size={12} aria-hidden />
                    Thinking built in
                  </span>
                ) : null}
              </div>
              <div>
                <span className="enter-hint">{sending ? "Esc to stop" : "Enter to send"}</span>
                {sending ? (
                  <button className="send-button" aria-label="Stop response" title="Stop (Esc)" onClick={stop}>
                    <Square size={14} />
                  </button>
                ) : (
                  <button
                    className="send-button"
                    disabled={!draft.trim() || !data}
                    aria-label="Send message"
                    onClick={send}
                  >
                    <ArrowUp size={18} />
                  </button>
                )}
              </div>
            </div>
          </div>
          <p className="composer-footnote">
            <ShieldCheck size={11} />
            Messages are sent to the selected provider. Check important answers.
          </p>
        </div>
        <div ref={end} className="chat-end" aria-hidden />
      </div>
    </div>
  );
}
