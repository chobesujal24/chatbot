import { NextResponse } from "next/server";
import type { ZodType } from "zod";
import { createHash, randomUUID } from "node:crypto";
import {
  bootstrapWorkspace,
  isAuthorized,
  requestWorkspace,
  responseSessionToken,
  WORKSPACE_TOKEN_HEADER,
} from "./workspace";
import { checkRateLimit } from "./rate-limit";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

/**
 * Database problems are operational, not bugs in the request. Naming them lets
 * the UI say what to do instead of showing a bare "Internal server error".
 */
function infrastructureError(error: unknown): { code: string; message: string } | null {
  const codes = new Set<string>();
  let current: unknown = error;
  // Drivers and query builders wrap the original error; walk the cause chain.
  for (let depth = 0; depth < 4 && current && typeof current === "object"; depth += 1) {
    const code = (current as { code?: unknown }).code;
    if (typeof code === "string") codes.add(code);
    current = (current as { cause?: unknown }).cause;
  }
  // 42P01 undefined_table, 42703 undefined_column
  if (codes.has("42P01") || codes.has("42703")) {
    return {
      code: "schema_out_of_date",
      message:
        "The database schema is missing or out of date. Run `npx drizzle-kit push`, then reload.",
    };
  }
  if (["ECONNREFUSED", "ENOTFOUND", "ETIMEDOUT", "57P03", "3D000", "28P01"].some((c) => codes.has(c))) {
    return {
      code: "database_unavailable",
      message:
        "The database could not be reached. Check that PostgreSQL is running and DATABASE_URL is correct.",
    };
  }
  return null;
}

export function errorResponse(error: unknown, requestId: string): NextResponse {
  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: { code: error.code, message: error.message }, requestId },
      { status: error.status, headers: { "x-request-id": requestId } },
    );
  }
  const infrastructure = infrastructureError(error);
  if (infrastructure) {
    console.error(`[${requestId}] ${infrastructure.code}`, error);
    return NextResponse.json(
      { error: infrastructure, requestId },
      { status: 503, headers: { "x-request-id": requestId } },
    );
  }
  console.error(`[${requestId}] unhandled`, error);
  return NextResponse.json(
    { error: { code: "internal_error", message: "Internal server error" }, requestId },
    { status: 500, headers: { "x-request-id": requestId } },
  );
}

/**
 * Tells the browser which workspace served this response. The client mirrors
 * the token, so it stays on the same workspace even when its cookie is blocked
 * or the server had to issue a new one. Applied to errors too: a failed request
 * must not leave the client guessing about its identity.
 */
async function withSessionToken(response: Response, request: Request): Promise<Response> {
  let token: string | null = null;
  try {
    token = await responseSessionToken(request);
  } catch {
    token = null;
  }
  if (!token) return response;
  try {
    response.headers.set(WORKSPACE_TOKEN_HEADER, token);
    return response;
  } catch {
    // Immutable headers (e.g. a redirect): rebuild the response around the body.
    const headers = new Headers(response.headers);
    headers.set(WORKSPACE_TOKEN_HEADER, token);
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  }
}

type RouteContext = unknown;
type Handler<C> = (request: Request, context: C) => Promise<Response>;

/** Wraps a route handler with structured errors, a request id and the session echo. */
export function route<C extends RouteContext>(handler: Handler<C>) {
  return async (request: Request, context: C): Promise<Response> => {
    const requestId = randomUUID().slice(0, 8);
    let response: Response;
    try {
      response = await handler(request, context);
    } catch (error) {
      response = errorResponse(error, requestId);
    }
    return withSessionToken(response, request);
  };
}

export interface GuardOptions {
  public?: boolean;
  rateLimit?: { bucket: string; limit: number; windowMs: number };
}

/** Every host this request may legitimately have been addressed to. */
function candidateHosts(request: Request): string[] {
  const hosts = new Set<string>();
  for (const name of ["x-forwarded-host", "host"]) {
    for (const part of (request.headers.get(name) ?? "").split(",")) {
      const host = part.trim().toLowerCase();
      if (host) hosts.add(host);
    }
  }
  try {
    hosts.add(new URL(request.url).host.toLowerCase());
  } catch {
    /* relative or malformed URL: the headers above are enough */
  }
  return [...hosts];
}

/**
 * CSRF defence for state-changing requests. Fetch metadata is preferred: the
 * browser sets it and a page cannot forge it, and unlike a Host comparison it
 * keeps working behind proxies that rewrite the Host header.
 */
function assertSameOrigin(request: Request): void {
  const method = request.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return;
  const site = request.headers.get("sec-fetch-site");
  if (site === "same-origin" || site === "none") return;
  if (site === "cross-site") {
    throw new ApiError(403, "bad_origin", "Cross-origin request refused.");
  }
  const origin = request.headers.get("origin");
  if (!origin) return; // non-browser client (curl, server-to-server)
  let originHost = "";
  try {
    originHost = new URL(origin).host.toLowerCase();
  } catch {
    originHost = "";
  }
  if (!originHost || !candidateHosts(request).includes(originHost)) {
    throw new ApiError(403, "bad_origin", "Cross-origin request refused.");
  }
}

/** Rate-limit key for callers without a workspace yet: a hashed client address. */
function clientHint(request: Request): string {
  const address =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip")?.trim();
  if (!address) return "anon";
  return `ip:${createHash("sha256").update(address).digest("hex").slice(0, 16)}`;
}

/** Verifies origin, authorization and workspace ownership in one place. */
export async function guard(
  request: Request,
  options: GuardOptions = {},
): Promise<{ workspaceId: string }> {
  assertSameOrigin(request);

  // Cookie OR the mirrored `x-nova-workspace` header. Resolved once per request.
  const known = await requestWorkspace(request);

  if (options.rateLimit) {
    const { allowed, retryAfterMs } = await checkRateLimit(
      `${options.rateLimit.bucket}:${known ?? clientHint(request)}`,
      options.rateLimit.limit,
      options.rateLimit.windowMs,
    );
    if (!allowed) {
      throw new ApiError(
        429,
        "rate_limited",
        `Too many requests. Try again in ${Math.ceil(retryAfterMs / 1000)}s.`,
      );
    }
  }

  if (options.public) {
    return { workspaceId: known ?? "" };
  }
  if (!(await isAuthorized())) {
    throw new ApiError(401, "authentication_required", "A passcode is required.");
  }
  if (known) return { workspaceId: known };
  // No valid proof at all (first visit, cleared storage, direct API call):
  // issue a workspace here so every route is self-sufficient. The token goes
  // back in the response headers, so the browser keeps using this one.
  const { id } = await bootstrapWorkspace(request);
  return { workspaceId: id };
}

/** Parses and validates a JSON body. Rejects unknown shapes with a clear 400. */
export async function parseBody<T>(
  request: Request,
  schema: ZodType<T>,
  options: { maxBodyBytes?: number } = {},
): Promise<T> {
  const raw = await request.text().catch(() => "");
  const cap = options.maxBodyBytes ?? 256_000;
  if (raw.length > cap) {
    throw new ApiError(413, "payload_too_large", "Request body is too large.");
  }
  let json: unknown;
  try {
    json = raw ? JSON.parse(raw) : {};
  } catch {
    throw new ApiError(400, "invalid_json", "Request body must be valid JSON.");
  }
  const result = schema.safeParse(json);
  if (!result.success) {
    const first = result.error.issues[0];
    const path = first?.path.join(".");
    throw new ApiError(
      400,
      "validation_error",
      path ? `${path}: ${first?.message}` : (first?.message ?? "Invalid request."),
    );
  }
  return result.data;
}

export const noStore = {
  "Cache-Control": "no-store, no-transform",
};

/** Validates URL search params with the same 400 envelope as request bodies. */
export function parseQuery<T>(request: Request, schema: ZodType<T>): T {
  const url = new URL(request.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const result = schema.safeParse(params);
  if (!result.success) {
    const first = result.error.issues[0];
    throw new ApiError(
      400,
      "validation_error",
      first?.path.length ? `${first.path.join(".")}: ${first.message}` : (first?.message ?? "Invalid query."),
    );
  }
  return result.data;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Path ids are never probed against the database with a malformed value. */
export const isUuid = (value: unknown): value is string =>
  typeof value === "string" && UUID_RE.test(value);

export function requireUuidParam(value: string | null, field = "id"): string {
  if (!isUuid(value)) {
    throw new ApiError(400, "validation_error", `${field} must be a valid id.`);
  }
  return value;
}
