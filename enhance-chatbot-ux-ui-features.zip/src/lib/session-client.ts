"use client";

/**
 * Workspace session on the browser side.
 *
 * The server proves a workspace with a signed token. It is delivered as an
 * HttpOnly cookie, but embedded previews and privacy modes routinely drop that
 * cookie, so the same token is mirrored here and sent as `x-nova-workspace`.
 *
 * Two rules keep a browser on ONE workspace for good:
 *
 *   1. Before the first API call of a page load, the stored token is verified
 *      once against `/api/session`. Every other request waits for that single
 *      round trip, so a missing or stale token can never make several
 *      concurrent requests mint several different workspaces.
 *   2. Every API response carries the workspace it was served for in
 *      `x-nova-workspace-token`; whatever the server used is what we keep.
 *
 * Losing track of the workspace is what used to surface as
 * "Conversation not found." on the second message of a chat.
 */

const STORAGE_KEY = "nova-workspace-token";
const AUTH_STORAGE_KEY = "nova-session-token";
const HEADER = "x-nova-workspace";
const AUTH_HEADER = "x-nova-session";
const TOKEN_RESPONSE_HEADER = "x-nova-workspace-token";
const AUTH_RESPONSE_HEADER = "x-nova-session-token";
const SESSION_ENDPOINT = "/api/session";
const RETRY_AFTER_FAILURE_MS = 2000;

let installed = false;
let verified = false;
let pending: Promise<void> | null = null;
let lastFailureAt = 0;

/** In-memory copies keep a tab working when localStorage itself is blocked. */
const memory: Record<string, string | null> = {
  [STORAGE_KEY]: null,
  [AUTH_STORAGE_KEY]: null,
};

function read(key: string): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(key) ?? memory[key] ?? null;
  } catch {
    return memory[key] ?? null;
  }
}

function write(key: string, value: string): void {
  memory[key] = value;
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* storage may be blocked; the in-memory copy still serves this tab */
  }
}

export function getWorkspaceToken(): string | null {
  return read(STORAGE_KEY);
}

export function setWorkspaceToken(token: string | null | undefined): void {
  if (typeof window === "undefined" || !token) return;
  write(STORAGE_KEY, token);
}

function apiUrl(input: RequestInfo | URL): URL | null {
  try {
    const url =
      typeof input === "string"
        ? new URL(input, window.location.origin)
        : input instanceof URL
          ? input
          : new URL(input.url, window.location.origin);
    return url.origin === window.location.origin && url.pathname.startsWith("/api/") ? url : null;
  } catch {
    return null;
  }
}

function withSessionHeaders(input: RequestInfo | URL, init?: RequestInit): RequestInit | undefined {
  const token = read(STORAGE_KEY);
  const auth = read(AUTH_STORAGE_KEY);
  if (!token && !auth) return init;
  const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
  if (token && !headers.has(HEADER)) headers.set(HEADER, token);
  if (auth && !headers.has(AUTH_HEADER)) headers.set(AUTH_HEADER, auth);
  return { ...init, headers };
}

/** Keeps whatever proofs the server says it used for this response. */
function capture(response: Response): void {
  const token = response.headers.get(TOKEN_RESPONSE_HEADER);
  if (token && token !== read(STORAGE_KEY)) write(STORAGE_KEY, token);
  const auth = response.headers.get(AUTH_RESPONSE_HEADER);
  if (auth && auth !== read(AUTH_STORAGE_KEY)) write(AUTH_STORAGE_KEY, auth);
}

/** Single-flight verification of the stored token; mints a workspace if needed. */
function verifySession(native: typeof fetch): Promise<void> {
  if (verified) return Promise.resolve();
  if (pending) return pending;
  if (Date.now() - lastFailureAt < RETRY_AFTER_FAILURE_MS) return Promise.resolve();
  pending = (async () => {
    try {
      const response = await native(
        SESSION_ENDPOINT,
        withSessionHeaders(SESSION_ENDPOINT, { cache: "no-store", credentials: "same-origin" }),
      );
      capture(response);
      if (response.ok) {
        // The response header is authoritative; the body covers proxies that
        // strip custom headers.
        if (!response.headers.get(TOKEN_RESPONSE_HEADER)) {
          const body = (await response.clone().json().catch(() => null)) as { token?: unknown } | null;
          if (typeof body?.token === "string" && body.token) write(STORAGE_KEY, body.token);
        }
        verified = true;
      } else {
        // 401 means a passcode is required first; try again after sign-in.
        lastFailureAt = Date.now();
      }
    } catch {
      // Offline or the server is restarting: let the real request report it.
      lastFailureAt = Date.now();
    }
  })().finally(() => {
    pending = null;
  });
  return pending;
}

declare global {
  interface Window {
    __novaNativeFetch?: typeof fetch;
    __novaSessionFetch?: boolean;
  }
}

/** Ensures a verified workspace session and returns its token. Safe to call repeatedly. */
export async function ensureWorkspaceSession(): Promise<string | null> {
  if (typeof window === "undefined") return null;
  const native = window.__novaNativeFetch ?? window.fetch.bind(window);
  await verifySession(native);
  return getWorkspaceToken();
}

/**
 * Patches window.fetch once so every same-origin API call carries the session
 * proofs and learns the workspace it was served for. Call at module scope of
 * any client entry.
 */
export function installWorkspaceSession(): void {
  if (installed || typeof window === "undefined") return;
  installed = true;
  if (window.__novaSessionFetch) return;
  window.__novaSessionFetch = true;

  const native = window.fetch.bind(window);
  window.__novaNativeFetch = native;

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = apiUrl(input);
    if (!url) return native(input, init);
    if (url.pathname !== SESSION_ENDPOINT) await verifySession(native);
    const response = await native(input, withSessionHeaders(input, init));
    capture(response);
    return response;
  };
}
