import "server-only";
import { createHash } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { freeMaxConfig, freeMaxCooldowns, freeMaxRuns } from "@/db/schema";
import { listCredentials, type StoredCredential } from "@/lib/credentials";
import { checkRateLimit } from "@/lib/rate-limit";
import { ApiError } from "@/lib/http";
import {
  createThinkSplitter,
  normalizeEffort,
  reasoningRequestParams,
  reasoningSupport,
  splitThink,
  type ReasoningChoice,
  type ReasoningEffort,
  type ThinkPart,
} from "@/lib/reasoning";
import { CATALOG, DEFAULT_ROUTING, type FreeProvider } from "./catalog";
import { parsePin, planRoutes, retryDelay } from "./policy";

export interface ChatTurn {
  role: "system" | "user" | "assistant";
  content: string;
}
type Attempt = { provider: string; status: number; note: string };

export interface FreeMaxUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

export type FreeMaxEvent =
  /** Sent once, right before the first delta: the route that is answering. */
  | { type: "route"; provider: string; providerName: string; model: string; effort: ReasoningEffort | null }
  | { type: "reasoning"; delta: string }
  | { type: "text"; delta: string };

export interface FreeMaxOptions {
  /** Requested thinking effort. Applied only where the routed model supports it. */
  effort?: ReasoningChoice;
  /** Receive live deltas. When set, the upstream request is streamed. */
  onEvent?: (event: FreeMaxEvent) => void;
}

export interface FreeMaxResult {
  text: string;
  reasoning: string;
  provider: string;
  model: string;
  usage: FreeMaxUsage;
  durationMs: number;
  attempts: Attempt[];
  /** The thinking effort actually sent to the provider, if any. */
  effort: ReasoningEffort | null;
  /** The caller aborted after output had started; `text` is partial. */
  stopped: boolean;
  /** Explains a reply that ended early. Empty for a normal completion. */
  notice: string;
}

interface UpstreamMessage {
  content?: unknown;
  refusal?: unknown;
  reasoning_content?: unknown;
  reasoning?: unknown;
}
interface UpstreamChoice {
  finish_reason?: string | null;
  message?: UpstreamMessage;
  delta?: UpstreamMessage;
}
interface UpstreamBody {
  model?: unknown;
  choices?: UpstreamChoice[];
  usage?: Record<string, unknown> | null;
  error?: { message?: unknown } | string | null;
}

/** Time allowed for a provider to start answering. */
const FIRST_BYTE_MS = 28_000;
/** Longest silence tolerated in the middle of a stream. */
const IDLE_MS = 45_000;
/** Hard ceiling for one streamed turn, safely inside the route's maxDuration. */
const STREAM_CAP_MS = 170_000;
/** Providers documented to accept `stream_options.include_usage`. */
const USAGE_IN_STREAM = new Set(["openrouter", "groq", "google", "cerebras"]);

const asText = (value: unknown): string => (typeof value === "string" ? value : "");
const clampCount = (value: unknown) =>
  Math.min(2147483647, Math.max(0, Math.floor(Number(value) || 0)));

function readUsage(usage: Record<string, unknown> | null | undefined): FreeMaxUsage | null {
  if (!usage || typeof usage !== "object") return null;
  return {
    inputTokens: clampCount(usage.prompt_tokens),
    outputTokens: clampCount(usage.completion_tokens),
    totalTokens: clampCount(usage.total_tokens),
  };
}

/** Rough token estimate for providers that do not report usage. */
function estimateUsage(turns: ChatTurn[], output: string): FreeMaxUsage {
  const inputTokens = Math.ceil(turns.reduce((total, turn) => total + turn.content.length, 0) / 4);
  const outputTokens = Math.ceil(output.length / 4);
  return { inputTokens, outputTokens, totalTokens: inputTokens + outputTokens };
}

/** Yields the payload of each `data:` line of a server-sent event stream. */
async function* sseData(
  body: ReadableStream<Uint8Array>,
  onChunk: () => void,
): AsyncGenerator<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      onChunk();
      buffer += decoder.decode(value, { stream: true });
      let newline = buffer.indexOf("\n");
      while (newline >= 0) {
        const line = buffer.slice(0, newline).trim();
        buffer = buffer.slice(newline + 1);
        if (line.startsWith("data:")) yield line.slice(5).trim();
        newline = buffer.indexOf("\n");
      }
    }
    const rest = buffer.trim();
    if (rest.startsWith("data:")) yield rest.slice(5).trim();
  } finally {
    await reader.cancel().catch(() => undefined);
  }
}

export function connectionFor(p: FreeProvider, credentials: StoredCredential[]) {
  // Never silently use a production key. Workspace users or the deployment owner
  // must explicitly attest that this is a free-plan account without paid overages.
  const stored = credentials.find(
    (c) => c.provider === p.id && c.enabled && c.options.freeMax === true,
  );
  const enabled = (process.env.FREE_MAX_ENABLED_PROVIDERS ?? "")
    .split(",")
    .map((s) => s.trim())
    .includes(p.id);
  const key =
    p.access === "keyless"
      ? ""
      : stored?.secret || (enabled && p.env ? process.env[p.env]?.trim() : "") || "";
  const account = String(stored?.options.accountId || process.env.CLOUDFLARE_ACCOUNT_ID || "");
  const ready =
    (p.access === "keyless" || Boolean(key)) &&
    (p.id !== "cloudflare" || /^[a-f0-9]{32}$/i.test(account));
  return { key, account, ready, id: stored?.id ?? null, fromEnv: !stored && Boolean(key) };
}

export async function readRouting(ws: string) {
  const [row] = await db.select().from(freeMaxConfig).where(eq(freeMaxConfig.workspaceId, ws));
  return { ...DEFAULT_ROUTING, ...row?.settings };
}

/**
 * Sends one logical chat turn through the free provider pool.
 *
 * Without `onEvent` the upstream call is a plain JSON completion. With it, the
 * call is streamed and deltas are forwarded as they arrive. Rotation to the
 * next provider only ever happens BEFORE any output has been delivered; once a
 * provider has started answering, the turn finishes with that provider.
 */
export async function runFreeMax(
  ws: string,
  turns: ChatTurn[],
  pin = "auto",
  maxTokens = 2048,
  signal?: AbortSignal,
  options: FreeMaxOptions = {},
): Promise<FreeMaxResult> {
  let selected: ReturnType<typeof parsePin>;
  try {
    selected = parsePin(pin);
  } catch {
    throw new ApiError(400, "unknown_model", "Choose a model from the model library.");
  }
  const [credentials, [config]] = await Promise.all([
    listCredentials(ws),
    db
      .insert(freeMaxConfig)
      .values({ workspaceId: ws, cursor: 1 })
      .onConflictDoUpdate({
        target: freeMaxConfig.workspaceId,
        set: { cursor: sql`${freeMaxConfig.cursor} + 1` },
      })
      .returning(),
  ]);
  const settings = { ...DEFAULT_ROUTING, ...config.settings };
  const candidates = planRoutes(
    CATALOG.filter((p) => connectionFor(p, credentials).ready),
    settings,
    config.cursor - 1,
    selected?.provider,
  );
  if (!candidates.length) {
    throw new ApiError(
      409,
      "setup_required",
      selected
        ? "This provider is disabled or needs a free API key. Open its provider details to connect it."
        : "No eligible routes. Enable a no-sign-up provider or connect a free API key in the directory.",
    );
  }

  const streaming = typeof options.onEvent === "function";
  const requested: ReasoningChoice = options.effort ?? "default";
  const started = Date.now();
  const deadline = AbortSignal.timeout(65_000);
  const attempts: Attempt[] = [];
  let count = 0;
  const budget = selected || !settings.rotation ? 1 : Math.min(5, Math.max(1, settings.maxAttempts));
  let failure =
    "The eligible providers are temporarily unavailable. Try again or connect another free provider.";
  let status = 503;

  for (const p of candidates) {
    if (count >= budget || deadline.aborted || signal?.aborted) break;
    const conn = connectionFor(p, credentials);
    const scope = createHash("sha256")
      .update(`${p.id}:${conn.key || "shared-anonymous"}`)
      .digest("hex");
    const [cool] = await db.select().from(freeMaxCooldowns).where(eq(freeMaxCooldowns.key, scope));
    if (cool && cool.until.getTime() > Date.now()) {
      attempts.push({ provider: p.id, status: 429, note: "Cooldown; no request sent" });
      status = 429;
      failure = `${p.name} is cooling down. Try again after ${cool.until.toISOString().slice(11, 19)} UTC, or connect another free provider.`;
      continue;
    }
    const model = selected?.model || p.models[0].id;
    if (p.access === "keyless") {
      const rate = await checkRateLimit(
        `free-max:${p.id}:${p.id === "ovh" ? model : "pool"}`,
        p.id === "ovh" ? 2 : 200,
        p.id === "ovh" ? 60_000 : 3_600_000,
      );
      if (!rate.allowed) {
        attempts.push({ provider: p.id, status: 429, note: "Shared anonymous allowance reached" });
        status = 429;
        failure = "The shared anonymous allowance is in use. Wait for its reset or connect a free key.";
        continue;
      }
    }
    count++;

    // Thinking effort is per model: clamp the request to what this one supports.
    const support = reasoningSupport(p.id, model, { compat: true });
    let effort = normalizeEffort(requested, support);
    const thinks = Boolean(support?.always) || (effort !== null && effort !== "none");
    const baseTokens = Math.min(4096, Math.max(128, maxTokens));
    const plain: Record<string, unknown> = {
      model,
      messages: turns,
      max_tokens: baseTokens,
      stream: streaming,
    };
    const extras: Record<string, unknown> = {
      // Reasoning tokens count against the output limit; leave room for the answer.
      ...(thinks ? { max_tokens: Math.min(8192, baseTokens * 2) } : {}),
      ...reasoningRequestParams(p.id, model, requested, { compat: true }),
      ...(streaming && USAGE_IN_STREAM.has(p.id) ? { stream_options: { include_usage: true } } : {}),
    };
    const hasExtras = Object.keys(extras).length > 0;

    const baseURL = p.baseURL.replace("{account}", conn.account);
    const watchdog = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const arm = (ms: number) => {
      clearTimeout(timer);
      const remaining = STREAM_CAP_MS - (Date.now() - started);
      timer = setTimeout(() => watchdog.abort(), Math.max(1000, Math.min(ms, remaining)));
    };
    const requestSignal = streaming
      ? AbortSignal.any([watchdog.signal, ...(signal ? [signal] : [])])
      : AbortSignal.any([AbortSignal.timeout(28_000), deadline, ...(signal ? [signal] : [])]);
    const send = (body: Record<string, unknown>) =>
      fetch(`${baseURL}/chat/completions`, {
        method: "POST",
        cache: "no-store",
        redirect: "error",
        headers: {
          "Content-Type": "application/json",
          ...(streaming ? { Accept: "text/event-stream" } : {}),
          ...(conn.key ? { Authorization: `Bearer ${conn.key}` } : {}),
        },
        body: JSON.stringify(body),
        signal: requestSignal,
      });

    try {
      if (streaming) arm(FIRST_BYTE_MS);
      let response = await send({ ...plain, ...extras });
      if (!response.ok && hasExtras && (response.status === 400 || response.status === 422)) {
        // Strict hosts reject parameters they do not know. Retry once with the
        // plain request instead of failing the turn over an optional setting.
        await response.body?.cancel().catch(() => undefined);
        effort = null;
        if (streaming) arm(FIRST_BYTE_MS);
        response = await send(plain);
      }

      if (!response.ok) {
        const code = response.status;
        const retryable = code === 429 || code === 402 || code === 408 || code >= 500;
        const note =
          code === 429
            ? "Provider rate limit"
            : code === 401 || code === 403
              ? "Access not authorized"
              : code === 402
                ? "Free allowance exhausted"
                : `Provider HTTP ${code}`;
        attempts.push({ provider: p.id, status: code, note });
        await response.body?.cancel().catch(() => undefined);
        if (retryable) {
          const until = new Date(
            Date.now() +
              (code === 429
                ? retryDelay(response.headers.get("retry-after"))
                : code === 402
                  ? 86_400_000
                  : 15_000),
          );
          await db
            .insert(freeMaxCooldowns)
            .values({ key: scope, until })
            .onConflictDoUpdate({
              target: freeMaxCooldowns.key,
              set: {
                until: sql`greatest(${freeMaxCooldowns.until}, ${until.toISOString()}::timestamptz)`,
              },
            });
          status = code === 429 ? 429 : 503;
          failure = `${p.name}: ${note.toLowerCase()}. Retry later or add another eligible free route.`;
          continue;
        }
        // Never route around safety refusals or authentication/policy errors.
        failure = `${p.name}: ${note}. Check this provider’s model availability, account tier, and key in the directory.`;
        status = 422;
        break;
      }

      let text = "";
      let reasoning = "";
      let actual = model;
      let usage: FreeMaxUsage | null = null;
      let refused = false;
      let emitted = false;
      let stopped = false;
      let interrupted = "";

      const announce = () => {
        if (emitted) return;
        emitted = true;
        options.onEvent?.({ type: "route", provider: p.id, providerName: p.name, model: actual, effort });
      };
      const deliver = (parts: ThinkPart[]) => {
        for (const part of parts) {
          if (!part.text) continue;
          if (streaming) announce();
          if (part.type === "reasoning") {
            reasoning += part.text;
            options.onEvent?.({ type: "reasoning", delta: part.text });
          } else {
            text += part.text;
            options.onEvent?.({ type: "text", delta: part.text });
          }
        }
      };

      const isEventStream =
        streaming &&
        Boolean(response.body) &&
        (response.headers.get("content-type") ?? "").includes("text/event-stream");

      if (isEventStream && response.body) {
        const splitter = createThinkSplitter();
        try {
          for await (const payload of sseData(response.body, () => arm(IDLE_MS))) {
            if (payload === "[DONE]") break;
            let json: UpstreamBody;
            try {
              json = JSON.parse(payload) as UpstreamBody;
            } catch {
              continue;
            }
            if (json.error) {
              interrupted =
                typeof json.error === "string"
                  ? json.error
                  : asText(json.error.message) || "The provider reported an error.";
              break;
            }
            if (typeof json.model === "string" && json.model && !emitted) {
              actual = json.model.slice(0, 180);
            }
            usage = readUsage(json.usage) ?? usage;
            const choice = json.choices?.[0];
            if (!choice) continue;
            const delta = choice.delta ?? {};
            const thought = asText(delta.reasoning_content) || asText(delta.reasoning);
            if (thought) deliver([{ type: "reasoning", text: thought }]);
            const piece = asText(delta.content);
            if (piece) deliver(splitter.push(piece));
            if (choice.finish_reason === "content_filter" || delta.refusal) refused = true;
          }
        } catch {
          if (signal?.aborted) stopped = true;
          else interrupted = "the provider stopped responding before the reply was complete.";
        }
        deliver(splitter.flush());
      } else {
        // Plain completion, or a host that ignored `stream: true`.
        const json = (await response.json()) as UpstreamBody;
        const choice = json.choices?.[0];
        refused = choice?.finish_reason === "content_filter" || Boolean(choice?.message?.refusal);
        if (!refused) {
          if (typeof json.model === "string" && json.model) actual = json.model.slice(0, 180);
          usage = readUsage(json.usage);
          const split = splitThink(asText(choice?.message?.content));
          const thought =
            asText(choice?.message?.reasoning_content) ||
            asText(choice?.message?.reasoning) ||
            split.reasoning;
          if (split.text.trim()) {
            deliver([
              ...(thought ? [{ type: "reasoning" as const, text: thought }] : []),
              { type: "text" as const, text: split.text },
            ]);
          }
        }
      }

      const produced = text.trim().length > 0;
      if (refused && !emitted) {
        failure = `${p.name} declined this request. No fallback was attempted.`;
        status = 422;
        attempts.push({ provider: p.id, status: 422, note: "Provider declined request" });
        break;
      }
      if (!emitted && !produced) {
        // Nothing has been shown yet, so moving on to another provider is safe.
        if (stopped) {
          failure = "Generation was stopped.";
          status = 499;
          break;
        }
        attempts.push({
          provider: p.id,
          status: 502,
          note: interrupted ? "Stream failed before any output" : "Empty completion",
        });
        failure = interrupted
          ? `${p.name} stopped responding. Try again or select another provider.`
          : `${p.name} returned no text. Choose another model or shorten your request.`;
        continue;
      }

      // Output has been delivered: finish with this provider, whatever happened.
      let notice = "";
      if (!stopped) {
        if (interrupted) notice = `${p.name} ended the reply early: ${interrupted}`;
        else if (refused) notice = `${p.name}'s content filter ended this reply early.`;
        else if (!produced) {
          notice =
            "The model spent its whole output budget thinking and returned no answer. Lower the thinking effort or ask a narrower question.";
        }
      }
      const finalUsage = usage && usage.totalTokens > 0 ? usage : estimateUsage(turns, text + reasoning);
      attempts.push({
        provider: p.id,
        status: 200,
        note: stopped ? "Stopped by user" : notice ? "Partial reply" : "Completed",
      });
      const durationMs = Date.now() - started;
      await db
        .insert(freeMaxRuns)
        .values({
          workspaceId: ws,
          provider: p.id,
          model: actual,
          outcome: "success",
          durationMs,
          tokens: finalUsage.totalTokens,
          attempts,
        })
        .catch(() => {
          console.warn("Free Max: completion delivered, but request metadata could not be saved.");
        });
      return {
        text,
        reasoning,
        provider: p.id,
        model: actual,
        usage: finalUsage,
        durationMs,
        attempts,
        effort,
        stopped,
        notice,
      };
    } catch {
      if (signal?.aborted) {
        failure = "Generation was stopped.";
        status = 499;
        break;
      }
      attempts.push({ provider: p.id, status: 503, note: "Connection timed out or unavailable" });
      failure = `${p.name} could not be reached. Try again or select another provider.`;
    } finally {
      clearTimeout(timer);
    }
  }

  // A request the caller cancelled is not a provider failure: keep it out of
  // the activity log. Bookkeeping must also never mask the real error.
  if (!signal?.aborted) {
    await Promise.resolve(
      db.insert(freeMaxRuns).values({
        workspaceId: ws,
        provider: attempts.at(-1)?.provider ?? "free-max",
        model: pin,
        outcome: "failed",
        durationMs: Date.now() - started,
        attempts,
      }),
    ).catch(() => {
      console.warn("Free Max: the failed request could not be recorded.");
    });
  }
  throw new ApiError(status, "route_unavailable", failure);
}
