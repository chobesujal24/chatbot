/**
 * Thinking ("reasoning") effort support, shared by the server and both chat
 * clients. Pure and dependency-free: it runs in the browser, in route handlers
 * and in unit tests.
 *
 * Three questions are answered here:
 *   1. Can this provider/model tune how hard it thinks, and at which levels?
 *   2. Which request parameter carries that level on an OpenAI-compatible API?
 *   3. How is inline `<think>…</think>` output separated from the answer?
 */

export const REASONING_EFFORTS = ["none", "minimal", "low", "medium", "high", "xhigh", "max"] as const;
export type ReasoningEffort = (typeof REASONING_EFFORTS)[number];
/** What a person can pick: an explicit level, or "default" to let the model decide. */
export type ReasoningChoice = ReasoningEffort | "default";
export const REASONING_CHOICES = ["default", ...REASONING_EFFORTS] as const;

export function isReasoningChoice(value: unknown): value is ReasoningChoice {
  return typeof value === "string" && (REASONING_CHOICES as readonly string[]).includes(value);
}

/** How the chosen level travels to the provider. */
export type ReasoningWire =
  | "native" // mapped by the AI SDK provider package (OpenAI, Anthropic, Google)
  | "reasoning_effort" // OpenAI-compatible `reasoning_effort`
  | "openrouter" // OpenRouter's unified `reasoning` object
  | "enable_thinking" // Qwen-style boolean switch
  | "thinking_type" // GLM-style `{ thinking: { type } }`
  | "groq_toggle"; // Groq Qwen: `reasoning_effort: "none" | "default"`

export interface ReasoningSupport {
  /** Human-readable model family, shown in the picker. */
  family: string;
  /** Selectable levels, weakest first. Empty when thinking cannot be tuned. */
  efforts: ReasoningEffort[];
  /** The model only has an on/off switch (shown as Off / On). */
  toggle: boolean;
  /** The model always reasons and exposes no control. */
  always: boolean;
  /** The final model is chosen later (auto routing); the level is applied if it fits. */
  generic: boolean;
  wire: ReasoningWire;
}

interface Detected {
  family: string;
  efforts: ReasoningEffort[];
  toggle?: boolean;
  always?: boolean;
  generic?: boolean;
}

const LEVELS: ReasoningEffort[] = ["low", "medium", "high"];
const SWITCH: ReasoningEffort[] = ["none", "medium"];
const NATIVE_PROVIDERS = new Set(["openai", "anthropic", "google"]);
const FREE_MAX_AUTO: Detected = {
  family: "Free Max",
  efforts: ["none", "low", "medium", "high"],
  generic: true,
};

/** Model-id heuristics. Order matters: specific families before broad ones. */
function detect(modelId: string): Detected | null {
  const id = modelId.toLowerCase();
  const tail = id.split("/").pop() ?? id;

  // Routers that choose the model themselves: forward the level and let them map it.
  if (/^openrouter\/(auto|free)$/.test(id) || /^kilo-auto\//.test(id)) {
    return { family: "Auto router", efforts: LEVELS, generic: true };
  }

  if (/gpt-oss/.test(id)) return { family: "GPT-OSS", efforts: LEVELS };
  if (/^o[134](-|$)/.test(tail) && !/^o1-(mini|preview)/.test(tail)) {
    return { family: "OpenAI o-series", efforts: LEVELS };
  }

  const gpt5 = /^gpt-5(?:\.(\d+))?/.exec(tail);
  if (gpt5 && !/chat/.test(tail)) {
    const minor = Number(gpt5[1] ?? 0);
    if (minor >= 2) return { family: "GPT-5", efforts: ["none", "low", "medium", "high", "xhigh"] };
    if (minor === 1) return { family: "GPT-5", efforts: ["none", "low", "medium", "high"] };
    return { family: "GPT-5", efforts: ["minimal", "low", "medium", "high"] };
  }
  if (/^codex-/.test(tail)) return { family: "Codex", efforts: LEVELS };

  // Extended thinking arrived with Claude 3.7; older generations have none.
  if (/claude/.test(id) && !/claude-(3-5|3\.5|3-opus|3-sonnet|3-haiku|2|instant)/.test(id)) {
    return { family: "Claude", efforts: ["none", "low", "medium", "high"] };
  }

  if (/gemini-2\.5-pro/.test(id)) return { family: "Gemini 2.5 Pro", efforts: LEVELS };
  if (/gemini-2\.5/.test(id)) return { family: "Gemini 2.5", efforts: ["none", "low", "medium", "high"] };
  if (/gemini-3/.test(id)) {
    return /pro/.test(tail)
      ? { family: "Gemini 3 Pro", efforts: ["low", "high"] }
      : { family: "Gemini 3", efforts: ["minimal", "low", "medium", "high"] };
  }

  if (/grok-3-mini/.test(id)) return { family: "Grok 3 Mini", efforts: ["low", "high"] };
  if (/sonar-deep-research/.test(id)) return { family: "Sonar Deep Research", efforts: LEVELS };

  // Always-on reasoners expose no dial; the UI simply explains that.
  if (
    /deepseek-r1|deepseek-reasoner|r1-distill|magistral|qwq|sonar-reasoning/.test(id) ||
    /(^|[-_/])(thinking|reasoner)([-_:]|$)/.test(id)
  ) {
    return { family: "Reasoning model", efforts: [], always: true };
  }

  if (/qwen-?3/.test(id) && !/coder|embed|rerank|-vl|asr|tts|guard/.test(id)) {
    return { family: "Qwen 3", efforts: SWITCH, toggle: true };
  }
  if (/glm-(4\.[5-9]|[5-9])/.test(id)) return { family: "GLM", efforts: SWITCH, toggle: true };

  return null;
}

function wireFor(provider: string, detected: Detected, compat: boolean): ReasoningWire {
  if (!compat && NATIVE_PROVIDERS.has(provider)) return "native";
  if (provider === "openrouter") return "openrouter";
  if (detected.toggle) {
    if (detected.family === "GLM") return "thinking_type";
    return provider === "groq" ? "groq_toggle" : "enable_thinking";
  }
  return "reasoning_effort";
}

function finish(provider: string, detected: Detected, compat: boolean): ReasoningSupport {
  return {
    family: detected.family,
    efforts: detected.efforts,
    toggle: Boolean(detected.toggle),
    always: Boolean(detected.always),
    generic: Boolean(detected.generic),
    wire: wireFor(provider, detected, compat),
  };
}

export interface ReasoningSupportOptions {
  /**
   * The provider is reached through an OpenAI-compatible endpoint even when its
   * id matches a native SDK provider (e.g. Gemini via its `/openai` surface).
   */
  compat?: boolean;
}

/**
 * Describes the thinking controls of a provider/model pair, or `null` when the
 * model has none. For the `free-max` provider the model is a routing pin
 * (`auto` or `provider::model`).
 */
export function reasoningSupport(
  provider: string | null | undefined,
  model: string | null | undefined,
  options: ReasoningSupportOptions = {},
): ReasoningSupport | null {
  const providerId = (provider ?? "").trim().toLowerCase();
  const raw = (model ?? "").trim();

  if (providerId === "free-max") {
    if (!raw.includes("::")) return finish("free-max", FREE_MAX_AUTO, true);
    const [pinned, ...rest] = raw.split("::");
    return reasoningSupport(pinned, rest.join("::"), { compat: true });
  }

  if (!raw || raw === "offline-demo") return null;
  const detected = detect(raw);
  return detected ? finish(providerId, detected, Boolean(options.compat)) : null;
}

/**
 * Clamps a requested level to the nearest one the model supports. Returns
 * `null` for "default" and for models without a dial, meaning: send nothing.
 */
export function normalizeEffort(
  choice: ReasoningChoice | null | undefined,
  support: ReasoningSupport | null | undefined,
): ReasoningEffort | null {
  if (!support || !choice || choice === "default" || support.efforts.length === 0) return null;
  if (support.efforts.includes(choice)) return choice;
  const target = REASONING_EFFORTS.indexOf(choice);
  let best = support.efforts[0];
  let bestDistance = Number.POSITIVE_INFINITY;
  for (const effort of support.efforts) {
    const distance = Math.abs(REASONING_EFFORTS.indexOf(effort) - target);
    // Strict comparison: on a tie the cheaper (earlier) level wins.
    if (distance < bestDistance) {
      best = effort;
      bestDistance = distance;
    }
  }
  return best;
}

/**
 * Extra Chat Completions body fields that apply the level on an
 * OpenAI-compatible endpoint. Empty when nothing should be sent.
 */
export function reasoningRequestParams(
  provider: string | null | undefined,
  model: string | null | undefined,
  choice: ReasoningChoice | null | undefined,
  options: ReasoningSupportOptions = { compat: true },
): Record<string, unknown> {
  const support = reasoningSupport(provider, model, options);
  const effort = normalizeEffort(choice, support);
  if (!support || !effort || support.wire === "native") return {};
  switch (support.wire) {
    case "openrouter":
      return support.toggle
        ? { reasoning: { enabled: effort !== "none" } }
        : { reasoning: { effort } };
    case "enable_thinking":
      return { enable_thinking: effort !== "none" };
    case "thinking_type":
      return { thinking: { type: effort === "none" ? "disabled" : "enabled" } };
    case "groq_toggle":
      return { reasoning_effort: effort === "none" ? "none" : "default" };
    default:
      return { reasoning_effort: effort };
  }
}

const EFFORT_NAMES: Record<ReasoningEffort, string> = {
  none: "Off",
  minimal: "Minimal",
  low: "Low",
  medium: "Medium",
  high: "High",
  xhigh: "Extra high",
  max: "Max",
};

export function effortLabel(choice: ReasoningChoice, support?: ReasoningSupport | null): string {
  if (choice === "default") return "Auto";
  if (choice !== "none" && support?.toggle) return "On";
  return EFFORT_NAMES[choice];
}

const EFFORT_HINTS: Record<ReasoningChoice, string> = {
  default: "Let the model decide how long to think.",
  none: "Answer straight away, with no thinking phase.",
  minimal: "The lightest possible reasoning pass.",
  low: "Quick reasoning for straightforward questions.",
  medium: "Balanced depth and speed.",
  high: "Thorough reasoning for hard problems. Slower.",
  xhigh: "Extended reasoning. Slowest, and uses more tokens.",
  max: "The largest reasoning budget the model allows.",
};

export function effortHint(choice: ReasoningChoice, support?: ReasoningSupport | null): string {
  if (choice !== "default" && choice !== "none" && support?.toggle) {
    return "Reason step by step before answering.";
  }
  return EFFORT_HINTS[choice];
}

/* ── Inline <think> handling ─────────────────────────────────────────────── */

export interface ThinkPart {
  type: "text" | "reasoning";
  text: string;
}

const OPEN_TAG = "<think>";
const CLOSE_TAG = "</think>";

/** Length of the longest suffix of `text` that could still grow into `tag`. */
function partialTagLength(text: string, tag: string): number {
  const max = Math.min(tag.length - 1, text.length);
  for (let size = max; size > 0; size -= 1) {
    if (tag.startsWith(text.slice(text.length - size))) return size;
  }
  return 0;
}

/**
 * Streaming splitter for models that inline their reasoning as
 * `<think>…</think>` ahead of the answer. Tags may be cut across chunks.
 *
 * An opening tag only counts before any answer text, so a reply that merely
 * talks about `<think>` tags is never mistaken for reasoning.
 */
export function createThinkSplitter() {
  let buffer = "";
  let inside = false;
  let sawAnswer = false;

  const emit = (out: ThinkPart[], type: ThinkPart["type"], text: string) => {
    let value = text;
    if (type === "text" && !sawAnswer) {
      // Drop the blank lines models emit before the answer / after </think>.
      value = value.replace(/^\s+/, "");
      if (!value) return;
      sawAnswer = true;
    }
    if (!value) return;
    const last = out[out.length - 1];
    if (last && last.type === type) last.text += value;
    else out.push({ type, text: value });
  };

  const drain = (final: boolean): ThinkPart[] => {
    const out: ThinkPart[] = [];
    while (buffer) {
      if (inside) {
        const end = buffer.indexOf(CLOSE_TAG);
        if (end >= 0) {
          emit(out, "reasoning", buffer.slice(0, end));
          buffer = buffer.slice(end + CLOSE_TAG.length);
          inside = false;
          continue;
        }
        const keep = final ? 0 : partialTagLength(buffer, CLOSE_TAG);
        emit(out, "reasoning", buffer.slice(0, buffer.length - keep));
        buffer = buffer.slice(buffer.length - keep);
        break;
      }
      if (sawAnswer) {
        emit(out, "text", buffer);
        buffer = "";
        break;
      }
      const start = buffer.indexOf(OPEN_TAG);
      if (start >= 0 && !buffer.slice(0, start).trim()) {
        buffer = buffer.slice(start + OPEN_TAG.length);
        inside = true;
        continue;
      }
      // Undecided: only whitespace or the beginning of a tag so far.
      const lead = buffer.replace(/^\s+/, "");
      if (!final && (lead === "" || OPEN_TAG.startsWith(lead))) break;
      emit(out, "text", buffer);
      buffer = "";
      break;
    }
    return out;
  };

  return {
    push(chunk: string): ThinkPart[] {
      buffer += chunk;
      return drain(false);
    },
    flush(): ThinkPart[] {
      return drain(true);
    },
  };
}

/** Splits a complete response into its answer and its inline reasoning. */
export function splitThink(input: string): { text: string; reasoning: string } {
  if (!input.includes("think>")) return { text: input, reasoning: "" };
  const splitter = createThinkSplitter();
  let text = "";
  let reasoning = "";
  for (const part of [...splitter.push(input), ...splitter.flush()]) {
    if (part.type === "text") text += part.text;
    else reasoning += part.text;
  }
  // Some chat templates open the block implicitly and emit only the closing tag.
  if (!reasoning) {
    const end = text.indexOf(CLOSE_TAG);
    if (end >= 0) {
      reasoning = text.slice(0, end);
      text = text.slice(end + CLOSE_TAG.length).replace(/^\s+/, "");
    }
  }
  return { text, reasoning: reasoning.trim() };
}

/** "Thought for 8s" style duration for a finished thinking phase. */
export function formatThinkingDuration(ms: number | null | undefined): string {
  if (!ms || ms < 1000) return "a moment";
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return rest ? `${minutes}m ${rest}s` : `${minutes}m`;
}

/** Live counter for a thinking phase that is still running. */
export function formatElapsed(ms: number): string {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  if (seconds < 60) return `${seconds}s`;
  return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
}
