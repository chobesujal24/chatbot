import "server-only";

import { cookies, headers } from "next/headers";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { agents, workspaces } from "@/db/schema";
import { eq } from "drizzle-orm";
import { appSecret } from "./secrets";
import { seedSkills } from "./skills";

const WORKSPACE_COOKIE = "nova_ws";
const SESSION_COOKIE = "nova_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;

/** Request headers a browser sends when its cookies are blocked. */
export const WORKSPACE_HEADER = "x-nova-workspace";
export const SESSION_HEADER = "x-nova-session";
/** Response headers that hand the current proofs back to the browser. */
export const WORKSPACE_TOKEN_HEADER = "x-nova-workspace-token";
export const SESSION_TOKEN_HEADER = "x-nova-session-token";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function sign(value: string, secret: string): string {
  return createHmac("sha256", secret).update(value).digest("hex").slice(0, 32);
}

/** Constant-time comparison that never throws on unequal byte lengths. */
function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

type RequestHeaders = Awaited<ReturnType<typeof headers>>;

/** The current request's header store, or null outside a request scope. */
async function requestHeaders(): Promise<RequestHeaders | null> {
  try {
    return await headers();
  } catch {
    return null;
  }
}

async function cookieValue(name: string): Promise<string | undefined> {
  try {
    return (await cookies()).get(name)?.value;
  } catch {
    return undefined;
  }
}

async function isHttps(): Promise<boolean> {
  const h = await requestHeaders();
  return (h?.get("x-forwarded-proto") ?? "http").split(",")[0].trim() === "https";
}

async function cookieOptions() {
  const secure = await isHttps();
  return {
    httpOnly: true,
    // Embedded previews are cross-site iframes: SameSite=Lax cookies are not
    // sent there. SameSite=None + Partitioned keeps the session working inside
    // the preview frame while staying scoped to it. Browsers that still refuse
    // the cookie fall back to the mirrored `x-nova-workspace` header.
    sameSite: secure ? ("none" as const) : ("lax" as const),
    secure,
    partitioned: secure,
    path: "/",
  };
}

/** Writes the signed workspace cookie. Safe inside route handlers only. */
export async function setWorkspaceCookie(id: string): Promise<void> {
  (await cookies()).set(WORKSPACE_COOKIE, await workspaceToken(id), {
    ...(await cookieOptions()),
    maxAge: 60 * 60 * 24 * 365,
  });
}

/** Sets the cookie when it is missing or points elsewhere; never throws. */
async function syncWorkspaceCookie(id: string): Promise<void> {
  try {
    const token = await workspaceToken(id);
    if ((await cookieValue(WORKSPACE_COOKIE)) !== token) await setWorkspaceCookie(id);
  } catch {
    /* read-only context (server component): the header proof still works */
  }
}

/** Signed bearer form of the workspace id, for clients that cannot keep cookies. */
export async function workspaceToken(id: string): Promise<string> {
  return `${id}.${sign(id, await appSecret())}`;
}

async function verifyWorkspaceToken(token: string): Promise<string | null> {
  if (token.length > 120) return null;
  const [id, signature, ...extra] = token.split(".");
  // A malformed id must never reach the database, where the column is a uuid.
  if (!id || !signature || extra.length > 0 || !UUID_RE.test(id)) return null;
  if (!safeEqual(signature, sign(id, await appSecret()))) return null;
  const [row] = await db
    .select({ id: workspaces.id })
    .from(workspaces)
    .where(eq(workspaces.id, id))
    .limit(1);
  return row?.id ?? null;
}

type SessionSource = "header" | "cookie" | "minted";
interface ResolvedSession {
  id: string;
  source: SessionSource;
}

/**
 * One resolution per request. Keyed by the request's header store, which Next
 * keeps stable for the lifetime of a request, so `guard`, the rate limiter and
 * the response echo all agree on the same workspace without repeating queries.
 */
const resolvedSessions = new WeakMap<object, ResolvedSession | null>();
/** The same resolution keyed by the Request itself, for callers that hold it. */
const sessionsByRequest = new WeakMap<Request, ResolvedSession | null>();

async function rememberSession(session: ResolvedSession, request?: Request): Promise<void> {
  if (request) sessionsByRequest.set(request, session);
  const key = await requestHeaders();
  if (key) resolvedSessions.set(key, session);
}

/**
 * Resolves the caller's workspace from EITHER proof: the `x-nova-workspace`
 * header the browser mirrors into localStorage, or the cookie. The header is
 * consulted on every path — including `/api/bootstrap` and `/api/free-max`,
 * which previously looked at the cookie alone and therefore handed a brand-new
 * workspace to any browser whose cookie was blocked. That is what made a
 * conversation "not found" on the very next message.
 */
async function resolveSession(request?: Request): Promise<ResolvedSession | null> {
  if (request && sessionsByRequest.has(request)) return sessionsByRequest.get(request) ?? null;
  const key = await requestHeaders();
  if (key && resolvedSessions.has(key)) return resolvedSessions.get(key) ?? null;

  let session: ResolvedSession | null = null;
  const headerToken = (
    request?.headers.get(WORKSPACE_HEADER) ??
    key?.get(WORKSPACE_HEADER) ??
    ""
  ).trim();
  if (headerToken) {
    const id = await verifyWorkspaceToken(headerToken);
    if (id) session = { id, source: "header" };
  }
  if (!session) {
    const raw = await cookieValue(WORKSPACE_COOKIE);
    const id = raw ? await verifyWorkspaceToken(raw) : null;
    if (id) session = { id, source: "cookie" };
  }
  if (request) sessionsByRequest.set(request, session);
  if (key) resolvedSessions.set(key, session);
  return session;
}

/** The verified workspace for this request, from the header or the cookie. */
export async function requestWorkspace(request?: Request): Promise<string | null> {
  return (await resolveSession(request))?.id ?? null;
}

/** Same resolution as `requestWorkspace`, for callers without the Request object. */
export async function currentWorkspace(): Promise<string | null> {
  return requestWorkspace();
}

/**
 * The signed token of the workspace this request was served for, to be echoed
 * in the response. Null when the request never resolved a workspace.
 */
export async function responseSessionToken(request?: Request): Promise<string | null> {
  const direct = request ? sessionsByRequest.get(request) : null;
  const key = direct ? null : await requestHeaders();
  const session = direct ?? (key ? resolvedSessions.get(key) : null);
  return session ? workspaceToken(session.id) : null;
}

/** Whether this deployment requires a passcode before a workspace is issued. */
export function passwordRequired(): boolean {
  return Boolean(process.env.APP_PASSWORD?.trim());
}

async function validSessionToken(raw: string | null | undefined): Promise<boolean> {
  if (!raw) return false;
  const [expires, signature, ...extra] = raw.split(".");
  if (!expires || !signature || extra.length > 0) return false;
  if (!(Number(expires) > Date.now())) return false;
  return safeEqual(signature, sign(`session:${expires}`, await appSecret()));
}

/** Passcode sessions accept the cookie or the mirrored `x-nova-session` header. */
export async function isAuthorized(): Promise<boolean> {
  if (!passwordRequired()) return true;
  const h = await requestHeaders();
  if (await validSessionToken(h?.get(SESSION_HEADER)?.trim())) return true;
  return validSessionToken(await cookieValue(SESSION_COOKIE));
}

export async function verifyPassword(password: string): Promise<boolean> {
  // Trimmed exactly like `passwordRequired`, so stray whitespace in the env
  // value can never produce a passcode nobody is able to type.
  const configured = process.env.APP_PASSWORD?.trim() ?? "";
  const a = createHmac("sha256", "nova-pw").update(password.trim()).digest();
  const b = createHmac("sha256", "nova-pw").update(configured).digest();
  return timingSafeEqual(a, b) && password.trim().length > 0;
}

/** Starts a passcode session and returns its token for header-based clients. */
export async function createSession(): Promise<string> {
  const expires = String(Date.now() + SESSION_TTL_MS);
  const token = `${expires}.${sign(`session:${expires}`, await appSecret())}`;
  (await cookies()).set(SESSION_COOKIE, token, {
    ...(await cookieOptions()),
    maxAge: SESSION_TTL_MS / 1000,
  });
  return token;
}

export const SEED_AGENTS = [
  {
    name: "General",
    description: "Everyday assistant with math, time, history and memory tools.",
    systemPrompt:
      "You are Nova's General agent. Be direct, concise and well-structured. Use your tools when they make an answer more accurate: calculator for arithmetic, currentTime for time questions, searchHistory for anything about past conversations, and saveMemory/recallMemories for durable facts. Prefer Markdown with fenced code blocks and tables where helpful.",
    tools: ["calculator", "currentTime", "searchHistory", "saveMemory", "recallMemories"],
    icon: "bot",
    isDefault: true,
  },
  {
    name: "Researcher",
    description: "Fetches web sources, searches history and tracks work in tasks.",
    systemPrompt:
      "You are Nova's Research agent. Use webSearch to find current sources and webFetch (or fetchUrl) to read pages, cross-check past conversations with searchHistory, and save durable findings with saveMemory. Track multi-step work with createTask/listTasks/completeTask. Always cite the URLs you used and state what you could not verify.",
    tools: ["webSearch", "webFetch", "fetchUrl", "searchHistory", "saveMemory", "recallMemories", "createTask", "listTasks", "completeTask", "currentTime"],
    icon: "search",
    isDefault: false,
  },
  {
    name: "Coder",
    description: "Engineering-focused agent for code, debugging and technical design.",
    systemPrompt:
      "You are Nova's Code agent, a senior engineer. Write precise, idiomatic code with fenced blocks and language tags, explain tradeoffs briefly, and use calculator for any arithmetic. Fetch documentation pages with fetchUrl when you need current API details. Track implementation work with the task tools.",
    tools: ["calculator", "webFetch", "fetchUrl", "searchHistory", "createTask", "listTasks", "completeTask"],
    icon: "code",
    isDefault: false,
  },
  {
    name: "Analyst",
    description: "Data-focused agent that computes carefully and presents tables.",
    systemPrompt:
      "You are Nova's Analyst agent. Compute with the calculator tool instead of mental math, present results in Markdown tables, and separate observed data from assumptions. Search history for prior context and save reusable findings to memory.",
    tools: ["calculator", "webSearch", "webFetch", "searchHistory", "recallMemories", "saveMemory", "createTask", "listTasks"],
    icon: "chart",
    isDefault: false,
  },
];

export async function seedAgents(workspaceId: string) {
  const existing = await db
    .select({ id: agents.id, name: agents.name, tools: agents.tools })
    .from(agents)
    .where(eq(agents.workspaceId, workspaceId));
  const byName = new Map(existing.map((a) => [a.name, a]));

  // Insert the agents that are missing.
  const missing = SEED_AGENTS.filter((s) => !byName.has(s.name)).map((s) => ({
    workspaceId,
    name: s.name,
    description: s.description,
    systemPrompt: s.systemPrompt,
    tools: s.tools,
    icon: s.icon,
    isDefault: s.isDefault,
    temperature: 0.7,
    maxSteps: 5,
  }));
  if (missing.length > 0) await db.insert(agents).values(missing);

  // Keep the tool set of seeded agents in sync with the current release.
  for (const seed of SEED_AGENTS) {
    const row = byName.get(seed.name);
    if (!row) continue;
    const merged = Array.from(new Set([...(row.tools ?? []), ...seed.tools]));
    if (merged.length !== (row.tools ?? []).length) {
      await db.update(agents).set({ tools: merged }).where(eq(agents.id, row.id));
    }
  }
}

/**
 * Returns the caller's workspace, minting one only when the request carries no
 * valid proof at all. Both proofs are honoured — the cookie and the mirrored
 * `x-nova-workspace` header — so a browser whose cookie is blocked keeps its
 * workspace instead of silently receiving a new, empty one on every call.
 */
export async function bootstrapWorkspace(
  request?: Request,
): Promise<{ id: string; created: boolean }> {
  const existing = await resolveSession(request);
  if (existing) {
    await db
      .update(workspaces)
      .set({ lastSeenAt: new Date() })
      .where(eq(workspaces.id, existing.id));
    // Bring the cookie in line with a header-proven session so both agree.
    if (existing.source === "header") await syncWorkspaceCookie(existing.id);
    return { id: existing.id, created: false };
  }
  const id = randomUUID();
  await db.insert(workspaces).values({ id });
  await seedAgents(id);
  await seedSkills(id);
  await syncWorkspaceCookie(id);
  await rememberSession({ id, source: "minted" }, request);
  return { id, created: true };
}
