import {
  extractReasoningMiddleware,
  wrapLanguageModel,
  type LanguageModel,
  type streamText,
} from "ai";
import type { Settings } from "./types";
import { findProvider } from "./providers";
import {
  normalizeEffort,
  reasoningRequestParams,
  reasoningSupport,
  type ReasoningChoice,
  type ReasoningEffort,
} from "./reasoning";

/** The slice of `streamText` options that carries a thinking effort. */
export type ReasoningCallOptions = Pick<
  Parameters<typeof streamText>[0],
  "reasoning" | "providerOptions"
>;

export interface ModelResolution {
  model: LanguageModel | null;
  error?: string;
  label: string;
  /** True when the workspace has no model provider configured at all. */
  missingCredentials: boolean;
  /** Spread into `streamText` to apply the requested thinking effort. */
  callOptions?: ReasoningCallOptions;
  /** The effort actually applied, after clamping to what the model supports. */
  reasoningEffort?: ReasoningEffort | null;
}

/**
 * Provider SDKs read env vars when imported and throw on empty strings, so we
 * strip injected blanks before loading them.
 */
const PROVIDER_ENV = [
  "OPENAI_API_KEY",
  "OPENAI_BASE_URL",
  "OPENAI_ORGANIZATION",
  "OPENAI_PROJECT",
  "ANTHROPIC_API_KEY",
  "ANTHROPIC_BASE_URL",
  "GOOGLE_GENERATIVE_AI_API_KEY",
  "GOOGLE_API_KEY",
  "GOOGLE_BASE_URL",
];

function sanitizeEnv() {
  for (const name of PROVIDER_ENV) {
    const value = process.env[name];
    if (value !== undefined && value.trim() === "") delete process.env[name];
  }
}

function serverFallbackKey(providerId: string): string {
  switch (providerId) {
    case "openai":
      return process.env.OPENAI_API_KEY?.trim() ?? "";
    case "anthropic":
      return process.env.ANTHROPIC_API_KEY?.trim() ?? "";
    case "google":
      return (
        process.env.GOOGLE_GENERATIVE_AI_API_KEY?.trim() ||
        process.env.GOOGLE_API_KEY?.trim() ||
        ""
      );
    default:
      return "";
  }
}

export interface ResolvedCredential {
  provider: string;
  secret: string;
  baseURL: string | null;
  options?: Record<string, unknown>;
}

export interface ModelOptions {
  /** Extra headers sent with every request (OpenRouter referer/title, gateways). */
  headers?: Record<string, string>;
  /** Per-request timeout in seconds. */
  timeout?: number;
  /** Requested thinking effort; ignored by models that cannot tune it. */
  reasoningEffort?: ReasoningChoice;
}

/**
 * Rewrites an OpenAI-compatible event stream so reasoning that arrives in a
 * side channel (`reasoning_content` on DeepSeek-style hosts, `reasoning` on
 * OpenRouter and Groq) is inlined as `<think>…</think>`. The reasoning
 * middleware then lifts it back out as proper reasoning parts, giving every
 * compatible host the same behaviour as models that inline their thinking.
 */
function reasoningToThinkTags(): TransformStream<Uint8Array, Uint8Array> {
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  let thinking = false;

  const rewrite = (line: string): string => {
    if (!line.startsWith("data:")) return line;
    const payload = line.slice(5).trim();
    if (!payload || payload === "[DONE]") return line;
    let json: {
      choices?: Array<{ delta?: Record<string, unknown>; finish_reason?: unknown }>;
    };
    try {
      json = JSON.parse(payload);
    } catch {
      return line;
    }
    const choice = json?.choices?.[0];
    const delta = choice?.delta;
    if (!choice || !delta || typeof delta !== "object") return line;
    const thought =
      typeof delta.reasoning_content === "string"
        ? delta.reasoning_content
        : typeof delta.reasoning === "string"
          ? delta.reasoning
          : "";
    if (!thought && !thinking) return line; // nothing to translate
    const content = typeof delta.content === "string" ? delta.content : "";
    const hasTools = Array.isArray(delta.tool_calls) && delta.tool_calls.length > 0;
    let next = "";
    if (thought) {
      next += thinking ? thought : `<think>${thought}`;
      thinking = true;
    }
    if (thinking && (content || hasTools || choice.finish_reason)) {
      next += "</think>";
      thinking = false;
    }
    next += content;
    delete delta.reasoning_content;
    delete delta.reasoning;
    delete delta.reasoning_details;
    delta.content = next;
    return `data: ${JSON.stringify(json)}`;
  };

  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      buffer += decoder.decode(chunk, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      if (lines.length > 0) {
        controller.enqueue(encoder.encode(`${lines.map(rewrite).join("\n")}\n`));
      }
    },
    flush(controller) {
      if (buffer) controller.enqueue(encoder.encode(rewrite(buffer)));
    },
  });
}

/**
 * `fetch` for OpenAI-compatible hosts: adds the provider's own thinking-effort
 * parameters to streamed chat requests and surfaces side-channel reasoning.
 * Utility calls (summaries, memory extraction) are not streamed and are left
 * untouched, so they never pay for extra thinking.
 */
function reasoningFetch(extra: Record<string, unknown>): typeof fetch {
  return async (input, init) => {
    let nextInit = init;
    let streaming = false;
    if (init && typeof init.body === "string") {
      try {
        const body = JSON.parse(init.body) as Record<string, unknown>;
        streaming = body.stream === true;
        if (streaming && Object.keys(extra).length > 0) {
          nextInit = { ...init, body: JSON.stringify({ ...body, ...extra }) };
        }
      } catch {
        /* not JSON: pass the request through unchanged */
      }
    }
    const response = await fetch(input, nextInit);
    const isEventStream = (response.headers.get("content-type") ?? "").includes("text/event-stream");
    if (!streaming || !response.ok || !response.body || !isEventStream) return response;
    const headers = new Headers(response.headers);
    headers.delete("content-length");
    headers.delete("content-encoding");
    return new Response(response.body.pipeThrough(reasoningToThinkTags()), {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  };
}

/** Gemini takes a token budget (2.5) or a named level (3.x) instead of an effort. */
function googleThinkingConfig(
  model: string,
  effort: ReasoningEffort,
): Record<string, string | number | boolean> {
  const id = model.toLowerCase();
  if (/gemini-3/.test(id)) {
    const level =
      effort === "none" || effort === "minimal"
        ? /pro/.test(id)
          ? "low"
          : "minimal"
        : effort === "xhigh" || effort === "max"
          ? "high"
          : effort;
    return { thinkingLevel: level, includeThoughts: true };
  }
  const budgets: Record<ReasoningEffort, number> = {
    none: 0,
    minimal: 512,
    low: 2048,
    medium: 8192,
    high: 24576,
    xhigh: 24576,
    max: 24576,
  };
  return { thinkingBudget: budgets[effort], includeThoughts: effort !== "none" };
}

export async function resolveModel(
  settings: Settings,
  credential: ResolvedCredential | null,
  options: ModelOptions = {},
): Promise<ModelResolution> {
  sanitizeEnv();

  const providerId = credential?.provider || settings.provider;
  if (!providerId || providerId === "offline") {
    // Check if deployment provides a server-level key before giving up.
    const fallbackProvider = serverFallbackKey("openai")
      ? "openai"
      : serverFallbackKey("anthropic")
        ? "anthropic"
        : serverFallbackKey("google")
          ? "google"
          : null;
    if (!fallbackProvider) {
      return {
        model: null,
        label: "unconfigured",
        missingCredentials: true,
        error: "No model provider is connected yet.",
      };
    }
    return resolveModel(
      { ...settings, provider: fallbackProvider },
      { provider: fallbackProvider, secret: serverFallbackKey(fallbackProvider), baseURL: null },
      options,
    );
  }

  const preset = findProvider(providerId);
  const rawModel =
    settings.model && settings.model !== "offline-demo" ? settings.model.trim() : "";
  const label = rawModel || preset?.models[0] || "";
  const apiKey = credential?.secret?.trim() || serverFallbackKey(providerId);
  const customBase = (credential?.baseURL ?? settings.baseURL ?? "").trim();
  const baseURL = customBase || preset?.baseURL || "";
  const extraHeaders =
    options.headers && Object.keys(options.headers).length > 0 ? options.headers : undefined;
  const requestedEffort: ReasoningChoice = options.reasoningEffort ?? "default";

  if (!label) {
    return {
      model: null,
      label: providerId,
      missingCredentials: false,
      error: `No model ID selected for ${preset?.label ?? providerId}. Pick or enter a model in Settings → Providers.`,
    };
  }

  if (providerId === "custom" || preset?.kind === "openai-compatible") {
    if (!baseURL) {
      return {
        model: null,
        label,
        missingCredentials: true,
        error: "No base URL configured. Add one in Settings → Providers.",
      };
    }
    if (preset?.requiresKey && !apiKey) {
      return {
        model: null,
        label,
        missingCredentials: true,
        error: `No API key stored for ${preset.label}. Add one in Settings → Providers.`,
      };
    }
    const { createOpenAI } = await import("@ai-sdk/openai");
    const effort = normalizeEffort(
      requestedEffort,
      reasoningSupport(providerId, label, { compat: true }),
    );
    const base = createOpenAI({
      apiKey: apiKey || "not-required",
      baseURL,
      ...(extraHeaders ? { headers: extraHeaders } : {}),
      fetch: reasoningFetch(reasoningRequestParams(providerId, label, requestedEffort, { compat: true })),
    }).chat(label);
    return {
      // Open models commonly inline their reasoning; keep it out of the answer.
      model: wrapLanguageModel({
        model: base,
        middleware: extractReasoningMiddleware({ tagName: "think" }),
      }),
      label,
      missingCredentials: false,
      reasoningEffort: effort,
    };
  }

  if (!apiKey) {
    return {
      model: null,
      label,
      missingCredentials: true,
      error: `No API key stored for ${preset?.label ?? providerId}. Add one in Settings → Providers.`,
    };
  }

  // Native SDK providers map the standard `reasoning` option themselves.
  const effort = normalizeEffort(requestedEffort, reasoningSupport(providerId, label));

  switch (providerId) {
    case "openai": {
      const { createOpenAI } = await import("@ai-sdk/openai");
      const effectiveBase = customBase || process.env.OPENAI_BASE_URL?.trim() || undefined;
      return {
        model: createOpenAI({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        }).chat(label),
        label,
        missingCredentials: false,
        reasoningEffort: effort,
        ...(effort ? { callOptions: { reasoning: effort } } : {}),
      };
    }
    case "anthropic": {
      const { createAnthropic } = await import("@ai-sdk/anthropic");
      const effectiveBase = customBase || process.env.ANTHROPIC_BASE_URL?.trim() || undefined;
      return {
        model: createAnthropic({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        })(label),
        label,
        missingCredentials: false,
        reasoningEffort: effort,
        ...(effort ? { callOptions: { reasoning: effort } } : {}),
      };
    }
    case "google": {
      const { createGoogleGenerativeAI } = await import("@ai-sdk/google");
      const effectiveBase = customBase || process.env.GOOGLE_BASE_URL?.trim() || undefined;
      return {
        model: createGoogleGenerativeAI({
          apiKey,
          ...(effectiveBase ? { baseURL: effectiveBase } : {}),
          ...(extraHeaders ? { headers: extraHeaders } : {}),
        })(label),
        label,
        missingCredentials: false,
        reasoningEffort: effort,
        ...(effort
          ? {
              callOptions: {
                providerOptions: { google: { thinkingConfig: googleThinkingConfig(label, effort) } },
              },
            }
          : {}),
      };
    }
    default:
      return {
        model: null,
        label,
        missingCredentials: true,
        error: `Provider "${providerId}" is not supported.`,
      };
  }
}
