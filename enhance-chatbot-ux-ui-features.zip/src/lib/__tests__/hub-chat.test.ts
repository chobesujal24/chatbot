import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { Chat } from "@/components/hub/chat";
import type { HubData } from "@/components/hub/types";
import { ReasoningBlock } from "@/components/reasoning-block";
import { DEFAULT_ROUTING } from "../free-max/catalog";

const data: HubData = {
  workspace: "workspace",
  routing: DEFAULT_ROUTING,
  history: [],
  runs: [],
  connections: [
    { provider: "kilo", ready: true, hasKey: false, fromEnv: false },
    { provider: "ovh", ready: true, hasKey: false, fromEnv: false },
  ],
};
const noop = () => {};
const render = (pin: string, conversationId: string | null = null) =>
  renderToStaticMarkup(
    createElement(Chat, {
      pin,
      setPin: noop,
      conversationId,
      setConversationId: noop,
      onRefresh: async () => {},
      data,
      onDetails: noop,
      onSettings: noop,
      notify: noop,
      onNew: noop,
      onGone: noop,
    }),
  );

describe("hub chat playground", () => {
  it("offers a generic thinking picker for automatic routing", () => {
    const html = render("auto");
    expect(html).toContain("A new conversation.");
    expect(html).toContain('aria-label="Thinking effort"');
    for (const label of ["Auto", "Off", "Low", "Medium", "High"]) {
      expect(html).toContain(`>${label}</option>`);
    }
  });

  it("lists only the levels a pinned model supports", () => {
    const html = render("ovh::gpt-oss-20b");
    expect(html).toContain(">High</option>");
    // GPT-OSS cannot switch reasoning off, so "Off" must not be offered.
    expect(html).not.toContain(">Off</option>");
  });

  it("hides the picker for models without a dial", () => {
    const html = render("kilo::google/gemma-4-31b-it:free");
    expect(html).not.toContain("Thinking effort");
    expect(html).not.toContain("Thinking built in");
  });

  it("labels reasoners that cannot be tuned", () => {
    const html = render("cloudflare::@cf/deepseek-ai/deepseek-r1-distill-qwen-32b");
    expect(html).toContain("Thinking built in");
    expect(html).not.toContain('aria-label="Thinking effort"');
  });

  it("shows a loading state while a conversation is fetched", () => {
    expect(render("auto", "11111111-2222-4333-8444-555555555555")).toContain("Loading conversation");
  });
});

describe("reasoning block", () => {
  it("summarises finished thinking and stays collapsed", () => {
    const html = renderToStaticMarkup(
      createElement(ReasoningBlock, { text: "step one", durationMs: 8200, effort: "high" }),
    );
    expect(html).toContain("Thought for 8s");
    expect(html).toContain('aria-expanded="false"');
    expect(html).not.toContain("step one");
  });

  it("opens while the model is thinking", () => {
    const html = renderToStaticMarkup(createElement(ReasoningBlock, { text: "working", live: true }));
    expect(html).toContain('aria-expanded="true"');
    expect(html).toContain("working");
  });

  it("renders nothing when there is no reasoning", () => {
    expect(renderToStaticMarkup(createElement(ReasoningBlock, { text: "  " }))).toBe("");
  });
});
