import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));
vi.mock("@/db", () => ({ db: {} }));

import { ApiError, errorResponse, isUuid } from "../http";

beforeEach(() => {
  vi.spyOn(console, "error").mockImplementation(() => {});
});

describe("error envelopes", () => {
  it("keeps typed API errors intact", async () => {
    const res = errorResponse(new ApiError(404, "conversation_not_found", "gone"), "req1");
    expect(res.status).toBe(404);
    expect(await res.json()).toMatchObject({
      error: { code: "conversation_not_found", message: "gone" },
      requestId: "req1",
    });
  });

  it("names a missing or outdated schema instead of a bare 500", async () => {
    const wrapped = Object.assign(new Error("Failed query"), {
      cause: Object.assign(new Error('relation "messages" does not exist'), { code: "42P01" }),
    });
    const res = errorResponse(wrapped, "req2");
    expect(res.status).toBe(503);
    const body = await res.json();
    expect(body.error.code).toBe("schema_out_of_date");
    expect(body.error.message).toContain("drizzle-kit push");
  });

  it("names an unreachable database", async () => {
    const res = errorResponse(Object.assign(new Error("connect failed"), { code: "ECONNREFUSED" }), "req3");
    expect(res.status).toBe(503);
    expect((await res.json()).error.code).toBe("database_unavailable");
  });

  it("never leaks the details of an unexpected error", async () => {
    const res = errorResponse(new Error("secret internal detail"), "req4");
    expect(res.status).toBe(500);
    expect(JSON.stringify(await res.json())).not.toContain("secret internal detail");
  });
});

describe("id validation", () => {
  it("accepts only real UUIDs", () => {
    expect(isUuid("11111111-2222-4333-8444-555555555555")).toBe(true);
    expect(isUuid("------------------------------------")).toBe(false);
    expect(isUuid("not-an-id")).toBe(false);
    expect(isUuid(null)).toBe(false);
  });
});
