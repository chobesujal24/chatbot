import { describe, expect, it } from "vitest";
import {
  createThinkSplitter,
  effortLabel,
  formatThinkingDuration,
  isReasoningChoice,
  normalizeEffort,
  reasoningRequestParams,
  reasoningSupport,
  splitThink,
} from "../reasoning";

describe("thinking-effort support detection", () => {
  it("offers levels only for models that can tune their thinking", () => {
    expect(reasoningSupport("groq", "openai/gpt-oss-120b", { compat: true })?.efforts).toEqual(["low", "medium", "high"]);
    expect(reasoningSupport("openai", "gpt-5-mini")?.efforts).toEqual(["minimal", "low", "medium", "high"]);
    expect(reasoningSupport("openai", "gpt-5.1")?.efforts).toEqual(["none", "low", "medium", "high"]);
    expect(reasoningSupport("openai", "gpt-5.2")?.efforts).toContain("xhigh");
    expect(reasoningSupport("openai", "o3-mini")?.efforts).toEqual(["low", "medium", "high"]);
    expect(reasoningSupport("google", "gemini-2.5-pro")?.efforts).toEqual(["low", "medium", "high"]);
    expect(reasoningSupport("google", "gemini-2.5-flash")?.efforts).toContain("none");
    expect(reasoningSupport("openrouter", "anthropic/claude-sonnet-4.5")?.efforts).toContain("high");
  });

  it("returns null for models without a thinking dial", () => {
    expect(reasoningSupport("openai", "gpt-4o")).toBeNull();
    expect(reasoningSupport("openai", "gpt-5-chat-latest")).toBeNull();
    expect(reasoningSupport("openai", "o1-mini")).toBeNull();
    expect(reasoningSupport("anthropic", "claude-3-5-sonnet-latest")).toBeNull();
    expect(reasoningSupport("groq", "llama-3.3-70b-versatile")).toBeNull();
    expect(reasoningSupport("openai", "")).toBeNull();
    expect(reasoningSupport("offline", "offline-demo")).toBeNull();
  });

  it("flags reasoners that cannot be tuned", () => {
    const r1 = reasoningSupport("cloudflare", "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b", { compat: true });
    expect(r1?.always).toBe(true);
    expect(r1?.efforts).toEqual([]);
  });

  it("uses the native wire only for SDK providers reached natively", () => {
    expect(reasoningSupport("anthropic", "claude-sonnet-4-5")?.wire).toBe("native");
    expect(reasoningSupport("google", "gemini-2.5-flash")?.wire).toBe("native");
    expect(reasoningSupport("google", "gemini-2.5-flash", { compat: true })?.wire).toBe("reasoning_effort");
  });

  it("treats Free Max pins as routes and auto routing as generic", () => {
    const auto = reasoningSupport("free-max", "auto");
    expect(auto?.generic).toBe(true);
    expect(auto?.efforts).toEqual(["none", "low", "medium", "high"]);
    expect(reasoningSupport("free-max", "")?.generic).toBe(true);
    const pinned = reasoningSupport("free-max", "groq::openai/gpt-oss-20b");
    expect(pinned?.generic).toBe(false);
    expect(pinned?.wire).toBe("reasoning_effort");
    expect(reasoningSupport("free-max", "kilo::google/gemma-4-31b-it:free")).toBeNull();
  });
});

describe("effort clamping", () => {
  const levels = reasoningSupport("groq", "openai/gpt-oss-20b", { compat: true });
  const toggle = reasoningSupport("siliconflow", "Qwen/Qwen3-8B", { compat: true });

  it("sends nothing for the default choice or unsupported models", () => {
    expect(normalizeEffort("default", levels)).toBeNull();
    expect(normalizeEffort("high", null)).toBeNull();
    expect(normalizeEffort(undefined, levels)).toBeNull();
  });

  it("snaps to the nearest supported level", () => {
    expect(normalizeEffort("medium", levels)).toBe("medium");
    expect(normalizeEffort("xhigh", levels)).toBe("high");
    expect(normalizeEffort("none", levels)).toBe("low");
    expect(normalizeEffort("high", toggle)).toBe("medium");
    expect(normalizeEffort("none", toggle)).toBe("none");
  });

  it("labels on/off switches as On and Off", () => {
    expect(effortLabel("medium", toggle)).toBe("On");
    expect(effortLabel("none", toggle)).toBe("Off");
    expect(effortLabel("medium", levels)).toBe("Medium");
    expect(effortLabel("default", levels)).toBe("Auto");
  });
});

describe("provider request parameters", () => {
  it("speaks each provider's own dialect", () => {
    expect(reasoningRequestParams("groq", "openai/gpt-oss-120b", "high")).toEqual({ reasoning_effort: "high" });
    expect(reasoningRequestParams("openrouter", "openai/gpt-oss-120b:free", "high")).toEqual({ reasoning: { effort: "high" } });
    expect(reasoningRequestParams("groq", "qwen/qwen3-32b", "none")).toEqual({ reasoning_effort: "none" });
    expect(reasoningRequestParams("groq", "qwen/qwen3-32b", "high")).toEqual({ reasoning_effort: "default" });
    expect(reasoningRequestParams("zai", "glm-4.7-flash", "none")).toEqual({ thinking: { type: "disabled" } });
    expect(reasoningRequestParams("siliconflow", "Qwen/Qwen3-8B", "medium")).toEqual({ enable_thinking: true });
    expect(reasoningRequestParams("openrouter", "qwen/qwen3-32b", "none")).toEqual({ reasoning: { enabled: false } });
  });

  it("adds nothing when no effort applies", () => {
    expect(reasoningRequestParams("groq", "openai/gpt-oss-120b", "default")).toEqual({});
    expect(reasoningRequestParams("groq", "llama-3.3-70b-versatile", "high")).toEqual({});
    expect(reasoningRequestParams("cloudflare", "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b", "high")).toEqual({});
  });
});

describe("inline <think> handling", () => {
  it("separates reasoning from the answer across chunk boundaries", () => {
    const splitter = createThinkSplitter();
    const parts = [
      ...splitter.push("<thi"),
      ...splitter.push("nk>plan"),
      ...splitter.push(" more</th"),
      ...splitter.push("ink>\n\nAnswer"),
      ...splitter.push(" here"),
      ...splitter.flush(),
    ];
    const reasoning = parts.filter((p) => p.type === "reasoning").map((p) => p.text).join("");
    const text = parts.filter((p) => p.type === "text").map((p) => p.text).join("");
    expect(reasoning).toBe("plan more");
    expect(text).toBe("Answer here");
  });

  it("never withholds a normal answer", () => {
    const splitter = createThinkSplitter();
    expect(splitter.push("Hello")).toEqual([{ type: "text", text: "Hello" }]);
    expect(splitter.push(" <b>world</b>")).toEqual([{ type: "text", text: " <b>world</b>" }]);
    expect(splitter.flush()).toEqual([]);
  });

  it("treats an unterminated block as reasoning", () => {
    expect(splitThink("<think>still going")).toEqual({ text: "", reasoning: "still going" });
  });

  it("handles templates that only emit the closing tag", () => {
    expect(splitThink("working it out</think>\n\nFinal answer")).toEqual({
      text: "Final answer",
      reasoning: "working it out",
    });
  });

  it("leaves answers that merely mention the tag alone", () => {
    const answer = "Use the <think> tag to show reasoning.";
    expect(splitThink(answer)).toEqual({ text: answer, reasoning: "" });
    expect(splitThink("plain text")).toEqual({ text: "plain text", reasoning: "" });
  });
});

describe("helpers", () => {
  it("validates stored choices", () => {
    expect(isReasoningChoice("high")).toBe(true);
    expect(isReasoningChoice("default")).toBe(true);
    expect(isReasoningChoice("extreme")).toBe(false);
    expect(isReasoningChoice(null)).toBe(false);
  });

  it("formats thinking time for people", () => {
    expect(formatThinkingDuration(400)).toBe("a moment");
    expect(formatThinkingDuration(8200)).toBe("8s");
    expect(formatThinkingDuration(72_000)).toBe("1m 12s");
    expect(formatThinkingDuration(120_000)).toBe("2m");
  });
});
