// @vitest-environment happy-dom
import { act, createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// The session layer patches window.fetch at import time; these tests drive the
// component against a plain mocked fetch instead.
vi.mock("@/lib/session-client", () => ({ installWorkspaceSession: () => {} }));

import { Chat } from "@/components/hub/chat";
import type { HubData } from "@/components/hub/types";
import { DEFAULT_ROUTING } from "../free-max/catalog";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const THREAD = "11111111-2222-4333-8444-555555555555";
const data: HubData = {
  workspace: "workspace",
  routing: DEFAULT_ROUTING,
  history: [],
  runs: [],
  connections: [
    { provider: "kilo", ready: true, hasKey: false, fromEnv: false },
    { provider: "ovh", ready: true, hasKey: false, fromEnv: false },
  ],
};

const makeProps = (conversationId: string | null = null) => ({
  pin: "auto",
  setPin: vi.fn(),
  conversationId,
  setConversationId: vi.fn(),
  onRefresh: vi.fn(async () => {}),
  data,
  onDetails: vi.fn(),
  onSettings: vi.fn(),
  notify: vi.fn(),
  onNew: vi.fn(),
  onGone: vi.fn(),
});

const line = (event: object) => `${JSON.stringify(event)}\n`;
const jsonResponse = (body: unknown, status = 200) => ({
  ok: status >= 200 && status < 300,
  status,
  headers: new Headers(),
  json: async () => body,
});
/** A streamed response whose chunks may be released later, to observe mid-stream UI. */
const streamResponse = (chunks: Array<string | Promise<string>>, headers: Record<string, string>) => {
  let index = 0;
  const encoder = new TextEncoder();
  return {
    ok: true,
    status: 200,
    headers: new Headers(headers),
    json: async () => ({}),
    body: {
      getReader: () => ({
        read: async () => {
          if (index >= chunks.length) return { done: true, value: undefined };
          return { done: false, value: encoder.encode(await chunks[index++]) };
        },
      }),
    },
  };
};

let container: HTMLDivElement;
let root: Root;
const fetchMock = vi.fn();

const flush = (ms = 40) =>
  act(async () => {
    await new Promise((resolve) => setTimeout(resolve, ms));
  });
const mount = (props: ReturnType<typeof makeProps>) =>
  act(async () => {
    root.render(createElement(Chat, props));
  });
const typeMessage = (text: string) =>
  act(async () => {
    const area = container.querySelector("textarea") as HTMLTextAreaElement;
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")!.set!.call(area, text);
    area.dispatchEvent(new Event("input", { bubbles: true }));
  });
const click = (selector: string) =>
  act(async () => {
    (container.querySelector(selector) as HTMLElement).click();
  });
const buttonByText = (text: string) =>
  Array.from(container.querySelectorAll("button")).find((b) => b.textContent?.includes(text));
const draft = () => (container.querySelector("textarea") as HTMLTextAreaElement).value;

beforeEach(() => {
  window.sessionStorage.clear();
  window.localStorage.clear();
  if (!Element.prototype.scrollIntoView) Element.prototype.scrollIntoView = () => {};
  fetchMock.mockReset();
  vi.stubGlobal("fetch", fetchMock);
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => {
    root.unmount();
  });
  container.remove();
  vi.unstubAllGlobals();
});

describe("playground chat flow", () => {
  it("streams thinking and the answer, then syncs with the server", async () => {
    let release!: (chunk: string) => void;
    const rest = new Promise<string>((resolve) => {
      release = resolve;
    });
    fetchMock.mockImplementation(async (url: string) => {
      if (url === "/api/chat") {
        return streamResponse(
          [
            line({ type: "start" }) +
              line({ type: "data-route", data: { provider: "kilo", providerName: "Kilo Gateway", model: "demo-model", effort: "high" } }) +
              line({ type: "reasoning-start", id: "r1" }) +
              line({ type: "reasoning-delta", id: "r1", delta: "Recalling the capital of France." }),
            rest,
          ],
          { "x-nova-conversation-id": THREAD },
        );
      }
      if (url.startsWith(`/api/conversations/${THREAD}/messages`)) {
        return jsonResponse({
          messages: [
            { id: "u1", role: "user", content: "Capital of France?" },
            {
              id: "a1",
              role: "assistant",
              content: "Paris.",
              reasoning: "Recalling the capital of France.",
              model: "kilo / demo-model",
              usage: { inputTokens: 5, outputTokens: 3, totalTokens: 8, durationMs: 900, reasoningMs: 2000, reasoningEffort: "high" },
            },
          ],
        });
      }
      throw new Error(`unexpected request: ${url}`);
    });

    const props = makeProps();
    await mount(props);

    // Pick a thinking effort, then send.
    await act(async () => {
      const select = container.querySelector('select[aria-label="Thinking effort"]') as HTMLSelectElement;
      select.value = "high";
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });
    await typeMessage("Capital of France?");
    await click('[aria-label="Send message"]');
    await flush();

    const request = JSON.parse(fetchMock.mock.calls[0][1].body as string);
    expect(request).toMatchObject({ mode: "send", content: "Capital of France?", conversationId: null });
    expect(request.settings).toMatchObject({ provider: "free-max", model: "auto", reasoningEffort: "high" });
    expect(window.localStorage.getItem("nova-thinking-effort")).toBe("high");

    // Mid-stream: the message is shown, thinking is live and open, the route is named.
    expect(props.setConversationId).toHaveBeenCalledWith(THREAD);
    expect(container.textContent).toContain("Capital of France?");
    expect(container.textContent).toContain("Thinking…");
    expect(container.textContent).toContain("Recalling the capital of France.");
    expect(container.textContent).toContain("Kilo Gateway · demo-model");
    expect(container.querySelector('[aria-label="Stop response"]')).not.toBeNull();
    expect(draft()).toBe("");

    // The parent adopts the new conversation id, as the hub shell does.
    await mount({ ...props, conversationId: THREAD });
    release(
      line({ type: "reasoning-end", id: "r1" }) +
        line({ type: "text-start", id: "t1" }) +
        line({ type: "text-delta", id: "t1", delta: "Paris." }) +
        line({ type: "text-end", id: "t1" }) +
        line({ type: "finish", finishReason: "stop" }),
    );
    await flush(80);

    // Done: the stored reply is shown, its reasoning folded away behind a summary.
    expect(container.textContent).toContain("Paris.");
    expect(container.textContent).toContain("Thought for 2s");
    expect(container.textContent).not.toContain("Recalling the capital of France.");
    expect(container.querySelector(".chat-alert")).toBeNull();
    expect(container.querySelector('[aria-label="Send message"]')).not.toBeNull();
    expect(buttonByText("Regenerate")).toBeDefined();
    expect(props.onRefresh).toHaveBeenCalled();
    // The conversation was not re-fetched merely because its id arrived.
    expect(fetchMock.mock.calls.filter(([url]) => String(url).includes("/messages"))).toHaveLength(1);
  });

  it("hands the message back and offers a way forward when the request fails", async () => {
    fetchMock.mockImplementation(async () =>
      jsonResponse({ error: { code: "setup_required", message: "No eligible routes." } }, 409),
    );
    const props = makeProps();
    await mount(props);
    await typeMessage("Hello there");
    await click('[aria-label="Send message"]');
    await flush();

    const alert = container.querySelector(".chat-alert");
    expect(alert?.textContent).toContain("No route is ready yet");
    expect(alert?.textContent).toContain("No eligible routes.");
    expect(draft()).toBe("Hello there");
    expect(buttonByText("Try again")).toBeDefined();
    expect(container.textContent).not.toContain("Finding an available free route");

    await act(async () => {
      buttonByText("Routing settings")?.click();
    });
    expect(props.onSettings).toHaveBeenCalledTimes(1);
  });

  it("drops a conversation that no longer exists instead of dead-ending", async () => {
    fetchMock.mockImplementation(async () =>
      jsonResponse({ error: { code: "conversation_not_found", message: "gone" } }, 404),
    );
    const props = makeProps(THREAD);
    await mount(props);
    await flush();

    expect(props.onGone).toHaveBeenCalledTimes(1);
    expect(props.notify).toHaveBeenCalledWith(expect.stringContaining("no longer available"));
    expect(container.querySelector(".chat-alert")).toBeNull();
  });

  it("explains when a message had to start a new conversation", async () => {
    fetchMock.mockImplementation(async (url: string) => {
      if (url === "/api/chat") {
        return streamResponse(
          [line({ type: "text-delta", id: "t1", delta: "Hi." }) + line({ type: "finish" })],
          { "x-nova-conversation-id": THREAD, "x-nova-conversation-recovered": "1" },
        );
      }
      return jsonResponse({
        messages: [
          { id: "u1", role: "user", content: "Hello" },
          { id: "a1", role: "assistant", content: "Hi." },
        ],
      });
    });
    const props = makeProps();
    await mount(props);
    await typeMessage("Hello");
    await click('[aria-label="Send message"]');
    await flush(80);

    expect(props.notify).toHaveBeenCalledWith(expect.stringContaining("started a new one"));
    expect(container.textContent).toContain("Hi.");
    expect(container.querySelector(".chat-alert")).toBeNull();
  });

  it("keeps an unsent draft for the next visit", async () => {
    const props = makeProps();
    await mount(props);
    await typeMessage("half-written thought");
    await flush(320);
    expect(window.sessionStorage.getItem("nova-hub-draft:new")).toBe("half-written thought");
  });
});
