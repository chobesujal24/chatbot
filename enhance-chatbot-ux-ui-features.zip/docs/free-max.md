# Free Max — provider research and operations

## Import provenance

The complete application source in `chatbot-ui-and-codebase-refinement.zip` was imported from [chobesujal24/chatbot](https://github.com/chobesujal24/chatbot) at revision `a9fb8054ce842aa44d1294e84d7a835072351a31`. The platform's package manifest was retained, upstream dependencies were installed with npm, and the existing database readiness check was preserved. The original application is at `/workspace`, advanced settings at `/settings`, and shared conversations at `/share/[token]`. The new provider hub is `/`.

## Research snapshot: November 18, 2026

24 distinct providers, 63 named model routes: two anonymous services, 20 free-key or renewable-allowance services, and two finite trials. Routes are provider/model pairs, not 63 distinct underlying model architectures. A gateway is counted once, not once per downstream model. The source of truth for IDs, base URLs, authentication, model names, and quota qualifications is `src/lib/free-max/catalog.ts`, exposed in the provider detail views and guide.

**Live-tested without credentials:** Kilo Gateway and OVHcloud both completed an anonymous Chat Completions POST. A complete request through the application itself was also tested. The OpenRouter, Kilo, Requesty, Ollama Cloud, and LLM7 public listings were inspected. These observations are not an uptime guarantee. Other providers were reviewed against their documentation; no credentials or unverified paid accounts were manufactured for testing.

| Provider | Access / allowance | Reference |
| --- | --- | --- |
| Kilo Gateway | Anonymous free models, 200 requests/hour/server IP | https://kilo.ai/docs/gateway/authentication |
| OVHcloud | Anonymous, 2 requests/minute/IP/model | https://docs.ovhcloud.com/en/guides/public-cloud/ai-machine-learning/ai-endpoints-getting-started |
| OpenRouter | Free key, 20 RPM and 50 RPD on a standard free account; only free model IDs | https://openrouter.ai/docs/api/reference/limits |
| Groq | Listed free text models: 30 RPM, 1,000 RPD, 200K tokens/day/model | https://console.groq.com/docs/rate-limits |
| Google AI Studio | Unbilled project; active model/project/region limits in AI Studio | https://ai.google.dev/gemini-api/docs/rate-limits and https://ai.google.dev/gemini-api/docs/openai |
| Mistral | Free Studio mode, organization-specific allowance | https://docs.mistral.ai/resources/known-limitations |
| Cloudflare Workers AI | 10,000 neurons/day; Free plan, account ID and scoped token | https://developers.cloudflare.com/workers-ai/platform/pricing/ |
| NVIDIA NIM | Free developer prototyping, not a production license | https://docs.api.nvidia.com/nim/docs/run-anywhere |
| Cohere | Evaluation key, 1,000 calls/month, model-specific RPM | https://docs.cohere.com/docs/rate-limits and https://docs.cohere.com/docs/compatibility-api |
| SambaNova | Free accounts: listed models 20 requests/day, 200K tokens/day | https://docs.sambanova.ai/docs/en/models/rate-limits |
| Z.ai | Explicitly free GLM Flash IDs; FlashX excluded | https://docs.z.ai/guides/overview/pricing |
| SiliconFlow | Selected free IDs only; identity and regional requirements | https://docs.siliconflow.com/en/userguide/rate-limits/rate-limit-and-upgradation |
| ModelScope | API-Inference model enrollment, account limits up to 2,000 calls/day | https://modelscope.cn/docs/model-service/API-Inference/intro |
| Ollama Cloud | Session and weekly allowance; cloud key, not local inference | https://docs.ollama.com/cloud |
| LLM7 | Current free-token tier: up to 100K tokens/day; do not assume legacy anonymous access | https://docs.llm7.io/limits |
| LongCat | Account-dependent daily token allowance | https://longcat.chat/platform/docs/ |
| Aion Labs | Daily free credits; no card for free plan. Token prices vary by model | https://www.aionlabs.ai/pricing/ and https://aionlabs.ai/docs/pricing |
| AIHubMix | Explicit GPT-OSS free ID: 10 RPM / 100 RPD | https://aihubmix.com/models/free |
| Requesty | 200 requests/day, 20/minute for new organizations on zero-priced models | https://docs.requesty.ai/features/free-models |
| OpenCode Zen | Selected promotional models only; terms/pricing can change | https://opencode.ai/docs/zen/ |
| AI/ML API | Free Gemma quickstart, up to 10 requests/hour for eligible new accounts | https://docs.aimlapi.com/quickstart/setting-up |
| Vercel AI Gateway | $5 monthly credit for eligible free accounts, a subset of models | https://vercel.com/docs/ai-gateway/pricing |
| Cerebras | **Manual only:** $5 trial / 30 days; verified payment method required | https://inference-docs.cerebras.ai/support/rate-limits |
| Alibaba Model Studio | **Manual only:** eligible Singapore model grant, up to 1M tokens / 90 days | https://www.alibabacloud.com/help/en/model-studio/model-pricing |

Free tokens, compute neurons, requests, and credits are different units; their counts are not added together. "High allowance" is a curated preference, not a guarantee that different units are directly comparable. Hugging Face is retained in the original application, but isn't advertised as a free route: the current Inference Providers pricing page says free accounts do not receive included monthly credits. GitHub Models and unverified anonymous proxies are not counted.

## One logical request

Choose **Free Max → Auto-select model**, or pin a specific `provider-id::model-id`. Free Max sends one request at a time, never a parallel broadcast. It stops at the first valid completion. Automatic routing excludes trials, missing keys, disabled providers and cooling-down routes. No multiple-account key cycling, scraping, or payment-tier fallback. A signed-in user can change the strategy, enable or disable routes, and select a maximum of 1–5 attempts. A provider refusal or unauthorized request stops the logical request rather than changing providers to bypass it.

Round-robin cursors, route settings, cooldowns, and request activity are persisted in PostgreSQL using Drizzle. Anonymous quota counters are shared across workspaces; keyed cooldowns are scoped to a secret fingerprint. `Retry-After` accepts seconds and HTTP dates. Requests have per-attempt and overall deadlines; abort signals propagate upstream. Some upstream computation may continue after a network timeout or cancellation. One logical hit does not guarantee one upstream HTTP request when fallback is used.

## Keys and billing

Add keys in **API keys** or a provider detail dialog. Nova encrypts them with AES-256-GCM; the hub exposes only a boolean connection state. Configure a strong deployment-specific `AUTH_SECRET`. Keys are never placed in localStorage or ordinary chat bodies. Use a free-only account, explicit spend limits and no automatic recharge. For metered providers, the application cannot independently verify the key's billing plan or guarantee a zero invoice. Trial models must be pinned explicitly while credit remains.

Environment-supplied keys are **opt-in**. Set the provider's environment variable from the catalog, then list its ID in `FREE_MAX_ENABLED_PROVIDERS` (comma-separated). Example: `FREE_MAX_ENABLED_PROVIDERS=groq,openrouter`. These keys are shared deployment resources. Do not enable a paid key. Cloudflare also requires `CLOUDFLARE_ACCOUNT_ID`. The two anonymous routes need no environment variables.

## Same-origin workspace API

1. `GET /api/free-max` initializes the signed browser workspace and returns its non-secret connection and routing state.
2. `POST /api/free-max/completions` with `model: "free-max"` and a `messages` array. Retain the workspace cookie. The endpoint returns the actual model, serving provider, usage, and attempt trace in an OpenAI-style non-streaming completion.
3. `POST /api/chat` with `settings.provider: "free-max"` uses the same engine and persists chat history. Free Max is a text chat route: unlike original agent providers it does not run additional tool loops or hidden model-based memory extraction. Text and Markdown file attachments are supported.

This is a private workspace endpoint, not a bearer-authenticated public OpenAI proxy. The optional Nova deployment passcode applies. The full original SDK-based chat, agents, memory, skills, tools, share links, and sandboxed code editor remain available from **Full workspace**.

## Privacy and reliability

Relevant chat history is sent to attempted providers, subject to their respective privacy policies. Model IDs and pricing are a reviewed snapshot; upstream deprecations and quota changes require catalog maintenance. No provider is described as online merely because its key has been saved. Rate limit, network, setup and upstream errors are shown rather than replaced with fabricated model replies. Real activity displays the last 100 logical requests. Prompt text and API keys are not included in routing logs.

## Streaming, thinking effort, and failure handling

Free Max replies are streamed. `runFreeMax` accepts an `onEvent` callback; when it is set the
upstream request uses `stream: true` and deltas are forwarded as they arrive. Rotation to the
next provider only happens **before** any output has been delivered. Once a provider has started
answering, the turn finishes with that provider, and an early end is explained in the reply
instead of silently switching models mid-answer. Without `onEvent` (the OpenAI-compatible
`/api/free-max/completions` endpoint) the call remains a plain JSON completion.

- **Timeouts.** 28 s to the first byte, 45 s of silence mid-stream, 170 s per turn.
- **Thinking effort.** The requested level is clamped per routed model (see
  `src/lib/reasoning.ts`). Reasoning tokens count against the output limit, so the limit is
  doubled (capped at 8,192) while a model is thinking. If a host answers 400/422 to these
  optional parameters, the request is retried once without them.
- **Usage.** `stream_options.include_usage` is only sent to providers documented to accept it;
  elsewhere token counts are estimated so activity totals stay meaningful.
- **Rollback.** A send that fails before any output (no eligible route, quota, cancellation) is
  removed again, so a retry never leaves a duplicated user message in the conversation.
- **Activity log.** A request the user cancelled is not recorded as a provider failure.
